"""Standalone CPU simulation. Trusted reference dependencies are never given to candidates."""
from pathlib import Path
import hashlib,json,os,re,sys,traceback
from cocotb_test.simulator import run
ROOT=Path(__file__).resolve().parent
OLD=Path('/mnt/oss/liuyue/opentrust_verilog_smoke_20261009/tools/iverilog')
CORE=ROOT.parent
VER=CORE/'tools/verilator'

def guard(task,code):
    text=re.sub(r'//[^\n]*|/\*[\s\S]*?\*/','',code)
    if not re.search(r'\bmodule\s+'+re.escape(task)+r'\b',text):return 'missing_module'
    if re.search(r'\b(force|release|bind|RefModule|stimulus_gen|DPI)\b|DPI-C',text):return 'forbidden_test_control'
    if any(x not in ('clog2','bits','signed','unsigned','countones') for x in re.findall(r'\$([A-Za-z_]\w*)',text)):return 'simulation_system_task'
    if any(x not in ('timescale','default_nettype') for x in re.findall(r'`([A-Za-z_]\w*)',text)):return 'preprocessor_access'
    core={'dma_write':'axi_dma_wr','udp_rx_guard':'udp_ip_rx','icache_ctrl':'ibex_icache'}[task]
    if re.findall(r'\bmodule\s+(\w+)',text)!=[task]:return 'extra_module'
    if not re.search(r'\b'+core+r'\s*(?:#\s*\(|[A-Za-z_]\w*\s*\()',text):return 'missing_upstream_core'
    return None

def grade(task,source,directory,seeds,trusted=False,project=False):
    directory=Path(directory);directory.mkdir(parents=True,exist_ok=False);source=Path(source)
    result=dict(task=task,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),trusted_reference=trusted,pass_test=False,seed_results=[])
    bad=None if trusted else guard(task,source.read_text())
    if bad:result['status']=bad
    else:
        sources=[source];includes=[]
        if (trusted or project) and task=='dma_write':sources+=[CORE/'upstream/verilog-axi/rtl/axi_dma_wr.v']
        if (trusted or project) and task=='udp_rx_guard':sources+=[CORE/'upstream/verilog-ethernet/rtl/udp_ip_rx.v']
        if (trusted or project) and task=='icache_ctrl':
            ibex=CORE/'upstream/ibex';sources=[ibex/'rtl/ibex_pkg.sv',source,ibex/'rtl/ibex_icache.sv'];includes=[ibex/'vendor/lowrisc_ip/ip/prim/rtl']
        simulator='verilator' if task=='icache_ctrl' else 'icarus'
        build=directory/'build'
        if not trusted and directory.name.endswith('_independent'):
            previous=directory.with_name(directory.name.removesuffix('_independent')+'_development')
            priorfile=previous/'score.json';program=previous/'build'/(task if simulator=='verilator' else task+'.vvp')
            if priorfile.exists() and program.exists():
                prior=json.loads(priorfile.read_text());digest=hashlib.sha256(program.read_bytes()).hexdigest()
                if prior.get('source_sha256')==result['source_sha256'] and prior.get('compiled_program_sha256')==digest:
                    build=previous/'build';result['reused_identical_compiled_program']=True
        os.environ.update(CUDA_VISIBLE_DEVICES='',VERILATOR_ROOT=str(VER/'share/verilator'),LD_LIBRARY_PATH=str(OLD/'lib'),PATH=str(CORE/'tools/bin')+':'+str(VER/'bin')+':'+str(OLD/'bin')+':'+os.environ['PATH'])
        os.environ['MAKEFLAGS']='-j2 CXX='+str(CORE/'tools/bin/g++')+' LINK='+str(CORE/'tools/bin/g++')+' AR='+str(CORE/'tools/bin/ar')
        os.environ['TMPDIR']=str(CORE/'tmp')
        for seed in seeds:
            evidence=directory/(str(seed)+'.json')
            try:
                run(simulator=simulator,verilog_sources=[str(x) for x in sources],includes=[str(x) for x in includes],toplevel=task,module='subsystem_tests',python_search=[str(ROOT)],sim_build=str(build),compile_args=['-Wno-fatal','--build-jobs','2'] if simulator=='verilator' else ['-g2012'],extra_env=dict(TEST_TASK=task,TEST_SEED=str(seed),TEST_RESULT=str(evidence)),waves=False,timescale='1ns/1ps')
                row=json.loads(evidence.read_text())
            except BaseException as exc:
                row=json.loads(evidence.read_text()) if evidence.exists() else dict(task=task,seed=seed,passed=False,error='compile_or_runtime_error',exception_type=type(exc).__name__,diagnostic=str(exc)[-2000:])
            result['seed_results'].append(row)
        result['pass_test']=all(x['passed'] for x in result['seed_results'])
        result['status']='pass' if result['pass_test'] else 'failed'
        program=build/(task if simulator=='verilator' else task+'.vvp')
        if program.exists():result['compiled_program_sha256']=hashlib.sha256(program.read_bytes()).hexdigest()
    (directory/'score.json').write_text(json.dumps(result,indent=2))
    return result

if __name__=='__main__':
    task,source,directory,seedtext,trusted=sys.argv[1:]
    r=grade(task,source,directory,[int(x) for x in seedtext.split(',')],trusted=='trusted',project=trusted=='project')
    print('SCORE_JSON '+json.dumps(r),flush=True)
