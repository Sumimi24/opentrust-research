`timescale 1ns/1ps
`default_nettype none

module dma_write(
input wire clk,
input wire rst,
input wire [15:0] desc_addr,
input wire [15:0] desc_len,
input wire [7:0] desc_tag,
input wire desc_valid,
output wire desc_ready,
input wire [31:0] s_data,
input wire [3:0] s_keep,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [15:0] status_len,
output wire [7:0] status_tag,
output wire [3:0] status_error,
output wire status_valid,
output wire [3:0] m_axi_awid,
output wire [15:0] m_axi_awaddr,
output wire [7:0] m_axi_awlen,
output wire [2:0] m_axi_awsize,
output wire [1:0] m_axi_awburst,
output wire m_axi_awlock,
output wire [3:0] m_axi_awcache,
output wire [2:0] m_axi_awprot,
output wire m_axi_awvalid,
input wire m_axi_awready,
output wire [31:0] m_axi_wdata,
output wire [3:0] m_axi_wstrb,
output wire m_axi_wlast,
output wire m_axi_wvalid,
input wire m_axi_wready,
input wire [3:0] m_axi_bid,
input wire [1:0] m_axi_bresp,
input wire m_axi_bvalid,
output wire m_axi_bready);

assign m_axi_awid = 4'd0;
assign m_axi_awsize = 3'd2;
assign m_axi_awburst = 2'b01;
assign m_axi_awlock = 1'b0;
assign m_axi_awcache = 4'd3;
assign m_axi_awprot = 3'd0;

reg active;
reg seen_slverr, seen_decerr;
reg [15:0] reg_desc_len;
reg [7:0] reg_desc_tag;
reg [15:0] bytes_left;
reg [15:0] byte_offset;
reg aw_done, w_done;
reg [3:0] b_pending;
reg [3:0] beat_count;
reg [15:0] burst_bytes;
reg [7:0] burst_beats;
reg [15:0] burst_start_offset;
reg [3:0] first_strb_mask;
reg stream_done;

wire raw_desc_ready;
wire raw_status_valid;
wire [3:0] raw_error;

assign desc_ready = raw_desc_ready && !active && !rst;
assign status_valid = raw_status_valid;
assign status_error = seen_decerr ? 4'd7 : (seen_slverr ? 4'd6 : raw_error);
assign status_len = reg_desc_len;
assign status_tag = reg_desc_tag;

always @(posedge clk) begin
    if (rst) begin
        active <= 1'b0;
        seen_slverr <= 1'b0;
        seen_decerr <= 1'b0;
        bytes_left <= 16'd0;
        byte_offset <= 16'd0;
        aw_done <= 1'b0;
        w_done <= 1'b0;
        b_pending <= 4'd0;
        beat_count <= 4'd0;
        stream_done <= 1'b0;
    end else begin
        if (raw_status_valid) begin
            active <= 1'b0;
            aw_done <= 1'b0;
            w_done <= 1'b0;
            b_pending <= 4'd0;
            beat_count <= 4'd0;
            stream_done <= 1'b0;
        end
        if (desc_valid && desc_ready) begin
            active <= 1'b1;
            seen_slverr <= 1'b0;
            seen_decerr <= 1'b0;
            reg_desc_len <= desc_len;
            reg_desc_tag <= desc_tag;
            bytes_left <= desc_len;
            byte_offset <= 16'd0;
            aw_done <= 1'b0;
            w_done <= 1'b0;
            b_pending <= 4'd0;
            beat_count <= 4'd0;
            stream_done <= 1'b0;
        end
        if (active && !aw_done && m_axi_awvalid && m_axi_awready) begin
            aw_done <= 1'b1;
            b_pending <= b_pending + 4'd1;
        end
        if (active && !w_done && m_axi_wvalid && m_axi_wready) begin
            beat_count <= beat_count + 4'd1;
            if (m_axi_wlast) begin
                w_done <= 1'b1;
                byte_offset <= byte_offset + burst_bytes;
                bytes_left <= bytes_left - burst_bytes;
                beat_count <= 4'd0;
                if (stream_done || (bytes_left == burst_bytes)) begin
                    aw_done <= 1'b0;
                    w_done <= 1'b0;
                    beat_count <= 4'd0;
                end
            end
        end
        if (active && m_axi_bvalid && m_axi_bready) begin
            if (m_axi_bresp == 2'b10) seen_slverr <= 1'b1;
            if (m_axi_bresp == 2'b11) seen_decerr <= 1'b1;
            b_pending <= b_pending - 4'd1;
        end
        if (active && s_valid && s_ready && s_last) begin
            stream_done <= 1'b1;
        end
    end
end

reg [15:0] cur_addr;
reg [1:0] align_val;
reg [15:0] max_page_bytes;
reg [15:0] eff_bytes;
reg [7:0] calc_beats;

always @(*) begin
    cur_addr = desc_addr + byte_offset;
    align_val = cur_addr[1:0];
    max_page_bytes = 16'h1000 - {12'b0, cur_addr[11:0]};
    if (bytes_left > max_page_bytes)
        eff_bytes = max_page_bytes;
    else
        eff_bytes = bytes_left;
    calc_beats = (eff_bytes + 16'd3 + {14'b0, align_val}) >> 2;
    if (calc_beats > 8'd16)
        calc_beats = 8'd16;
    burst_beats = calc_beats;
    burst_bytes = ({8'b0, calc_beats} << 2) - {14'b0, align_val};
    if (burst_bytes > eff_bytes)
        burst_bytes = eff_bytes;
    burst_start_offset = byte_offset;
    first_strb_mask = 4'hF << align_val;
end

assign m_axi_awaddr = {cur_addr[15:2], 2'b00};
assign m_axi_awlen = burst_beats - 8'd1;
assign m_axi_awvalid = active && !aw_done && (bytes_left > 16'd0);

wire w_active;
assign w_active = active && !w_done && (bytes_left > 16'd0 || beat_count > 4'd0);

assign m_axi_wdata = s_data;
assign m_axi_wvalid = w_active && s_valid && !stream_done;
assign s_ready = w_active && m_axi_wready && !stream_done;

wire is_first_beat;
assign is_first_beat = (beat_count == 4'd0);

reg [3:0] calc_wstrb;
always @(*) begin
    if (is_first_beat)
        calc_wstrb = s_keep & first_strb_mask;
    else
        calc_wstrb = s_keep;
end
assign m_axi_wstrb = calc_wstrb;

reg calc_wlast;
always @(*) begin
    if (is_first_beat)
        calc_wlast = (burst_beats == 8'd1);
    else
        calc_wlast = (beat_count == burst_beats - 4'd1);
end
assign m_axi_wlast = calc_wlast;

assign m_axi_bready = active && (b_pending > 4'd0);

axi_dma_wr #(.AXI_DATA_WIDTH(32),.AXI_ADDR_WIDTH(16),.AXI_STRB_WIDTH(4),.AXI_ID_WIDTH(4),.AXIS_DATA_WIDTH(32),.AXIS_KEEP_WIDTH(4),.LEN_WIDTH(16),.TAG_WIDTH(8),.ENABLE_UNALIGNED(1)) core(
.clk(clk),
.rst(rst),
.s_axis_write_desc_addr(desc_addr),
.s_axis_write_desc_len(desc_len),
.s_axis_write_desc_tag(desc_tag),
.s_axis_write_desc_valid(desc_valid && !active),
.s_axis_write_desc_ready(raw_desc_ready),
.m_axis_write_desc_status_len(),
.m_axis_write_desc_status_tag(),
.m_axis_write_desc_status_error(raw_error),
.m_axis_write_desc_status_valid(raw_status_valid),
.s_axis_write_data_tdata(s_data),
.s_axis_write_data_tkeep(s_keep),
.s_axis_write_data_tvalid(s_valid),
.s_axis_write_data_tready(s_ready),
.s_axis_write_data_tlast(s_last),
.s_axis_write_data_tid(8'b0),
.s_axis_write_data_tdest(8'b0),
.s_axis_write_data_tuser(1'b0),
.enable(1'b1),
.abort(1'b0),
.m_axi_awid(m_axi_awid),
.m_axi_awaddr(m_axi_awaddr),
.m_axi_awlen(m_axi_awlen),
.m_axi_awsize(m_axi_awsize),
.m_axi_awburst(m_axi_awburst),
.m_axi_awlock(m_axi_awlock),
.m_axi_awcache(m_axi_awcache),
.m_axi_awprot(),
.m_axi_awvalid(m_axi_awvalid),
.m_axi_awready(m_axi_awready),
.m_axi_wdata(m_axi_wdata),
.m_axi_wstrb(m_axi_wstrb),
.m_axi_wlast(m_axi_wlast),
.m_axi_wvalid(m_axi_wvalid),
.m_axi_wready(m_axi_wready),
.m_axi_bid(m_axi_bid),
.m_axi_bresp(m_axi_bresp),
.m_axi_bvalid(m_axi_bvalid),
.m_axi_bready(m_axi_bready));

endmodule
