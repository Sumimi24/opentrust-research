`timescale 1ns/1ps
`default_nettype none

module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

reg [7:0] buf [0:511];
reg [9:0] n;
reg [9:0] ptr;
reg [2:0] state;
reg oversize;
reg status_valid_r;
reg [3:0] status_error_r;
reg [31:0] r_src_ip;
reg [15:0] r_src_port;
reg [15:0] r_dst_port;
reg [15:0] r_payload_len;
reg [8:0] ip_sum;
reg [16:0] udp_sum;
reg [8:0] j;
reg [3:0] error_code;
reg [15:0] ip_total_length;
reg [15:0] udp_length;
reg [15:0] w16;
reg [16:0] tmp_udp;
reg [15:0] folded_ip;
reg [15:0] folded_udp;
reg [15:0] udp_cksum_field;
reg [31:0] dst_ip;
reg compute_done;

wire [15:0] parsed_length;
wire hdr_ready;
wire parse_ready;

udp_ip_rx parser_inst (
    .clk(clk),
    .rst(rst),
    .s_ip_hdr_valid(state == 3'd4),
    .s_ip_hdr_ready(hdr_ready),
    .s_eth_dest_mac(48'b0),
    .s_eth_src_mac(48'b0),
    .s_eth_type(16'h0800),
    .s_ip_version(buf[0][7:4]),
    .s_ip_ihl(buf[0][3:0]),
    .s_ip_dscp(buf[1][7:2]),
    .s_ip_ecn(buf[1][1:0]),
    .s_ip_length({buf[2], buf[3]}),
    .s_ip_identification({buf[4], buf[5]}),
    .s_ip_flags(buf[6][7:5]),
    .s_ip_fragment_offset({buf[6][4:0], buf[7]}),
    .s_ip_ttl(buf[8]),
    .s_ip_protocol(buf[9]),
    .s_ip_header_checksum({buf[10], buf[11]}),
    .s_ip_source_ip({buf[12], buf[13], buf[14], buf[15]}),
    .s_ip_dest_ip({buf[16], buf[17], buf[18], buf[19]}),
    .s_ip_payload_axis_tdata(buf[ptr]),
    .s_ip_payload_axis_tvalid(state == 3'd5),
    .s_ip_payload_axis_tready(parse_ready),
    .s_ip_payload_axis_tlast(ptr == ip_total_length - 10'd1),
    .s_ip_payload_axis_tuser(1'b0),
    .m_udp_hdr_ready(1'b1),
    .m_ip_source_ip(),
    .m_udp_source_port(),
    .m_udp_dest_port(),
    .m_udp_length(parsed_length),
    .m_udp_payload_axis_tdata(m_data),
    .m_udp_payload_axis_tvalid(m_valid),
    .m_udp_payload_axis_tready(m_ready),
    .m_udp_payload_axis_tlast(m_last)
);

assign s_ready = !rst && (state == 3'd0);
assign status_valid = status_valid_r;
assign status_error = status_error_r;
assign m_src_ip = r_src_ip;
assign m_src_port = r_src_port;
assign m_dst_port = r_dst_port;
assign m_payload_len = r_payload_len;

always @(posedge clk) begin
    if (rst) begin
        state <= 3'd0;
        n <= 10'd0;
        ptr <= 10'd0;
        oversize <= 1'b0;
        status_valid_r <= 1'b0;
        status_error_r <= 4'd0;
        r_src_ip <= 32'd0;
        r_src_port <= 16'd0;
        r_dst_port <= 16'd0;
        r_payload_len <= 16'd0;
        ip_sum <= 9'd0;
        udp_sum <= 17'd0;
        j <= 9'd0;
        error_code <= 4'd0;
        compute_done <= 1'b0;
    end else begin
        status_valid_r <= 1'b0;
        case (state)
            3'd0: begin
                n <= 10'd0;
                oversize <= 1'b0;
                if (s_valid && s_ready) begin
                    if (n < 10'd512) buf[n] <= s_data;
                    else oversize <= 1'b1;
                    n <= n + 10'd1;
                    if (s_last) state <= 3'd1;
                end
            end
            3'd1: begin
                ip_sum <= 9'd0;
                udp_sum <= 17'd0;
                j <= 9'd0;
                error_code <= 4'd0;
                compute_done <= 1'b0;
                state <= 3'd2;
            end
            3'd2: begin
                if (!compute_done) begin
                    if (j == 9'd0) begin
                        if (oversize || n < 10'd28 || n > 10'd512) error_code <= 4'd1;
                        else if (buf[0][7:4] != 4'd4 || buf[0][3:0] != 4'd5 || buf[9] != 8'd17 || (buf[6] & 8'h3F) != 8'd0 || buf[7] != 8'd0) error_code <= 4'd1;
                        j <= 9'd1;
                    end else if (j == 9'd1) begin
                        ip_total_length <= {buf[2], buf[3]};
                        udp_length <= {buf[24], buf[25]};
                        udp_cksum_field <= {buf[26], buf[27]};
                        dst_ip <= {buf[16], buf[17], buf[18], buf[19]};
                        if (error_code == 4'd0) begin
                            if ({buf[2], buf[3]} != n || {buf[24], buf[25]} != {buf[2], buf[3]} - 16'd20) error_code <= 4'd2;
                            else if (({buf[24], buf[25]} - 16'd8) < 16'd1 || ({buf[24], buf[25]} - 16'd8) > 16'd256) error_code <= 4'd2;
                        end
                        j <= 9'd2;
                    end else if (j >= 9'd2 && j <= 9'd11) begin
                        if (error_code == 4'd0) begin
                            w16 <= {buf[(j-9'd2)*2], buf[(j-9'd2)*2+9'd1]};
                            ip_sum <= ip_sum + w16[15:8] + w16[7:0];
                        end
                        j <= j + 9'd1;
                    end else if (j == 9'd12) begin
                        if (error_code == 4'd0) begin
                            folded_ip <= ip_sum[7:0] + ip_sum[15:8] + ip_sum[8];
                            if ((ip_sum[7:0] + ip_sum[15:8] + ip_sum[8]) != 16'hFFFF) error_code <= 4'd3;
                        end
                        j <= 9'd13;
                    end else if (j == 9'd13) begin
                        if (error_code == 4'd0 && udp_cksum_field != 16'd0) begin
                            udp_sum <= 17'd0;
                            j <= 9'd14;
                        end else begin
                            compute_done <= 1'b1;
                        end
                    end else if (j >= 9'd14 && j <= 9'd17) begin
                        w16 <= {buf[12+(j-9'd14)*2], buf[13+(j-9'd14)*2]};
                        udp_sum <= udp_sum + 17'(w16);
                        j <= j + 9'd1;
                    end else if (j == 9'd18) begin
                        udp_sum <= udp_sum + 17'd17 + 17'(udp_length);
                        j <= 9'd19;
                    end else if (j >= 9'd19 && j <= 9'd274) begin
                        if (error_code == 4'd0) begin
                            tmp_udp <= udp_sum;
                            if ((j - 9'd19) * 2 < n - 10'd20) begin
                                tmp_udp <= tmp_udp + 17'({buf[20+(j-9'd19)*2], buf[21+(j-9'd19)*2]});
                            end else if ((j - 9'd19) * 2 == n - 10'd20) begin
                                tmp_udp <= tmp_udp + 17'({buf[20+(j-9'd19)*2], 8'd0});
                            end
                            udp_sum <= tmp_udp;
                        end
                        if (j == 9'd274) compute_done <= 1'b1;
                        j <= j + 9'd1;
                    end
                end else begin
                    if (error_code == 4'd0 && udp_cksum_field != 16'd0) begin
                        folded_udp <= udp_sum[15:0] + 16'(udp_sum[16]);
                        if ((udp_sum[15:0] + 16'(udp_sum[16])) != 16'hFFFF) error_code <= 4'd4;
                    end
                    if (error_code == 4'd0) begin
                        if (dst_ip != 32'h0A000002 || {buf[22], buf[23]} != 16'd9000) error_code <= 4'd5;
                    end
                    state <= 3'd3;
                end
            end
            3'd3: begin
                status_valid_r <= 1'b1;
                status_error_r <= error_code;
                if (error_code == 4'd0) begin
                    state <= 3'd4;
                    r_src_ip <= {buf[12], buf[13], buf[14], buf[15]};
                    r_src_port <= {buf[20], buf[21]};
                    r_dst_port <= {buf[22], buf[23]};
                    r_payload_len <= udp_length - 16'd8;
                end else begin
                    state <= 3'd0;
                    n <= 10'd0;
                end
            end
            3'd4: begin
                if (hdr_ready) begin
                    state <= 3'd5;
                    ptr <= 10'd28;
                end
            end
            3'd5: begin
                if (parse_ready) begin
                    if (ptr == ip_total_length - 10'd1) state <= 3'd6;
                    else ptr <= ptr + 10'd1;
                end
            end
            3'd6: begin
                if (m_valid && m_ready && m_last) begin
                    state <= 3'd0;
                    n <= 10'd0;
                end
            end
            default: state <= 3'd0;
        endcase
    end
end

endmodule
