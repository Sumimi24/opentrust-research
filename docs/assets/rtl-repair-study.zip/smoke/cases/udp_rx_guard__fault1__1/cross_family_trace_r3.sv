`timescale 1ns/1ps
`default_nettype none

module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

reg [7:0] buf0 [0:511];
reg [9:0] n;
reg [9:0] ptr;
reg [2:0] state;
reg oversize;
reg status_valid_r;
reg [3:0] status_error_r;
reg [31:0] r_src_ip;
reg [15:0] r_src_port;
reg [15:0] r_dst_port;
reg [15:0] r_payload_len;

reg [3:0] error_code;
reg [15:0] ip_total_length;
reg [15:0] udp_length;
reg [31:0] dst_ip;

reg [16:0] ip_sum;
reg [16:0] udp_sum;
reg [8:0] j;
reg compute_done;

wire [15:0] parsed_length;
wire hdr_ready;
wire parse_ready;

wire [3:0] s_ip_version;
wire [3:0] s_ip_ihl;
wire [5:0] s_ip_dscp;
wire [1:0] s_ip_ecn;
wire [15:0] s_ip_length;
wire [15:0] s_ip_identification;
wire [2:0] s_ip_flags;
wire [12:0] s_ip_fragment_offset;
wire [7:0] s_ip_ttl;
wire [7:0] s_ip_protocol;
wire [15:0] s_ip_header_checksum;
wire [31:0] s_ip_source_ip;
wire [31:0] s_ip_dest_ip;
wire [7:0] s_ip_payload_axis_tdata;
wire s_ip_payload_axis_tvalid;
wire s_ip_payload_axis_tlast;

assign s_ip_version = buf0[0][7:4];
assign s_ip_ihl = buf0[0][3:0];
assign s_ip_dscp = buf0[1][7:2];
assign s_ip_ecn = buf0[1][1:0];
assign s_ip_length = {buf0[2], buf0[3]};
assign s_ip_identification = {buf0[4], buf0[5]};
assign s_ip_flags = buf0[6][7:5];
assign s_ip_fragment_offset = {buf0[6][4:0], buf0[7]};
assign s_ip_ttl = buf0[8];
assign s_ip_protocol = buf0[9];
assign s_ip_header_checksum = {buf0[10], buf0[11]};
assign s_ip_source_ip = {buf0[12], buf0[13], buf0[14], buf0[15]};
assign s_ip_dest_ip = {buf0[16], buf0[17], buf0[18], buf0[19]};
assign s_ip_payload_axis_tdata = buf0[ptr] ^ 8'h01;
assign s_ip_payload_axis_tvalid = (state == 3'd5);
assign s_ip_payload_axis_tlast = (ptr == ip_total_length - 10'd1);

udp_ip_rx parser_inst (
    .clk(clk),
    .rst(rst),
    .s_ip_hdr_valid(state == 3'd4),
    .s_ip_hdr_ready(hdr_ready),
    .s_eth_dest_mac(48'b0),
    .s_eth_src_mac(48'b0),
    .s_eth_type(16'h0800),
    .s_ip_version(s_ip_version),
    .s_ip_ihl(s_ip_ihl),
    .s_ip_dscp(s_ip_dscp),
    .s_ip_ecn(s_ip_ecn),
    .s_ip_length(s_ip_length),
    .s_ip_identification(s_ip_identification),
    .s_ip_flags(s_ip_flags),
    .s_ip_fragment_offset(s_ip_fragment_offset),
    .s_ip_ttl(s_ip_ttl),
    .s_ip_protocol(s_ip_protocol),
    .s_ip_header_checksum(s_ip_header_checksum),
    .s_ip_source_ip(s_ip_source_ip),
    .s_ip_dest_ip(s_ip_dest_ip),
    .s_ip_payload_axis_tdata(s_ip_payload_axis_tdata),
    .s_ip_payload_axis_tvalid(s_ip_payload_axis_tvalid),
    .s_ip_payload_axis_tready(parse_ready),
    .s_ip_payload_axis_tlast(s_ip_payload_axis_tlast),
    .s_ip_payload_axis_tuser(1'b0),
    .m_udp_hdr_ready(1'b1),
    .m_ip_source_ip(),
    .m_udp_source_port(),
    .m_udp_dest_port(),
    .m_udp_length(parsed_length),
    .m_udp_payload_axis_tdata(m_data),
    .m_udp_payload_axis_tvalid(m_valid),
    .m_udp_payload_axis_tready(m_ready),
    .m_udp_payload_axis_tlast(m_last)
);

assign s_ready = !rst && (state == 3'd0);
assign status_valid = status_valid_r;
assign status_error = status_error_r;
assign m_src_ip = r_src_ip;
assign m_src_port = r_src_port;
assign m_dst_port = r_dst_port;
assign m_payload_len = r_payload_len;

function automatic [15:0] fold_func(input [16:0] val);
    reg [16:0] v;
    begin
        v = val[15:0] + {15'd0, val[16]};
        v = v[15:0] + {15'd0, v[16]};
        fold_func = v[15:0];
    end
endfunction

always @(posedge clk) begin
    if (rst) begin
        state <= 3'd0;
        n <= 10'd0;
        ptr <= 10'd0;
        oversize <= 1'b0;
        status_valid_r <= 1'b0;
        status_error_r <= 4'd0;
        r_src_ip <= 32'd0;
        r_src_port <= 16'd0;
        r_dst_port <= 16'd0;
        r_payload_len <= 16'd0;
        error_code <= 4'd0;
        ip_total_length <= 16'd0;
        udp_length <= 16'd0;
        dst_ip <= 32'd0;
        ip_sum <= 17'd0;
        udp_sum <= 17'd0;
        j <= 9'd0;
        compute_done <= 1'b0;
    end else begin
        status_valid_r <= 1'b0;
        case (state)
            3'd0: begin
                if (s_valid && s_ready) begin
                    if (n < 10'd512) buf0[n] <= s_data;
                    else oversize <= 1'b1;
                    n <= n + 10'd1;
                    if (s_last) begin
                        state <= 3'd1;
                        ip_sum <= 17'd0;
                        udp_sum <= 17'd0;
                        j <= 9'd0;
                        error_code <= 4'd0;
                        compute_done <= 1'b0;
                    end
                end
            end
            3'd1: begin
                if (!compute_done) begin
                    if (j == 9'd0) begin
                        if (oversize || n < 10'd28 || n > 10'd512) error_code <= 4'd1;
                        else if (buf0[0][7:4] != 4'd4 || buf0[0][3:0] != 4'd5 || buf0[9] != 8'd17 || (buf0[6] & 8'h3F) != 8'd0 || buf0[7] != 8'd0) error_code <= 4'd1;
                        j <= 9'd1;
                    end else if (j == 9'd1) begin
                        ip_total_length <= {buf0[2], buf0[3]};
                        udp_length <= {buf0[24], buf0[25]};
                        dst_ip <= {buf0[16], buf0[17], buf0[18], buf0[19]};
                        if (error_code == 4'd0) begin
                            if ({buf0[2], buf0[3]} != n || {buf0[24], buf0[25]} != ({buf0[2], buf0[3]} - 16'd20)) error_code <= 4'd2;
                            else if (({buf0[24], buf0[25]} - 16'd8) < 16'd1 || ({buf0[24], buf0[25]} - 16'd8) > 16'd256) error_code <= 4'd2;
                        end
                        j <= 9'd2;
                    end else if (j >= 9'd2 && j < 9'd12) begin
                        if (error_code == 4'd0) begin
                            ip_sum <= ip_sum + {1'b0, buf0[(j-9'd2)*2], buf0[(j-9'd2)*2 + 9'd1]};
                        end
                        j <= j + 9'd1;
                    end else if (j == 9'd12) begin
                        if (error_code == 4'd0) begin
                            if (fold_func(ip_sum) != 16'hFFFF) error_code <= 4'd3;
                        end
                        if ({buf0[26], buf0[27]} == 16'd0) begin
                            compute_done <= 1'b1;
                        end
                        j <= 9'd13;
                    end else if (j >= 9'd13 && j < 9'd17) begin
                        if (error_code == 4'd0) begin
                            udp_sum <= udp_sum + {1'b0, buf0[12+(j-9'd13)*2], buf0[13+(j-9'd13)*2]};
                        end
                        j <= j + 9'd1;
                    end else if (j == 9'd17) begin
                        if (error_code == 4'd0) begin
                            udp_sum <= udp_sum + 17'd17 + {1'b0, udp_length};
                        end
                        j <= 9'd18;
                    end else if (j >= 9'd18 && j <= 9'd274) begin
                        if (error_code == 4'd0 && {buf0[26], buf0[27]} != 16'd0) begin
                            if ((j - 9'd18) * 2 + 20 < n) begin
                                udp_sum <= udp_sum + {1'b0, buf0[20+(j-9'd18)*2], buf0[21+(j-9'd18)*2]};
                            end else if ((j - 9'd18) * 2 + 20 == n - 10'd1) begin
                                udp_sum <= udp_sum + {1'b0, buf0[20+(j-9'd18)*2], 8'd0};
                            end
                        end
                        if (j == 9'd274) compute_done <= 1'b1;
                        j <= j + 9'd1;
                    end
                end else begin
                    if (error_code == 4'd0) begin
                        if ({buf0[26], buf0[27]} != 16'd0 && fold_func(udp_sum) != 16'hFFFF) error_code <= 4'd4;
                        if (dst_ip != 32'h0A000002 || {buf0[22], buf0[23]} != 16'd9000) error_code <= 4'd5;
                    end
                    state <= 3'd2;
                end
            end
            3'd2: begin
                status_valid_r <= 1'b1;
                status_error_r <= error_code;
                if (error_code == 4'd0) begin
                    state <= 3'd3;
                    r_src_ip <= {buf0[12], buf0[13], buf0[14], buf0[15]};
                    r_src_port <= {buf0[20], buf0[21]};
                    r_dst_port <= {buf0[22], buf0[23]};
                    r_payload_len <= udp_length - 16'd8;
                end else begin
                    state <= 3'd0;
                    n <= 10'd0;
                end
            end
            3'd3: begin
                state <= 3'd4;
                ptr <= 10'd28;
            end
            3'd4: begin
                if (hdr_ready) begin
                    state <= 3'd5;
                end
            end
            3'd5: begin
                if (parse_ready) begin
                    if (ptr == ip_total_length - 10'd1) state <= 3'd6;
                    else ptr <= ptr + 10'd1;
                end
            end
            3'd6: begin
                if (m_valid && m_ready && m_last) begin
                    state <= 3'd0;
                    n <= 10'd0;
                end
            end
            default: state <= 3'd0;
        endcase
    end
end

endmodule
