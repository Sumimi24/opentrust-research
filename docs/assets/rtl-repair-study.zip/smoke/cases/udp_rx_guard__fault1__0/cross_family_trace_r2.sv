module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

reg [7:0] bytes[0:511];
reg [9:0] n_reg;
reg oversize_reg;
reg [9:0] ptr_reg;
reg [2:0] state_reg;

reg status_valid_reg;
reg [3:0] status_error_reg;

localparam [2:0]
    STATE_RECV   = 3'd0,
    STATE_STATUS = 3'd1,
    STATE_HDR    = 3'd2,
    STATE_PAY    = 3'd3,
    STATE_DRAIN  = 3'd4;

assign s_ready = !rst && (state_reg == STATE_RECV);

function automatic [15:0] get_word16;
    input integer offset;
    begin
        get_word16 = {bytes[offset], bytes[offset+1]};
    end
endfunction

function automatic [31:0] fold_once;
    input [31:0] value;
    reg [31:0] t;
    begin
        t = (value[15:0] + value[31:16]);
        fold_once = t;
    end
endfunction

reg [3:0] error_code_comb;
reg [15:0] ip_len_comb;
reg [15:0] udp_len_comb;
reg [31:0] ip_sum_comb;
reg [31:0] udp_sum_comb;
integer j;

always @* begin
    ip_len_comb = get_word16(2);
    udp_len_comb = get_word16(24);
    ip_sum_comb = 0;
    udp_sum_comb = 0;
    error_code_comb = 0;

    if (n_reg < 10'd28 || oversize_reg || bytes[0][7:4] != 4'd4 || bytes[0][3:0] != 4'd5 || bytes[9] != 8'd17 || bytes[6][5] != 1'b0 || bytes[6][4:0] != 5'd0 || bytes[7] != 8'd0) begin
        error_code_comb = 4'd1;
    end else if (ip_len_comb != n_reg || udp_len_comb != (ip_len_comb - 16'd20) || udp_len_comb < 16'd9 || udp_len_comb > 16'd264) begin
        error_code_comb = 4'd2;
    end else begin
        for (j = 0; j < 20; j = j + 2) begin
            ip_sum_comb = ip_sum_comb + get_word16(j);
        end
        ip_sum_comb = fold_once(ip_sum_comb);
        ip_sum_comb = fold_once(ip_sum_comb);
        if (ip_sum_comb[15:0] != 16'hffff) begin
            error_code_comb = 4'd3;
        end else begin
            udp_sum_comb = 0;
            udp_sum_comb = udp_sum_comb + get_word16(12);
            udp_sum_comb = udp_sum_comb + get_word16(14);
            udp_sum_comb = udp_sum_comb + get_word16(16);
            udp_sum_comb = udp_sum_comb + get_word16(18);
            udp_sum_comb = udp_sum_comb + 16'd17;
            udp_sum_comb = udp_sum_comb + udp_len_comb;
            for (j = 20; j < 512; j = j + 2) begin
                if (j < n_reg) begin
                    udp_sum_comb = udp_sum_comb + {bytes[j], ((j+1) < n_reg) ? bytes[j+1] : 8'h00};
                end
            end
            udp_sum_comb = fold_once(udp_sum_comb);
            udp_sum_comb = fold_once(udp_sum_comb);
            if (get_word16(26) != 16'd0 && udp_sum_comb[15:0] != 16'hffff) begin
                error_code_comb = 4'd4;
            end else if ({bytes[16], bytes[17], bytes[18], bytes[19]} != 32'h0a000002 || get_word16(22) != 16'd9000) begin
                error_code_comb = 4'd5;
            end
        end
    end
end

reg parser_hdr_valid_reg;
wire parser_hdr_ready;

wire [31:0] parser_m_src_ip;
wire [15:0] parser_m_src_port;
wire [15:0] parser_m_dst_port;
wire [15:0] parser_m_udp_length;

wire [7:0] parser_m_data;
wire parser_m_valid;
wire parser_m_last;

wire parser_payload_valid = (state_reg == STATE_PAY);
wire parser_payload_ready;
wire parser_payload_last = (ptr_reg == n_reg-1);

assign m_data = parser_m_data;
assign m_valid = parser_m_valid;
assign m_last = parser_m_last;
assign m_src_ip = parser_m_src_ip;
assign m_src_port = parser_m_src_port;
assign m_dst_port = parser_m_dst_port;
assign m_payload_len = parser_m_udp_length - 16'd8;

assign status_valid = status_valid_reg;
assign status_error = status_error_reg;

always @(posedge clk) begin
    if (rst) begin
        n_reg <= 10'd0;
        oversize_reg <= 1'b0;
        ptr_reg <= 10'd20;
        state_reg <= STATE_RECV;
        status_valid_reg <= 1'b0;
        status_error_reg <= 4'd0;
        parser_hdr_valid_reg <= 1'b0;
    end else begin
        status_valid_reg <= 1'b0;

        if (parser_hdr_valid_reg && parser_hdr_ready) begin
            parser_hdr_valid_reg <= 1'b0;
        end

        case (state_reg)
            STATE_RECV: begin
                if (s_valid && s_ready) begin
                    if (!oversize_reg && n_reg < 10'd512) begin
                        bytes[n_reg] <= s_data;
                    end

                    if (!oversize_reg) begin
                        if (n_reg == 10'd511) begin
                            oversize_reg <= 1'b1;
                        end else begin
                            n_reg <= n_reg + 10'd1;
                        end
                    end

                    if (s_last) begin
                        state_reg <= STATE_STATUS;
                    end
                end
            end

            STATE_STATUS: begin
                status_valid_reg <= 1'b1;
                status_error_reg <= error_code_comb;
                if (error_code_comb == 4'd0) begin
                    ptr_reg <= 10'd20;
                    parser_hdr_valid_reg <= 1'b1;
                    state_reg <= STATE_HDR;
                end else begin
                    n_reg <= 10'd0;
                    oversize_reg <= 1'b0;
                    ptr_reg <= 10'd20;
                    state_reg <= STATE_RECV;
                end
            end

            STATE_HDR: begin
                if (parser_hdr_valid_reg && parser_hdr_ready) begin
                    state_reg <= STATE_PAY;
                end
            end

            STATE_PAY: begin
                if (parser_payload_valid && parser_payload_ready) begin
                    if (ptr_reg == n_reg-1) begin
                        state_reg <= STATE_DRAIN;
                    end else begin
                        ptr_reg <= ptr_reg + 10'd1;
                    end
                end
            end

            STATE_DRAIN: begin
                if (parser_m_valid && m_ready && parser_m_last) begin
                    n_reg <= 10'd0;
                    oversize_reg <= 1'b0;
                    ptr_reg <= 10'd20;
                    state_reg <= STATE_RECV;
                end
            end

            default: begin
                n_reg <= 10'd0;
                oversize_reg <= 1'b0;
                ptr_reg <= 10'd20;
                state_reg <= STATE_RECV;
                parser_hdr_valid_reg <= 1'b0;
            end
        endcase
    end
end

udp_ip_rx parser(
    .clk(clk),
    .rst(rst),
    .s_ip_hdr_valid(parser_hdr_valid_reg),
    .s_ip_hdr_ready(parser_hdr_ready),
    .s_eth_dest_mac(48'd0),
    .s_eth_src_mac(48'd0),
    .s_eth_type(16'h0800),
    .s_ip_version(bytes[0][7:4]),
    .s_ip_ihl(bytes[0][3:0]),
    .s_ip_dscp(bytes[1][7:2]),
    .s_ip_ecn(bytes[1][1:0]),
    .s_ip_length({bytes[2], bytes[3]}),
    .s_ip_identification({bytes[4], bytes[5]}),
    .s_ip_flags(bytes[6][7:5]),
    .s_ip_fragment_offset({bytes[6][4:0], bytes[7]}),
    .s_ip_ttl(bytes[8]),
    .s_ip_protocol(bytes[9]),
    .s_ip_header_checksum({bytes[10], bytes[11]}),
    .s_ip_source_ip({bytes[12], bytes[13], bytes[14], bytes[15]}),
    .s_ip_dest_ip({bytes[16], bytes[17], bytes[18], bytes[19]}),
    .s_ip_payload_axis_tdata(bytes[ptr_reg]),
    .s_ip_payload_axis_tvalid(parser_payload_valid),
    .s_ip_payload_axis_tready(parser_payload_ready),
    .s_ip_payload_axis_tlast(parser_payload_last),
    .s_ip_payload_axis_tuser(1'b0),
    .m_udp_hdr_ready(1'b1),
    .m_ip_source_ip(parser_m_src_ip),
    .m_udp_source_port(parser_m_src_port),
    .m_udp_dest_port(parser_m_dst_port),
    .m_udp_length(parser_m_udp_length),
    .m_udp_payload_axis_tdata(parser_m_data),
    .m_udp_payload_axis_tvalid(parser_m_valid),
    .m_udp_payload_axis_tready(m_ready),
    .m_udp_payload_axis_tlast(parser_m_last)
);

endmodule
