module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

reg [7:0] bytes[0:511];
reg [9:0] n;
reg [9:0] ptr;
reg [2:0] state;
reg status_valid_reg;
reg [3:0] status_error_reg;
reg [16:0] ip_sum;
reg [17:0] udp_sum;
reg [15:0] ip_len;
reg [15:0] udp_len;
reg [3:0] error_code;
reg [9:0] j;
reg [9:0] udp_payload_len;
reg [15:0] parsed_length;
reg [31:0] m_src_ip_reg;
reg [15:0] m_src_port_reg;
reg [15:0] m_dst_port_reg;
reg [15:0] m_payload_len_reg;
reg [7:0] m_data_reg;
reg m_valid_reg;
reg m_last_reg;
reg hdr_ready;
reg parse_ready;
reg [9:0] status_cnt;
reg [12:0] drain_cnt;
reg [3:0] ready_cnt;
reg output_active;

wire [15:0] word16_ip [0:9];
wire [15:0] word16_udp_hdr;
wire [15:0] word16_udp_len;

assign word16_ip[0] = {bytes[0], bytes[1]};
assign word16_ip[1] = {bytes[2], bytes[3]};
assign word16_ip[2] = {bytes[4], bytes[5]};
assign word16_ip[3] = {bytes[6], bytes[7]};
assign word16_ip[4] = {bytes[8], bytes[9]};
assign word16_ip[5] = {bytes[10], bytes[11]};
assign word16_ip[6] = {bytes[12], bytes[13]};
assign word16_ip[7] = {bytes[14], bytes[15]};
assign word16_ip[8] = {bytes[16], bytes[17]};
assign word16_ip[9] = {bytes[18], bytes[19]};

assign word16_udp_hdr = {bytes[20], bytes[21]};
assign word16_udp_len = {bytes[24], bytes[25]};

function automatic [16:0] fold_sum(input [17:0] value);
    reg [17:0] v;
    begin
        v = value[15:0] + value[17:16];
        fold_sum = v[15:0] + v[17:16];
    end
endfunction

function automatic [16:0] fold32(input [31:0] value);
    reg [16:0] v;
    begin
        v = value[31:16] + value[15:0];
        fold32 = v[15:0] + v[16];
    end
endfunction

assign s_ready = !rst && ((state == 3'd0) || (state == 3'd4 && !output_active)) && !(n >= 512 && state == 3'd0);
assign status_valid = status_valid_reg;
assign status_error = status_error_reg;
assign m_data = m_data_reg;
assign m_valid = m_valid_reg;
assign m_last = m_last_reg;
assign m_src_ip = m_src_ip_reg;
assign m_src_port = m_src_port_reg;
assign m_dst_port = m_dst_port_reg;
assign m_payload_len = m_payload_len_reg;

always @(posedge clk) begin
    if (rst) begin
        state <= 3'd0;
        n <= 10'd0;
        ptr <= 10'd20;
        status_valid_reg <= 1'b0;
        status_error_reg <= 4'd0;
        ip_sum <= 17'd0;
        udp_sum <= 18'd0;
        ip_len <= 16'd0;
        udp_len <= 16'd0;
        error_code <= 4'd0;
        j <= 10'd0;
        udp_payload_len <= 10'd0;
        parsed_length <= 16'd0;
        m_src_ip_reg <= 32'd0;
        m_src_port_reg <= 16'd0;
        m_dst_port_reg <= 16'd0;
        m_payload_len_reg <= 16'd0;
        m_data_reg <= 8'd0;
        m_valid_reg <= 1'b0;
        m_last_reg <= 1'b0;
        hdr_ready <= 1'b0;
        parse_ready <= 1'b0;
        status_cnt <= 10'd0;
        drain_cnt <= 13'd0;
        ready_cnt <= 4'd0;
        output_active <= 1'b0;
    end else begin
        status_valid_reg <= 1'b0;
        hdr_ready <= 1'b0;
        parse_ready <= 1'b0;
        
        if (m_ready) begin
            ready_cnt <= 4'd0;
        end else if (ready_cnt < 4'd15) begin
            ready_cnt <= ready_cnt + 4'd1;
        end
        
        case (state)
            3'd0: begin
                m_valid_reg <= 1'b0;
                m_last_reg <= 1'b0;
                output_active <= 1'b0;
                drain_cnt <= 13'd0;
                status_cnt <= 10'd0;
                
                if (s_valid && s_ready) begin
                    if (n < 10'd512) begin
                        bytes[n] <= s_data;
                    end
                    n <= n + 10'd1;
                    if (s_last) begin
                        state <= 3'd1;
                    end
                end
            end
            
            3'd1: begin
                ip_len <= word16_ip[1];
                udp_len <= word16_udp_len;
                udp_payload_len <= (word16_udp_len > 16'd8) ? (word16_udp_len - 16'd8) : 16'd0;
                
                error_code <= 4'd0;
                
                if (n < 10'd28 || n > 10'd512) begin
                    error_code <= 4'd1;
                end else if (bytes[0][7:4] != 4'd4 || bytes[0][3:0] != 4'd5) begin
                    error_code <= 4'd1;
                end else if (bytes[9] != 8'd17) begin
                    error_code <= 4'd1;
                end else if (bytes[6][5] != 1'b0 || bytes[6][6] != 1'b0 || bytes[7] != 8'd0 || bytes[6][4:0] != 5'd0) begin
                    error_code <= 4'd1;
                end else begin
                    ip_sum <= 17'd0;
                    for (j = 0; j < 10; j = j + 1) begin
                        ip_sum <= ip_sum + {1'b0, word16_ip[j]};
                    end
                    
                    if (fold_sum(ip_sum) != 17'h0FFFF) begin
                        error_code <= 4'd3;
                    end else begin
                        if (word16_ip[1] != n[15:0]) begin
                            error_code <= 4'd2;
                        end else if (word16_udp_len != word16_ip[1] - 16'd20) begin
                            error_code <= 4'd2;
                        end else if (udp_payload_len < 10'd1 || udp_payload_len > 10'd256) begin
                            error_code <= 4'd2;
                        end else begin
                            udp_sum <= 18'd0;
                            
                            udp_sum <= udp_sum + {2'b0, word16_ip[6]};
                            udp_sum <= udp_sum + {2'b0, word16_ip[7]};
                            udp_sum <= udp_sum + {2'b0, word16_ip[8]};
                            udp_sum <= udp_sum + {2'b0, word16_ip[9]};
                            udp_sum <= udp_sum + {2'b0, 8'd0, 8'd17};
                            udp_sum <= udp_sum + {2'b0, word16_udp_len};
                            
                            for (j = 10'd20; j < n; j = j + 10'd2) begin
                                if (j + 1 < n) begin
                                    udp_sum <= udp_sum + {2'b0, bytes[j], bytes[j+1]};
                                end else begin
                                    udp_sum <= udp_sum + {2'b0, bytes[j], 8'd0};
                                end
                            end
                            
                            if (word16_udp_hdr[1] != 0 && fold32(udp_sum) != 17'h0FFFF) begin
                                error_code <= 4'd4;
                            end else if ({bytes[16], bytes[17], bytes[18], bytes[19]} != 32'h0A000002 || 
                                       {bytes[22], bytes[23]} != 16'd9000) begin
                                error_code <= 4'd5;
                            end else begin
                                error_code <= 4'd0;
                            end
                        end
                    end
                end
                
                state <= 3'd2;
            end
            
            3'd2: begin
                status_valid_reg <= 1'b1;
                status_error_reg <= error_code;
                status_cnt <= 10'd0;
                
                if (error_code == 4'd0) begin
                    m_src_ip_reg <= {bytes[12], bytes[13], bytes[14], bytes[15]};
                    m_src_port_reg <= {bytes[20], bytes[21]};
                    m_dst_port_reg <= {bytes[22], bytes[23]};
                    m_payload_len_reg <= udp_payload_len[15:0];
                    parsed_length <= udp_len;
                    ptr <= 10'd28;
                    output_active <= 1'b1;
                    state <= 3'd3;
                end else begin
                    state <= 3'd0;
                    n <= 10'd0;
                end
            end
            
            3'd3: begin
                status_cnt <= status_cnt + 10'd1;
                
                if (m_ready || !m_valid_reg) begin
                    if (ptr < n) begin
                        m_data_reg <= bytes[ptr];
                        m_valid_reg <= 1'b1;
                        if (ptr == n - 10'd1) begin
                            m_last_reg <= 1'b1;
                        end else begin
                            m_last_reg <= 1'b0;
                        end
                        ptr <= ptr + 10'd1;
                    end else begin
                        m_valid_reg <= 1'b0;
                        m_last_reg <= 1'b0;
                        if (m_last_reg && !m_valid_reg) begin
                            state <= 3'd4;
                        end
                    end
                end
                
                if (status_cnt >= 10'd1023) begin
                    state <= 3'd4;
                end
            end
            
            3'd4: begin
                m_valid_reg <= 1'b0;
                
                if (m_last_reg && m_valid_reg && m_ready) begin
                    m_last_reg <= 1'b0;
                end
                
                drain_cnt <= drain_cnt + 13'd1;
                
                if (!output_active || (drain_cnt >= 13'd4095)) begin
                    state <= 3'd0;
                    n <= 10'd0;
                    output_active <= 1'b0;
                end
            end
            
            default: begin
                state <= 3'd0;
                n <= 10'd0;
                ptr <= 10'd20;
                status_valid_reg <= 1'b0;
                status_error_reg <= 4'd0;
                m_valid_reg <= 1'b0;
                m_last_reg <= 1'b0;
                output_active <= 1'b0;
            end
        endcase
    end
end

udp_ip_rx parser(
    .clk(clk),
    .rst(rst),
    .s_ip_hdr_valid(state == 3'd2 && error_code == 4'd0),
    .s_ip_hdr_ready(hdr_ready),
    .s_eth_dest_mac(48'b0),
    .s_eth_src_mac(48'b0),
    .s_eth_type(16'h0800),
    .s_ip_version(bytes[0][7:4]),
    .s_ip_ihl(bytes[0][3:0]),
    .s_ip_dscp(bytes[1][7:2]),
    .s_ip_ecn(bytes[1][1:0]),
    .s_ip_length({bytes[2], bytes[3]}),
    .s_ip_identification({bytes[4], bytes[5]}),
    .s_ip_flags(bytes[6][7:5]),
    .s_ip_fragment_offset({bytes[6][4:0], bytes[7]}),
    .s_ip_ttl(bytes[8]),
    .s_ip_protocol(bytes[9]),
    .s_ip_header_checksum({bytes[10], bytes[11]}),
    .s_ip_source_ip({bytes[12], bytes[13], bytes[14], bytes[15]}),
    .s_ip_dest_ip({bytes[16], bytes[17], bytes[18], bytes[19]}),
    .s_ip_payload_axis_tdata((ptr < n) ? bytes[ptr] : 8'd0),
    .s_ip_payload_axis_tvalid(state == 3'd3 && ptr >= 10'd20 && ptr < n),
    .s_ip_payload_axis_tready(parse_ready),
    .s_ip_payload_axis_tlast(ptr == n - 10'd1),
    .s_ip_payload_axis_tuser(1'b0),
    .m_udp_hdr_ready(1'b1),
    .m_ip_source_ip(),
    .m_udp_source_port(),
    .m_udp_dest_port(),
    .m_udp_length(parsed_length),
    .m_udp_payload_axis_tdata(),
    .m_udp_payload_axis_tvalid(),
    .m_udp_payload_axis_tready(),
    .m_udp_payload_axis_tlast(),
    .m_udp_payload_axis_tuser()
);

endmodule
