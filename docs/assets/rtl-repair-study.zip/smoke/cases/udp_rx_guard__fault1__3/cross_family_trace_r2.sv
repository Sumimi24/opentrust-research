module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error
);

localparam ST_IDLE   = 3'd0;
localparam ST_RECV   = 3'd1;
localparam ST_STATUS = 3'd2;
localparam ST_HDR    = 3'd3;
localparam ST_FEED   = 3'd4;
localparam ST_OUT    = 3'd5;

reg [7:0] frame_mem[0:511];

reg [2:0] state_reg = ST_IDLE;

reg [9:0] frame_len_reg = 10'd0;
reg oversize_reg = 1'b0;

reg [3:0] error_reg = 4'd0;

reg [31:0] src_ip_reg = 32'd0;
reg [15:0] src_port_reg = 16'd0;
reg [15:0] dst_port_reg = 16'd0;
reg [15:0] payload_len_reg = 16'd0;

reg status_valid_reg = 1'b0;
reg [3:0] status_error_reg = 4'd0;

reg [8:0] feed_ptr_reg = 9'd0;
reg [8:0] out_count_reg = 9'd0;

reg out_valid_reg = 1'b0;
reg [7:0] out_data_reg = 8'd0;
reg out_last_reg = 1'b0;

wire parser_s_ip_hdr_ready;
wire parser_s_ip_payload_tready;
wire [31:0] parser_m_ip_source_ip;
wire [15:0] parser_m_udp_source_port;
wire [15:0] parser_m_udp_dest_port;
wire [15:0] parser_m_udp_length;
wire [7:0] parser_m_udp_payload_tdata;
wire parser_m_udp_payload_tvalid;
wire parser_m_udp_payload_tlast;

wire [15:0] ip_total_length_w = {frame_mem[2], frame_mem[3]};
wire [15:0] udp_length_w = {frame_mem[24], frame_mem[25]};
wire [15:0] udp_checksum_w = {frame_mem[26], frame_mem[27]};
wire [31:0] dst_ip_w = {frame_mem[16], frame_mem[17], frame_mem[18], frame_mem[19]};
wire [15:0] dst_port_w = {frame_mem[22], frame_mem[23]};
wire [15:0] src_port_w = {frame_mem[20], frame_mem[21]};
wire [31:0] src_ip_w = {frame_mem[12], frame_mem[13], frame_mem[14], frame_mem[15]};
wire [15:0] calc_payload_len_w = udp_length_w - 16'd8;

assign s_ready = !rst && (state_reg == ST_IDLE || state_reg == ST_RECV);

assign m_data = out_data_reg;
assign m_valid = out_valid_reg;
assign m_last = out_last_reg;
assign m_src_ip = src_ip_reg;
assign m_src_port = src_port_reg;
assign m_dst_port = dst_port_reg;
assign m_payload_len = payload_len_reg;
assign status_valid = status_valid_reg;
assign status_error = status_error_reg;

function [15:0] add_fold16;
    input [17:0] sum;
    reg [16:0] t;
    begin
        t = sum[15:0] + sum[17:16];
        t = t[15:0] + t[16];
        add_fold16 = t[15:0];
    end
endfunction

integer i;
reg [17:0] ip_sum_tmp;
reg [17:0] udp_sum_tmp;
reg [15:0] ip_fold_tmp;
reg [15:0] udp_fold_tmp;
reg [3:0] next_error_tmp;

always @(posedge clk) begin
    if (rst) begin
        state_reg <= ST_IDLE;
        frame_len_reg <= 10'd0;
        oversize_reg <= 1'b0;
        error_reg <= 4'd0;
        src_ip_reg <= 32'd0;
        src_port_reg <= 16'd0;
        dst_port_reg <= 16'd0;
        payload_len_reg <= 16'd0;
        status_valid_reg <= 1'b0;
        status_error_reg <= 4'd0;
        feed_ptr_reg <= 9'd0;
        out_count_reg <= 9'd0;
        out_valid_reg <= 1'b0;
        out_data_reg <= 8'd0;
        out_last_reg <= 1'b0;
    end else begin
        status_valid_reg <= 1'b0;

        if (out_valid_reg && m_ready) begin
            out_valid_reg <= 1'b0;
            out_last_reg <= 1'b0;
        end

        case (state_reg)
            ST_IDLE: begin
                frame_len_reg <= 10'd0;
                oversize_reg <= 1'b0;
                error_reg <= 4'd0;
                feed_ptr_reg <= 9'd0;
                out_count_reg <= 9'd0;
                if (s_valid && s_ready) begin
                    if (10'd0 < 10'd512) begin
                        frame_mem[0] <= s_data;
                    end
                    frame_len_reg <= 10'd1;
                    oversize_reg <= 1'b0;
                    if (s_last) begin
                        state_reg <= ST_STATUS;
                    end else begin
                        state_reg <= ST_RECV;
                    end
                end
            end

            ST_RECV: begin
                if (s_valid && s_ready) begin
                    if (frame_len_reg < 10'd512) begin
                        frame_mem[frame_len_reg] <= s_data;
                    end else begin
                        oversize_reg <= 1'b1;
                    end
                    frame_len_reg <= frame_len_reg + 10'd1;
                    if (s_last) begin
                        state_reg <= ST_STATUS;
                    end
                end
            end

            ST_STATUS: begin
                next_error_tmp = 4'd0;

                if (frame_len_reg < 10'd28 || oversize_reg || frame_len_reg > 10'd512 ||
                    frame_mem[0][7:4] != 4'd4 ||
                    frame_mem[0][3:0] != 4'd5 ||
                    frame_mem[9] != 8'd17 ||
                    frame_mem[6][5] != 1'b0 ||
                    {frame_mem[6][4:0], frame_mem[7]} != 13'd0) begin
                    next_error_tmp = 4'd1;
                end else if (ip_total_length_w != frame_len_reg ||
                             udp_length_w != (ip_total_length_w - 16'd20) ||
                             calc_payload_len_w < 16'd1 ||
                             calc_payload_len_w > 16'd256) begin
                    next_error_tmp = 4'd2;
                end else begin
                    ip_sum_tmp = 18'd0;
                    for (i = 0; i < 20; i = i + 2) begin
                        ip_sum_tmp = ip_sum_tmp + {2'b00, frame_mem[i], frame_mem[i+1]};
                        ip_sum_tmp = {2'b00, add_fold16(ip_sum_tmp)};
                    end
                    ip_fold_tmp = add_fold16(ip_sum_tmp);
                    if (ip_fold_tmp != 16'hffff) begin
                        next_error_tmp = 4'd3;
                    end else begin
                        udp_sum_tmp = 18'd0;
                        udp_sum_tmp = udp_sum_tmp + {2'b00, frame_mem[12], frame_mem[13]};
                        udp_sum_tmp = {2'b00, add_fold16(udp_sum_tmp)};
                        udp_sum_tmp = udp_sum_tmp + {2'b00, frame_mem[14], frame_mem[15]};
                        udp_sum_tmp = {2'b00, add_fold16(udp_sum_tmp)};
                        udp_sum_tmp = udp_sum_tmp + {2'b00, frame_mem[16], frame_mem[17]};
                        udp_sum_tmp = {2'b00, add_fold16(udp_sum_tmp)};
                        udp_sum_tmp = udp_sum_tmp + {2'b00, frame_mem[18], frame_mem[19]};
                        udp_sum_tmp = {2'b00, add_fold16(udp_sum_tmp)};
                        udp_sum_tmp = udp_sum_tmp + 18'h0011;
                        udp_sum_tmp = {2'b00, add_fold16(udp_sum_tmp)};
                        udp_sum_tmp = udp_sum_tmp + {2'b00, udp_length_w};
                        udp_sum_tmp = {2'b00, add_fold16(udp_sum_tmp)};
                        for (i = 20; i < frame_len_reg; i = i + 2) begin
                            if (i+1 < frame_len_reg) begin
                                udp_sum_tmp = udp_sum_tmp + {2'b00, frame_mem[i], frame_mem[i+1]};
                            end else begin
                                udp_sum_tmp = udp_sum_tmp + {2'b00, frame_mem[i], 8'h00};
                            end
                            udp_sum_tmp = {2'b00, add_fold16(udp_sum_tmp)};
                        end
                        udp_fold_tmp = add_fold16(udp_sum_tmp);
                        if (udp_checksum_w != 16'h0000 && udp_fold_tmp != 16'hffff) begin
                            next_error_tmp = 4'd4;
                        end else if (dst_ip_w != 32'h0a000002 || dst_port_w != 16'd9000) begin
                            next_error_tmp = 4'd5;
                        end
                    end
                end

                error_reg <= next_error_tmp;
                status_valid_reg <= 1'b1;
                status_error_reg <= next_error_tmp;

                if (next_error_tmp == 4'd0) begin
                    src_ip_reg <= src_ip_w;
                    src_port_reg <= src_port_w;
                    dst_port_reg <= dst_port_w;
                    payload_len_reg <= calc_payload_len_w;
                    feed_ptr_reg <= 9'd20;
                    out_count_reg <= 9'd0;
                    state_reg <= ST_HDR;
                end else begin
                    state_reg <= ST_IDLE;
                end
            end

            ST_HDR: begin
                if (parser_s_ip_hdr_ready) begin
                    state_reg <= ST_FEED;
                end
            end

            ST_FEED: begin
                if (feed_ptr_reg < frame_len_reg && parser_s_ip_payload_tready) begin
                    if (feed_ptr_reg == frame_len_reg - 1) begin
                        state_reg <= ST_OUT;
                    end
                    feed_ptr_reg <= feed_ptr_reg + 9'd1;
                end
            end

            ST_OUT: begin
                if (!out_valid_reg && parser_m_udp_payload_tvalid) begin
                    out_valid_reg <= 1'b1;
                    out_data_reg <= parser_m_udp_payload_tdata;
                    out_last_reg <= parser_m_udp_payload_tlast;
                end

                if (parser_m_udp_payload_tvalid && (!out_valid_reg || m_ready)) begin
                    if (parser_m_udp_payload_tlast) begin
                        if (!out_valid_reg || m_ready) begin
                            state_reg <= ST_IDLE;
                        end
                    end
                end
            end

            default: begin
                state_reg <= ST_IDLE;
            end
        endcase
    end
end

udp_ip_rx parser(
    .clk(clk),
    .rst(rst),
    .s_ip_hdr_valid(state_reg == ST_HDR),
    .s_ip_hdr_ready(parser_s_ip_hdr_ready),
    .s_eth_dest_mac(48'd0),
    .s_eth_src_mac(48'd0),
    .s_eth_type(16'h0800),
    .s_ip_version(frame_mem[0][7:4]),
    .s_ip_ihl(frame_mem[0][3:0]),
    .s_ip_dscp(frame_mem[1][7:2]),
    .s_ip_ecn(frame_mem[1][1:0]),
    .s_ip_length({frame_mem[2], frame_mem[3]}),
    .s_ip_identification({frame_mem[4], frame_mem[5]}),
    .s_ip_flags(frame_mem[6][7:5]),
    .s_ip_fragment_offset({frame_mem[6][4:0], frame_mem[7]}),
    .s_ip_ttl(frame_mem[8]),
    .s_ip_protocol(frame_mem[9]),
    .s_ip_header_checksum({frame_mem[10], frame_mem[11]}),
    .s_ip_source_ip({frame_mem[12], frame_mem[13], frame_mem[14], frame_mem[15]}),
    .s_ip_dest_ip({frame_mem[16], frame_mem[17], frame_mem[18], frame_mem[19]}),
    .s_ip_payload_axis_tdata(frame_mem[feed_ptr_reg]),
    .s_ip_payload_axis_tvalid(state_reg == ST_FEED),
    .s_ip_payload_axis_tready(parser_s_ip_payload_tready),
    .s_ip_payload_axis_tlast(feed_ptr_reg == frame_len_reg - 1),
    .s_ip_payload_axis_tuser(1'b0),
    .m_udp_hdr_valid(),
    .m_udp_hdr_ready(1'b1),
    .m_eth_dest_mac(),
    .m_eth_src_mac(),
    .m_eth_type(),
    .m_ip_version(),
    .m_ip_ihl(),
    .m_ip_dscp(),
    .m_ip_ecn(),
    .m_ip_length(),
    .m_ip_identification(),
    .m_ip_flags(),
    .m_ip_fragment_offset(),
    .m_ip_ttl(),
    .m_ip_protocol(),
    .m_ip_header_checksum(),
    .m_ip_source_ip(parser_m_ip_source_ip),
    .m_ip_dest_ip(),
    .m_udp_source_port(parser_m_udp_source_port),
    .m_udp_dest_port(parser_m_udp_dest_port),
    .m_udp_length(parser_m_udp_length),
    .m_udp_checksum(),
    .m_udp_payload_axis_tdata(parser_m_udp_payload_tdata),
    .m_udp_payload_axis_tvalid(parser_m_udp_payload_tvalid),
    .m_udp_payload_axis_tready(!out_valid_reg || m_ready),
    .m_udp_payload_axis_tlast(parser_m_udp_payload_tlast),
    .m_udp_payload_axis_tuser()
);

endmodule
