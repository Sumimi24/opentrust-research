`timescale 1ns/1ps
`default_nettype none

module icache_ctrl(
input wire clk_i,
input wire rst_ni,
input wire req_i,
input wire branch_i,
input wire [31:0] addr_i,
input wire ready_i,
output wire valid_o,
output wire [31:0] rdata_o,
output wire [31:0] addr_o,
output wire err_o,
output wire instr_req_o,
input wire instr_gnt_i,
output wire [31:0] instr_addr_o,
input wire [31:0] instr_rdata_i,
input wire instr_err_i,
input wire instr_rvalid_i,
input wire icache_inval_i,
output wire busy_o);

import ibex_pkg::*;

wire [1:0] tag_req, data_req;
wire tag_write, data_write;
wire [7:0] tag_addr, data_addr;
wire [21:0] tag_wdata;
wire [63:0] data_wdata;
reg [21:0] tag_rdata[2];
reg [63:0] data_rdata[2];
reg [21:0] tag_mem0[256], tag_mem1[256];
reg [63:0] data_mem0[256], data_mem1[256];

always @(posedge clk_i) begin
  if (tag_req[0]) begin
    tag_rdata[0] <= tag_mem0[tag_addr];
    if (tag_write) tag_mem0[tag_addr] <= tag_wdata;
  end
  if (tag_req[1]) begin
    tag_rdata[1] <= tag_mem1[tag_addr];
    if (tag_write) tag_mem1[tag_addr] <= tag_wdata;
  end
  if (data_req[0]) begin
    data_rdata[0] <= data_mem0[data_addr];
    if (data_write) data_mem0[data_addr] <= data_wdata;
  end
  if (data_req[1]) begin
    data_rdata[1] <= data_mem1[data_addr];
    if (data_write) data_mem1[data_addr] <= data_wdata;
  end
end

wire core_valid;
wire [31:0] core_rdata;
wire [31:0] core_addr;
wire core_err;
wire core_busy;

ibex_icache #(.ICacheECC(0), .ResetAll(1), .BranchCache(0), .TweakInfection(0)) core(
  .clk_i(clk_i),
  .rst_ni(rst_ni),
  .req_i(req_i),
  .branch_i(branch_i),
  .addr_i(addr_i),
  .ready_i(ready_i),
  .valid_o(core_valid),
  .rdata_o(core_rdata),
  .addr_o(core_addr),
  .err_o(core_err),
  .instr_req_o(instr_req_o),
  .instr_gnt_i(instr_gnt_i),
  .instr_addr_o(instr_addr_o),
  .instr_rdata_i(instr_rdata_i),
  .instr_err_i(instr_err_i),
  .instr_rvalid_i(instr_rvalid_i),
  .icache_inval_i(icache_inval_i),
  .busy_o(core_busy),
  .ic_tag_req_o(tag_req),
  .ic_tag_write_o(tag_write),
  .ic_tag_addr_o(tag_addr),
  .ic_tag_wdata_o(tag_wdata),
  .ic_tag_rdata_i(tag_rdata),
  .ic_data_req_o(data_req),
  .ic_data_write_o(data_write),
  .ic_data_addr_o(data_addr),
  .ic_data_wdata_o(data_wdata),
  .ic_data_rdata_i(data_rdata),
  .ic_scr_key_valid_i(1'b1),
  .icache_enable_i(1'b1)
);

reg branch_pending;
reg [31:0] branch_addr_hold;
reg error_consumed;

always @(posedge clk_i or negedge rst_ni) begin
  if (!rst_ni) begin
    branch_pending <= 1'b0;
    branch_addr_hold <= 32'd0;
    error_consumed <= 1'b0;
  end else begin
    if (branch_i) begin
      branch_pending <= 1'b1;
      branch_addr_hold <= addr_i;
      error_consumed <= 1'b0;
    end else if (branch_pending && core_valid && (core_addr == branch_addr_hold)) begin
      branch_pending <= 1'b0;
    end
    if (core_valid && core_err && ready_i) begin
      error_consumed <= 1'b1;
    end
  end
end

wire suppress_output = branch_pending || error_consumed;

assign valid_o = suppress_output ? 1'b0 : core_valid;
assign rdata_o = core_rdata;
assign addr_o  = core_addr;
assign err_o   = suppress_output ? 1'b0 : core_err;
assign busy_o  = core_busy;

endmodule
