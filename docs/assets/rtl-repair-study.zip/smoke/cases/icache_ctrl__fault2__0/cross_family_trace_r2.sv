module icache_ctrl(
input wire clk_i,
input wire rst_ni,
input wire req_i,
input wire branch_i,
input wire [31:0] addr_i,
input wire ready_i,
output wire valid_o,
output wire [31:0] rdata_o,
output wire [31:0] addr_o,
output wire err_o,
output wire instr_req_o,
input wire instr_gnt_i,
output wire [31:0] instr_addr_o,
input wire [31:0] instr_rdata_i,
input wire instr_err_i,
input wire instr_rvalid_i,
input wire icache_inval_i,
output wire busy_o);

  import ibex_pkg::*;

  wire        core_valid_o;
  wire [31:0] core_rdata_o;
  wire [31:0] core_addr_o;
  wire        core_err_o;
  wire        core_instr_req_o;
  wire [31:0] core_instr_addr_o;
  wire        core_busy_o;

  wire [1:0]  tag_req;
  wire        tag_write;
  wire [7:0]  tag_addr;
  wire [21:0] tag_wdata;
  logic [21:0] tag_rdata [2];

  wire [1:0]  data_req;
  wire        data_write;
  wire [7:0]  data_addr;
  wire [63:0] data_wdata;
  logic [63:0] data_rdata [2];

  logic [21:0] tag_mem0 [256];
  logic [21:0] tag_mem1 [256];
  logic [63:0] data_mem0 [256];
  logic [63:0] data_mem1 [256];

  logic        hold_valid_q;
  logic [31:0] hold_rdata_q;
  logic [31:0] hold_addr_q;
  logic        hold_err_q;

  logic        branch_seen_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      tag_rdata[0] <= '0;
      tag_rdata[1] <= '0;
      data_rdata[0] <= '0;
      data_rdata[1] <= '0;
      hold_valid_q  <= 1'b0;
      hold_rdata_q  <= 32'h0;
      hold_addr_q   <= 32'h0;
      hold_err_q    <= 1'b0;
      branch_seen_q <= 1'b0;
    end else begin
      if (tag_req[0]) begin
        tag_rdata[0] <= tag_mem0[tag_addr];
        if (tag_write) tag_mem0[tag_addr] <= tag_wdata;
      end
      if (tag_req[1]) begin
        tag_rdata[1] <= tag_mem1[tag_addr];
        if (tag_write) tag_mem1[tag_addr] <= tag_wdata;
      end
      if (data_req[0]) begin
        data_rdata[0] <= data_mem0[data_addr];
        if (data_write) data_mem0[data_addr] <= data_wdata;
      end
      if (data_req[1]) begin
        data_rdata[1] <= data_mem1[data_addr];
        if (data_write) data_mem1[data_addr] <= data_wdata;
      end

      if (branch_i) begin
        hold_valid_q  <= 1'b0;
        hold_rdata_q  <= 32'h0;
        hold_addr_q   <= 32'h0;
        hold_err_q    <= 1'b0;
        branch_seen_q <= 1'b1;
      end else begin
        if (hold_valid_q) begin
          if (ready_i) begin
            hold_valid_q <= 1'b0;
          end
        end else if (branch_seen_q && core_valid_o) begin
          hold_valid_q <= 1'b1;
          hold_rdata_q <= core_rdata_o;
          hold_addr_q  <= core_addr_o;
          hold_err_q   <= core_err_o;
        end
      end
    end
  end

  assign valid_o = hold_valid_q;
  assign rdata_o = hold_rdata_q;
  assign addr_o  = hold_addr_q;
  assign err_o   = hold_err_q;

  assign instr_req_o  = core_instr_req_o;
  assign instr_addr_o = {core_instr_addr_o[31:2], 2'b00};
  assign busy_o       = core_busy_o;

  wire core_ready_i = branch_seen_q ? (!hold_valid_q || ready_i) : ready_i;

  ibex_icache #(
    .ICacheECC(0),
    .ResetAll(1),
    .BranchCache(0),
    .TweakInfection(0)
  ) core (
    .clk_i(clk_i),
    .rst_ni(rst_ni),
    .req_i(req_i),
    .branch_i(branch_i),
    .addr_i({addr_i[31:2], 2'b00}),
    .ready_i(core_ready_i),
    .valid_o(core_valid_o),
    .rdata_o(core_rdata_o),
    .addr_o(core_addr_o),
    .err_o(core_err_o),
    .instr_req_o(core_instr_req_o),
    .instr_gnt_i(instr_gnt_i),
    .instr_addr_o(core_instr_addr_o),
    .instr_rdata_i(instr_rdata_i),
    .instr_err_i(instr_err_i),
    .instr_rvalid_i(instr_rvalid_i),
    .icache_inval_i(icache_inval_i),
    .busy_o(core_busy_o),
    .ic_tag_req_o(tag_req),
    .ic_tag_write_o(tag_write),
    .ic_tag_addr_o(tag_addr),
    .ic_tag_wdata_o(tag_wdata),
    .ic_tag_rdata_i(tag_rdata),
    .ic_data_req_o(data_req),
    .ic_data_write_o(data_write),
    .ic_data_addr_o(data_addr),
    .ic_data_wdata_o(data_wdata),
    .ic_data_rdata_i(data_rdata),
    .ic_scr_key_valid_i(1'b1),
    .icache_enable_i(1'b1)
  );

endmodule
