"""Use an ld INPUT script for this Verilator recipe; OSS cannot rewrite ar indexes."""
from pathlib import Path
import sys
root=Path(__file__).resolve().parent
mode,target,*objects=sys.argv[1:];target=Path(target).resolve()
assert target.is_relative_to(root) and mode in ('-rc','-s')
if mode=='-rc':
    paths=[Path(x).resolve() for x in objects]
    assert paths and all(x.is_relative_to(root) and x.suffix=='.o' and x.is_file() for x in paths)
    target.write_text('INPUT ('+' '.join('"'+str(x)+'"' for x in paths)+')\n')
else:
    assert not objects and target.read_text().startswith('INPUT ('),'Expected the link input script'
