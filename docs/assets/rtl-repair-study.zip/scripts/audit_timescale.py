"""Validate the isolated time-precision amendment and frozen-decision reassessment."""
from pathlib import Path
import hashlib,json,random
ROOT=Path(r'C:/Users/10929/Documents/ChatGPT/VLA/opentrust_verified_engineering/engineering_subsystems_v01_20261011/prospective_repair_v04_20261012')
OUT=ROOT/'precision_revision'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    plan=read(OUT/'plan.json');summary=read(OUT/'summary.json');p=read(ROOT/'protocol.json')
    assert summary['complete'] and summary['model_calls']==0
    assert sha(Path(__file__).parent/'regrade_timescale.py')==plan['driver_sha256']
    assert sha(ROOT/'cpu_grade.py')==plan['original_grader_sha256']==p['sha256']['cpu_grade.py']
    assert sha(ROOT/'cpu_grade_timescale_revision.py')==plan['revised_grader_sha256']
    original=(ROOT/'cpu_grade.py').read_text(encoding='utf-8')
    start=original.index("        if not trusted and build==directory/'build':")
    end=original.index('        os.environ.update',start)
    expected=(original[:start]+original[end:]).replace('waves=False)',"waves=False,timescale='1ns/1ps')")
    assert (ROOT/'cpu_grade_timescale_revision.py').read_text(encoding='utf-8')==expected
    assert sha(ROOT/'selection.json')==read(OUT/'selection_binding.json')['selection_sha256']==read(ROOT/'selection_manifest.json')['sha256']
    for name,digest in p['sha256'].items():assert sha(ROOT/name)==digest,name
    rows=read(OUT/'results.json');selected=read(ROOT/'selection.json')['rows']
    source_gate={(r['case'],r['method']):r['source_contract_valid'] for r in read(ROOT/'source_contract_audit.json')['rows']}
    assert len(rows)==216 and [{k:r[k] for k in selected[0]} for r in rows]==selected
    for row in rows:
        assert row['source_contract_valid']==source_gate[row['case'],row['method']]
        assert sha(ROOT/row['source'])==row['source_sha256']
        for stage in ('development','independent'):
            score=read(OUT/'scores'/(row['task']+'_'+row['source_sha256'][:16]+'_'+stage)/'score.json')
            assert score['grader_sha256']==plan['revised_grader_sha256'] and score['stage']==stage
            assert score['source_sha256']==row['source_sha256']
            assert score['pass_test']==row['regraded_'+stage+'_pass']
            assert not score['seed_results'] or [s['seed'] for s in score['seed_results']]==p[stage+'_seeds']
            assert not any('simulator precision' in s.get('error','') for s in score['seed_results'])
            log=(OUT/'scores'/(row['task']+'_'+row['source_sha256'][:16]+'_'+stage)/'simulation.log').read_text(encoding='utf-8')
            assert not any(x in log for x in ('OSError: [Errno 22] Invalid argument','file truncated','No space left on device','Bus error'))
    q=read(OUT/'qualification.json');assert len(q)==21 and all(x['qualified'] for x in q)
    reference_passes=0
    for row in q:
        score=read(OUT/'scores'/(row['id'].split('__')[0]+'_'+row['source_sha256'][:16]+'_qualification')/'score.json')
        assert score['grader_sha256']==plan['revised_grader_sha256']
        if row['reference']:
            assert score['pass_test'] and [s['seed'] for s in score['seed_results']]==p['development_seeds']+p['independent_seeds']
            reference_passes+=len(score['seed_results'])
        else:
            assert score.get('compiled_program_sha256') and [s['seed'] for s in score['seed_results']]==p['development_seeds'][:1]
            assert all(not s['passed'] and s.get('error_type')=='AssertionError' for s in score['seed_results'])
    for method,totals in summary['methods'].items():
        group=[r for r in rows if r['method']==method]
        assert totals==dict(n=72,regraded_development_pass=sum(r['regraded_development_pass'] for r in group),regraded_independent_pass=sum(r['regraded_independent_pass'] for r in group),frozen_correct_adoption=sum(r['development_pass'] and r['regraded_independent_pass'] and r['source_contract_valid'] for r in group),frozen_false_adoption=sum(r['development_pass'] and not(r['regraded_independent_pass'] and r['source_contract_valid']) for r in group),development_rejected_but_independent_pass=sum(not r['development_pass'] and r['regraded_independent_pass'] for r in group))
    assert reference_passes==15
    tasks={t:{m:dict(n=24,correct_adoption=sum(r['task']==t and r['method']==m and r['development_pass'] and r['regraded_independent_pass'] and r['source_contract_valid'] for r in rows)) for m in summary['methods']} for t in ('dma_write','udp_rx_guard','icache_ctrl')}
    fixed={m:dict(n=18,correct_adoption=sum(r['producer']=='gpt-5.4' and r['method']==m and r['development_pass'] and r['regraded_independent_pass'] and r['source_contract_valid'] for r in rows),false_adoption=sum(r['producer']=='gpt-5.4' and r['method']==m and r['development_pass'] and not(r['regraded_independent_pass'] and r['source_contract_valid']) for r in rows),logical_calls=sum(r['calls'] for r in rows if r['producer']=='gpt-5.4' and r['method']==m)) for m in summary['methods']}
    clusters={}
    for row in rows:clusters.setdefault(row['task'],{}).setdefault(row['fault'],[]).append(row)
    rng=random.Random(46111);diff=[]
    for _ in range(2000):
        sample=[]
        for group in clusters.values():
            for ident in rng.choices(list(group),k=len(group)):sample.extend(group[ident])
        rates={m:sum(r['development_pass'] and r['regraded_independent_pass'] and r['source_contract_valid'] for r in sample if r['method']==m)/sum(r['method']==m for r in sample) for m in ('same_family_trace','cross_family_trace')}
        diff.append(rates['cross_family_trace']-rates['same_family_trace'])
    audit=dict(passed=True,rows=216,reference_seed_passes=15,functional_fault_rejections=18,source_and_selection_unchanged=True,task_assertions_unchanged=True,isolated_grader_revision=True,immutable_source_upload=True,model_calls=0,residual_time_precision_errors=0,residual_filesystem_errors=0,interpretation=plan['interpretation'],tasks=tasks,GPT_initial_paired_routes=fixed,cross_minus_same_correct_adoption_difference95=[sorted(diff)[49],sorted(diff)[1949]])
    (OUT/'audit.json').write_text(json.dumps(audit,indent=2)+'\n',encoding='utf-8');print(json.dumps(audit))

if __name__=='__main__':main()
