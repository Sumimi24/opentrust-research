"""Fresh scaffold repair benchmark: pinned upstream cores plus qualified injected faults."""
from pathlib import Path
import json,shutil,hashlib
BASE=Path(__file__).resolve().parent
CORE=Path(r'C:/Users/10929/Documents/ChatGPT/VLA/opentrust_verified_engineering/engineering_subsystems_v01_20261011')
OLD=CORE/'corrected_v03';ROOT=CORE/'prospective_repair_v04_20261012'

def save(path,value):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def replace(code,a,b):assert code.count(a)==1,a;return code.replace(a,b)

FAULTS={
'dma_write':[
 ('tag',('.s_axis_write_desc_tag(desc_tag)',".s_axis_write_desc_tag(desc_tag ^ 8'h01)")),
 ('length',('.s_axis_write_desc_len(desc_len)',".s_axis_write_desc_len(desc_len - 16'd1)")),
 ('unaligned',('.ENABLE_UNALIGNED(1)','.ENABLE_UNALIGNED(0)')),
 ('keep',('.s_axis_write_data_tkeep(s_keep)',".s_axis_write_data_tkeep(4'b1111)")),
 ('aligned_addr',('.s_axis_write_desc_addr(desc_addr)',".s_axis_write_desc_addr(desc_addr & 16'hfffc)")),
 ('error_priority',("seen_decerr ? 4'd7 : (seen_slverr ? 4'd6 : raw_error)","seen_slverr ? 4'd6 : (seen_decerr ? 4'd7 : raw_error)"))],
'udp_rx_guard':[
 ('ip_checksum',('if(fold(ip_sum)!=65535)error_code=3;',"if(1'b0)error_code=3;")),
 ('payload',('.s_ip_payload_axis_tdata(bytes[ptr])',".s_ip_payload_axis_tdata(bytes[ptr] ^ 8'h01)")),
 ('destination',("!=32'h0a000002","!=32'h0a000003")),
 ('zero_checksum',('word16(26)!=0 && fold(udp_sum)!=65535','fold(udp_sum)!=65535')),
 ('udp_checksum',('if(word16(26)!=0 && fold(udp_sum)!=65535)error_code=4;',"if(1'b0)error_code=4;")),
 ('short_payload',('n<28 || n>512','n<32 || n>512'))],
'icache_ctrl':[
 ('invalidate',('.icache_inval_i(icache_inval_i)',".icache_inval_i(1'b0)")),
 ('branch',('.branch_i(branch_i)',".branch_i(1'b0)")),
 ('ready',('.ready_i(ready_i)',".ready_i(1'b1)")),
 ('error',('.instr_err_i(instr_err_i)',".instr_err_i(1'b0)")),
 ('request',('.req_i(req_i)',".req_i(1'b0)")),
 ('write',('if(data_write)data_mem0[data_addr]<=data_wdata;',"if(1'b0)data_mem0[data_addr]<=data_wdata;"))]}

def main():
    assert not ROOT.exists(),'Do not overwrite an existing prospective experiment'
    ROOT.mkdir()
    for name in ('oracles.py','interfaces.json','subsystem_tests.py'):shutil.copyfile(OLD/name,ROOT/name)
    grader=(OLD/'cpu_grade.py').read_text(encoding='utf-8')
    grader=grader.replace('def grade(task,source,directory,seeds,trusted=False):','def grade(task,source,directory,seeds,trusted=False,project=False):')
    grader=grader.replace("if trusted and task==", "if (trusted or project) and task==")
    grader=grader.replace("trusted=='trusted')", "trusted=='trusted',project=trusted=='project')")
    (ROOT/'cpu_grade.py').write_text(grader,encoding='utf-8')
    rows=[]
    for task,faults in FAULTS.items():
        folder=ROOT/'tasks'/task;folder.mkdir(parents=True)
        for name in ('contract.txt','reference.sv'):shutil.copyfile(OLD/'tasks'/task/name,folder/name)
        reference=(folder/'reference.sv').read_text(encoding='utf-8')
        for k,(label,pair) in enumerate(faults):
            code=replace(reference,*pair);path=folder/(f'fault{k}.sv');path.write_text(code,encoding='utf-8')
            rows.append(dict(id=task+'__fault'+str(k),task=task,fault_label=label,source=path.relative_to(ROOT).as_posix(),source_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),mutation=dict(before=pair[0],after=pair[1]),origin='injected wrapper integration fault; not a historical upstream bug'))
    save(ROOT/'faults.json',rows)
    config=json.loads((BASE/'protocol_formal/api_config.json').read_text(encoding='utf-8'));config['timeout_seconds']=[60,600];config['api_workers']=4
    for value in config['model_parameters'].values():value['max_completion_tokens']=16384
    save(ROOT/'api_config.json',config)
    save(ROOT/'design.json',dict(status='qualification_pending',tasks=3,injected_faults=18,producers=['gpt-5.4','qwen3.8-max','deepseek-v4-pro','kimi-k2.5'],methods=['direct_patch','same_family_trace','cross_family_trace'],max_total_model_calls_per_route=3,development_seeds=[12347,23471],independent_seeds=[34583,45691,56701],upstream_cores_available_to_all_routes=True,reference_wrapper_hidden=True,selection_before_independent_tests=True,CPU_only=True,GPU_used=False,scope='18 injected wrapper faults in three fixed open-source subsystem contracts; not 18 independent projects'))
    print(json.dumps(dict(root=str(ROOT),faults=len(rows))))

if __name__=='__main__':main()
