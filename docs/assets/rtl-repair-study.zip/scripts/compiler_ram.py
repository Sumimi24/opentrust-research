"""OSS cannot seek while writing ELF: emit to anonymous CPU RAM, then copy sequentially."""
import os,sys,subprocess
from pathlib import Path
args=sys.argv[1:];kind=args.pop(0);compiler='/usr/bin/'+kind
root=Path(__file__).resolve().parent
env=dict(os.environ,TMPDIR=str(root/'tmp'))
if '-o' not in args:sys.exit(subprocess.call([compiler]+args,env=env))
index=args.index('-o')+1;target=Path(args[index]).resolve()
assert target.is_relative_to(root),'Compiler output must remain in the owned experiment'
if '-MMD' in args and '-MF' not in args:args+=['-MF',str(target.with_suffix('.d')),'-MT',str(target)]
fd=os.memfd_create('opentrust-cpu-build',0)
args[index]='/proc/'+str(os.getpid())+'/fd/'+str(fd)
rc=subprocess.call([compiler]+args,env=env)
if rc==0:
    os.lseek(fd,0,0)
    with target.open('wb') as out:
        while True:
            block=os.read(fd,1024*1024)
            if not block:break
            out.write(block)
os.close(fd);sys.exit(rc)
