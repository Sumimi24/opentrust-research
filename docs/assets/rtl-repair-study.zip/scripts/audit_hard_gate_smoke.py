"""Audit a fresh smoke of source gates and independent CPU evaluation, not a method comparison."""
from pathlib import Path
import collections,hashlib,json,re
ROOT=Path(r'C:/Users/10929/Documents/ChatGPT/VLA/opentrust_verified_engineering/engineering_subsystems_v01_20261011/sourcegate_smoke_v05_20261012')
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    p=read(ROOT/'protocol.json');s=read(ROOT/'summary.json');assert s['complete']
    for name,digest in p['sha256'].items():assert sha(ROOT/name)==digest,name
    assert sha(ROOT/'cpu_grade.py')==p['grader_sha256']
    assert sha(ROOT/'selection.json')==read(ROOT/'selection_manifest.json')['sha256']
    selected=read(ROOT/'selection.json');assert not selected['independent_feedback_used']
    rows=read(ROOT/'final_results.json');assert len(rows)==len({r['case'] for r in rows})==12
    categories=collections.Counter()
    assert [{k:r[k] for k in selected['rows'][0]} for r in rows]==selected['rows']
    for row in rows:
        assert row['calls']<=3 and sha(ROOT/row['source'])==row['source_sha256']
        for stage in ('development','independent'):
            score=read(ROOT/'scores'/(row['task']+'_'+row['source_sha256'][:16]+'_'+stage)/'score.json')
            assert score['source_sha256']==row['source_sha256'] and score['stage']==stage
            assert score['pass_test']==row[stage+'_pass']
            assert not score['seed_results'] or [x['seed'] for x in score['seed_results']]==p[stage+'_seeds']
            assert not any('simulator precision' in x.get('error','') for x in score['seed_results'])
            log=(ROOT/'scores'/(row['task']+'_'+row['source_sha256'][:16]+'_'+stage)/'simulation.log').read_text(encoding='utf-8')
            assert not any(x in log for x in ('OSError: [Errno 22] Invalid argument','file truncated','No space left on device','Bus error'))
            if stage=='independent':
                category='pass' if score['pass_test'] else score['status'] if not score['seed_results'] else 'functional_assertion' if any(x.get('error_type')=='AssertionError' for x in score['seed_results']) else 'compile_or_runtime_error'
                categories[category]+=1
        if row['development_pass']:
            text=re.sub(r'//[^\n]*|/\*[\s\S]*?\*/','',(ROOT/row['source']).read_text(encoding='utf-8'))
            core={'dma_write':'axi_dma_wr','udp_rx_guard':'udp_ip_rx','icache_ctrl':'ibex_icache'}[row['task']]
            assert re.findall(r'\bmodule\s+(\w+)',text)==[row['task']]
            assert re.search(r'\b'+core+r'\s*(?:#\s*\(|[A-Za-z_]\w*\s*\()',text)
    calls=[]
    for path in (ROOT/'cases').glob('*/api_attempts.jsonl'):
        records=[json.loads(x) for x in path.read_text(encoding='utf-8').splitlines()]
        assert len(records)==len({x['tag'] for x in records})
        for record in records:
            assert record['attempt']==1
            saved=read(path.parent/(record['tag']+'.json'))
            assert all(saved[k]==v for k,v in record.items())
            text=record.get('text','').strip() if record['ok'] else ''
            if text.startswith('```') and text.endswith('```'):text=text.split('\n',1)[1].rsplit('```',1)[0].strip()
            assert (path.parent/(record['tag']+'.sv')).read_text(encoding='utf-8')==text+'\n'
        calls.extend(records)
    assert len(calls)==s['actual_calls']==sum(r['calls'] for r in rows)<=36
    assert dict(collections.Counter(x['status'] for x in calls))==s['api_statuses']
    for branch in read(ROOT/'branches_round3.json'):
        assert branch['calls']==1+len(branch['history'])
        for h in branch['history']:
            assert all(x['seed'] in p['development_seeds'] for x in h['feedback']['failures'])
            expected=p['producers'][(p['producers'].index(branch['producer'])+h['round']-1)%4]
            record=read(ROOT/'cases'/branch['case']/('cross_family_trace_r'+str(h['round'])+'.json'))
            assert record['request']['model']==h['model']==expected
            original=next(f for f in read(ROOT/'faults.json') if f['id']==branch['fault'])
            assert (ROOT/original['source']).read_text(encoding='utf-8') in record['request']['messages'][1]['content']
            assert json.dumps(h['feedback']) in record['request']['messages'][-1]['content']
    q=read(ROOT/'qualification_summary.json');assert len(q)==6
    assert all(x['pass_test'] if x['reference'] else x['functional_rejection'] for x in q)
    references=0
    for row in q:
        score=read(ROOT/'qualification'/(row['id']+'.json'))
        if row['reference']:
            assert [x['seed'] for x in score['seed_results']]==p['development_seeds']+p['independent_seeds'];references+=sum(x['passed'] for x in score['seed_results'])
        else:assert score.get('compiled_program_sha256') and all(not x['passed'] and x.get('error_type')=='AssertionError' for x in score['seed_results'])
    controls=read(ROOT/'source_gate_controls.json');assert len(controls)==3
    for row in controls:
        score=read(ROOT/'qualification'/(row['task']+'__source_gate_control.json'))
        assert score['status']=='missing_upstream_core' and not score['seed_results'] and not score['pass_test']
    record=s['methods']['cross_family_trace']
    assert record==dict(n=12,independent_pass=sum(r['independent_pass'] for r in rows),correct_adoption=sum(r['development_pass'] and r['independent_pass'] for r in rows),false_adoption=sum(r['development_pass'] and not r['independent_pass'] for r in rows),logical_calls=sum(r['calls'] for r in rows))
    audit=dict(passed=True,cases=12,reference_seed_passes=references,functional_fault_rejections=3,source_gate_rejections=3,source_and_selection_bound=True,development_only_feedback=True,actual_calls=len(calls),new_independent_seeds=p['independent_seeds'],CPU_only=True,GPU_used=False,scope='Pipeline smoke; not an effect-size or generalization claim',tasks={t:dict(n=4,correct_adoption=sum(r['task']==t and r['development_pass'] and r['independent_pass'] for r in rows),false_adoption=sum(r['task']==t and r['development_pass'] and not r['independent_pass'] for r in rows)) for t in p['tasks']})
    audit['independent_result_categories']=dict(categories)
    audit['residual_filesystem_errors']=0
    assert references==15
    (ROOT/'delivery_audit.json').write_text(json.dumps(audit,indent=2)+'\n',encoding='utf-8');print(json.dumps(audit))

if __name__=='__main__':main()
