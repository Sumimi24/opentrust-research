from pathlib import Path
import json,sys,tarfile,shlex
BASE=Path(__file__).resolve().parent
sys.path.insert(0,r'C:/Users/10929/Documents/ChatGPT/VLA/opentrust_verified_engineering')
from subsystem_remote import connect,environment,ROOT as CORE,REMOTE as REMOTE_CORE
ROOT=CORE/'sourcegate_smoke_v05_20261012';REMOTE=REMOTE_CORE+'/'+ROOT.name

def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
def main():
    c=connect()
    try:
        archive=ROOT/'inputs.tar.gz'
        with tarfile.open(archive,'w:gz') as z:
            for p in ROOT.rglob('*'):
                if p.is_file() and p.suffix in ('.py','.json','.sv','.txt'):z.add(p,arcname=ROOT.name+'/'+p.relative_to(ROOT).as_posix())
        s=c.open_sftp();s.put(str(archive),REMOTE_CORE+'/sourcegate_v05_inputs.tar.gz');s.close()
        _,o,e=c.exec_command(environment()+'tar --touch --no-same-owner --no-same-permissions -xzf sourcegate_v05_inputs.tar.gz',timeout=120)
        o.read();err=e.read();assert o.channel.recv_exit_status()==0,err.decode()
        faults=json.loads((ROOT/'faults.json').read_text(encoding='utf-8'));plan=json.loads((ROOT/'design.json').read_text(encoding='utf-8'))
        jobs=[dict(id=t+'__reference',task=t,source='tasks/'+t+'/reference.sv',reference=True) for t in ('dma_write','udp_rx_guard','icache_ctrl')]+[dict(x,reference=False) for x in faults]
        folder=ROOT/'qualification';folder.mkdir(exist_ok=True);rows=[]
        for job in jobs:
            target=folder/(job['id']+'.json')
            if target.exists():score=json.loads(target.read_text(encoding='utf-8'))
            else:
                seeds=plan['development_seeds']+plan['independent_seeds'] if job['reference'] else [plan['development_seeds'][0]]
                outdir=REMOTE+'/qualification/'+job['id']
                cmd=environment()+'nice -n 15 /usr/bin/prlimit --cpu=120 --as=4294967296 --fsize=134217728 -- python3 '+ROOT.name+'/cpu_grade.py '+job['task']+' '+REMOTE+'/'+job['source']+' '+outdir+' '+','.join(map(str,seeds))+' project'
                _,o,e=c.exec_command(cmd,timeout=600);log=o.read().decode()+e.read().decode();rc=o.channel.recv_exit_status();(folder/(job['id']+'.log')).write_text(log,encoding='utf-8')
                s=c.open_sftp();s.get(outdir+'/score.json',str(target));s.close();score=json.loads(target.read_text(encoding='utf-8'))
            row=dict(id=job['id'],reference=job['reference'],pass_test=score['pass_test'],compiled=bool(score.get('compiled_program_sha256')),functional_rejection=bool(score['seed_results']) and all(not x['passed'] and x.get('error_type')=='AssertionError' for x in score['seed_results']))
            rows.append(row);save(ROOT/'qualification_progress.json',rows);print(json.dumps(row),flush=True)
        save(ROOT/'qualification_summary.json',rows)
        assert all(r['pass_test'] if r['reference'] else r['functional_rejection'] for r in rows)
        controls=[]
        for task in ('dma_write','udp_rx_guard','icache_ctrl'):
            outdir=REMOTE+'/source_gate_controls/'+task
            cmd=environment()+'python3 '+ROOT.name+'/cpu_grade.py '+task+' '+REMOTE+'/tasks/'+task+'/omission_control.sv '+outdir+' '+str(plan['development_seeds'][0])+' project'
            _,o,e=c.exec_command(cmd,timeout=60);log=o.read().decode()+e.read().decode();assert o.channel.recv_exit_status()==0,log[-1000:]
            target=folder/(task+'__source_gate_control.json');s=c.open_sftp();s.get(outdir+'/score.json',str(target));s.close();score=json.loads(target.read_text(encoding='utf-8'))
            assert score['status']=='missing_upstream_core' and not score['seed_results'] and not score['pass_test']
            controls.append(dict(task=task,status=score['status'],source_sha256=score['source_sha256']))
        save(ROOT/'source_gate_controls.json',controls)
        print('ALL_THREE_FAULTS_AND_SOURCE_GATES_QUALIFIED',flush=True)
    finally:c.close()

if __name__=='__main__':main()
