from pathlib import Path
import collections,csv,hashlib,json,random,re,tarfile
ROOT=Path(r'C:/Users/10929/Documents/ChatGPT/VLA/opentrust_verified_engineering/engineering_subsystems_v01_20261011/prospective_repair_v04_20261012')
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    p=read(ROOT/'protocol.json');summary=read(ROOT/'summary.json');assert summary['complete']
    for name,digest in p['sha256'].items():assert sha(ROOT/name)==digest,name
    assert sha(ROOT/'selection.json')==read(ROOT/'selection_manifest.json')['sha256']
    selection=read(ROOT/'selection.json');assert not selection['independent_feedback_used']
    results=read(ROOT/'final_results.json');assert len(results)==216
    assert len({(r['case'],r['method']) for r in results})==216
    initial=read(ROOT/'initial.json');assert len({r['case'] for r in initial})==72
    assert [(r['case'],r['method'],r['source_sha256']) for r in results]==[(r['case'],r['method'],r['source_sha256']) for r in selection['rows']]
    for row in results:
        assert row['calls']<=3 and sha(ROOT/row['source'])==row['source_sha256']
        for stage in ('development','independent'):
            s=read(ROOT/'scores'/(row['task']+'_'+row['source_sha256'][:16]+'_'+stage)/'score.json')
            assert s['source_sha256']==row['source_sha256'] and s['stage']==stage
            expected=p['development_seeds'] if stage=='development' else p['independent_seeds']
            assert not s['seed_results'] or [x['seed'] for x in s['seed_results']]==expected
            assert s['pass_test']==row['development_pass' if stage=='development' else 'independent_pass']
    attempts=[]
    for file in (ROOT/'cases').glob('*/api_attempts.jsonl'):
        rows=[json.loads(x) for x in file.read_text(encoding='utf-8').splitlines()]
        assert len(rows)==len({x['tag'] for x in rows}) and all(x['attempt']==1 for x in rows)
        for row in rows:
            saved=read(file.parent/(row['tag']+'.json'))
            assert all(saved[k]==v for k,v in row.items())
            assert set(saved)-set(row)=={'attempts','first_attempt_status'}
            assert saved['attempts']==1 and saved['first_attempt_status']==row['status']
            source=file.parent/(row['tag']+'.sv')
            text=row.get('text','').strip() if row['ok'] else ''
            if text.startswith('```') and text.endswith('```'):text=text.split('\n',1)[1].rsplit('```',1)[0].strip()
            assert source.read_text(encoding='utf-8')==text+'\n'
        attempts.extend(rows)
    assert len(attempts)==summary['actual_calls']==72+sum(r['calls']-1 for r in results if r['method']!='direct_patch')
    assert len(attempts)<=p['maximum_actual_calls']
    assert dict(collections.Counter(r['status'] for r in attempts))==summary['api_statuses']
    q=read(ROOT/'qualification_summary.json')
    assert len(q)==21 and all(x['pass_test'] if x['reference'] else x['functional_rejection'] for x in q)
    references=0
    for row in q:
        score=read(ROOT/'qualification'/(row['id']+'.json'))
        assert score['pass_test']==row['pass_test'] and bool(score.get('compiled_program_sha256'))==row['compiled']
        expected=p['development_seeds']+p['independent_seeds'] if row['reference'] else p['development_seeds'][:1]
        assert [s['seed'] for s in score['seed_results']]==expected
        if row['reference']:references+=sum(s['passed'] for s in score['seed_results'])
        else:assert all(not s['passed'] and s.get('error_type')=='AssertionError' for s in score['seed_results'])
    assert references==15
    upstream=read(ROOT.parent/'upstream_sources.json')
    for source in upstream['sources']:
        name=source['repository'].split('/')[-1]
        archive=ROOT.parent/'upstream'/(name+'.tar.gz')
        assert sha(archive)==source['archive_sha256']
        files={'verilog-axi':['rtl/axi_dma_wr.v'],'verilog-ethernet':['rtl/udp_ip_rx.v'],'ibex':['rtl/ibex_pkg.sv','rtl/ibex_icache.sv']}[name]
        with tarfile.open(archive) as tar:
            prefix=tar.getnames()[0]
            for path in files:
                assert tar.extractfile(prefix+'/'+path).read()==(ROOT.parent/'upstream'/name/path).read_bytes()
    for b in read(ROOT/'branches_round3.json'):
        assert b['calls']==1+len(b['history'])
        for h in b['history']:
            assert all(x['seed'] in p['development_seeds'] for x in h['feedback']['failures'])
            before=ROOT/'cases'/b['case']/('initial.sv' if h['round']==2 else b['method']+'_r2.sv')
            score=read(ROOT/'scores'/(b['task']+'_'+sha(before)[:16]+'_development')/'score.json')
            assert h['feedback']['failures']==[x for x in score['seed_results'] if not x['passed']]
            record=read(ROOT/'cases'/b['case']/(b['method']+'_r'+str(h['round'])+'.json'))
            models=p['producers'];expected=b['producer'] if b['method']=='same_family_trace' else models[(models.index(b['producer'])+h['round']-1)%len(models)]
            assert record['request']['model']==h['model']==expected
            assert record['request']['messages'][2]['content']==before.read_text(encoding='utf-8')
            assert json.dumps(h['feedback']) in record['request']['messages'][-1]['content']
    for method,record in summary['methods'].items():
        group=[r for r in results if r['method']==method]
        assert len(group)==record['n']==72
        assert sum(r['independent_pass'] for r in group)==record['independent_pass']
        assert sum(r['development_pass'] and r['independent_pass'] for r in group)==record['correct_adoption']
        assert sum(r['development_pass'] and not r['independent_pass'] for r in group)==record['false_adoption']
        assert sum(r['calls'] for r in group)==record['logical_calls']
    scanned=0
    for path in ROOT.rglob('*'):
        if path.is_file() and path.suffix in ('.json','.jsonl','.txt','.py','.sv','.log') and '__pycache__' not in path.parts:
            assert not re.search(r'\bsk-[A-Za-z0-9_-]{40,}',path.read_text(encoding='utf-8',errors='replace')),path;scanned+=1
    with (ROOT/'results_table.csv').open('w',encoding='utf-8-sig',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(results[0]));writer.writeheader();writer.writerows(results)
    # Paired difference, stratified by task and resampled at injected fault (not API-call) unit.
    clusters={}
    for r in results:clusters.setdefault(r['task'],{}).setdefault(r['fault'],[]).append(r)
    rng=random.Random(46111);differences=[]
    for _ in range(2000):
        sample=[]
        for group in clusters.values():
            keys=list(group)
            for ident in rng.choices(keys,k=len(keys)):sample.extend(group[ident])
        rates={m:sum(r['development_pass'] and r['independent_pass'] for r in sample if r['method']==m)/sum(r['method']==m for r in sample) for m in ('same_family_trace','cross_family_trace')}
        differences.append(rates['cross_family_trace']-rates['same_family_trace'])
    fixed=[r for r in results if r['producer']=='gpt-5.4' and r['method']=='same_family_trace']
    fixed_paired={m:[r for r in results if r['producer']=='gpt-5.4' and r['method']==m] for m in ('direct_patch','same_family_trace','cross_family_trace')}
    # The original model instruction requires integration with the pinned core.
    # Functional simulation alone does not check this source-level obligation.
    compliance=[]
    for row in results:
        text=re.sub(r'//[^\n]*|/\*[\s\S]*?\*/','',(ROOT/row['source']).read_text(encoding='utf-8'))
        core={'dma_write':'axi_dma_wr','udp_rx_guard':'udp_ip_rx','icache_ctrl':'ibex_icache'}[row['task']]
        present=bool(re.search(r'\b'+core+r'\s*(?:#\s*\(|[A-Za-z_]\w*\s*\()',text))
        modules=re.findall(r'\bmodule\s+(\w+)',text)
        valid=present and modules==[row['task']]
        compliance.append(dict(row,required_core=core,core_instance_present=present,only_requested_module=modules==[row['task']],source_contract_valid=valid))
    compliant_methods={}
    for method in summary['methods']:
        group=[r for r in compliance if r['method']==method]
        compliant_methods[method]=dict(n=72,source_contract_valid=sum(r['source_contract_valid'] for r in group),correct_adoption=sum(r['development_pass'] and r['independent_pass'] and r['source_contract_valid'] for r in group),false_adoption=sum(r['development_pass'] and not(r['independent_pass'] and r['source_contract_valid']) for r in group),accepted_source_violations=sum(r['development_pass'] and not r['source_contract_valid'] for r in group))
    compliant_tasks={t:{m:dict(n=24,correct_adoption=sum(r['task']==t and r['method']==m and r['development_pass'] and r['independent_pass'] and r['source_contract_valid'] for r in compliance)) for m in summary['methods']} for t in clusters}
    compliant_fixed={m:dict(n=18,correct_adoption=sum(r['producer']=='gpt-5.4' and r['method']==m and r['development_pass'] and r['independent_pass'] and r['source_contract_valid'] for r in compliance),false_adoption=sum(r['producer']=='gpt-5.4' and r['method']==m and r['development_pass'] and not(r['independent_pass'] and r['source_contract_valid']) for r in compliance),logical_calls=sum(r['producer']=='gpt-5.4' and r['method']==m and r['calls'] for r in compliance)) for m in summary['methods']}
    by_case={(r['case'],r['method']):r['source_contract_valid'] for r in compliance}
    time_precision_rows=[]
    for row in compliance:
        score=read(ROOT/'scores'/(row['task']+'_'+row['source_sha256'][:16]+'_development')/'score.json')
        if any('simulator precision' in s.get('error','') for s in score['seed_results']):
            time_precision_rows.append(dict(case=row['case'],method=row['method'],task=row['task'],core_instance_present=row['core_instance_present']))
    rng=random.Random(46111);contract_differences=[]
    for _ in range(2000):
        sample=[]
        for group in clusters.values():
            keys=list(group)
            for ident in rng.choices(keys,k=len(keys)):sample.extend(group[ident])
        rates={m:sum(r['development_pass'] and r['independent_pass'] and by_case[r['case'],r['method']] for r in sample if r['method']==m)/sum(r['method']==m for r in sample) for m in ('same_family_trace','cross_family_trace')}
        contract_differences.append(rates['cross_family_trace']-rates['same_family_trace'])
    (ROOT/'source_contract_audit.json').write_text(json.dumps(dict(criterion='Original instruction: integrate the provided immutable core; return only the requested module. Presence is a necessary source check, not proof that all behavior uses the core.',assessment='Posthoc source compliance audit; original selection and functional scores preserved.',rows=compliance,methods=compliant_methods),indent=2)+'\n',encoding='utf-8')
    failures={}
    disagreements=[]
    for row in results:
        score=read(ROOT/'scores'/(row['task']+'_'+row['source_sha256'][:16]+'_independent')/'score.json')
        log=(ROOT/'scores'/(row['task']+'_'+row['source_sha256'][:16]+'_independent')/'simulation.log').read_text(encoding='utf-8')
        record=read((ROOT/row['source']).with_suffix('.json'))
        if record['status']!='complete':category='API:'+record['status']
        elif score['status'] not in ('pass','failed'):category='contract_gate:'+score['status']
        elif 'OSError: [Errno 22] Invalid argument' in log:category='environment_filesystem'
        elif row['independent_pass']:category='pass'
        elif any('simulator precision' in s.get('error','') for s in score['seed_results']):category='simulation_time_precision'
        elif any(s.get('error')=='compile_or_runtime_error' for s in score['seed_results']):category='compile_or_runtime'
        else:category='functional_contract'
        failures.setdefault(row['method'],collections.Counter())[category]+=1
        if row['development_pass']!=row['independent_pass']:
            disagreements.append(dict(case=row['case'],task=row['task'],method=row['method'],development_pass=row['development_pass'],independent_pass=row['independent_pass'],source_sha256=row['source_sha256']))
    audit=dict(passed=True,base_contracts=3,injected_faults=18,initial_repair_cases=72,paired_rows=216,
        reference_seed_passes=15,functional_fault_rejections=18,one_equivalent_mutation_excluded=True,
        selection_unchanged=True,independent_feedback_not_used=True,frozen_sources_unchanged=True,credential_scan_files=scanned,
        API_output_source_binding=True,actual_calls=len(attempts),summary_recomputed=True,
        upstream_archives_and_four_core_sources_match_pinned_versions=True,
        usage_tokens={k:sum((a.get('usage') or {}).get(k,0) for a in attempts) for k in ('prompt_tokens','completion_tokens','total_tokens')},
        API_reported_models=dict(collections.Counter(a.get('reported_model') or 'unknown' for a in attempts)),
        fixed_GPT_three_call_control=dict(n=18,correct_adoption=sum(r['development_pass'] and r['independent_pass'] for r in fixed),false_adoption=sum(r['development_pass'] and not r['independent_pass'] for r in fixed),logical_calls=sum(r['calls'] for r in fixed)),
        GPT_initial_paired_routes={m:dict(n=len(group),correct_adoption=sum(r['development_pass'] and r['independent_pass'] for r in group),false_adoption=sum(r['development_pass'] and not r['independent_pass'] for r in group),logical_calls=sum(r['calls'] for r in group)) for m,group in fixed_paired.items()},
        independent_result_categories={m:dict(counts) for m,counts in failures.items()},development_independent_disagreements=disagreements,
        cross_minus_same_correct_adoption_difference95=[sorted(differences)[49],sorted(differences)[1949]],
        tasks={t:{m:dict(n=sum(r['task']==t and r['method']==m for r in results),correct_adoption=sum(r['task']==t and r['method']==m and r['development_pass'] and r['independent_pass'] for r in results)) for m in ('direct_patch','same_family_trace','cross_family_trace')} for t in clusters},
        source_contract_methods=compliant_methods,
        source_contract_tasks=compliant_tasks,source_contract_GPT_initial_routes=compliant_fixed,
        source_contract_cross_minus_same_difference95=[sorted(contract_differences)[49],sorted(contract_differences)[1949]],
        final_development_time_precision_rows=time_precision_rows,
        CPU_only=True,GPU_used=False,boundary='Injection benchmark on three wrapper contracts; no historical bug, PPA, formal proof or whole-core claim')
    (ROOT/'delivery_audit.json').write_text(json.dumps(audit,indent=2)+'\n',encoding='utf-8');print(json.dumps(audit))

if __name__=='__main__':main()
