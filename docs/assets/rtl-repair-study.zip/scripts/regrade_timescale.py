"""Execution-only reassessment of frozen sources; never calls a model or changes selection."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import collections,hashlib,json,sys,threading
sys.path.insert(0,r'C:/Users/10929/Documents/ChatGPT/VLA/opentrust_verified_engineering')
from subsystem_remote import connect,environment,ROOT as CORE,REMOTE as REMOTE_CORE
ROOT=CORE/'prospective_repair_v04_20261012';OUT=ROOT/'precision_revision';REMOTE=REMOTE_CORE+'/'+ROOT.name

def read(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    assert read(ROOT/'summary.json')['complete']
    assert read(ROOT/'delivery_audit.json')['passed']
    source_gate={(r['case'],r['method']):r['source_contract_valid'] for r in read(ROOT/'source_contract_audit.json')['rows']}
    plan=read(OUT/'plan.json');p=read(ROOT/'protocol.json');selection_sha=sha(ROOT/'selection.json')
    assert sha(ROOT/'cpu_grade_timescale_revision.py')==plan['revised_grader_sha256']
    assert sha(ROOT/'cpu_grade.py')==plan['original_grader_sha256']
    save(OUT/'selection_binding.json',dict(selection_sha256=selection_sha,model_calls=0))
    c=connect();lock=threading.Lock();locks={}
    try:
        s=c.open_sftp();s.put(str(ROOT/'cpu_grade_timescale_revision.py'),REMOTE+'/cpu_grade_timescale_revision.py');s.close()
        def grade(task,source,stage,seeds):
            digest=sha(ROOT/source);label=task+'_'+digest[:16]+'_'+stage
            with lock:local_lock=locks.setdefault(label,threading.Lock())
            with local_lock:
                folder=OUT/'scores'/label;target=folder/'score.json'
                if target.exists():return read(target)
                folder.mkdir(parents=True,exist_ok=True)
                remote_source=REMOTE+'/precision_revision/candidates/'+task+'_'+digest+'.sv'
                s=c.open_sftp()
                for path in (REMOTE+'/precision_revision',REMOTE+'/precision_revision/candidates'):
                    try:s.mkdir(path)
                    except OSError:pass
                try:
                    with s.open(remote_source,'rb') as stream:assert hashlib.sha256(stream.read()).hexdigest()==digest
                except FileNotFoundError:s.put(str(ROOT/source),remote_source)
                s.close()
                outdir=REMOTE+'/precision_revision/scores/'+label
                cmd=environment()+'nice -n 15 /usr/bin/prlimit --cpu=120 --as=4294967296 --fsize=134217728 -- python3 '+ROOT.name+'/cpu_grade_timescale_revision.py '+task+' '+remote_source+' '+outdir+' '+','.join(map(str,seeds))+' project'
                _,o,e=c.exec_command(cmd,timeout=600);log=o.read().decode()+e.read().decode();rc=o.channel.recv_exit_status()
                (folder/'simulation.log').write_text(log,encoding='utf-8')
                s=c.open_sftp();s.get(outdir+'/score.json',str(target));s.close()
                score=read(target);assert score['source_sha256']==digest
                score.update(stage=stage,returncode=rc,grader_sha256=plan['revised_grader_sha256']);save(target,score)
                print(json.dumps(dict(task=task,stage=stage,passed=score['pass_test'],source=digest[:12])),flush=True)
                return score
        qualified=[]
        jobs=[dict(id=t+'__reference',task=t,source='tasks/'+t+'/reference.sv',reference=True) for t in ('dma_write','udp_rx_guard','icache_ctrl')]+[dict(x,reference=False) for x in read(ROOT/'faults.json')]
        for job in jobs:
            seeds=p['development_seeds']+p['independent_seeds'] if job['reference'] else p['development_seeds'][:1]
            score=grade(job['task'],job['source'],'qualification',seeds)
            valid=score['pass_test'] if job['reference'] else bool(score['seed_results']) and all(not x['passed'] and x.get('error_type')=='AssertionError' for x in score['seed_results'])
            assert valid,job['id'];qualified.append(dict(id=job['id'],reference=job['reference'],qualified=True,source_sha256=score['source_sha256']))
        save(OUT/'qualification.json',qualified)
        selected=read(ROOT/'selection.json')['rows']
        unique=list({(r['task'],r['source_sha256']):r for r in selected}.values())
        for stage in ('development','independent'):
            with ThreadPoolExecutor(max_workers=2) as pool:
                list(pool.map(lambda r:grade(r['task'],r['source'],stage,p[stage+'_seeds']),unique))
        results=[]
        for r in selected:
            scores={stage:read(OUT/'scores'/(r['task']+'_'+r['source_sha256'][:16]+'_'+stage)/'score.json') for stage in ('development','independent')}
            results.append(dict(r,source_contract_valid=source_gate[r['case'],r['method']],regraded_development_pass=scores['development']['pass_test'],regraded_independent_pass=scores['independent']['pass_test']))
        save(OUT/'results.json',results)
        methods={}
        for method in ('direct_patch','same_family_trace','cross_family_trace'):
            group=[r for r in results if r['method']==method]
            methods[method]=dict(n=len(group),regraded_development_pass=sum(r['regraded_development_pass'] for r in group),regraded_independent_pass=sum(r['regraded_independent_pass'] for r in group),frozen_correct_adoption=sum(r['development_pass'] and r['regraded_independent_pass'] and r['source_contract_valid'] for r in group),frozen_false_adoption=sum(r['development_pass'] and not(r['regraded_independent_pass'] and r['source_contract_valid']) for r in group),development_rejected_but_independent_pass=sum(not r['development_pass'] and r['regraded_independent_pass'] for r in group))
        assert sha(ROOT/'selection.json')==selection_sha
        summary=dict(complete=True,model_calls=0,selection_unchanged=True,unique_final_sources=len(unique),qualification_rows=21,methods=methods,interpretation=plan['interpretation'])
        save(OUT/'summary.json',summary);print(json.dumps(summary),flush=True)
    finally:c.close()

if __name__=='__main__':main()
