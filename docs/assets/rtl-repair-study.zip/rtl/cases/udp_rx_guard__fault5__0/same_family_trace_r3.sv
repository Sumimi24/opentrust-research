module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error
);

reg [7:0] frame_mem[0:511];

reg [2:0] state_reg;
localparam [2:0]
    ST_RECV   = 3'd0,
    ST_STATUS = 3'd1,
    ST_HDR    = 3'd2,
    ST_SEND   = 3'd3,
    ST_WAIT   = 3'd4;

reg [9:0] frame_len_reg;
reg oversize_reg;

reg status_valid_reg;
reg [3:0] status_error_reg;

reg [31:0] meta_src_ip_reg;
reg [15:0] meta_src_port_reg;
reg [15:0] meta_dst_port_reg;
reg [15:0] meta_payload_len_reg;

reg [9:0] send_idx_reg;

reg out_valid_reg;
reg [7:0] out_data_reg;
reg out_last_reg;

wire [15:0] ip_total_length_w = {frame_mem[2], frame_mem[3]};
wire [15:0] udp_src_port_w    = {frame_mem[20], frame_mem[21]};
wire [15:0] udp_dst_port_w    = {frame_mem[22], frame_mem[23]};
wire [15:0] udp_length_w      = {frame_mem[24], frame_mem[25]};
wire [15:0] udp_checksum_w    = {frame_mem[26], frame_mem[27]};
wire [31:0] src_ip_w          = {frame_mem[12], frame_mem[13], frame_mem[14], frame_mem[15]};
wire [31:0] dst_ip_w          = {frame_mem[16], frame_mem[17], frame_mem[18], frame_mem[19]};

reg [31:0] ip_sum_calc;
reg [31:0] udp_sum_calc;
reg [3:0] error_calc;
reg [15:0] temp_word;
integer i;

function [15:0] fold16;
    input [31:0] sum_in;
    reg [31:0] t;
    begin
        t = sum_in;
        t = (t[15:0] + t[31:16]);
        t = (t[15:0] + t[31:16]);
        t = (t[15:0] + t[31:16]);
        fold16 = t[15:0];
    end
endfunction

always @* begin
    ip_sum_calc = 32'd0;
    udp_sum_calc = 32'd0;
    error_calc = 4'd0;
    temp_word = 16'd0;

    if ((frame_len_reg < 10'd28) ||
        oversize_reg ||
        (frame_mem[0][7:4] != 4'd4) ||
        (frame_mem[0][3:0] != 4'd5) ||
        (frame_mem[9] != 8'd17) ||
        (frame_mem[6][5] != 1'b0) ||
        ({frame_mem[6][4:0], frame_mem[7]} != 13'd0)) begin
        error_calc = 4'd1;
    end else if ((ip_total_length_w != frame_len_reg) ||
                 (udp_length_w != (ip_total_length_w - 16'd20)) ||
                 ((udp_length_w - 16'd8) < 16'd1) ||
                 ((udp_length_w - 16'd8) > 16'd256)) begin
        error_calc = 4'd2;
    end else begin
        for (i = 0; i < 20; i = i + 2) begin
            ip_sum_calc = ip_sum_calc + {frame_mem[i], frame_mem[i+1]};
        end
        if (fold16(ip_sum_calc) != 16'hffff) begin
            error_calc = 4'd3;
        end else begin
            if (udp_checksum_w != 16'h0000) begin
                udp_sum_calc = 32'd0;
                udp_sum_calc = udp_sum_calc + {frame_mem[12], frame_mem[13]};
                udp_sum_calc = udp_sum_calc + {frame_mem[14], frame_mem[15]};
                udp_sum_calc = udp_sum_calc + {frame_mem[16], frame_mem[17]};
                udp_sum_calc = udp_sum_calc + {frame_mem[18], frame_mem[19]};
                udp_sum_calc = udp_sum_calc + 16'h0011;
                udp_sum_calc = udp_sum_calc + udp_length_w;

                for (i = 0; i < 512; i = i + 2) begin
                    if (i < udp_length_w) begin
                        if ((20 + i + 1) < frame_len_reg) begin
                            temp_word = {frame_mem[20+i], frame_mem[20+i+1]};
                        end else begin
                            temp_word = {frame_mem[20+i], 8'h00};
                        end
                        udp_sum_calc = udp_sum_calc + temp_word;
                    end
                end

                if (fold16(udp_sum_calc) != 16'hffff) begin
                    error_calc = 4'd4;
                end else if ((dst_ip_w != 32'h0a000002) || (udp_dst_port_w != 16'd9000)) begin
                    error_calc = 4'd5;
                end
            end else begin
                if ((dst_ip_w != 32'h0a000002) || (udp_dst_port_w != 16'd9000)) begin
                    error_calc = 4'd5;
                end
            end
        end
    end
end

wire parser_ip_hdr_ready;
wire parser_udp_hdr_valid;
wire [31:0] parser_src_ip;
wire [15:0] parser_src_port;
wire [15:0] parser_dst_port;
wire [15:0] parser_udp_length;
wire [7:0] parser_tdata;
wire parser_tvalid;
wire parser_tlast;
wire parser_tuser;

wire parser_tready;
assign parser_tready = (~out_valid_reg) | m_ready;

udp_ip_rx parser_inst (
    .clk(clk),
    .rst(rst),
    .s_ip_hdr_valid(state_reg == ST_HDR),
    .s_ip_hdr_ready(parser_ip_hdr_ready),
    .s_eth_dest_mac(48'd0),
    .s_eth_src_mac(48'd0),
    .s_eth_type(16'h0800),
    .s_ip_version(frame_mem[0][7:4]),
    .s_ip_ihl(frame_mem[0][3:0]),
    .s_ip_dscp(frame_mem[1][7:2]),
    .s_ip_ecn(frame_mem[1][1:0]),
    .s_ip_length({frame_mem[2], frame_mem[3]}),
    .s_ip_identification({frame_mem[4], frame_mem[5]}),
    .s_ip_flags(frame_mem[6][7:5]),
    .s_ip_fragment_offset({frame_mem[6][4:0], frame_mem[7]}),
    .s_ip_ttl(frame_mem[8]),
    .s_ip_protocol(frame_mem[9]),
    .s_ip_header_checksum({frame_mem[10], frame_mem[11]}),
    .s_ip_source_ip({frame_mem[12], frame_mem[13], frame_mem[14], frame_mem[15]}),
    .s_ip_dest_ip({frame_mem[16], frame_mem[17], frame_mem[18], frame_mem[19]}),
    .s_ip_payload_axis_tdata(frame_mem[send_idx_reg]),
    .s_ip_payload_axis_tvalid(state_reg == ST_SEND),
    .s_ip_payload_axis_tready(),
    .s_ip_payload_axis_tlast(send_idx_reg == (frame_len_reg - 10'd1)),
    .s_ip_payload_axis_tuser(1'b0),
    .m_udp_hdr_valid(parser_udp_hdr_valid),
    .m_udp_hdr_ready(1'b1),
    .m_eth_dest_mac(),
    .m_eth_src_mac(),
    .m_eth_type(),
    .m_ip_version(),
    .m_ip_ihl(),
    .m_ip_dscp(),
    .m_ip_ecn(),
    .m_ip_length(),
    .m_ip_identification(),
    .m_ip_flags(),
    .m_ip_fragment_offset(),
    .m_ip_ttl(),
    .m_ip_protocol(),
    .m_ip_header_checksum(),
    .m_ip_source_ip(parser_src_ip),
    .m_ip_dest_ip(),
    .m_udp_source_port(parser_src_port),
    .m_udp_dest_port(parser_dst_port),
    .m_udp_length(parser_udp_length),
    .m_udp_checksum(),
    .m_udp_payload_axis_tdata(parser_tdata),
    .m_udp_payload_axis_tvalid(parser_tvalid),
    .m_udp_payload_axis_tready(parser_tready),
    .m_udp_payload_axis_tlast(parser_tlast),
    .m_udp_payload_axis_tuser(parser_tuser),
    .busy(),
    .error_header_early_termination(),
    .error_payload_early_termination()
);

assign s_ready = (state_reg == ST_RECV);

assign m_data = out_data_reg;
assign m_valid = out_valid_reg;
assign m_last = out_last_reg;
assign m_src_ip = meta_src_ip_reg;
assign m_src_port = meta_src_port_reg;
assign m_dst_port = meta_dst_port_reg;
assign m_payload_len = meta_payload_len_reg;

assign status_valid = status_valid_reg;
assign status_error = status_error_reg;

always @(posedge clk) begin
    if (rst) begin
        state_reg <= ST_RECV;
        frame_len_reg <= 10'd0;
        oversize_reg <= 1'b0;
        status_valid_reg <= 1'b0;
        status_error_reg <= 4'd0;
        meta_src_ip_reg <= 32'd0;
        meta_src_port_reg <= 16'd0;
        meta_dst_port_reg <= 16'd0;
        meta_payload_len_reg <= 16'd0;
        send_idx_reg <= 10'd20;
        out_valid_reg <= 1'b0;
        out_data_reg <= 8'd0;
        out_last_reg <= 1'b0;
    end else begin
        status_valid_reg <= 1'b0;

        if (out_valid_reg && m_ready) begin
            out_valid_reg <= 1'b0;
        end

        if (((~out_valid_reg) | m_ready) && parser_tvalid) begin
            out_valid_reg <= 1'b1;
            out_data_reg <= parser_tdata;
            out_last_reg <= parser_tlast;
        end

        case (state_reg)
            ST_RECV: begin
                if (s_valid) begin
                    if (frame_len_reg < 10'd512) begin
                        frame_mem[frame_len_reg] <= s_data;
                    end else begin
                        oversize_reg <= 1'b1;
                    end
                    frame_len_reg <= frame_len_reg + 10'd1;
                    if (s_last) begin
                        state_reg <= ST_STATUS;
                    end
                end
            end

            ST_STATUS: begin
                status_valid_reg <= 1'b1;
                status_error_reg <= error_calc;
                if (error_calc == 4'd0) begin
                    meta_src_ip_reg <= src_ip_w;
                    meta_src_port_reg <= udp_src_port_w;
                    meta_dst_port_reg <= udp_dst_port_w;
                    meta_payload_len_reg <= udp_length_w - 16'd8;
                    send_idx_reg <= 10'd20;
                    out_valid_reg <= 1'b0;
                    state_reg <= ST_HDR;
                end else begin
                    frame_len_reg <= 10'd0;
                    oversize_reg <= 1'b0;
                    state_reg <= ST_RECV;
                end
            end

            ST_HDR: begin
                if (parser_ip_hdr_ready) begin
                    send_idx_reg <= 10'd20;
                    state_reg <= ST_SEND;
                end
            end

            ST_SEND: begin
                if ((~out_valid_reg | m_ready)) begin
                    if (send_idx_reg == (frame_len_reg - 10'd1)) begin
                        state_reg <= ST_WAIT;
                    end else begin
                        send_idx_reg <= send_idx_reg + 10'd1;
                    end
                end
            end

            ST_WAIT: begin
                if (~out_valid_reg) begin
                    frame_len_reg <= 10'd0;
                    oversize_reg <= 1'b0;
                    state_reg <= ST_RECV;
                end
            end

            default: begin
                state_reg <= ST_RECV;
            end
        endcase
    end
end

endmodule
