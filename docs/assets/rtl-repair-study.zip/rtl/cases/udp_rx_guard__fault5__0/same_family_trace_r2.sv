module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error
);

reg [7:0] buf_mem[0:511];

reg [2:0] state_reg;
localparam [2:0]
    ST_RECV   = 3'd0,
    ST_STATUS = 3'd1,
    ST_HDR    = 3'd2,
    ST_PAY    = 3'd3,
    ST_WAIT   = 3'd4;

reg [9:0] rx_count_reg;
reg oversize_reg;

reg status_valid_reg;
reg [3:0] status_error_reg;

reg [31:0] meta_src_ip_reg;
reg [15:0] meta_src_port_reg;
reg [15:0] meta_dst_port_reg;
reg [15:0] meta_payload_len_reg;

reg [9:0] pay_ptr_reg;

reg hold_valid_reg;
reg [7:0] hold_data_reg;
reg hold_last_reg;

wire [15:0] ip_total_length_w = {buf_mem[2], buf_mem[3]};
wire [15:0] udp_src_port_w    = {buf_mem[20], buf_mem[21]};
wire [15:0] udp_dst_port_w    = {buf_mem[22], buf_mem[23]};
wire [15:0] udp_length_w      = {buf_mem[24], buf_mem[25]};
wire [15:0] udp_checksum_w    = {buf_mem[26], buf_mem[27]};
wire [31:0] src_ip_w          = {buf_mem[12], buf_mem[13], buf_mem[14], buf_mem[15]};
wire [31:0] dst_ip_w          = {buf_mem[16], buf_mem[17], buf_mem[18], buf_mem[19]};

reg [31:0] ip_sum_calc;
reg [31:0] udp_sum_calc;
reg [3:0] error_calc;
reg [15:0] udp_word_temp;
integer i;

function [15:0] fold16;
    input [31:0] sum_in;
    reg [31:0] t;
    begin
        t = sum_in;
        t = (t[15:0] + t[31:16]);
        t = (t[15:0] + t[31:16]);
        t = (t[15:0] + t[31:16]);
        fold16 = t[15:0];
    end
endfunction

always @* begin
    ip_sum_calc = 32'd0;
    udp_sum_calc = 32'd0;
    error_calc = 4'd0;
    udp_word_temp = 16'd0;

    if (rx_count_reg < 10'd28 ||
        oversize_reg ||
        (buf_mem[0][7:4] != 4'd4) ||
        (buf_mem[0][3:0] != 4'd5) ||
        (buf_mem[9] != 8'd17) ||
        (buf_mem[6][5] != 1'b0) ||
        ({buf_mem[6][4:0], buf_mem[7]} != 13'd0)) begin
        error_calc = 4'd1;
    end else if ((ip_total_length_w != rx_count_reg) ||
                 (udp_length_w != (ip_total_length_w - 16'd20)) ||
                 (udp_length_w < 16'd9) ||
                 (udp_length_w > 16'd264)) begin
        error_calc = 4'd2;
    end else begin
        for (i = 0; i < 20; i = i + 2) begin
            ip_sum_calc = ip_sum_calc + {buf_mem[i], buf_mem[i+1]};
        end
        if (fold16(ip_sum_calc) != 16'hffff) begin
            error_calc = 4'd3;
        end else begin
            udp_sum_calc = 32'd0;
            udp_sum_calc = udp_sum_calc + {buf_mem[12], buf_mem[13]};
            udp_sum_calc = udp_sum_calc + {buf_mem[14], buf_mem[15]};
            udp_sum_calc = udp_sum_calc + {buf_mem[16], buf_mem[17]};
            udp_sum_calc = udp_sum_calc + {buf_mem[18], buf_mem[19]};
            udp_sum_calc = udp_sum_calc + 16'h0011;
            udp_sum_calc = udp_sum_calc + udp_length_w;
            for (i = 20; i < 512; i = i + 2) begin
                if (i < rx_count_reg) begin
                    if ((i + 1) < rx_count_reg) begin
                        udp_word_temp = {buf_mem[i], buf_mem[i+1]};
                    end else begin
                        udp_word_temp = {buf_mem[i], 8'h00};
                    end
                    udp_sum_calc = udp_sum_calc + udp_word_temp;
                end
            end
            if ((udp_checksum_w != 16'h0000) && (fold16(udp_sum_calc) != 16'hffff)) begin
                error_calc = 4'd4;
            end else if ((dst_ip_w != 32'h0a000002) || (udp_dst_port_w != 16'd9000)) begin
                error_calc = 4'd5;
            end
        end
    end
end

wire parser_ip_hdr_ready;
wire parser_udp_hdr_valid;
wire [31:0] parser_src_ip;
wire [15:0] parser_src_port;
wire [15:0] parser_dst_port;
wire [15:0] parser_length;
wire [7:0] parser_tdata;
wire parser_tvalid;
wire parser_tlast;

wire parser_tready;
assign parser_tready = (!hold_valid_reg) || m_ready;

udp_ip_rx parser_inst (
    .clk(clk),
    .rst(rst),

    .s_ip_hdr_valid(state_reg == ST_HDR),
    .s_ip_hdr_ready(parser_ip_hdr_ready),
    .s_eth_dest_mac(48'd0),
    .s_eth_src_mac(48'd0),
    .s_eth_type(16'h0800),
    .s_ip_version(buf_mem[0][7:4]),
    .s_ip_ihl(buf_mem[0][3:0]),
    .s_ip_dscp(buf_mem[1][7:2]),
    .s_ip_ecn(buf_mem[1][1:0]),
    .s_ip_length({buf_mem[2], buf_mem[3]}),
    .s_ip_identification({buf_mem[4], buf_mem[5]}),
    .s_ip_flags(buf_mem[6][7:5]),
    .s_ip_fragment_offset({buf_mem[6][4:0], buf_mem[7]}),
    .s_ip_ttl(buf_mem[8]),
    .s_ip_protocol(buf_mem[9]),
    .s_ip_header_checksum({buf_mem[10], buf_mem[11]}),
    .s_ip_source_ip({buf_mem[12], buf_mem[13], buf_mem[14], buf_mem[15]}),
    .s_ip_dest_ip({buf_mem[16], buf_mem[17], buf_mem[18], buf_mem[19]}),
    .s_ip_payload_axis_tdata(buf_mem[pay_ptr_reg]),
    .s_ip_payload_axis_tvalid((state_reg == ST_PAY) && !hold_valid_reg),
    .s_ip_payload_axis_tready(),
    .s_ip_payload_axis_tlast(pay_ptr_reg == (rx_count_reg - 10'd1)),
    .s_ip_payload_axis_tuser(1'b0),

    .m_udp_hdr_valid(parser_udp_hdr_valid),
    .m_udp_hdr_ready(1'b1),
    .m_eth_dest_mac(),
    .m_eth_src_mac(),
    .m_eth_type(),
    .m_ip_version(),
    .m_ip_ihl(),
    .m_ip_dscp(),
    .m_ip_ecn(),
    .m_ip_length(),
    .m_ip_identification(),
    .m_ip_flags(),
    .m_ip_fragment_offset(),
    .m_ip_ttl(),
    .m_ip_protocol(),
    .m_ip_header_checksum(),
    .m_ip_source_ip(parser_src_ip),
    .m_ip_dest_ip(),
    .m_udp_source_port(parser_src_port),
    .m_udp_dest_port(parser_dst_port),
    .m_udp_length(parser_length),
    .m_udp_checksum(),
    .m_udp_payload_axis_tdata(parser_tdata),
    .m_udp_payload_axis_tvalid(parser_tvalid),
    .m_udp_payload_axis_tready(parser_tready),
    .m_udp_payload_axis_tlast(parser_tlast),
    .m_udp_payload_axis_tuser(),

    .busy(),
    .error_header_early_termination(),
    .error_payload_early_termination(),
    .error_invalid_header(),
    .error_invalid_checksum()
);

assign s_ready = (!rst) && (state_reg == ST_RECV);
assign status_valid = status_valid_reg;
assign status_error = status_error_reg;

assign m_valid = hold_valid_reg;
assign m_data = hold_data_reg;
assign m_last = hold_last_reg;
assign m_src_ip = meta_src_ip_reg;
assign m_src_port = meta_src_port_reg;
assign m_dst_port = meta_dst_port_reg;
assign m_payload_len = meta_payload_len_reg;

always @(posedge clk) begin
    if (rst) begin
        state_reg <= ST_RECV;
        rx_count_reg <= 10'd0;
        oversize_reg <= 1'b0;
        status_valid_reg <= 1'b0;
        status_error_reg <= 4'd0;
        meta_src_ip_reg <= 32'd0;
        meta_src_port_reg <= 16'd0;
        meta_dst_port_reg <= 16'd0;
        meta_payload_len_reg <= 16'd0;
        pay_ptr_reg <= 10'd20;
        hold_valid_reg <= 1'b0;
        hold_data_reg <= 8'd0;
        hold_last_reg <= 1'b0;
    end else begin
        status_valid_reg <= 1'b0;

        if (hold_valid_reg && m_ready) begin
            hold_valid_reg <= 1'b0;
        end

        if (((!hold_valid_reg) || m_ready) && parser_tvalid) begin
            hold_valid_reg <= 1'b1;
            hold_data_reg <= parser_tdata;
            hold_last_reg <= parser_tlast;
        end

        case (state_reg)
            ST_RECV: begin
                rx_count_reg <= 10'd0 + rx_count_reg;
                if (s_valid) begin
                    if (rx_count_reg < 10'd512) begin
                        buf_mem[rx_count_reg] <= s_data;
                    end else begin
                        oversize_reg <= 1'b1;
                    end
                    rx_count_reg <= rx_count_reg + 10'd1;
                    if (s_last) begin
                        state_reg <= ST_STATUS;
                    end
                end
            end

            ST_STATUS: begin
                status_valid_reg <= 1'b1;
                status_error_reg <= error_calc;
                if (error_calc == 4'd0) begin
                    meta_src_ip_reg <= src_ip_w;
                    meta_src_port_reg <= udp_src_port_w;
                    meta_dst_port_reg <= udp_dst_port_w;
                    meta_payload_len_reg <= udp_length_w - 16'd8;
                    pay_ptr_reg <= 10'd20;
                    hold_valid_reg <= 1'b0;
                    state_reg <= ST_HDR;
                end else begin
                    rx_count_reg <= 10'd0;
                    oversize_reg <= 1'b0;
                    state_reg <= ST_RECV;
                end
            end

            ST_HDR: begin
                if (parser_ip_hdr_ready) begin
                    pay_ptr_reg <= 10'd20;
                    state_reg <= ST_PAY;
                end
            end

            ST_PAY: begin
                if (!hold_valid_reg && parser_tready) begin
                    if (pay_ptr_reg == (rx_count_reg - 10'd1)) begin
                        state_reg <= ST_WAIT;
                    end else begin
                        pay_ptr_reg <= pay_ptr_reg + 10'd1;
                    end
                end
            end

            ST_WAIT: begin
                if (!hold_valid_reg) begin
                    rx_count_reg <= 10'd0;
                    oversize_reg <= 1'b0;
                    state_reg <= ST_RECV;
                end
            end

            default: begin
                state_reg <= ST_RECV;
            end
        endcase
    end
end

endmodule
