module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

reg [7:0] bytes[0:511];

reg [2:0] state_reg;
localparam [2:0]
    ST_IDLE   = 3'd0,
    ST_STATUS = 3'd1,
    ST_HDR    = 3'd2,
    ST_PAY    = 3'd3,
    ST_WAIT   = 3'd4;

reg [9:0] n_reg;
reg oversize_reg;
reg [9:0] ptr_reg;

reg status_valid_reg;
reg [3:0] status_error_reg;

reg [3:0] error_code_reg;

wire [15:0] hdr_ip_length_w;
wire [15:0] hdr_udp_src_port_w;
wire [15:0] hdr_udp_dst_port_w;
wire [15:0] hdr_udp_length_w;
wire [31:0] hdr_src_ip_w;
wire [31:0] hdr_dst_ip_w;

assign hdr_ip_length_w     = {bytes[2],bytes[3]};
assign hdr_src_ip_w        = {bytes[12],bytes[13],bytes[14],bytes[15]};
assign hdr_dst_ip_w        = {bytes[16],bytes[17],bytes[18],bytes[19]};
assign hdr_udp_src_port_w  = {bytes[20],bytes[21]};
assign hdr_udp_dst_port_w  = {bytes[22],bytes[23]};
assign hdr_udp_length_w    = {bytes[24],bytes[25]};

function [16:0] fold17;
    input [31:0] value;
    reg [31:0] t;
    begin
        t = value;
        t = (t[15:0] + t[31:16]);
        t = (t[15:0] + t[31:16]);
        fold17 = t[16:0];
    end
endfunction

function [15:0] word16;
    input integer offset;
    begin
        word16 = {bytes[offset], bytes[offset+1]};
    end
endfunction

reg [31:0] ip_sum_calc;
reg [31:0] udp_sum_calc;
reg [3:0] error_code_calc;
integer j;
reg [15:0] udp_word;
reg [7:0] udp_hi;
reg [7:0] udp_lo;

always @* begin
    ip_sum_calc = 32'd0;
    udp_sum_calc = 32'd0;
    error_code_calc = 4'd0;

    if (n_reg < 10'd28 || oversize_reg || bytes[0][7:4] != 4'd4 || bytes[0][3:0] != 4'd5 || bytes[9] != 8'd17 || bytes[6][5] || ({bytes[6][4:0],bytes[7]} != 13'd0)) begin
        error_code_calc = 4'd1;
    end else if (hdr_ip_length_w != n_reg[15:0] || hdr_udp_length_w != (hdr_ip_length_w - 16'd20) || hdr_udp_length_w < 16'd9 || hdr_udp_length_w > 16'd264) begin
        error_code_calc = 4'd2;
    end else begin
        ip_sum_calc = 32'd0;
        for (j = 0; j < 20; j = j + 2) begin
            ip_sum_calc = ip_sum_calc + word16(j);
        end
        if (fold17(ip_sum_calc)[15:0] != 16'hffff) begin
            error_code_calc = 4'd3;
        end else begin
            udp_sum_calc = 32'd0;
            udp_sum_calc = udp_sum_calc + word16(12);
            udp_sum_calc = udp_sum_calc + word16(14);
            udp_sum_calc = udp_sum_calc + word16(16);
            udp_sum_calc = udp_sum_calc + word16(18);
            udp_sum_calc = udp_sum_calc + 16'h0011;
            udp_sum_calc = udp_sum_calc + hdr_udp_length_w;

            for (j = 20; j < 512; j = j + 2) begin
                if (j < n_reg) begin
                    udp_hi = bytes[j];
                    if ((j + 1) < n_reg)
                        udp_lo = bytes[j+1];
                    else
                        udp_lo = 8'h00;
                    udp_word = {udp_hi, udp_lo};
                    udp_sum_calc = udp_sum_calc + udp_word;
                end
            end

            if (word16(26) != 16'h0000 && fold17(udp_sum_calc)[15:0] != 16'hffff) begin
                error_code_calc = 4'd4;
            end else if (hdr_dst_ip_w != 32'h0a000002 || hdr_udp_dst_port_w != 16'd9000) begin
                error_code_calc = 4'd5;
            end
        end
    end
end

wire parser_hdr_ready;
wire parser_payload_ready;
wire [31:0] parser_src_ip;
wire [15:0] parser_src_port;
wire [15:0] parser_dst_port;
wire [15:0] parser_udp_length;
wire [7:0] parser_m_data;
wire parser_m_valid;
wire parser_m_last;

reg out_hold_valid_reg;
reg [7:0] out_hold_data_reg;
reg out_hold_last_reg;

reg [31:0] meta_src_ip_reg;
reg [15:0] meta_src_port_reg;
reg [15:0] meta_dst_port_reg;
reg [15:0] meta_payload_len_reg;

assign s_ready = !rst && (state_reg == ST_IDLE);

assign status_valid = status_valid_reg;
assign status_error = status_error_reg;

assign m_valid = out_hold_valid_reg;
assign m_data = out_hold_data_reg;
assign m_last = out_hold_last_reg;
assign m_src_ip = meta_src_ip_reg;
assign m_src_port = meta_src_port_reg;
assign m_dst_port = meta_dst_port_reg;
assign m_payload_len = meta_payload_len_reg;

udp_ip_rx parser(
    .clk(clk),
    .rst(rst),
    .s_ip_hdr_valid(state_reg == ST_HDR),
    .s_ip_hdr_ready(parser_hdr_ready),
    .s_eth_dest_mac(48'b0),
    .s_eth_src_mac(48'b0),
    .s_eth_type(16'h0800),
    .s_ip_version(bytes[0][7:4]),
    .s_ip_ihl(bytes[0][3:0]),
    .s_ip_dscp(bytes[1][7:2]),
    .s_ip_ecn(bytes[1][1:0]),
    .s_ip_length({bytes[2],bytes[3]}),
    .s_ip_identification({bytes[4],bytes[5]}),
    .s_ip_flags(bytes[6][7:5]),
    .s_ip_fragment_offset({bytes[6][4:0],bytes[7]}),
    .s_ip_ttl(bytes[8]),
    .s_ip_protocol(bytes[9]),
    .s_ip_header_checksum({bytes[10],bytes[11]}),
    .s_ip_source_ip({bytes[12],bytes[13],bytes[14],bytes[15]}),
    .s_ip_dest_ip({bytes[16],bytes[17],bytes[18],bytes[19]}),
    .s_ip_payload_axis_tdata(bytes[ptr_reg]),
    .s_ip_payload_axis_tvalid(state_reg == ST_PAY && !out_hold_valid_reg),
    .s_ip_payload_axis_tready(parser_payload_ready),
    .s_ip_payload_axis_tlast(ptr_reg == (n_reg - 10'd1)),
    .s_ip_payload_axis_tuser(1'b0),
    .m_udp_hdr_ready(1'b1),
    .m_ip_source_ip(parser_src_ip),
    .m_udp_source_port(parser_src_port),
    .m_udp_dest_port(parser_dst_port),
    .m_udp_length(parser_udp_length),
    .m_udp_payload_axis_tdata(parser_m_data),
    .m_udp_payload_axis_tvalid(parser_m_valid),
    .m_udp_payload_axis_tready(!out_hold_valid_reg || m_ready),
    .m_udp_payload_axis_tlast(parser_m_last)
);

always @(posedge clk) begin
    if (rst) begin
        state_reg <= ST_IDLE;
        n_reg <= 10'd0;
        oversize_reg <= 1'b0;
        ptr_reg <= 10'd20;
        status_valid_reg <= 1'b0;
        status_error_reg <= 4'd0;
        error_code_reg <= 4'd0;
        out_hold_valid_reg <= 1'b0;
        out_hold_data_reg <= 8'd0;
        out_hold_last_reg <= 1'b0;
        meta_src_ip_reg <= 32'd0;
        meta_src_port_reg <= 16'd0;
        meta_dst_port_reg <= 16'd0;
        meta_payload_len_reg <= 16'd0;
    end else begin
        status_valid_reg <= 1'b0;

        if (out_hold_valid_reg && m_ready) begin
            out_hold_valid_reg <= 1'b0;
        end

        if ((!out_hold_valid_reg || m_ready) && parser_m_valid) begin
            out_hold_valid_reg <= 1'b1;
            out_hold_data_reg <= parser_m_data;
            out_hold_last_reg <= parser_m_last;
        end

        case (state_reg)
            ST_IDLE: begin
                if (s_valid && s_ready) begin
                    if (n_reg < 10'd512) begin
                        bytes[n_reg] <= s_data;
                        n_reg <= n_reg + 10'd1;
                    end else begin
                        oversize_reg <= 1'b1;
                    end
                    if (s_last) begin
                        if (!oversize_reg && (n_reg + 10'd1) <= 10'd512)
                            bytes[n_reg] <= s_data;
                        state_reg <= ST_STATUS;
                    end
                end
            end

            ST_STATUS: begin
                error_code_reg <= error_code_calc;
                status_valid_reg <= 1'b1;
                status_error_reg <= error_code_calc;
                if (error_code_calc == 4'd0) begin
                    meta_src_ip_reg <= hdr_src_ip_w;
                    meta_src_port_reg <= hdr_udp_src_port_w;
                    meta_dst_port_reg <= hdr_udp_dst_port_w;
                    meta_payload_len_reg <= hdr_udp_length_w - 16'd8;
                    ptr_reg <= 10'd20;
                    out_hold_valid_reg <= 1'b0;
                    state_reg <= ST_HDR;
                end else begin
                    state_reg <= ST_IDLE;
                end
            end

            ST_HDR: begin
                if (parser_hdr_ready) begin
                    ptr_reg <= 10'd20;
                    state_reg <= ST_PAY;
                end
            end

            ST_PAY: begin
                if (!out_hold_valid_reg && parser_payload_ready) begin
                    if (ptr_reg == (n_reg - 10'd1)) begin
                        state_reg <= ST_WAIT;
                    end else begin
                        ptr_reg <= ptr_reg + 10'd1;
                    end
                end
            end

            ST_WAIT: begin
                if (!out_hold_valid_reg) begin
                    state_reg <= ST_IDLE;
                end
            end

            default: begin
                state_reg <= ST_IDLE;
            end
        endcase
    end
end

endmodule
