`timescale 1ns/1ps
`default_nettype none

module icache_ctrl(
input wire clk_i,
input wire rst_ni,
input wire req_i,
input wire branch_i,
input wire [31:0] addr_i,
input wire ready_i,
output wire valid_o,
output wire [31:0] rdata_o,
output wire [31:0] addr_o,
output wire err_o,
output wire instr_req_o,
input wire instr_gnt_i,
output wire [31:0] instr_addr_o,
input wire [31:0] instr_rdata_i,
input wire instr_err_i,
input wire instr_rvalid_i,
input wire icache_inval_i,
output wire busy_o);

reg [31:0] pc_q, pc_d;
reg [31:0] fetch_addr_q, fetch_addr_d;
reg [31:0] buf_addr [1:0];
reg [31:0] buf_data [1:0];
reg buf_err [1:0];
reg buf_valid [1:0];
reg [1:0] buf_cnt_q, buf_cnt_d;
reg req_outstanding_q, req_outstanding_d;
reg [4:0] resp_cnt_q, resp_cnt_d;
reg branch_q;
reg icache_inval_q;
reg busy_q;
reg valid_q;
reg [31:0] rdata_q;
reg [31:0] addr_q;
reg err_q;
reg [1:0] state_q, state_d;

localparam ST_IDLE = 2'd0;
localparam ST_FILL = 2'd1;
localparam ST_DRAIN = 2'd2;

wire [31:0] next_pc = {pc_q[31:2], 2'b00} + 32'd4;
wire hit0 = buf_valid[0] && (buf_addr[0] == pc_q);
wire hit1 = buf_valid[1] && (buf_addr[1] == pc_q);
wire hit = hit0 || hit1;
wire [31:0] hit_data = hit0 ? buf_data[0] : buf_data[1];
wire hit_err = hit0 ? buf_err[0] : buf_err[1];

always @(*) begin
  pc_d = pc_q;
  fetch_addr_d = fetch_addr_q;
  buf_cnt_d = buf_cnt_q;
  req_outstanding_d = req_outstanding_q;
  resp_cnt_d = resp_cnt_q;
  state_d = state_q;
  valid_q = 1'b0;
  rdata_q = 32'd0;
  addr_q = 32'd0;
  err_q = 1'b0;
  busy_q = 1'b0;

  if (branch_i) begin
    pc_d = addr_i;
    fetch_addr_d = addr_i;
    buf_cnt_d = 2'd0;
    req_outstanding_d = 1'b0;
    resp_cnt_d = 5'd0;
    state_d = ST_FILL;
  end else if (ready_i && valid_o) begin
    pc_d = next_pc;
  end

  case (state_q)
    ST_IDLE: begin
      if (req_i && !hit) begin
        state_d = ST_FILL;
      end
    end
    ST_FILL: begin
      busy_q = req_outstanding_q || (buf_cnt_q != 2'd0);
      if (req_i && buf_cnt_q < 2'd2) begin
        if (!req_outstanding_q) begin
          req_outstanding_d = 1'b1;
          fetch_addr_d = {fetch_addr_q[31:4], 4'd0} + 32'd8;
        end
      end
    end
    ST_DRAIN: begin
      busy_q = resp_cnt_q != 5'd0;
    end
  endcase
end

always @(posedge clk_i or negedge rst_ni) begin
  if (!rst_ni) begin
    pc_q <= 32'd0;
    fetch_addr_q <= 32'd0;
    buf_cnt_q <= 2'd0;
    req_outstanding_q <= 1'b0;
    resp_cnt_q <= 5'd0;
    state_q <= ST_IDLE;
    branch_q <= 1'b0;
    icache_inval_q <= 1'b0;
    buf_valid[0] <= 1'b0;
    buf_valid[1] <= 1'b0;
  end else begin
    pc_q <= pc_d;
    fetch_addr_q <= fetch_addr_d;
    buf_cnt_q <= buf_cnt_d;
    req_outstanding_q <= req_outstanding_d;
    resp_cnt_q <= resp_cnt_d;
    state_q <= state_d;
    branch_q <= branch_i;
    icache_inval_q <= icache_inval_i;

    if (branch_i) begin
      buf_valid[0] <= 1'b0;
      buf_valid[1] <= 1'b0;
    end

    if (instr_rvalid_i) begin
      if (buf_cnt_q < 2'd2) begin
        buf_addr[buf_cnt_q] <= fetch_addr_q;
        buf_data[buf_cnt_q] <= instr_rdata_i;
        buf_err[buf_cnt_q] <= instr_err_i;
        buf_valid[buf_cnt_q] <= 1'b1;
        buf_cnt_d <= buf_cnt_q + 2'd1;
      end
      resp_cnt_d <= resp_cnt_q + 5'd1;
    end

    if (ready_i && valid_o) begin
      if (hit0) buf_valid[0] <= 1'b0;
      if (hit1) buf_valid[1] <= 1'b0;
      if (buf_cnt_q > 2'd0) buf_cnt_d <= buf_cnt_q - 2'd1;
    end

    if (instr_gnt_i && req_outstanding_q) begin
      req_outstanding_d <= 1'b0;
    end
  end
end

wire output_valid = hit;
assign valid_o = output_valid;
assign rdata_o = hit_data;
assign addr_o = pc_q;
assign err_o = hit_err;
assign instr_req_o = req_i && !req_outstanding_q && (buf_cnt_q < 2'd2) && !hit;
assign instr_addr_o = {fetch_addr_q[31:4], 4'd0} + (buf_cnt_q == 2'd0 ? 32'd0 : 32'd4);
assign busy_o = req_outstanding_q || (resp_cnt_q != 5'd0) || icache_inval_i;

endmodule
