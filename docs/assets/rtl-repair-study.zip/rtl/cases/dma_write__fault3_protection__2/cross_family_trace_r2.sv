module dma_write(
    input wire clk,
    input wire rst,
    input wire [15:0] desc_addr,
    input wire [15:0] desc_len,
    input wire [7:0] desc_tag,
    input wire desc_valid,
    output wire desc_ready,
    input wire [31:0] s_data,
    input wire [3:0] s_keep,
    input wire s_valid,
    output wire s_ready,
    input wire s_last,
    output wire [15:0] status_len,
    output wire [7:0] status_tag,
    output wire [3:0] status_error,
    output wire status_valid,
    output wire [3:0] m_axi_awid,
    output wire [15:0] m_axi_awaddr,
    output wire [7:0] m_axi_awlen,
    output wire [2:0] m_axi_awsize,
    output wire [1:0] m_axi_awburst,
    output wire m_axi_awlock,
    output wire [3:0] m_axi_awcache,
    output wire [2:0] m_axi_awprot,
    output wire m_axi_awvalid,
    input wire m_axi_awready,
    output wire [31:0] m_axi_wdata,
    output wire [3:0] m_axi_wstrb,
    output wire m_axi_wlast,
    output wire m_axi_wvalid,
    input wire m_axi_wready,
    input wire [3:0] m_axi_bid,
    input wire [1:0] m_axi_bresp,
    input wire m_axi_bvalid,
    output wire m_axi_bready
);

    // Fixed constant output assignments
    assign m_axi_awid    = 4'd0;
    assign m_axi_awsize  = 3'd2;   // 4-byte wide
    assign m_axi_awburst = 2'd1;   // INCR
    assign m_axi_awlock  = 1'b0;
    assign m_axi_awcache = 4'd3;
    assign m_axi_awprot  = 3'd0;

    // Internal state
    localparam STATE_IDLE    = 2'd0;
    localparam STATE_ACTIVE  = 2'd1;
    localparam STATE_DONE    = 2'd2;

    reg [1:0] state, state_next;
    reg [15:0] i_addr, i_addr_next;
    reg [15:0] remain, remain_next;
    reg [7:0]  tag_reg, tag_next;
    reg [1:0]  err_reg, err_next;
    reg        aw_active, aw_active_next;
    reg [7:0]  aw_len, aw_len_next;
    reg [15:0] aw_addr, aw_addr_next;
    reg [15:0] burst_remain, burst_remain_next;
    reg [15:0] w_count, w_count_next;
    reg        w_last_reg, w_last_next;
    reg        b_pending_burst, b_pending_burst_next;

    // Combinational outputs
    wire desc_accept;
    wire write_active;
    wire axi_aw_hs;
    wire axi_w_hs;
    wire axi_b_hs;

    assign desc_accept = desc_valid && desc_ready;
    assign axi_aw_hs   = m_axi_awvalid && m_axi_awready;
    assign axi_w_hs    = m_axi_wvalid  && m_axi_wready;
    assign axi_b_hs    = m_axi_bvalid  && m_axi_bready;

    // Desc ready: accept when idle
    assign desc_ready = (state == STATE_IDLE);

    // Status output values
    assign status_len   = remain;
    assign status_tag   = tag_reg;
    assign status_error = (err_reg[1]) ? 4'd7 : (err_reg[0] ? 4'd6 : 4'd0);
    assign status_valid = (state == STATE_DONE);

    // Stream read side
    assign write_active = (state == STATE_ACTIVE) && (remain > 0);
    assign s_ready = write_active && ((m_axi_wvalid && m_axi_wready) || !m_axi_wvalid) && (w_count < burst_remain);

    // AXI Write data channel
    wire [1:0] byte_offset;
    reg [3:0] lane_mask;
    assign byte_offset = i_addr[1:0];
    always @* begin
        if (w_count == 0) begin
            case (byte_offset)
                2'd0: lane_mask = 4'b1111;
                2'd1: lane_mask = 4'b1110;
                2'd2: lane_mask = 4'b1100;
                default: lane_mask = 4'b1000;
            endcase
        end else begin
            lane_mask = 4'b1111;
        end
    end

    assign m_axi_wdata  = s_data;
    assign m_axi_wstrb  = s_keep & lane_mask;
    assign m_axi_wlast  = w_last_reg;
    assign m_axi_wvalid = write_active && s_valid;

    // AXI AW channel
    assign m_axi_awaddr  = aw_addr;
    assign m_axi_awlen   = aw_len;
    assign m_axi_awvalid = aw_active && (state == STATE_ACTIVE);

    // B ready always high
    assign m_axi_bready = 1'b1;

    // Page boundary calculation
    wire [15:0] page_boundary;
    wire [15:0] max_beats_boundary;
    wire [15:0] max_beats_remain;
    wire [7:0] beats;
    wire [7:0] final_beats;

    assign page_boundary = 16'h1000 - i_addr[11:0];
    assign max_beats_boundary = page_boundary >> 2;
    assign max_beats_remain = (remain + 3) >> 2;
    assign beats = (max_beats_remain < 16) ? max_beats_remain[7:0] : 8'd16;
    assign final_beats = (beats < max_beats_boundary) ? beats : max_beats_boundary[7:0];

    // Next-state logic
    always @* begin
        state_next         = state;
        i_addr_next        = i_addr;
        remain_next        = remain;
        tag_next           = tag_reg;
        err_next           = err_reg;
        aw_active_next     = aw_active;
        aw_len_next        = aw_len;
        aw_addr_next       = aw_addr;
        burst_remain_next  = burst_remain;
        w_count_next       = w_count;
        w_last_next        = w_last_reg;
        b_pending_burst_next = b_pending_burst;

        case (state)
            STATE_IDLE: begin
                if (desc_accept) begin
                    i_addr_next        = desc_addr;
                    remain_next        = desc_len;
                    tag_next           = desc_tag;
                    err_next           = 2'd0;
                    state_next         = STATE_ACTIVE;
                    aw_active_next     = 1'b0;
                    aw_len_next        = 8'd0;
                    aw_addr_next       = 16'd0;
                    burst_remain_next  = 16'd0;
                    w_count_next       = 16'd0;
                    w_last_next        = 1'b0;
                    b_pending_burst_next = 1'b0;
                end
            end

            STATE_ACTIVE: begin
                // AW channel management
                if (!aw_active && (remain > 0) && !b_pending_burst) begin
                    aw_active_next     = 1'b1;
                    aw_len_next        = final_beats - 8'd1;
                    aw_addr_next       = i_addr;
                    burst_remain_next  = {8'd0, final_beats};
                    w_count_next       = 16'd0;
                    w_last_next        = 1'b0;
                end

                // AW handshake
                if (axi_aw_hs) begin
                    aw_active_next = 1'b0;
                end

                // W channel management
                if (axi_w_hs) begin
                    w_count_next = w_count + 16'd1;
                    remain_next = remain - 16'd4;
                    i_addr_next = i_addr + 16'd4;
                end

                // WLAST logic
                if (axi_w_hs && (w_count == burst_remain - 1)) begin
                    b_pending_burst_next = 1'b1;
                end

                if (axi_w_hs && w_last_reg) begin
                    w_last_next = 1'b0;
                end

                if (!axi_w_hs && (w_count == burst_remain - 1) && m_axi_wvalid) begin
                    w_last_next = 1'b1;
                end else if (!m_axi_wvalid) begin
                    w_last_next = (w_count == burst_remain - 1);
                end

                // B response handling
                if (axi_b_hs) begin
                    if (m_axi_bresp == 2'b11) err_next[1] = 1'b1;
                    else if (m_axi_bresp == 2'b10 && !err_next[1]) err_next[0] = 1'b1;

                    if (b_pending_burst) begin
                        b_pending_burst_next = 1'b0;
                        if (remain == 0) begin
                            state_next = STATE_DONE;
                        end
                    end
                end
            end

            STATE_DONE: begin
                state_next = STATE_IDLE;
            end
        endcase
    end

    always @(posedge clk) begin
        if (rst) begin
            state         <= STATE_IDLE;
            i_addr        <= 16'd0;
            remain        <= 16'd0;
            tag_reg       <= 8'd0;
            err_reg       <= 2'd0;
            aw_active     <= 1'b0;
            aw_len        <= 8'd0;
            aw_addr       <= 16'd0;
            burst_remain  <= 16'd0;
            w_count       <= 16'd0;
            w_last_reg    <= 1'b0;
            b_pending_burst <= 1'b0;
        end else begin
            state         <= state_next;
            i_addr        <= i_addr_next;
            remain        <= remain_next;
            tag_reg       <= tag_next;
            err_reg       <= err_next;
            aw_active     <= aw_active_next;
            aw_len        <= aw_len_next;
            aw_addr       <= aw_addr_next;
            burst_remain  <= burst_remain_next;
            w_count       <= w_count_next;
            w_last_reg    <= w_last_next;
            b_pending_burst <= b_pending_burst_next;
        end
    end

endmodule
