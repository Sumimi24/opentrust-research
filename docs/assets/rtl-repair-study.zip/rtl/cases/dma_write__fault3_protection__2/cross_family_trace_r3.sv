`timescale 1ns/1ps
module dma_write(
    input wire clk,
    input wire rst,
    input wire [15:0] desc_addr,
    input wire [15:0] desc_len,
    input wire [7:0] desc_tag,
    input wire desc_valid,
    output wire desc_ready,
    input wire [31:0] s_data,
    input wire [3:0] s_keep,
    input wire s_valid,
    output wire s_ready,
    input wire s_last,
    output wire [15:0] status_len,
    output wire [7:0] status_tag,
    output wire [3:0] status_error,
    output wire status_valid,
    output wire [3:0] m_axi_awid,
    output wire [15:0] m_axi_awaddr,
    output wire [7:0] m_axi_awlen,
    output wire [2:0] m_axi_awsize,
    output wire [1:0] m_axi_awburst,
    output wire m_axi_awlock,
    output wire [3:0] m_axi_awcache,
    output wire [2:0] m_axi_awprot,
    output wire m_axi_awvalid,
    input wire m_axi_awready,
    output wire [31:0] m_axi_wdata,
    output wire [3:0] m_axi_wstrb,
    output wire m_axi_wlast,
    output wire m_axi_wvalid,
    input wire m_axi_wready,
    input wire [3:0] m_axi_bid,
    input wire [1:0] m_axi_bresp,
    input wire m_axi_bvalid,
    output wire m_axi_bready
);

    reg active_reg = 1'b0;

    reg [15:0] desc_addr_reg = 16'd0;
    reg [15:0] desc_len_reg = 16'd0;
    reg [7:0] desc_tag_reg = 8'd0;

    reg [15:0] bytes_received_reg = 16'd0;
    reg [15:0] bytes_sent_reg = 16'd0;
    reg [15:0] bytes_acked_reg = 16'd0;

    reg [15:0] frame_start_addr_reg = 16'd0;
    reg [15:0] frame_end_addr_reg = 16'd0;

    reg [31:0] data_mem_reg[0:127];
    reg [3:0] keep_mem_reg[0:127];

    reg [15:0] burst_addr_reg = 16'd0;
    reg [7:0] burst_beats_reg = 8'd0;
    reg [15:0] burst_bytes_reg = 16'd0;
    reg awvalid_reg = 1'b0;
    reg [15:0] burst_sent_bytes_reg = 16'd0;
    reg [7:0] burst_sent_beats_reg = 8'd0;
    reg wvalid_reg = 1'b0;
    reg [31:0] wdata_reg = 32'd0;
    reg [3:0] wstrb_reg = 4'd0;
    reg wlast_reg = 1'b0;
    reg burst_active_reg = 1'b0;
    reg b_pending_reg = 1'b0;

    reg [15:0] status_len_reg = 16'd0;
    reg [7:0] status_tag_reg = 8'd0;
    reg [3:0] status_error_reg = 4'd0;
    reg status_valid_reg = 1'b0;

    reg slverr_seen_reg = 1'b0;
    reg decerr_seen_reg = 1'b0;

    integer i;

    wire [15:0] rec_word_index;
    wire [15:0] rec_byte_offset;
    wire [15:0] rec_bytes_left;
    wire [3:0] rec_expected_keep;

    assign rec_word_index = bytes_received_reg >> 2;
    assign rec_byte_offset = frame_start_addr_reg + bytes_received_reg;
    assign rec_bytes_left = desc_len_reg - bytes_received_reg;
    assign rec_expected_keep =
        (rec_byte_offset[1:0] == 2'd0) ? ((rec_bytes_left >= 16'd4) ? 4'b1111 :
                                          (rec_bytes_left == 16'd3) ? 4'b0111 :
                                          (rec_bytes_left == 16'd2) ? 4'b0011 :
                                          4'b0001) :
        (rec_byte_offset[1:0] == 2'd1) ? ((rec_bytes_left >= 16'd4) ? 4'b1110 :
                                          (rec_bytes_left == 16'd3) ? 4'b1110 :
                                          (rec_bytes_left == 16'd2) ? 4'b0110 :
                                          4'b0010) :
        (rec_byte_offset[1:0] == 2'd2) ? ((rec_bytes_left >= 16'd4) ? 4'b1100 :
                                          (rec_bytes_left >= 16'd2) ? 4'b1100 :
                                          4'b0100) :
                                          4'b1000;

    wire desc_handshake;
    wire s_handshake;
    wire aw_handshake;
    wire w_handshake;
    wire b_handshake;

    assign desc_handshake = desc_valid && desc_ready;
    assign s_handshake = s_valid && s_ready;
    assign aw_handshake = awvalid_reg && m_axi_awready;
    assign w_handshake = wvalid_reg && m_axi_wready;
    assign b_handshake = m_axi_bvalid && m_axi_bready;

    assign desc_ready = !active_reg;

    assign s_ready = active_reg && (bytes_received_reg < desc_len_reg);

    assign status_len = status_len_reg;
    assign status_tag = status_tag_reg;
    assign status_error = status_error_reg;
    assign status_valid = status_valid_reg;

    assign m_axi_awid = 4'd0;
    assign m_axi_awaddr = burst_addr_reg;
    assign m_axi_awlen = burst_beats_reg - 8'd1;
    assign m_axi_awsize = 3'd2;
    assign m_axi_awburst = 2'b01;
    assign m_axi_awlock = 1'b0;
    assign m_axi_awcache = 4'd3;
    assign m_axi_awprot = 3'd0;
    assign m_axi_awvalid = awvalid_reg;

    assign m_axi_wdata = wdata_reg;
    assign m_axi_wstrb = wstrb_reg;
    assign m_axi_wlast = wlast_reg;
    assign m_axi_wvalid = wvalid_reg;

    assign m_axi_bready = 1'b1;

    function [7:0] calc_burst_beats;
        input [15:0] addr_in;
        input [15:0] bytes_left_in;
        reg [15:0] bytes_to_4k;
        reg [15:0] beats_to_4k;
        reg [15:0] total_span;
        reg [15:0] beats_needed;
        reg [15:0] beats_tmp;
        begin
            bytes_to_4k = 16'd4096 - {4'd0, addr_in[11:0]};
            beats_to_4k = bytes_to_4k >> 2;
            if (beats_to_4k == 16'd0)
                beats_to_4k = 16'd1;

            total_span = addr_in[1:0] + bytes_left_in;
            beats_needed = (total_span + 16'd3) >> 2;

            beats_tmp = beats_needed;
            if (beats_tmp > 16'd16)
                beats_tmp = 16'd16;
            if (beats_tmp > beats_to_4k)
                beats_tmp = beats_to_4k;
            if (beats_tmp == 16'd0)
                beats_tmp = 16'd1;

            calc_burst_beats = beats_tmp[7:0];
        end
    endfunction

    function [3:0] calc_wstrb;
        input [15:0] base_addr;
        input [15:0] total_len;
        input [15:0] beat_idx;
        reg [15:0] start_off;
        reg [15:0] end_off;
        reg [15:0] lane;
        reg [3:0] mask;
        begin
            start_off = base_addr[1:0];
            end_off = start_off + total_len;
            mask = 4'b0000;
            for (lane = 0; lane < 4; lane = lane + 1) begin
                if (((beat_idx << 2) + lane) >= start_off && ((beat_idx << 2) + lane) < end_off)
                    mask[lane] = 1'b1;
            end
            calc_wstrb = mask;
        end
    endfunction

    function [31:0] get_word_data;
        input [15:0] beat_idx;
        begin
            get_word_data = data_mem_reg[beat_idx[6:0]];
        end
    endfunction

    always @(posedge clk) begin
        if (rst) begin
            active_reg <= 1'b0;
            desc_addr_reg <= 16'd0;
            desc_len_reg <= 16'd0;
            desc_tag_reg <= 8'd0;
            bytes_received_reg <= 16'd0;
            bytes_sent_reg <= 16'd0;
            bytes_acked_reg <= 16'd0;
            frame_start_addr_reg <= 16'd0;
            frame_end_addr_reg <= 16'd0;
            burst_addr_reg <= 16'd0;
            burst_beats_reg <= 8'd0;
            burst_bytes_reg <= 16'd0;
            awvalid_reg <= 1'b0;
            burst_sent_bytes_reg <= 16'd0;
            burst_sent_beats_reg <= 8'd0;
            wvalid_reg <= 1'b0;
            wdata_reg <= 32'd0;
            wstrb_reg <= 4'd0;
            wlast_reg <= 1'b0;
            burst_active_reg <= 1'b0;
            b_pending_reg <= 1'b0;
            status_len_reg <= 16'd0;
            status_tag_reg <= 8'd0;
            status_error_reg <= 4'd0;
            status_valid_reg <= 1'b0;
            slverr_seen_reg <= 1'b0;
            decerr_seen_reg <= 1'b0;
            for (i = 0; i < 128; i = i + 1) begin
                data_mem_reg[i] <= 32'd0;
                keep_mem_reg[i] <= 4'd0;
            end
        end else begin
            status_valid_reg <= 1'b0;

            if (desc_handshake) begin
                active_reg <= 1'b1;
                desc_addr_reg <= desc_addr;
                desc_len_reg <= desc_len;
                desc_tag_reg <= desc_tag;
                bytes_received_reg <= 16'd0;
                bytes_sent_reg <= 16'd0;
                bytes_acked_reg <= 16'd0;
                frame_start_addr_reg <= {desc_addr[15:2], 2'b00};
                frame_end_addr_reg <= desc_addr + desc_len;
                burst_addr_reg <= 16'd0;
                burst_beats_reg <= 8'd0;
                burst_bytes_reg <= 16'd0;
                awvalid_reg <= 1'b0;
                burst_sent_bytes_reg <= 16'd0;
                burst_sent_beats_reg <= 8'd0;
                wvalid_reg <= 1'b0;
                wdata_reg <= 32'd0;
                wstrb_reg <= 4'd0;
                wlast_reg <= 1'b0;
                burst_active_reg <= 1'b0;
                b_pending_reg <= 1'b0;
                slverr_seen_reg <= 1'b0;
                decerr_seen_reg <= 1'b0;
                for (i = 0; i < 128; i = i + 1) begin
                    keep_mem_reg[i] <= 4'd0;
                end
            end

            if (s_handshake) begin
                data_mem_reg[rec_word_index[6:0]] <= s_data;
                keep_mem_reg[rec_word_index[6:0]] <= s_keep;
                bytes_received_reg <= bytes_received_reg + ((rec_expected_keep[0] ? 16'd1 : 16'd0) +
                                                             (rec_expected_keep[1] ? 16'd1 : 16'd0) +
                                                             (rec_expected_keep[2] ? 16'd1 : 16'd0) +
                                                             (rec_expected_keep[3] ? 16'd1 : 16'd0));
            end

            if (active_reg && !burst_active_reg && !awvalid_reg && !wvalid_reg && !b_pending_reg && (bytes_sent_reg < desc_len_reg)) begin
                burst_addr_reg <= frame_start_addr_reg + bytes_sent_reg;
                burst_beats_reg <= calc_burst_beats(frame_start_addr_reg + bytes_sent_reg, desc_len_reg - bytes_sent_reg);
                burst_bytes_reg <= desc_len_reg - bytes_sent_reg;
                awvalid_reg <= 1'b1;
                burst_active_reg <= 1'b1;
                burst_sent_beats_reg <= 8'd0;
                burst_sent_bytes_reg <= bytes_sent_reg;
            end

            if (aw_handshake) begin
                awvalid_reg <= 1'b0;
            end

            if (burst_active_reg && !wvalid_reg && (burst_sent_beats_reg < burst_beats_reg) && (bytes_received_reg >= (burst_sent_bytes_reg + (((burst_sent_beats_reg + 8'd1) << 2) - burst_addr_reg[1:0]) ? 16'd0 : 16'd0))) begin
                if (bytes_received_reg >= (((burst_sent_beats_reg + 16'd1) << 2) >= burst_addr_reg[1:0] ? (burst_sent_bytes_reg + (((burst_sent_beats_reg + 16'd1) << 2) - burst_addr_reg[1:0])) : burst_sent_bytes_reg)) begin
                    wdata_reg <= get_word_data((burst_sent_bytes_reg >> 2) + burst_sent_beats_reg);
                    wstrb_reg <= calc_wstrb(burst_addr_reg, burst_bytes_reg, burst_sent_beats_reg);
                    wlast_reg <= (burst_sent_beats_reg + 8'd1 == burst_beats_reg);
                    wvalid_reg <= 1'b1;
                end
            end

            if (w_handshake) begin
                wvalid_reg <= 1'b0;
                burst_sent_beats_reg <= burst_sent_beats_reg + 8'd1;
                if (wlast_reg) begin
                    b_pending_reg <= 1'b1;
                end
            end

            if (burst_active_reg && !wvalid_reg && (burst_sent_beats_reg == burst_beats_reg) && !b_pending_reg) begin
                b_pending_reg <= 1'b1;
            end

            if (b_handshake) begin
                if (m_axi_bresp == 2'b10)
                    slverr_seen_reg <= 1'b1;
                if (m_axi_bresp == 2'b11)
                    decerr_seen_reg <= 1'b1;

                if (b_pending_reg) begin
                    b_pending_reg <= 1'b0;
                    burst_active_reg <= 1'b0;
                    bytes_sent_reg <= bytes_sent_reg + burst_bytes_reg;
                    bytes_acked_reg <= bytes_acked_reg + burst_bytes_reg;

                    if (bytes_sent_reg + burst_bytes_reg >= desc_len_reg) begin
                        active_reg <= 1'b0;
                        status_len_reg <= desc_len_reg;
                        status_tag_reg <= desc_tag_reg;
                        if (decerr_seen_reg || (m_axi_bresp == 2'b11))
                            status_error_reg <= 4'd7;
                        else if (slverr_seen_reg || (m_axi_bresp == 2'b10))
                            status_error_reg <= 4'd6;
                        else
                            status_error_reg <= 4'd0;
                        status_valid_reg <= 1'b1;
                    end
                end
            end
        end
    end

endmodule
