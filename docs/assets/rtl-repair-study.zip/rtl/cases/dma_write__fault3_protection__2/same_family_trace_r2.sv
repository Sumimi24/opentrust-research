module dma_write(
    input wire clk,
    input wire rst,
    input wire [15:0] desc_addr,
    input wire [15:0] desc_len,
    input wire [7:0] desc_tag,
    input wire desc_valid,
    output wire desc_ready,
    input wire [31:0] s_data,
    input wire [3:0] s_keep,
    input wire s_valid,
    output wire s_ready,
    input wire s_last,
    output wire [15:0] status_len,
    output wire [7:0] status_tag,
    output wire [3:0] status_error,
    output wire status_valid,
    output wire [3:0] m_axi_awid,
    output wire [15:0] m_axi_awaddr,
    output wire [7:0] m_axi_awlen,
    output wire [2:0] m_axi_awsize,
    output wire [1:0] m_axi_awburst,
    output wire m_axi_awlock,
    output wire [3:0] m_axi_awcache,
    output wire [2:0] m_axi_awprot,
    output wire m_axi_awvalid,
    input wire m_axi_awready,
    output wire [31:0] m_axi_wdata,
    output wire [3:0] m_axi_wstrb,
    output wire m_axi_wlast,
    output wire m_axi_wvalid,
    input wire m_axi_wready,
    input wire [3:0] m_axi_bid,
    input wire [1:0] m_axi_bresp,
    input wire m_axi_bvalid,
    output wire m_axi_bready
);

    assign m_axi_awid    = 4'd0;
    assign m_axi_awsize  = 3'd2;
    assign m_axi_awburst = 2'd1;
    assign m_axi_awlock  = 1'b0;
    assign m_axi_awcache = 4'd3;
    assign m_axi_awprot  = 3'd0;

    localparam STATE_IDLE   = 2'd0;
    localparam STATE_ACTIVE = 2'd1;
    localparam STATE_DONE   = 2'd2;

    reg [1:0]  state, state_next;
    reg [15:0] i_addr, i_addr_next;
    reg [15:0] remain, remain_next;
    reg [7:0]  tag_reg, tag_next;
    reg [1:0]  err_reg, err_next;
    reg        aw_active, aw_active_next;
    reg [7:0]  aw_len, aw_len_next;
    reg [15:0] aw_addr, aw_addr_next;
    reg [15:0] burst_remain, burst_remain_next;
    reg [15:0] w_cnt, w_cnt_next;
    reg        w_last, w_last_next;
    reg        b_pend, b_pend_next;

    assign desc_ready = (state == STATE_IDLE);

    assign status_len   = remain;
    assign status_tag   = tag_reg;
    assign status_error = err_reg[1] ? 4'd7 : (err_reg[0] ? 4'd6 : 4'd0);
    assign status_valid = (state == STATE_DONE);

    wire active_wr;
    assign active_wr = (state == STATE_ACTIVE) && (remain > 0) && !b_pend;

    wire [1:0] byte_off;
    assign byte_off = i_addr[1:0];

    wire [3:0] first_mask;
    assign first_mask = (byte_off == 2'd0) ? 4'b1111 :
                        (byte_off == 2'd1) ? 4'b1110 :
                        (byte_off == 2'd2) ? 4'b1100 : 4'b1000;

    wire [3:0] wstrb_int;
    assign wstrb_int = (w_cnt == 0) ? (s_keep & first_mask) : s_keep;

    wire this_last;
    assign this_last = (w_cnt == burst_remain - 1);

    assign m_axi_wdata  = s_data;
    assign m_axi_wstrb  = wstrb_int;
    assign m_axi_wlast  = w_last;
    assign m_axi_wvalid = active_wr && s_valid;
    assign s_ready      = active_wr && ((m_axi_wvalid && m_axi_wready) || !m_axi_wvalid);

    assign m_axi_awaddr  = aw_addr;
    assign m_axi_awlen   = aw_len;
    assign m_axi_awvalid = aw_active && (state == STATE_ACTIVE);
    assign m_axi_bready  = 1'b1;

    wire desc_acc;
    assign desc_acc = desc_valid && desc_ready;

    always @* begin
        state_next        = state;
        i_addr_next       = i_addr;
        remain_next       = remain;
        tag_next          = tag_reg;
        err_next          = err_reg;
        aw_active_next    = aw_active;
        aw_len_next       = aw_len;
        aw_addr_next      = aw_addr;
        burst_remain_next = burst_remain;
        w_cnt_next        = w_cnt;
        w_last_next       = w_last;
        b_pend_next       = b_pend;

        case (state)
            STATE_IDLE: begin
                if (desc_acc) begin
                    i_addr_next        = desc_addr;
                    remain_next        = desc_len;
                    tag_next           = desc_tag;
                    err_next           = 2'd0;
                    state_next         = STATE_ACTIVE;
                    aw_active_next     = 1'b0;
                    burst_remain_next  = 16'd0;
                    w_cnt_next         = 16'd0;
                    w_last_next        = 1'b0;
                    b_pend_next        = 1'b0;
                end
            end

            STATE_ACTIVE: begin
                if (!aw_active && (remain > 0) && !b_pend) begin
                    wire [15:0] pg_left;
                    assign pg_left = 16'h1000 - i_addr[11:0];
                    wire [15:0] max_remain;
                    assign max_remain = (remain + 3) >> 2;
                    wire [7:0] cand;
                    assign cand = (max_remain < 16) ? max_remain[7:0] : 8'd16;
                    wire [7:0] beats;
                    assign beats = (cand < pg_left[7:0]) ? cand : pg_left[7:0];
                    aw_active_next    = 1'b1;
                    aw_len_next       = beats - 8'd1;
                    aw_addr_next      = i_addr;
                    burst_remain_next = {8'd0, beats};
                    w_cnt_next        = 16'd0;
                    w_last_next       = 1'b0;
                end

                if (aw_active && m_axi_awvalid && m_axi_awready)
                    aw_active_next = 1'b0;

                if (m_axi_wvalid && m_axi_wready) begin
                    w_cnt_next = w_cnt + 16'd1;
                    remain_next = remain - 16'd4;
                    i_addr_next = i_addr + 16'd4;
                    if (this_last) begin
                        b_pend_next = 1'b1;
                    end
                end

                if (!m_axi_wvalid)
                    w_last_next = this_last;
                else if (m_axi_wready)
                    w_last_next = (w_cnt_next == burst_remain);
                else
                    w_last_next = w_last;

                if (m_axi_bvalid && m_axi_bready) begin
                    if (m_axi_bresp == 2'b11)
                        err_next[1] = 1'b1;
                    else if (m_axi_bresp == 2'b10 && !err_next[1])
                        err_next[0] = 1'b1;
                    if (b_pend) begin
                        b_pend_next = 1'b0;
                        if (remain == 0)
                            state_next = STATE_DONE;
                    end
                end
            end

            STATE_DONE: begin
                state_next = STATE_IDLE;
            end
        endcase
    end

    always @(posedge clk) begin
        if (rst) begin
            state        <= STATE_IDLE;
            i_addr       <= 16'd0;
            remain       <= 16'd0;
            tag_reg      <= 8'd0;
            err_reg      <= 2'd0;
            aw_active    <= 1'b0;
            aw_len       <= 8'd0;
            aw_addr      <= 16'd0;
            burst_remain <= 16'd0;
            w_cnt        <= 16'd0;
            w_last       <= 1'b0;
            b_pend       <= 1'b0;
        end else begin
            state        <= state_next;
            i_addr       <= i_addr_next;
            remain       <= remain_next;
            tag_reg      <= tag_next;
            err_reg      <= err_next;
            aw_active    <= aw_active_next;
            aw_len       <= aw_len_next;
            aw_addr      <= aw_addr_next;
            burst_remain <= burst_remain_next;
            w_cnt        <= w_cnt_next;
            w_last       <= w_last_next;
            b_pend       <= b_pend_next;
        end
    end

endmodule
