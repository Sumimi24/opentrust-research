module udp_rx_guard(
    input wire clk,
    input wire rst,
    input wire [7:0] s_data,
    input wire s_valid,
    output wire s_ready,
    input wire s_last,
    output wire [7:0] m_data,
    output wire m_valid,
    input wire m_ready,
    output wire m_last,
    output wire [31:0] m_src_ip,
    output wire [15:0] m_src_port,
    output wire [15:0] m_dst_port,
    output wire [15:0] m_payload_len,
    output wire status_valid,
    output wire [3:0] status_error
);

    localparam ST_IDLE       = 3'd0;
    localparam ST_EVALUATE   = 3'd1;
    localparam ST_STATUS     = 3'd2;
    localparam ST_FWD_HDR    = 3'd3;
    localparam ST_FWD_PAYLOAD = 3'd4;

    reg [7:0] bytes [0:511]; // synthesis syn_ramstyle="block_ram"
    reg [9:0] n;              // number of bytes stored (0..512)
    reg [2:0] state;
    reg [9:0] ptr;
    reg status_valid_reg;
    reg [3:0] status_error_reg;
    reg [3:0] error_code;

    // Output registers for valid frame metadata
    reg [31:0] m_src_ip_reg;
    reg [15:0] m_src_port_reg;
    reg [15:0] m_dst_port_reg;
    reg [15:0] m_payload_len_reg;
    reg m_last_reg;
    reg [7:0] m_data_reg;
    reg m_valid_reg;
    reg fwd_in_progress;
    reg [9:0] fwd_ptr;

    wire hdr_ready;
    wire parse_ready;
    wire [15:0] parsed_length;
    wire [7:0] parser_data;
    wire parser_valid;
    wire parser_last;
    wire parser_ready;

    // Combinational error checks
    function integer word16;
        input integer offset;
        begin
            word16 = {bytes[offset], bytes[offset+1]};
        end
    endfunction

    function integer fold;
        input integer value;
        integer v;
        begin
            v = (value & 16'hFFFF) + (value >> 16);
            fold = (v & 16'hFFFF) + (v >> 16);
        end
    endfunction

    integer ip_sum, udp_sum, ip_len, udp_len, j;
    always @* begin
        ip_sum = 0;
        udp_sum = 0;
        ip_len = word16(2);
        udp_len = word16(24);
        error_code = 0;

        if (n < 28 || n > 512 || bytes[0][7:4] != 4 || bytes[0][3:0] != 5 || 
            bytes[9] != 17 || bytes[6][5] == 1 || {bytes[6][4:0], bytes[7]} != 0)
            error_code = 1;
        else if (ip_len != n || udp_len != (ip_len - 20) || (udp_len - 8) < 1 || (udp_len - 8) > 256)
            error_code = 2;
        else begin
            for (j = 0; j < 20; j = j + 2) ip_sum = ip_sum + word16(j);
            if (fold(ip_sum) != 16'hFFFF)
                error_code = 3;
            else begin
                for (j = 12; j < 20; j = j + 2) udp_sum = udp_sum + word16(j);
                udp_sum = udp_sum + 17 + udp_len;
                for (j = 20; j < n; j = j + 2) begin
                    if (j+1 < n)
                        udp_sum = udp_sum + {bytes[j], bytes[j+1]};
                    else
                        udp_sum = udp_sum + {bytes[j], 8'h00};
                end
                if (word16(26) != 0 && fold(udp_sum) != 16'hFFFF)
                    error_code = 4;
                else if ({bytes[16], bytes[17], bytes[18], bytes[19]} != 32'h0a000002 || word16(22) != 16'd9000)
                    error_code = 5;
            end
        end
    end

    assign s_ready = !rst && (state == ST_IDLE);
    assign status_valid = status_valid_reg;
    assign status_error = status_error_reg;
    assign m_src_ip = m_src_ip_reg;
    assign m_src_port = m_src_port_reg;
    assign m_dst_port = m_dst_port_reg;
    assign m_payload_len = m_payload_len_reg;
    assign m_data = m_data_reg;
    assign m_valid = m_valid_reg;
    assign m_last = m_last_reg;
    assign m_payload_len_reg = (udp_len - 8);

    // Instantiate upstream parser
    udp_ip_rx parser (
        .clk(clk),
        .rst(rst),
        .s_ip_hdr_valid(state == ST_FWD_HDR),
        .s_ip_hdr_ready(hdr_ready),
        .s_eth_dest_mac(48'b0),
        .s_eth_src_mac(48'b0),
        .s_eth_type(16'h0800),
        .s_ip_version(bytes[0][7:4]),
        .s_ip_ihl(bytes[0][3:0]),
        .s_ip_dscp(bytes[1][7:2]),
        .s_ip_ecn(bytes[1][1:0]),
        .s_ip_length({bytes[2], bytes[3]}),
        .s_ip_identification({bytes[4], bytes[5]}),
        .s_ip_flags(bytes[6][7:5]),
        .s_ip_fragment_offset({bytes[6][4:0], bytes[7]}),
        .s_ip_ttl(bytes[8]),
        .s_ip_protocol(bytes[9]),
        .s_ip_header_checksum({bytes[10], bytes[11]}),
        .s_ip_source_ip({bytes[12], bytes[13], bytes[14], bytes[15]}),
        .s_ip_dest_ip({bytes[16], bytes[17], bytes[18], bytes[19]}),
        .s_ip_payload_axis_tdata(fwd_in_progress ? bytes[fwd_ptr] : 8'd0),
        .s_ip_payload_axis_tvalid(fwd_in_progress && fwd_ptr >= 20 && fwd_ptr < n),
        .s_ip_payload_axis_tready(parse_ready),
        .s_ip_payload_axis_tlast(fwd_in_progress && fwd_ptr == (n - 1)),
        .s_ip_payload_axis_tuser(1'b0),
        .m_udp_hdr_ready(1'b1),
        .m_ip_source_ip(m_src_ip_reg),
        .m_udp_source_port(m_src_port_reg),
        .m_udp_dest_port(m_dst_port_reg),
        .m_udp_length(parsed_length),
        .m_udp_payload_axis_tdata(parser_data),
        .m_udp_payload_axis_tvalid(parser_valid),
        .m_udp_payload_axis_tready(parser_ready),
        .m_udp_payload_axis_tlast(parser_last)
    );

    assign parser_ready = m_ready || !m_valid_reg;

    always @(posedge clk) begin
        if (rst) begin
            state <= ST_IDLE;
            n <= 0;
            ptr <= 0;
            status_valid_reg <= 1'b0;
            status_error_reg <= 4'd0;
            m_valid_reg <= 1'b0;
            m_last_reg <= 1'b0;
            fwd_in_progress <= 1'b0;
            fwd_ptr <= 0;
            m_data_reg <= 8'd0;
        end else begin
            if (status_valid_reg)
                status_valid_reg <= 1'b0;

            case (state)
                ST_IDLE: begin
                    if (s_valid && s_ready) begin
                        if (n < 512) bytes[n] <= s_data;
                        n <= n + 1;
                        if (s_last) begin
                            state <= ST_EVALUATE;
                            ptr <= 20;
                        end
                    end
                end

                ST_EVALUATE: begin
                    state <= ST_STATUS;
                end

                ST_STATUS: begin
                    status_valid_reg <= 1'b1;
                    status_error_reg <= error_code;
                    if (error_code == 0) begin
                        state <= ST_FWD_HDR;
                        fwd_in_progress <= 1'b0;
                        fwd_ptr <= 20;
                    end else begin
                        state <= ST_IDLE;
                        n <= 0;
                    end
                end

                ST_FWD_HDR: begin
                    if (hdr_ready) begin
                        fwd_in_progress <= 1'b1;
                        state <= ST_FWD_PAYLOAD;
                    end
                end

                ST_FWD_PAYLOAD: begin
                    if (fwd_in_progress && parse_ready) begin
                        if (fwd_ptr == (n - 1)) begin
                            fwd_in_progress <= 1'b0;
                        end else begin
                            fwd_ptr <= fwd_ptr + 1;
                        end
                    end

                    if (parser_valid && m_ready) begin
                        m_data_reg <= parser_data;
                        m_last_reg <= parser_last;
                        m_valid_reg <= 1'b1;
                    end else if (m_valid_reg && m_ready) begin
                        m_valid_reg <= 1'b0;
                    end

                    if (m_valid_reg && m_ready && m_last_reg) begin
                        state <= ST_IDLE;
                        n <= 0;
                        m_valid_reg <= 1'b0;
                        m_last_reg <= 1'b0;
                    end
                end

                default: state <= ST_IDLE;
            endcase
        end
    end

endmodule
