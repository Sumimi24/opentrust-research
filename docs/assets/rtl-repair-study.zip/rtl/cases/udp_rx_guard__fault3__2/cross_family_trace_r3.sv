`timescale 1ns/1ps
module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error
);

localparam ST_IDLE   = 2'd0;
localparam ST_RECV   = 2'd1;
localparam ST_STATUS = 2'd2;
localparam ST_OUT    = 2'd3;

reg [1:0] state_reg;

reg [7:0] frame_mem[0:511];
reg [9:0] frame_len_reg;
reg oversize_reg;

reg [31:0] sum_ip_reg;
reg [31:0] sum_udp_reg;

reg [3:0] status_error_reg;
reg status_valid_reg;

reg [31:0] m_src_ip_reg;
reg [15:0] m_src_port_reg;
reg [15:0] m_dst_port_reg;
reg [15:0] m_payload_len_reg;

reg [9:0] out_idx_reg;
reg [9:0] out_end_reg;
reg m_valid_reg;
reg [7:0] m_data_reg;
reg m_last_reg;

integer i;
integer udp_end_i;
reg [31:0] tmp_ip_sum;
reg [31:0] tmp_udp_sum;
reg [15:0] ip_total_length;
reg [15:0] udp_length_field;
reg [15:0] udp_checksum_field;
reg [15:0] payload_length_field;
reg [31:0] dst_ip_field;
reg [31:0] src_ip_field;
reg [15:0] src_port_field;
reg [15:0] dst_port_field;
reg [3:0] calc_error;
reg [15:0] folded_ip;
reg [15:0] folded_udp;

function [15:0] fold16;
    input [31:0] x;
    reg [31:0] y;
    begin
        y = x;
        y = (y[15:0] + y[31:16]);
        y = (y[15:0] + y[31:16]);
        y = (y[15:0] + y[31:16]);
        fold16 = y[15:0];
    end
endfunction

assign s_ready = (state_reg == ST_IDLE) || (state_reg == ST_RECV);

assign m_data = m_data_reg;
assign m_valid = m_valid_reg;
assign m_last = m_last_reg;
assign m_src_ip = m_src_ip_reg;
assign m_src_port = m_src_port_reg;
assign m_dst_port = m_dst_port_reg;
assign m_payload_len = m_payload_len_reg;
assign status_valid = status_valid_reg;
assign status_error = status_error_reg;

always @(posedge clk) begin
    if (rst) begin
        state_reg <= ST_IDLE;
        frame_len_reg <= 10'd0;
        oversize_reg <= 1'b0;
        sum_ip_reg <= 32'd0;
        sum_udp_reg <= 32'd0;
        status_error_reg <= 4'd0;
        status_valid_reg <= 1'b0;
        m_src_ip_reg <= 32'd0;
        m_src_port_reg <= 16'd0;
        m_dst_port_reg <= 16'd0;
        m_payload_len_reg <= 16'd0;
        out_idx_reg <= 10'd0;
        out_end_reg <= 10'd0;
        m_valid_reg <= 1'b0;
        m_data_reg <= 8'd0;
        m_last_reg <= 1'b0;
    end else begin
        status_valid_reg <= 1'b0;

        if (state_reg == ST_OUT) begin
            if (m_valid_reg && m_ready) begin
                if (out_idx_reg == out_end_reg) begin
                    m_valid_reg <= 1'b0;
                    m_last_reg <= 1'b0;
                    state_reg <= ST_IDLE;
                    frame_len_reg <= 10'd0;
                    oversize_reg <= 1'b0;
                end else begin
                    out_idx_reg <= out_idx_reg + 10'd1;
                    m_data_reg <= frame_mem[out_idx_reg + 10'd1];
                    m_last_reg <= ((out_idx_reg + 10'd1) == out_end_reg);
                end
            end
        end else begin
            if (s_valid && s_ready) begin
                if (state_reg == ST_IDLE) begin
                    frame_len_reg <= 10'd0;
                    oversize_reg <= 1'b0;
                    state_reg <= ST_RECV;
                end

                if (frame_len_reg < 10'd512) begin
                    frame_mem[frame_len_reg] <= s_data;
                end else begin
                    oversize_reg <= 1'b1;
                end

                if (frame_len_reg == 10'd511) begin
                    oversize_reg <= 1'b1;
                end

                if (frame_len_reg < 10'd512) begin
                    frame_len_reg <= frame_len_reg + 10'd1;
                end

                if (s_last) begin
                    tmp_ip_sum = 32'd0;
                    tmp_udp_sum = 32'd0;

                    ip_total_length = 16'd0;
                    udp_length_field = 16'd0;
                    udp_checksum_field = 16'd0;
                    payload_length_field = 16'd0;
                    dst_ip_field = 32'd0;
                    src_ip_field = 32'd0;
                    src_port_field = 16'd0;
                    dst_port_field = 16'd0;
                    calc_error = 4'd0;
                    folded_ip = 16'd0;
                    folded_udp = 16'd0;

                    if ((frame_len_reg + 10'd1) >= 10'd20) begin
                        ip_total_length = {frame_mem[2], frame_mem[3]};
                        src_ip_field = {frame_mem[12], frame_mem[13], frame_mem[14], frame_mem[15]};
                        dst_ip_field = {frame_mem[16], frame_mem[17], frame_mem[18], frame_mem[19]};
                    end
                    if ((frame_len_reg + 10'd1) >= 10'd28) begin
                        src_port_field = {frame_mem[20], frame_mem[21]};
                        dst_port_field = {frame_mem[22], frame_mem[23]};
                        udp_length_field = {frame_mem[24], frame_mem[25]};
                        udp_checksum_field = {frame_mem[26], frame_mem[27]};
                    end

                    if (udp_length_field >= 16'd8) begin
                        payload_length_field = udp_length_field - 16'd8;
                    end else begin
                        payload_length_field = 16'd0;
                    end

                    if ((frame_len_reg + 10'd1) >= 10'd20) begin
                        for (i = 0; i < 20; i = i + 2) begin
                            if (i == 10) begin
                                tmp_ip_sum = tmp_ip_sum + {8'h00, 8'h00};
                            end else begin
                                tmp_ip_sum = tmp_ip_sum + {frame_mem[i], frame_mem[i+1]};
                            end
                        end
                        tmp_ip_sum = tmp_ip_sum + {8'h00, s_data};
                        folded_ip = fold16(tmp_ip_sum + {frame_mem[10], frame_mem[11]});
                    end else begin
                        folded_ip = 16'h0000;
                    end

                    if ((frame_len_reg + 10'd1) >= 10'd28) begin
                        tmp_udp_sum = 32'd0;
                        tmp_udp_sum = tmp_udp_sum + {frame_mem[12], frame_mem[13]};
                        tmp_udp_sum = tmp_udp_sum + {frame_mem[14], frame_mem[15]};
                        tmp_udp_sum = tmp_udp_sum + {frame_mem[16], frame_mem[17]};
                        tmp_udp_sum = tmp_udp_sum + {frame_mem[18], frame_mem[19]};
                        tmp_udp_sum = tmp_udp_sum + 16'h0011;
                        tmp_udp_sum = tmp_udp_sum + udp_length_field;
                        udp_end_i = 20 + udp_length_field - 1;
                        if (udp_end_i > (frame_len_reg)) begin
                            udp_end_i = frame_len_reg;
                        end
                        i = 20;
                        while (i <= udp_end_i) begin
                            if (i == udp_end_i) begin
                                if (i == frame_len_reg) begin
                                    tmp_udp_sum = tmp_udp_sum + {s_data, 8'h00};
                                end else begin
                                    tmp_udp_sum = tmp_udp_sum + {frame_mem[i], 8'h00};
                                end
                            end else begin
                                if (i == frame_len_reg) begin
                                    tmp_udp_sum = tmp_udp_sum + {s_data, frame_mem[i+1]};
                                end else if ((i+1) == frame_len_reg) begin
                                    tmp_udp_sum = tmp_udp_sum + {frame_mem[i], s_data};
                                end else begin
                                    tmp_udp_sum = tmp_udp_sum + {frame_mem[i], frame_mem[i+1]};
                                end
                            end
                            i = i + 2;
                        end
                        folded_udp = fold16(tmp_udp_sum);
                    end else begin
                        folded_udp = 16'h0000;
                    end

                    if (((frame_len_reg + 10'd1) < 10'd28) ||
                        oversize_reg ||
                        ({frame_mem[0][7:4], frame_mem[0][3:0]}[7:4] != 4'd4) ||
                        (frame_mem[0][3:0] != 4'd5) ||
                        ((frame_mem[9]) != 8'd17) ||
                        (frame_mem[6][5] != 1'b0) ||
                        ({frame_mem[6][4:0], frame_mem[7]} != 13'd0)) begin
                        calc_error = 4'd1;
                    end else if ((ip_total_length != (frame_len_reg + 10'd1)) ||
                                 (udp_length_field != (ip_total_length - 16'd20)) ||
                                 (payload_length_field < 16'd1) ||
                                 (payload_length_field > 16'd256)) begin
                        calc_error = 4'd2;
                    end else if (folded_ip != 16'hffff) begin
                        calc_error = 4'd3;
                    end else if ((udp_checksum_field != 16'h0000) && (folded_udp != 16'hffff)) begin
                        calc_error = 4'd4;
                    end else if ((dst_ip_field != 32'h0a000002) || (dst_port_field != 16'd9000)) begin
                        calc_error = 4'd5;
                    end else begin
                        calc_error = 4'd0;
                    end

                    sum_ip_reg <= tmp_ip_sum;
                    sum_udp_reg <= tmp_udp_sum;
                    status_error_reg <= calc_error;
                    status_valid_reg <= 1'b1;

                    if (calc_error == 4'd0) begin
                        m_src_ip_reg <= src_ip_field;
                        m_src_port_reg <= src_port_field;
                        m_dst_port_reg <= dst_port_field;
                        m_payload_len_reg <= payload_length_field;
                        out_idx_reg <= 10'd28;
                        out_end_reg <= 10'd27 + payload_length_field;
                        m_data_reg <= frame_mem[28];
                        m_last_reg <= (payload_length_field == 16'd1);
                        m_valid_reg <= 1'b1;
                        state_reg <= ST_OUT;
                    end else begin
                        m_valid_reg <= 1'b0;
                        m_last_reg <= 1'b0;
                        frame_len_reg <= 10'd0;
                        oversize_reg <= 1'b0;
                        state_reg <= ST_IDLE;
                    end
                end
            end
        end
    end
end

endmodule
