module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

reg [7:0] bytes[0:511];
reg [9:0] n;
reg [9:0] ptr;
reg [2:0] state;
reg status_valid_reg;
reg [3:0] status_error_reg;
reg [31:0] m_src_ip_reg;
reg [15:0] m_src_port_reg;
reg [15:0] m_dst_port_reg;
reg [15:0] m_payload_len_reg;
reg [15:0] udp_len_reg;
reg m_valid_reg;
reg m_last_reg;
reg [7:0] m_data_reg;

wire [15:0] ip_len = {bytes[2], bytes[3]};
wire [15:0] udp_len = {bytes[24], bytes[25]};
wire [15:0] udp_checksum = {bytes[26], bytes[27]};

function [15:0] ones_comp_add(input [16:0] a, input [16:0] b);
    reg [17:0] sum;
    begin
        sum = a + b;
        ones_comp_add = sum[15:0] + sum[16];
    end
endfunction

function [15:0] fold16(input [31:0] val);
    reg [16:0] sum;
    begin
        sum = val[15:0] + val[31:16];
        fold16 = sum[15:0] + sum[16];
    end
endfunction

reg [31:0] ip_checksum_acc;
reg [31:0] udp_checksum_acc;
integer i;

wire ip_checksum_ok = (fold16(ip_checksum_acc) == 16'hffff);
wire udp_checksum_ok = (udp_checksum == 16'h0000) || (fold16(udp_checksum_acc) == 16'hffff);

wire [15:0] ip_total_length = {bytes[2], bytes[3]};
wire [15:0] udp_length_field = {bytes[24], bytes[25]};
wire [15:0] payload_len_calc = udp_length_field - 16'd8;

wire err1 = (n < 10'd28) || (n > 10'd512) || (bytes[0] != 8'h45) || (bytes[9] != 8'd17) || ((bytes[6] & 8'h20) != 8'h00) || ({bytes[6][4:0], bytes[7]} != 13'h0000);
wire err2 = (ip_total_length != n) || (udp_length_field != ip_total_length - 16'd20) || (payload_len_calc < 16'd1) || (payload_len_calc > 16'd256);
wire err3 = !ip_checksum_ok;
wire err4 = !udp_checksum_ok;
wire err5 = ({bytes[16], bytes[17], bytes[18], bytes[19]} != 32'h0a000002) || ({bytes[22], bytes[23]} != 16'd9000);

reg [3:0] calc_error;

always @(*) begin
    calc_error = 4'd0;
    if (err1) calc_error = 4'd1;
    else if (err2) calc_error = 4'd2;
    else if (err3) calc_error = 4'd3;
    else if (err4) calc_error = 4'd4;
    else if (err5) calc_error = 4'd5;
end

assign s_ready = (state == 3'd0) && !rst;

assign status_valid = status_valid_reg;
assign status_error = status_error_reg;
assign m_src_ip = m_src_ip_reg;
assign m_src_port = m_src_port_reg;
assign m_dst_port = m_dst_port_reg;
assign m_payload_len = m_payload_len_reg;
assign m_data = m_data_reg;
assign m_valid = m_valid_reg;
assign m_last = m_last_reg;

always @(posedge clk) begin
    if (rst) begin
        state <= 3'd0;
        n <= 10'd0;
        ptr <= 10'd0;
        status_valid_reg <= 1'b0;
        status_error_reg <= 4'd0;
        m_src_ip_reg <= 32'd0;
        m_src_port_reg <= 16'd0;
        m_dst_port_reg <= 16'd0;
        m_payload_len_reg <= 16'd0;
        udp_len_reg <= 16'd0;
        m_valid_reg <= 1'b0;
        m_last_reg <= 1'b0;
        m_data_reg <= 8'd0;
        ip_checksum_acc <= 32'd0;
        udp_checksum_acc <= 32'd0;
        for (i = 0; i < 512; i = i + 1) bytes[i] <= 8'd0;
    end else begin
        status_valid_reg <= 1'b0;
        
        case (state)
        3'd0: begin
            m_valid_reg <= 1'b0;
            m_last_reg <= 1'b0;
            if (s_valid && s_ready) begin
                if (n < 10'd512) begin
                    bytes[n] <= s_data;
                end
                if (n < 10'd512) begin
                    n <= n + 10'd1;
                end else begin
                    n <= n;
                end
                if (s_last) begin
                    state <= 3'd1;
                end
            end
        end
        
        3'd1: begin
            ip_checksum_acc <= 32'd0;
            udp_checksum_acc <= 32'd0;
            state <= 3'd2;
        end
        
        3'd2: begin
            ip_checksum_acc <= {bytes[0], bytes[1]} + {bytes[2], bytes[3]} + {bytes[4], bytes[5]} + {bytes[6], bytes[7]} + {bytes[8], bytes[9]} + {bytes[10], bytes[11]} + {bytes[12], bytes[13]} + {bytes[14], bytes[15]} + {bytes[16], bytes[17]} + {bytes[18], bytes[19]};
            udp_checksum_acc <= {bytes[12], bytes[13]} + {bytes[14], bytes[15]} + {bytes[16], bytes[17]} + {bytes[18], bytes[19]} + 16'd17 + udp_len + {bytes[20], bytes[21]} + {bytes[22], bytes[23]} + {bytes[24], bytes[25]} + {bytes[26], bytes[27]};
            state <= 3'd3;
        end
        
        3'd3: begin
            for (i = 28; i < n; i = i + 2) begin
                if (i + 1 < n) begin
                    udp_checksum_acc <= udp_checksum_acc + {bytes[i], bytes[i+1]};
                end else begin
                    udp_checksum_acc <= udp_checksum_acc + {bytes[i], 8'h00};
                end
            end
            state <= 3'd4;
        end
        
        3'd4: begin
            status_valid_reg <= 1'b1;
            status_error_reg <= calc_error;
            
            if (calc_error == 4'd0) begin
                m_src_ip_reg <= {bytes[12], bytes[13], bytes[14], bytes[15]};
                m_src_port_reg <= {bytes[20], bytes[21]};
                m_dst_port_reg <= {bytes[22], bytes[23]};
                m_payload_len_reg <= udp_len - 16'd8;
                udp_len_reg <= udp_len;
                ptr <= 10'd28;
                state <= 3'd5;
            end else begin
                n <= 10'd0;
                state <= 3'd0;
            end
        end
        
        3'd5: begin
            if (m_ready || !m_valid_reg) begin
                if (ptr < n) begin
                    m_data_reg <= bytes[ptr];
                    m_valid_reg <= 1'b1;
                    if (ptr == n - 10'd1) begin
                        m_last_reg <= 1'b1;
                    end else begin
                        m_last_reg <= 1'b0;
                    end
                    ptr <= ptr + 10'd1;
                end else begin
                    m_valid_reg <= 1'b0;
                    m_last_reg <= 1'b0;
                    n <= 10'd0;
                    state <= 3'd0;
                end
            end
        end
        
        default: state <= 3'd0;
        endcase
    end
end

endmodule
