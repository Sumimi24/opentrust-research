`timescale 1ns/1ps
`default_nettype none

module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output reg s_ready,
input wire s_last,
output reg [7:0] m_data,
output reg m_valid,
input wire m_ready,
output reg m_last,
output reg [31:0] m_src_ip,
output reg [15:0] m_src_port,
output reg [15:0] m_dst_port,
output reg [15:0] m_payload_len,
output reg status_valid,
output reg [3:0] status_error);

reg [7:0] buf_0, buf_1, buf_2, buf_3, buf_4, buf_5, buf_6, buf_7;
reg [7:0] buf_8, buf_9, buf_10, buf_11, buf_12, buf_13, buf_14, buf_15;
reg [7:0] buf_16, buf_17, buf_18, buf_19, buf_20, buf_21, buf_22, buf_23;
reg [7:0] buf_24, buf_25, buf_26, buf_27;
reg [7:0] mem [0:483];

reg [9:0] byte_cnt;
reg [2:0] state;
reg [3:0] err_code;
reg [9:0] out_ptr;
reg [9:0] out_end;
reg [8:0] ip_csum_acc;
reg [4:0] ip_csum_idx;
reg [16:0] udp_csum_acc;
reg [9:0] udp_csum_idx;
reg [3:0] status_timer;

localparam S_IDLE    = 3'd0;
localparam S_RECV    = 3'd1;
localparam S_IP_CHK  = 3'd2;
localparam S_UDP_CHK = 3'd3;
localparam S_STATUS  = 3'd4;
localparam S_OUT     = 3'd5;

reg [15:0] w_ip_total_len;
reg [15:0] w_udp_len;
reg [15:0] w_udp_csum;
reg [15:0] w_plen;
reg w_oversize;
reg w_short;
reg w_v4;
reg w_ihl5;
reg w_proto17;
reg w_mf;
reg w_frag;
reg w_e1;
reg w_ip_match;
reg w_udp_match;
reg w_pl_ok;
reg w_e2;
reg [15:0] w_ip_folded;
reg w_e3;
reg [16:0] udp_pseudo_sum;
reg [16:0] udp_next;
reg [15:0] udp_f1;
reg [15:0] udp_f2;
reg w_e4;
reg [31:0] w_dst_ip;
reg [15:0] w_dst_port_val;
reg w_e5;
reg [7:0] rdata;
reg [7:0] rdata_next;
reg [7:0] out_byte;

integer i;

always @(posedge clk) begin
    if (rst) begin
        state <= S_IDLE;
        byte_cnt <= 10'd0;
        status_valid <= 1'b0;
        err_code <= 4'd0;
        ip_csum_acc <= 9'd0;
        ip_csum_idx <= 5'd0;
        udp_csum_acc <= 17'd0;
        udp_csum_idx <= 10'd0;
        out_ptr <= 10'd0;
        out_end <= 10'd0;
        status_timer <= 4'd0;
        s_ready <= 1'b1;
        m_valid <= 1'b0;
        m_last <= 1'b0;
        m_data <= 8'd0;
        m_src_ip <= 32'd0;
        m_src_port <= 16'd0;
        m_dst_port <= 16'd0;
        m_payload_len <= 16'd0;
        status_error <= 4'd0;
        for (i = 0; i < 484; i = i + 1) mem[i] <= 8'd0;
        buf_0 <= 8'd0; buf_1 <= 8'd0; buf_2 <= 8'd0; buf_3 <= 8'd0;
        buf_4 <= 8'd0; buf_5 <= 8'd0; buf_6 <= 8'd0; buf_7 <= 8'd0;
        buf_8 <= 8'd0; buf_9 <= 8'd0; buf_10 <= 8'd0; buf_11 <= 8'd0;
        buf_12 <= 8'd0; buf_13 <= 8'd0; buf_14 <= 8'd0; buf_15 <= 8'd0;
        buf_16 <= 8'd0; buf_17 <= 8'd0; buf_18 <= 8'd0; buf_19 <= 8'd0;
        buf_20 <= 8'd0; buf_21 <= 8'd0; buf_22 <= 8'd0; buf_23 <= 8'd0;
        buf_24 <= 8'd0; buf_25 <= 8'd0; buf_26 <= 8'd0; buf_27 <= 8'd0;
    end else begin
        case (state)
            S_IDLE: begin
                status_valid <= 1'b0;
                byte_cnt <= 10'd0;
                s_ready <= 1'b1;
                m_valid <= 1'b0;
                if (s_valid) begin
                    if (10'd0 == 10'd0) buf_0 <= s_data;
                    else if (10'd0 == 10'd1) buf_1 <= s_data;
                    else if (10'd0 == 10'd2) buf_2 <= s_data;
                    else if (10'd0 == 10'd3) buf_3 <= s_data;
                    else if (10'd0 == 10'd4) buf_4 <= s_data;
                    else if (10'd0 == 10'd5) buf_5 <= s_data;
                    else if (10'd0 == 10'd6) buf_6 <= s_data;
                    else if (10'd0 == 10'd7) buf_7 <= s_data;
                    else if (10'd0 == 10'd8) buf_8 <= s_data;
                    else if (10'd0 == 10'd9) buf_9 <= s_data;
                    else if (10'd0 == 10'd10) buf_10 <= s_data;
                    else if (10'd0 == 10'd11) buf_11 <= s_data;
                    else if (10'd0 == 10'd12) buf_12 <= s_data;
                    else if (10'd0 == 10'd13) buf_13 <= s_data;
                    else if (10'd0 == 10'd14) buf_14 <= s_data;
                    else if (10'd0 == 10'd15) buf_15 <= s_data;
                    else if (10'd0 == 10'd16) buf_16 <= s_data;
                    else if (10'd0 == 10'd17) buf_17 <= s_data;
                    else if (10'd0 == 10'd18) buf_18 <= s_data;
                    else if (10'd0 == 10'd19) buf_19 <= s_data;
                    else if (10'd0 == 10'd20) buf_20 <= s_data;
                    else if (10'd0 == 10'd21) buf_21 <= s_data;
                    else if (10'd0 == 10'd22) buf_22 <= s_data;
                    else if (10'd0 == 10'd23) buf_23 <= s_data;
                    else if (10'd0 == 10'd24) buf_24 <= s_data;
                    else if (10'd0 == 10'd25) buf_25 <= s_data;
                    else if (10'd0 == 10'd26) buf_26 <= s_data;
                    else if (10'd0 == 10'd27) buf_27 <= s_data;
                    else mem[10'd0 - 10'd28] <= s_data;
                    byte_cnt <= 10'd1;
                    if (s_last) begin
                        state <= S_IP_CHK;
                        ip_csum_acc <= 9'd0;
                        ip_csum_idx <= 5'd0;
                        s_ready <= 1'b0;
                    end else begin
                        state <= S_RECV;
                    end
                end
            end
            S_RECV: begin
                s_ready <= !w_oversize;
                if (s_valid && s_ready) begin
                    if (!w_oversize) begin
                        if (byte_cnt == 10'd0) buf_0 <= s_data;
                        else if (byte_cnt == 10'd1) buf_1 <= s_data;
                        else if (byte_cnt == 10'd2) buf_2 <= s_data;
                        else if (byte_cnt == 10'd3) buf_3 <= s_data;
                        else if (byte_cnt == 10'd4) buf_4 <= s_data;
                        else if (byte_cnt == 10'd5) buf_5 <= s_data;
                        else if (byte_cnt == 10'd6) buf_6 <= s_data;
                        else if (byte_cnt == 10'd7) buf_7 <= s_data;
                        else if (byte_cnt == 10'd8) buf_8 <= s_data;
                        else if (byte_cnt == 10'd9) buf_9 <= s_data;
                        else if (byte_cnt == 10'd10) buf_10 <= s_data;
                        else if (byte_cnt == 10'd11) buf_11 <= s_data;
                        else if (byte_cnt == 10'd12) buf_12 <= s_data;
                        else if (byte_cnt == 10'd13) buf_13 <= s_data;
                        else if (byte_cnt == 10'd14) buf_14 <= s_data;
                        else if (byte_cnt == 10'd15) buf_15 <= s_data;
                        else if (byte_cnt == 10'd16) buf_16 <= s_data;
                        else if (byte_cnt == 10'd17) buf_17 <= s_data;
                        else if (byte_cnt == 10'd18) buf_18 <= s_data;
                        else if (byte_cnt == 10'd19) buf_19 <= s_data;
                        else if (byte_cnt == 10'd20) buf_20 <= s_data;
                        else if (byte_cnt == 10'd21) buf_21 <= s_data;
                        else if (byte_cnt == 10'd22) buf_22 <= s_data;
                        else if (byte_cnt == 10'd23) buf_23 <= s_data;
                        else if (byte_cnt == 10'd24) buf_24 <= s_data;
                        else if (byte_cnt == 10'd25) buf_25 <= s_data;
                        else if (byte_cnt == 10'd26) buf_26 <= s_data;
                        else if (byte_cnt == 10'd27) buf_27 <= s_data;
                        else mem[byte_cnt - 10'd28] <= s_data;
                    end
                    byte_cnt <= byte_cnt + 10'd1;
                    if (s_last) begin
                        state <= S_IP_CHK;
                        ip_csum_acc <= 9'd0;
                        ip_csum_idx <= 5'd0;
                        s_ready <= 1'b0;
                    end
                end
            end
            S_IP_CHK: begin
                s_ready <= 1'b0;
                if (w_e1) begin
                    err_code <= 4'd1;
                    state <= S_STATUS;
                    status_timer <= 4'd0;
                end else if (w_e2) begin
                    err_code <= 4'd2;
                    state <= S_STATUS;
                    status_timer <= 4'd0;
                end else begin
                    ip_csum_acc <= ip_csum_acc + {rdata, rdata_next};
                    ip_csum_idx <= ip_csum_idx + 5'd2;
                    if (ip_csum_idx == 5'd18) begin
                        if (w_e3) begin
                            err_code <= 4'd3;
                            state <= S_STATUS;
                            status_timer <= 4'd0;
                        end else begin
                            state <= S_UDP_CHK;
                            udp_csum_acc <= udp_pseudo_sum;
                            udp_csum_idx <= 10'd20;
                        end
                    end
                end
            end
            S_UDP_CHK: begin
                s_ready <= 1'b0;
                udp_csum_acc <= udp_next;
                udp_csum_idx <= udp_csum_idx + 10'd2;
                if (udp_csum_idx + 10'd2 >= byte_cnt) begin
                    if (w_e4) begin
                        err_code <= 4'd4;
                        state <= S_STATUS;
                        status_timer <= 4'd0;
                    end else if (w_e5) begin
                        err_code <= 4'd5;
                        state <= S_STATUS;
                        status_timer <= 4'd0;
                    end else begin
                        err_code <= 4'd0;
                        state <= S_STATUS;
                        status_timer <= 4'd0;
                        out_ptr <= 10'd28;
                        out_end <= byte_cnt - 10'd1;
                    end
                end
            end
            S_STATUS: begin
                s_ready <= 1'b0;
                status_valid <= 1'b1;
                status_error <= err_code;
                status_timer <= status_timer + 4'd1;
                if (status_timer == 4'd15) begin
                    status_valid <= 1'b0;
                    if (err_code == 4'd0) begin
                        state <= S_OUT;
                        m_valid <= 1'b1;
                        m_data <= out_byte;
                        m_last <= (10'd28 == out_end);
                        m_src_ip <= {buf_12, buf_13, buf_14, buf_15};
                        m_src_port <= {buf_20, buf_21};
                        m_dst_port <= {buf_22, buf_23};
                        m_payload_len <= w_plen;
                    end else begin
                        state <= S_IDLE;
                        byte_cnt <= 10'd0;
                        s_ready <= 1'b1;
                        m_valid <= 1'b0;
                    end
                end
            end
            S_OUT: begin
                s_ready <= 1'b0;
                if (m_valid && m_ready) begin
                    if (m_last) begin
                        state <= S_IDLE;
                        byte_cnt <= 10'd0;
                        m_valid <= 1'b0;
                        s_ready <= 1'b1;
                    end else begin
                        out_ptr <= out_ptr + 10'd1;
                        if (out_ptr + 10'd1 == 10'd28) m_data <= buf_28;
                        else if (out_ptr + 10'd1 == 10'd29) m_data <= buf_29;
                        else if (out_ptr + 10'd1 == 10'd30) m_data <= buf_30;
                        else if (out_ptr + 10'd1 == 10'd31) m_data <= buf_31;
                        else m_data <= mem[out_ptr + 10'd1 - 10'd28];
                        m_last <= ((out_ptr + 10'd1) == out_end);
                    end
                end
            end
            default: begin
                state <= S_IDLE;
                s_ready <= 1'b1;
                m_valid <= 1'b0;
            end
        endcase
    end
end

always @(*) begin
    case(ip_csum_idx)
        5'd0:  rdata = buf_0;
        5'd1:  rdata = buf_1;
        5'd2:  rdata = buf_2;
        5'd3:  rdata = buf_3;
        5'd4:  rdata = buf_4;
        5'd5:  rdata = buf_5;
        5'd6:  rdata = buf_6;
        5'd7:  rdata = buf_7;
        5'd8:  rdata = buf_8;
        5'd9:  rdata = buf_9;
        5'd10: rdata = buf_10;
        5'd11: rdata = buf_11;
        5'd12: rdata = buf_12;
        5'd13: rdata = buf_13;
        5'd14: rdata = buf_14;
        5'd15: rdata = buf_15;
        5'd16: rdata = buf_16;
        5'd17: rdata = buf_17;
        5'd18: rdata = buf_18;
        5'd19: rdata = buf_19;
        default: rdata = 8'd0;
    endcase
    case(ip_csum_idx + 5'd1)
        5'd0:  rdata_next = buf_0;
        5'd1:  rdata_next = buf_1;
        5'd2:  rdata_next = buf_2;
        5'd3:  rdata_next = buf_3;
        5'd4:  rdata_next = buf_4;
        5'd5:  rdata_next = buf_5;
        5'd6:  rdata_next = buf_6;
        5'd7:  rdata_next = buf_7;
        5'd8:  rdata_next = buf_8;
        5'd9:  rdata_next = buf_9;
        5'd10: rdata_next = buf_10;
        5'd11: rdata_next = buf_11;
        5'd12: rdata_next = buf_12;
        5'd13: rdata_next = buf_13;
        5'd14: rdata_next = buf_14;
        5'd15: rdata_next = buf_15;
        5'd16: rdata_next = buf_16;
        5'd17: rdata_next = buf_17;
        5'd18: rdata_next = buf_18;
        5'd19: rdata_next = buf_19;
        default: rdata_next = 8'd0;
    endcase

    if (udp_csum_idx == 10'd28) out_byte = buf_28;
    else if (udp_csum_idx == 10'd29) out_byte = buf_29;
    else if (udp_csum_idx == 10'd30) out_byte = buf_30;
    else if (udp_csum_idx == 10'd31) out_byte = buf_31;
    else out_byte = mem[udp_csum_idx - 10'd28];

    w_ip_total_len = {buf_2, buf_3};
    w_udp_len      = {buf_24, buf_25};
    w_udp_csum     = {buf_26, buf_27};
    w_plen         = w_udp_len - 16'd8;

    w_oversize = (byte_cnt > 10'd512);
    w_short    = (byte_cnt < 10'd28);
    w_v4       = (buf_0[7:4] != 4'd4);
    w_ihl5     = (buf_0[3:0] != 4'd5);
    w_proto17  = (buf_9 != 8'd17);
    w_mf       = buf_6[5];
    w_frag     = (buf_6[4:0] != 5'd0) | (buf_7 != 8'd0);
    w_e1       = w_short | w_oversize | w_v4 | w_ihl5 | w_proto17 | w_mf | w_frag;

    w_ip_match = (w_ip_total_len == byte_cnt);
    w_udp_match= (w_udp_len == (w_ip_total_len - 16'd20));
    w_pl_ok    = (w_plen >= 16'd1) & (w_plen <= 16'd256);
    w_e2       = ~w_ip_match | ~w_udp_match | ~w_pl_ok;

    w_ip_folded = ip_csum_acc[8:0] + {7'd0, ip_csum_acc[8]};
    w_e3 = (w_ip_folded != 16'hFFFF);

    udp_pseudo_sum = {1'b0,buf_12,buf_13} + {1'b0,buf_14,buf_15}
                   + {1'b0,buf_16,buf_17} + {1'b0,buf_18,buf_19}
                   + 17'd17 + {1'b0,w_udp_len[15:0]};

    if (udp_csum_idx + 10'd1 < byte_cnt) begin
        if (udp_csum_idx + 10'd1 == 10'd28) udp_next = udp_csum_acc + {1'b0, out_byte, buf_29};
        else if (udp_csum_idx + 10'd1 == 10'd29) udp_next = udp_csum_acc + {1'b0, out_byte, buf_30};
        else if (udp_csum_idx + 10'd1 == 10'd30) udp_next = udp_csum_acc + {1'b0, out_byte, buf_31};
        else if (udp_csum_idx + 10'd1 == 10'd31) udp_next = udp_csum_acc + {1'b0, out_byte, mem[10'd3]};
        else udp_next = udp_csum_acc + {1'b0, out_byte, mem[udp_csum_idx + 10'd1 - 10'd28]};
    end else begin
        udp_next = udp_csum_acc + {1'b0, out_byte, 8'd0};
    end

    udp_f1 = udp_csum_acc[15:0] + {15'd0, udp_csum_acc[16]};
    udp_f2 = udp_f1[15:0] + {15'd0, udp_f1[16]};
    w_e4 = (w_udp_csum != 16'd0) & (udp_f2 != 16'hFFFF);

    w_dst_ip   = {buf_16, buf_17, buf_18, buf_19};
    w_dst_port_val = {buf_22, buf_23};
    w_e5 = (w_dst_ip != 32'h0A000002) | (w_dst_port_val != 16'd9000);
end

endmodule
