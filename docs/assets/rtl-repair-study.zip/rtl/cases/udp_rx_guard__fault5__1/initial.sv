`timescale 1ns/1ps
`default_nettype none

module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
output wire s_ready,
input wire s_valid,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

reg [7:0] buf [0:511];
reg [9:0] byte_cnt;
reg [2:0] state;
reg [3:0] err_code;
reg [9:0] out_ptr;
reg [9:0] out_end;
reg [8:0] ip_csum_acc;
reg [4:0] ip_csum_idx;
reg [16:0] udp_csum_acc;
reg [9:0] udp_csum_idx;
reg [3:0] status_timer;

localparam S_IDLE=0, S_RECV=1, S_IP_CHK=2, S_UDP_CHK=3, S_STATUS=4, S_OUT=5;

wire [15:0] w_ip_total_len = {buf[2], buf[3]};
wire [15:0] w_udp_len      = {buf[24], buf[25]};
wire [15:0] w_udp_csum     = {buf[26], buf[27]};
wire [15:0] w_plen         = w_udp_len - 16'd8;

wire w_oversize = (byte_cnt > 10'd512);
wire w_short    = (byte_cnt < 10'd28);
wire w_v4       = (buf[0][7:4] != 4'd4);
wire w_ihl5     = (buf[0][3:0] != 4'd5);
wire w_proto17  = (buf[9] != 8'd17);
wire w_mf       = buf[6][5];
wire w_frag     = (buf[6][4:0] != 5'd0) || (buf[7] != 8'd0);
wire w_e1       = w_short | w_oversize | w_v4 | w_ihl5 | w_proto17 | w_mf | w_frag;

wire w_ip_match = (w_ip_total_len == byte_cnt);
wire w_udp_match= (w_udp_len == (w_ip_total_len - 16'd20));
wire w_pl_ok    = (w_plen >= 16'd1) && (w_plen <= 16'd256);
wire w_e2       = ~w_ip_match | ~w_udp_match | ~w_pl_ok;

wire [15:0] w_ip_folded;
assign w_ip_folded = ip_csum_acc[8:0] + {7'd0, ip_csum_acc[8]};
wire w_e3 = (w_ip_folded != 16'hFFFF);

wire [16:0] udp_pseudo_sum;
assign udp_pseudo_sum = {1'b0,buf[12],buf[13]} + {1'b0,buf[14],buf[15]}
                      + {1'b0,buf[16],buf[17]} + {1'b0,buf[18],buf[19]}
                      + 17'd17 + {1'b0,w_udp_len[15:0]};

wire [16:0] udp_next;
assign udp_next = udp_csum_acc + {1'b0, buf[udp_csum_idx], (udp_csum_idx+1 < byte_cnt) ? buf[udp_csum_idx+1] : 8'd0};

wire [15:0] udp_f1, udp_f2;
assign udp_f1 = udp_csum_acc[15:0] + {15'd0, udp_csum_acc[16]};
assign udp_f2 = udp_f1[15:0] + {15'd0, udp_f1[16]};
wire w_e4 = (w_udp_csum != 16'd0) && (udp_f2 != 16'hFFFF);

wire [31:0] w_dst_ip   = {buf[16], buf[17], buf[18], buf[19]};
wire [15:0] w_dst_port = {buf[22], buf[23]};
wire w_e5 = (w_dst_ip != 32'h0A000002) || (w_dst_port != 16'd9000);

assign s_ready = (state == S_IDLE) || ((state == S_RECV) && !w_oversize);
assign status_valid = (state == S_STATUS);
assign status_error = err_code;

assign m_valid   = (state == S_OUT);
assign m_data    = buf[out_ptr];
assign m_last    = (out_ptr == out_end);
assign m_src_ip  = {buf[12], buf[13], buf[14], buf[15]};
assign m_src_port= {buf[20], buf[21]};
assign m_dst_port= {buf[22], buf[23]};
assign m_payload_len = w_plen;

integer i;
always @(posedge clk) begin
    if (rst) begin
        state <= S_IDLE;
        byte_cnt <= 0;
        status_valid <= 1'b0;
        err_code <= 4'd0;
        ip_csum_acc <= 0;
        ip_csum_idx <= 0;
        udp_csum_acc <= 0;
        udp_csum_idx <= 0;
        out_ptr <= 0;
        out_end <= 0;
        status_timer <= 0;
        for (i = 0; i < 512; i = i + 1) buf[i] <= 8'd0;
    end else begin
        case (state)
            S_IDLE: begin
                status_valid <= 1'b0;
                byte_cnt <= 0;
                if (s_valid && s_ready) begin
                    buf[0] <= s_data;
                    byte_cnt <= 1;
                    if (s_last) begin
                        state <= S_IP_CHK;
                        ip_csum_acc <= 0;
                        ip_csum_idx <= 0;
                    end else begin
                        state <= S_RECV;
                    end
                end
            end
            S_RECV: begin
                if (s_valid && s_ready) begin
                    if (!w_oversize) buf[byte_cnt] <= s_data;
                    byte_cnt <= byte_cnt + 1;
                    if (s_last) begin
                        state <= S_IP_CHK;
                        ip_csum_acc <= 0;
                        ip_csum_idx <= 0;
                    end
                end
            end
            S_IP_CHK: begin
                if (w_e1) begin
                    err_code <= 4'd1;
                    state <= S_STATUS;
                    status_timer <= 0;
                end else if (w_e2) begin
                    err_code <= 4'd2;
                    state <= S_STATUS;
                    status_timer <= 0;
                end else begin
                    ip_csum_acc <= ip_csum_acc + {buf[ip_csum_idx], buf[ip_csum_idx+1]};
                    ip_csum_idx <= ip_csum_idx + 2;
                    if (ip_csum_idx == 18) begin
                        if (w_e3) begin
                            err_code <= 4'd3;
                            state <= S_STATUS;
                            status_timer <= 0;
                        end else begin
                            state <= S_UDP_CHK;
                            udp_csum_acc <= udp_pseudo_sum;
                            udp_csum_idx <= 20;
                        end
                    end
                end
            end
            S_UDP_CHK: begin
                udp_csum_acc <= udp_next;
                udp_csum_idx <= udp_csum_idx + 2;
                if (udp_csum_idx + 2 >= byte_cnt) begin
                    if (w_e4) begin
                        err_code <= 4'd4;
                        state <= S_STATUS;
                        status_timer <= 0;
                    end else if (w_e5) begin
                        err_code <= 4'd5;
                        state <= S_STATUS;
                        status_timer <= 0;
                    end else begin
                        err_code <= 4'd0;
                        state <= S_STATUS;
                        status_timer <= 0;
                        out_ptr <= 28;
                        out_end <= byte_cnt - 1;
                    end
                end
            end
            S_STATUS: begin
                status_valid <= 1'b1;
                status_timer <= status_timer + 1;
                if (status_timer == 4'd15) begin
                    status_valid <= 1'b0;
                    if (err_code == 4'd0) begin
                        state <= S_OUT;
                    end else begin
                        state <= S_IDLE;
                        byte_cnt <= 0;
                    end
                end
            end
            S_OUT: begin
                if (m_valid && m_ready) begin
                    if (m_last) begin
                        state <= S_IDLE;
                        byte_cnt <= 0;
                    end else begin
                        out_ptr <= out_ptr + 1;
                    end
                end
            end
            default: state <= S_IDLE;
        endcase
    end
end

endmodule
