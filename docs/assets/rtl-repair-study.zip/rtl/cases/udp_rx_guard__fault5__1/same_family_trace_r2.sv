`timescale 1ns/1ps
`default_nettype none

module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output reg s_ready,
input wire s_last,
output reg [7:0] m_data,
output reg m_valid,
input wire m_ready,
output reg m_last,
output reg [31:0] m_src_ip,
output reg [15:0] m_src_port,
output reg [15:0] m_dst_port,
output reg [15:0] m_payload_len,
output reg status_valid,
output reg [3:0] status_error);

reg [7:0] buf [0:511];
reg [9:0] byte_cnt;
reg [2:0] state;
reg [3:0] err_code;
reg [9:0] out_ptr;
reg [9:0] out_end;
reg [8:0] ip_csum_acc;
reg [4:0] ip_csum_idx;
reg [16:0] udp_csum_acc;
reg [9:0] udp_csum_idx;
reg [3:0] status_timer;

localparam S_IDLE    = 3'd0;
localparam S_RECV    = 3'd1;
localparam S_IP_CHK  = 3'd2;
localparam S_UDP_CHK = 3'd3;
localparam S_STATUS  = 3'd4;
localparam S_OUT     = 3'd5;

reg [15:0] w_ip_total_len;
reg [15:0] w_udp_len;
reg [15:0] w_udp_csum;
reg [15:0] w_plen;
reg w_oversize;
reg w_short;
reg w_v4;
reg w_ihl5;
reg w_proto17;
reg w_mf;
reg w_frag;
reg w_e1;
reg w_ip_match;
reg w_udp_match;
reg w_pl_ok;
reg w_e2;
reg [15:0] w_ip_folded;
reg w_e3;
reg [16:0] udp_pseudo_sum;
reg [16:0] udp_next;
reg [15:0] udp_f1;
reg [15:0] udp_f2;
reg w_e4;
reg [31:0] w_dst_ip;
reg [15:0] w_dst_port_val;
reg w_e5;

integer i;

always @(posedge clk) begin
    if (rst) begin
        state <= S_IDLE;
        byte_cnt <= 10'd0;
        status_valid <= 1'b0;
        err_code <= 4'd0;
        ip_csum_acc <= 9'd0;
        ip_csum_idx <= 5'd0;
        udp_csum_acc <= 17'd0;
        udp_csum_idx <= 10'd0;
        out_ptr <= 10'd0;
        out_end <= 10'd0;
        status_timer <= 4'd0;
        s_ready <= 1'b1;
        m_valid <= 1'b0;
        m_last <= 1'b0;
        m_data <= 8'd0;
        m_src_ip <= 32'd0;
        m_src_port <= 16'd0;
        m_dst_port <= 16'd0;
        m_payload_len <= 16'd0;
        status_error <= 4'd0;
        for (i = 0; i < 512; i = i + 1) buf[i] <= 8'd0;
    end else begin
        case (state)
            S_IDLE: begin
                status_valid <= 1'b0;
                byte_cnt <= 10'd0;
                s_ready <= 1'b1;
                m_valid <= 1'b0;
                if (s_valid) begin
                    buf[0] <= s_data;
                    byte_cnt <= 10'd1;
                    if (s_last) begin
                        state <= S_IP_CHK;
                        ip_csum_acc <= 9'd0;
                        ip_csum_idx <= 5'd0;
                        s_ready <= 1'b0;
                    end else begin
                        state <= S_RECV;
                    end
                end
            end
            S_RECV: begin
                s_ready <= !w_oversize;
                if (s_valid && s_ready) begin
                    if (!w_oversize) buf[byte_cnt] <= s_data;
                    byte_cnt <= byte_cnt + 10'd1;
                    if (s_last) begin
                        state <= S_IP_CHK;
                        ip_csum_acc <= 9'd0;
                        ip_csum_idx <= 5'd0;
                        s_ready <= 1'b0;
                    end
                end
            end
            S_IP_CHK: begin
                s_ready <= 1'b0;
                if (w_e1) begin
                    err_code <= 4'd1;
                    state <= S_STATUS;
                    status_timer <= 4'd0;
                end else if (w_e2) begin
                    err_code <= 4'd2;
                    state <= S_STATUS;
                    status_timer <= 4'd0;
                end else begin
                    ip_csum_acc <= ip_csum_acc + {buf[ip_csum_idx], buf[ip_csum_idx+1]};
                    ip_csum_idx <= ip_csum_idx + 5'd2;
                    if (ip_csum_idx == 5'd18) begin
                        if (w_e3) begin
                            err_code <= 4'd3;
                            state <= S_STATUS;
                            status_timer <= 4'd0;
                        end else begin
                            state <= S_UDP_CHK;
                            udp_csum_acc <= udp_pseudo_sum;
                            udp_csum_idx <= 10'd20;
                        end
                    end
                end
            end
            S_UDP_CHK: begin
                s_ready <= 1'b0;
                udp_csum_acc <= udp_next;
                udp_csum_idx <= udp_csum_idx + 10'd2;
                if (udp_csum_idx + 10'd2 >= byte_cnt) begin
                    if (w_e4) begin
                        err_code <= 4'd4;
                        state <= S_STATUS;
                        status_timer <= 4'd0;
                    end else if (w_e5) begin
                        err_code <= 4'd5;
                        state <= S_STATUS;
                        status_timer <= 4'd0;
                    end else begin
                        err_code <= 4'd0;
                        state <= S_STATUS;
                        status_timer <= 4'd0;
                        out_ptr <= 10'd28;
                        out_end <= byte_cnt - 10'd1;
                    end
                end
            end
            S_STATUS: begin
                s_ready <= 1'b0;
                status_valid <= 1'b1;
                status_error <= err_code;
                status_timer <= status_timer + 4'd1;
                if (status_timer == 4'd15) begin
                    status_valid <= 1'b0;
                    if (err_code == 4'd0) begin
                        state <= S_OUT;
                        m_valid <= 1'b1;
                        m_data <= buf[28];
                        m_last <= (10'd28 == out_end);
                        m_src_ip <= {buf[12], buf[13], buf[14], buf[15]};
                        m_src_port <= {buf[20], buf[21]};
                        m_dst_port <= {buf[22], buf[23]};
                        m_payload_len <= w_plen;
                    end else begin
                        state <= S_IDLE;
                        byte_cnt <= 10'd0;
                        s_ready <= 1'b1;
                        m_valid <= 1'b0;
                    end
                end
            end
            S_OUT: begin
                s_ready <= 1'b0;
                if (m_valid && m_ready) begin
                    if (m_last) begin
                        state <= S_IDLE;
                        byte_cnt <= 10'd0;
                        m_valid <= 1'b0;
                        s_ready <= 1'b1;
                    end else begin
                        out_ptr <= out_ptr + 10'd1;
                        m_data <= buf[out_ptr + 10'd1];
                        m_last <= ((out_ptr + 10'd1) == out_end);
                    end
                end
            end
            default: begin
                state <= S_IDLE;
                s_ready <= 1'b1;
                m_valid <= 1'b0;
            end
        endcase
    end
end

always @(*) begin
    w_ip_total_len = {buf[2], buf[3]};
    w_udp_len      = {buf[24], buf[25]};
    w_udp_csum     = {buf[26], buf[27]};
    w_plen         = w_udp_len - 16'd8;

    w_oversize = (byte_cnt > 10'd512);
    w_short    = (byte_cnt < 10'd28);
    w_v4       = (buf[0][7:4] != 4'd4);
    w_ihl5     = (buf[0][3:0] != 4'd5);
    w_proto17  = (buf[9] != 8'd17);
    w_mf       = buf[6][5];
    w_frag     = (buf[6][4:0] != 5'd0) || (buf[7] != 8'd0);
    w_e1       = w_short | w_oversize | w_v4 | w_ihl5 | w_proto17 | w_mf | w_frag;

    w_ip_match = (w_ip_total_len == byte_cnt);
    w_udp_match= (w_udp_len == (w_ip_total_len - 16'd20));
    w_pl_ok    = (w_plen >= 16'd1) && (w_plen <= 16'd256);
    w_e2       = ~w_ip_match | ~w_udp_match | ~w_pl_ok;

    w_ip_folded = ip_csum_acc[8:0] + {7'd0, ip_csum_acc[8]};
    w_e3 = (w_ip_folded != 16'hFFFF);

    udp_pseudo_sum = {1'b0,buf[12],buf[13]} + {1'b0,buf[14],buf[15]}
                   + {1'b0,buf[16],buf[17]} + {1'b0,buf[18],buf[19]}
                   + 17'd17 + {1'b0,w_udp_len[15:0]};

    udp_next = udp_csum_acc + {1'b0, buf[udp_csum_idx], (udp_csum_idx+10'd1 < byte_cnt) ? buf[udp_csum_idx+10'd1] : 8'd0};

    udp_f1 = udp_csum_acc[15:0] + {15'd0, udp_csum_acc[16]};
    udp_f2 = udp_f1[15:0] + {15'd0, udp_f1[16]};
    w_e4 = (w_udp_csum != 16'd0) && (udp_f2 != 16'hFFFF);

    w_dst_ip   = {buf[16], buf[17], buf[18], buf[19]};
    w_dst_port_val = {buf[22], buf[23]};
    w_e5 = (w_dst_ip != 32'h0A000002) || (w_dst_port_val != 16'd9000);
end

endmodule
