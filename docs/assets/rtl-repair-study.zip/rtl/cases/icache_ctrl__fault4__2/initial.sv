module icache_ctrl(
input wire clk_i,
input wire rst_ni,
input wire req_i,
input wire branch_i,
input wire [31:0] addr_i,
input wire ready_i,
output wire valid_o,
output wire [31:0] rdata_o,
output wire [31:0] addr_o,
output wire err_o,
output wire instr_req_o,
input wire instr_gnt_i,
output wire [31:0] instr_addr_o,
input wire [31:0] instr_rdata_i,
input wire instr_err_i,
input wire instr_rvalid_i,
input wire icache_inval_i,
output wire busy_o
);

  // Tag memory: 22 bits (valid + tag)
  // Data memory: 64 bits (2 instructions)
  // Single-bank, 256 entries, direct-mapped
  reg [21:0] tag_mem [0:255];
  reg [63:0] data_mem [0:255];
  
  wire [21:0] tag_rdata;
  wire [63:0] data_rdata;
  wire tag_write, data_write;
  wire [7:0] tag_addr, data_addr;
  wire [21:0] tag_wdata;
  wire [63:0] data_wdata;
  
  assign tag_addr = addr_i[9:2];  // 8-bit index from bits 9:2 (word address bits 11:2 shifted)
  assign data_addr = addr_i[9:2];
  
  reg tag_req_q, data_req_q;
  wire tag_req, data_req;
  assign tag_req = 1'b1;  // Always read for lookup
  assign data_req = 1'b1; // Always read for lookup
  
  always @(posedge clk_i) begin
    if (tag_req) begin
      tag_rdata <= tag_mem[tag_addr];
      if (tag_write) tag_mem[tag_addr] <= tag_wdata;
    end
    if (data_req) begin
      data_rdata <= data_mem[data_addr];
      if (data_write) data_mem[data_addr] <= data_wdata;
    end
  end
  
  wire [21:0] current_tag;
  assign current_tag = {2'b00, addr_i[31:12]}; // 20-bit tag + 2-bit valid/parity placeholder
  
  ibex_icache #(
    .ICacheECC(0),
    .ResetAll(1),
    .BranchCache(0),
    .TweakInfection(0)
  ) core (
    .clk_i(clk_i),
    .rst_ni(rst_ni),
    .req_i(req_i),
    .branch_i(branch_i),
    .addr_i(addr_i),
    .ready_i(ready_i),
    .valid_o(valid_o),
    .rdata_o(rdata_o),
    .addr_o(addr_o),
    .err_o(err_o),
    .instr_req_o(instr_req_o),
    .instr_gnt_i(instr_gnt_i),
    .instr_addr_o(instr_addr_o),
    .instr_rdata_i(instr_rdata_i),
    .instr_err_i(instr_err_i),
    .instr_rvalid_i(instr_rvalid_i),
    .icache_inval_i(icache_inval_i),
    .busy_o(busy_o),
    .ic_tag_req_o(),
    .ic_tag_write_o(tag_write),
    .ic_tag_addr_o(),
    .ic_tag_wdata_o(tag_wdata),
    .ic_tag_rdata_i(tag_rdata),
    .ic_data_req_o(),
    .ic_data_write_o(data_write),
    .ic_data_addr_o(),
    .ic_data_wdata_o(data_wdata),
    .ic_data_rdata_i(data_rdata),
    .ic_scr_key_valid_i(1'b1),
    .icache_enable_i(1'b1)
  );

endmodule
