module icache_ctrl(
input wire clk_i,
input wire rst_ni,
input wire req_i,
input wire branch_i,
input wire [31:0] addr_i,
input wire ready_i,
output wire valid_o,
output wire [31:0] rdata_o,
output wire [31:0] addr_o,
output wire err_o,
output wire instr_req_o,
input wire instr_gnt_i,
output wire [31:0] instr_addr_o,
input wire [31:0] instr_rdata_i,
input wire instr_err_i,
input wire instr_rvalid_i,
input wire icache_inval_i,
output wire busy_o
);

  wire ic_tag_req_o;
  wire ic_tag_write_o;
  wire [9:0] ic_tag_addr_o;
  wire [21:0] ic_tag_wdata_o;
  wire [21:0] ic_tag_rdata_i;
  wire ic_data_req_o;
  wire ic_data_write_o;
  wire [9:0] ic_data_addr_o;
  wire [63:0] ic_data_wdata_o;
  wire [63:0] ic_data_rdata_i;

  reg [21:0] tag_mem [0:1023];
  reg [63:0] data_mem [0:1023];

  reg [21:0] tag_rdata_q;
  reg [63:0] data_rdata_q;

  always @(posedge clk_i) begin
    if (ic_tag_req_o) begin
      tag_rdata_q <= tag_mem[ic_tag_addr_o];
      if (ic_tag_write_o) tag_mem[ic_tag_addr_o] <= ic_tag_wdata_o;
    end
    if (ic_data_req_o) begin
      data_rdata_q <= data_mem[ic_data_addr_o];
      if (ic_data_write_o) data_mem[ic_data_addr_o] <= ic_data_wdata_o;
    end
  end

  assign ic_tag_rdata_i = tag_rdata_q;
  assign ic_data_rdata_i = data_rdata_q;

  ibex_icache #(
    .ICacheECC(0),
    .ResetAll(1),
    .BranchCache(0),
    .TweakInfection(0)
  ) core (
    .clk_i(clk_i),
    .rst_ni(rst_ni),
    .req_i(req_i),
    .branch_i(branch_i),
    .addr_i(addr_i),
    .ready_i(ready_i),
    .valid_o(valid_o),
    .rdata_o(rdata_o),
    .addr_o(addr_o),
    .err_o(err_o),
    .instr_req_o(instr_req_o),
    .instr_gnt_i(instr_gnt_i),
    .instr_addr_o(instr_addr_o),
    .instr_rdata_i(instr_rdata_i),
    .instr_err_i(instr_err_i),
    .instr_rvalid_i(instr_rvalid_i),
    .icache_inval_i(icache_inval_i),
    .busy_o(busy_o),
    .ic_tag_req_o(ic_tag_req_o),
    .ic_tag_write_o(ic_tag_write_o),
    .ic_tag_addr_o(ic_tag_addr_o),
    .ic_tag_wdata_o(ic_tag_wdata_o),
    .ic_tag_rdata_i(ic_tag_rdata_i),
    .ic_data_req_o(ic_data_req_o),
    .ic_data_write_o(ic_data_write_o),
    .ic_data_addr_o(ic_data_addr_o),
    .ic_data_wdata_o(ic_data_wdata_o),
    .ic_data_rdata_i(ic_data_rdata_i),
    .ic_scr_key_valid_i(1'b1),
    .icache_enable_i(1'b1)
  );

endmodule
