`timescale 1ns / 1ps
`default_nettype none

module dma_write(
input wire clk,
input wire rst,
input wire [15:0] desc_addr,
input wire [15:0] desc_len,
input wire [7:0] desc_tag,
input wire desc_valid,
output wire desc_ready,
input wire [31:0] s_data,
input wire [3:0] s_keep,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [15:0] status_len,
output wire [7:0] status_tag,
output wire [3:0] status_error,
output wire status_valid,
output wire [3:0] m_axi_awid,
output wire [15:0] m_axi_awaddr,
output wire [7:0] m_axi_awlen,
output wire [2:0] m_axi_awsize,
output wire [1:0] m_axi_awburst,
output wire m_axi_awlock,
output wire [3:0] m_axi_awcache,
output wire [2:0] m_axi_awprot,
output wire m_axi_awvalid,
input wire m_axi_awready,
output wire [31:0] m_axi_wdata,
output wire [3:0] m_axi_wstrb,
output wire m_axi_wlast,
output wire m_axi_wvalid,
input wire m_axi_wready,
input wire [3:0] m_axi_bid,
input wire [1:0] m_axi_bresp,
input wire m_axi_bvalid,
output wire m_axi_bready);

reg [2:0] state;
localparam S_IDLE = 3'd0, S_RUN = 3'd1, S_WAIT_B = 3'd2, S_STATUS = 3'd3;

reg [15:0] r_addr, r_rem, r_total;
reg [7:0]  r_tag;
reg        seen_slverr, seen_decerr;
reg [3:0]  aw_pending;

reg        aw_done;
reg [15:0] aw_addr_r;
reg [7:0]  aw_len_r;

wire [15:0] start_offset = r_addr[1:0];
wire [15:0] bytes_in_first_burst = (16'd4 << $clog2({1'b0, ~start_offset[1:0]})) - {14'd0, start_offset};
wire [15:0] eff_bytes = (r_rem < bytes_in_first_burst) ? r_rem : bytes_in_first_burst;
wire [3:0]  beats = ((eff_bytes + start_offset + 16'd3) >> 2);
wire [15:0] next_addr = (r_addr & 16'hFFFC) + (r_rem < bytes_in_first_burst ? r_rem : bytes_in_first_burst);
wire [15:0] next_rem  = (r_rem < bytes_in_first_burst) ? 16'd0 : (r_rem - bytes_in_first_burst);
wire        last_burst = (next_rem == 16'd0);

assign desc_ready    = (state == S_IDLE);
assign status_valid  = (state == S_STATUS);
assign status_len    = r_total;
assign status_tag    = r_tag;
assign status_error  = seen_decerr ? 4'd7 : (seen_slverr ? 4'd6 : 4'd0);

assign m_axi_awid    = 4'd0;
assign m_axi_awaddr  = aw_done ? aw_addr_r : r_addr;
assign m_axi_awlen   = aw_done ? aw_len_r : (beats - 4'd1);
assign m_axi_awsize  = 3'd2;
assign m_axi_awburst = 2'b01;
assign m_axi_awlock  = 1'b0;
assign m_axi_awcache = 4'd3;
assign m_axi_awprot  = 3'd0;
assign m_axi_awvalid = (state == S_RUN) && !aw_done;

assign s_ready       = (state == S_RUN) && m_axi_wready;
assign m_axi_wvalid  = (state == S_RUN) && s_valid;
assign m_axi_wdata   = s_data;
assign m_axi_wlast   = s_last;

reg [3:0] wstrb_r;
always @(*) begin
    if (s_last) begin
        wstrb_r = s_keep & ~((4'd1 << start_offset) - 4'd1);
    end else begin
        wstrb_r = ~(4'hF << start_offset);
    end
end
assign m_axi_wstrb = wstrb_r;

assign m_axi_bready = (state == S_WAIT_B);

always @(posedge clk) begin
    if (rst) begin
        state <= S_IDLE;
        aw_pending <= 4'd0;
        seen_slverr <= 1'b0;
        seen_decerr <= 1'b0;
        aw_done <= 1'b0;
    end else begin
        case (state)
            S_IDLE: begin
                if (desc_valid) begin
                    r_addr      <= desc_addr;
                    r_rem       <= desc_len;
                    r_total     <= desc_len;
                    r_tag       <= desc_tag;
                    seen_slverr <= 1'b0;
                    seen_decerr <= 1'b0;
                    aw_pending  <= 4'd0;
                    aw_done     <= 1'b0;
                    state       <= S_RUN;
                end
            end
            S_RUN: begin
                if (m_axi_awvalid && m_axi_awready) begin
                    aw_done    <= 1'b1;
                    aw_addr_r  <= r_addr;
                    aw_len_r   <= beats - 4'd1;
                    aw_pending <= aw_pending + 4'd1;
                end
                if (m_axi_wvalid && m_axi_wready && s_last) begin
                    r_addr  <= next_addr;
                    r_rem   <= next_rem;
                    aw_done <= 1'b0;
                    if (last_burst)
                        state <= S_WAIT_B;
                end
            end
            S_WAIT_B: begin
                if (m_axi_bvalid) begin
                    if (m_axi_bresp == 2'b10) seen_slverr <= 1'b1;
                    if (m_axi_bresp == 2'b11) seen_decerr <= 1'b1;
                    aw_pending <= aw_pending - 4'd1;
                    if (aw_pending == 4'd1)
                        state <= S_STATUS;
                end
            end
            S_STATUS: begin
                state <= S_IDLE;
            end
        endcase
    end
end

endmodule
