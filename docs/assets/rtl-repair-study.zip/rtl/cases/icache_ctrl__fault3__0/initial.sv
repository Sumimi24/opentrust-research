module icache_ctrl(
input wire clk_i,
input wire rst_ni,
input wire req_i,
input wire branch_i,
input wire [31:0] addr_i,
input wire ready_i,
output wire valid_o,
output wire [31:0] rdata_o,
output wire [31:0] addr_o,
output wire err_o,
output wire instr_req_o,
input wire instr_gnt_i,
output wire [31:0] instr_addr_o,
input wire [31:0] instr_rdata_i,
input wire instr_err_i,
input wire instr_rvalid_i,
input wire icache_inval_i,
output wire busy_o);

import ibex_pkg::*;

wire [1:0] tag_req;
wire [1:0] data_req;
wire tag_write;
wire data_write;
wire [7:0] tag_addr;
wire [7:0] data_addr;
wire [21:0] tag_wdata;
wire [63:0] data_wdata;

reg [21:0] tag_rdata_q[0:1];
reg [63:0] data_rdata_q[0:1];

reg [21:0] tag_mem0[0:255];
reg [21:0] tag_mem1[0:255];
reg [63:0] data_mem0[0:255];
reg [63:0] data_mem1[0:255];

integer i;
always @(negedge rst_ni or posedge clk_i) begin
  if (!rst_ni) begin
    for (i = 0; i < 256; i = i + 1) begin
      tag_mem0[i] <= 22'd0;
      tag_mem1[i] <= 22'd0;
      data_mem0[i] <= 64'd0;
      data_mem1[i] <= 64'd0;
    end
    tag_rdata_q[0] <= 22'd0;
    tag_rdata_q[1] <= 22'd0;
    data_rdata_q[0] <= 64'd0;
    data_rdata_q[1] <= 64'd0;
  end else begin
    if (tag_req[0]) begin
      if (tag_write) tag_mem0[tag_addr] <= tag_wdata;
      tag_rdata_q[0] <= tag_write ? tag_wdata : tag_mem0[tag_addr];
    end
    if (tag_req[1]) begin
      if (tag_write) tag_mem1[tag_addr] <= tag_wdata;
      tag_rdata_q[1] <= tag_write ? tag_wdata : tag_mem1[tag_addr];
    end
    if (data_req[0]) begin
      if (data_write) data_mem0[data_addr] <= data_wdata;
      data_rdata_q[0] <= data_write ? data_wdata : data_mem0[data_addr];
    end
    if (data_req[1]) begin
      if (data_write) data_mem1[data_addr] <= data_wdata;
      data_rdata_q[1] <= data_write ? data_wdata : data_mem1[data_addr];
    end
  end
end

ibex_icache #(
  .ICacheECC(0),
  .ResetAll(1),
  .BranchCache(0),
  .TweakInfection(0)
) core (
  .clk_i(clk_i),
  .rst_ni(rst_ni),
  .req_i(req_i),
  .branch_i(branch_i),
  .addr_i(addr_i),
  .ready_i(ready_i),
  .valid_o(valid_o),
  .rdata_o(rdata_o),
  .addr_o(addr_o),
  .err_o(err_o),
  .instr_req_o(instr_req_o),
  .instr_gnt_i(instr_gnt_i),
  .instr_addr_o(instr_addr_o),
  .instr_rdata_i(instr_rdata_i),
  .instr_err_i(instr_err_i),
  .instr_rvalid_i(instr_rvalid_i),
  .icache_inval_i(icache_inval_i),
  .busy_o(busy_o),
  .ic_tag_req_o(tag_req),
  .ic_tag_write_o(tag_write),
  .ic_tag_addr_o(tag_addr),
  .ic_tag_wdata_o(tag_wdata),
  .ic_tag_rdata_i(tag_rdata_q),
  .ic_data_req_o(data_req),
  .ic_data_write_o(data_write),
  .ic_data_addr_o(data_addr),
  .ic_data_wdata_o(data_wdata),
  .ic_data_rdata_i(data_rdata_q),
  .ic_scr_key_valid_i(1'b1),
  .icache_enable_i(1'b1)
);

endmodule
