`timescale 1ns/1ps
`default_nettype none

module icache_ctrl(
input wire clk_i,
input wire rst_ni,
input wire req_i,
input wire branch_i,
input wire [31:0] addr_i,
input wire ready_i,
output wire valid_o,
output wire [31:0] rdata_o,
output wire [31:0] addr_o,
output wire err_o,
output wire instr_req_o,
input wire instr_gnt_i,
output wire [31:0] instr_addr_o,
input wire [31:0] instr_rdata_i,
input wire instr_err_i,
input wire instr_rvalid_i,
input wire icache_inval_i,
output wire busy_o);

import ibex_pkg::*;

wire [1:0] tag_req, data_req;
wire tag_write, data_write;
wire [7:0] tag_addr, data_addr;
wire [21:0] tag_wdata;
wire [63:0] data_wdata;
reg [21:0] tag_rdata[2];
reg [63:0] data_rdata[2];
reg [21:0] tag_mem0[256], tag_mem1[256];
reg [63:0] data_mem0[256], data_mem1[256];

always @(posedge clk_i) begin
    if (tag_req[0]) begin
        tag_rdata[0] <= tag_mem0[tag_addr];
        if (tag_write) tag_mem0[tag_addr] <= tag_wdata;
    end
    if (tag_req[1]) begin
        tag_rdata[1] <= tag_mem1[tag_addr];
        if (tag_write) tag_mem1[tag_addr] <= tag_wdata;
    end
    if (data_req[0]) begin
        data_rdata[0] <= data_mem0[data_addr];
        if (data_write) data_mem0[data_addr] <= data_wdata;
    end
    if (data_req[1]) begin
        data_rdata[1] <= data_mem1[data_addr];
        if (data_write) data_mem1[data_addr] <= data_wdata;
    end
end

wire core_valid, core_err;
wire [31:0] core_rdata, core_addr;

reg error_consumed_q, error_consumed_d;
reg branch_pending_q, branch_pending_d;
reg [31:0] next_pc_q, next_pc_d;

reg [31:0] held_addr_q, held_addr_d;
reg [31:0] held_rdata_q, held_rdata_d;
reg held_err_q, held_err_d;
reg held_valid_q, held_valid_d;

wire out_valid = core_valid | held_valid_q;
wire out_err = held_valid_q ? held_err_q : core_err;
wire [31:0] out_rdata = held_valid_q ? held_rdata_q : core_rdata;
wire [31:0] out_addr = held_valid_q ? held_addr_q : core_addr;

assign valid_o = branch_pending_q ? 1'b0 : (error_consumed_q ? 1'b0 : out_valid);
assign err_o = out_err;
assign rdata_o = out_rdata;
assign addr_o = out_addr;

always @* begin
    error_consumed_d = error_consumed_q;
    branch_pending_d = branch_pending_q;
    next_pc_d = next_pc_q;
    held_valid_d = held_valid_q;
    held_addr_d = held_addr_q;
    held_rdata_d = held_rdata_q;
    held_err_d = held_err_q;

    if (!rst_ni) begin
        error_consumed_d = 1'b0;
        branch_pending_d = 1'b0;
        next_pc_d = 32'd0;
        held_valid_d = 1'b0;
        held_addr_d = 32'd0;
        held_rdata_d = 32'd0;
        held_err_d = 1'b0;
    end else begin
        if (branch_i) begin
            branch_pending_d = 1'b1;
            error_consumed_d = 1'b0;
            next_pc_d = addr_i;
            held_valid_d = 1'b0;
        end else if (branch_pending_d && core_valid && !held_valid_q) begin
            if (core_addr == next_pc_q) begin
                branch_pending_d = 1'b0;
            end
        end

        if (out_valid && !branch_i) begin
            if (ready_i) begin
                if (out_err)
                    error_consumed_d = 1'b1;
            end else begin
                held_valid_d = 1'b1;
                held_addr_d = out_addr;
                held_rdata_d = out_rdata;
                held_err_d = out_err;
            end
        end else if (ready_i && held_valid_q && !branch_i) begin
            held_valid_d = 1'b0;
        end else if (branch_i && held_valid_q) begin
            held_valid_d = 1'b0;
        end
    end
end

always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
        error_consumed_q <= 1'b0;
        branch_pending_q <= 1'b0;
        next_pc_q <= 32'd0;
        held_valid_q <= 1'b0;
        held_addr_q <= 32'd0;
        held_rdata_q <= 32'd0;
        held_err_q <= 1'b0;
    end else begin
        error_consumed_q <= error_consumed_d;
        branch_pending_q <= branch_pending_d;
        next_pc_q <= next_pc_d;
        held_valid_q <= held_valid_d;
        held_addr_q <= held_addr_d;
        held_rdata_q <= held_rdata_d;
        held_err_q <= held_err_d;
    end
end

ibex_icache #(
    .ICacheECC(0),
    .ResetAll(1),
    .BranchCache(0),
    .TweakInfection(0)
) core (
    .clk_i(clk_i),
    .rst_ni(rst_ni),
    .req_i(req_i),
    .branch_i(branch_i),
    .addr_i(addr_i),
    .ready_i(ready_i),
    .valid_o(core_valid),
    .rdata_o(core_rdata),
    .addr_o(core_addr),
    .err_o(core_err),
    .instr_req_o(instr_req_o),
    .instr_gnt_i(instr_gnt_i),
    .instr_addr_o(instr_addr_o),
    .instr_rdata_i(instr_rdata_i),
    .instr_err_i(instr_err_i),
    .instr_rvalid_i(instr_rvalid_i),
    .icache_inval_i(icache_inval_i),
    .busy_o(busy_o),
    .ic_tag_req_o(tag_req),
    .ic_tag_write_o(tag_write),
    .ic_tag_addr_o(tag_addr),
    .ic_tag_wdata_o(tag_wdata),
    .ic_tag_rdata_i(tag_rdata),
    .ic_data_req_o(data_req),
    .ic_data_write_o(data_write),
    .ic_data_addr_o(data_addr),
    .ic_data_wdata_o(data_wdata),
    .ic_data_rdata_i(data_rdata),
    .ic_scr_key_valid_i(1'b1),
    .icache_enable_i(1'b1)
);

endmodule
```
