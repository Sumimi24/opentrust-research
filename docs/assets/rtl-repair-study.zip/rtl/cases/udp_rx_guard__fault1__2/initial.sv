module udp_rx_guard(
    input wire clk,
    input wire rst,
    input wire [7:0] s_data,
    input wire s_valid,
    output wire s_ready,
    input wire s_last,
    output wire [7:0] m_data,
    output wire m_valid,
    input wire m_ready,
    output wire m_last,
    output wire [31:0] m_src_ip,
    output wire [15:0] m_src_port,
    output wire [15:0] m_dst_port,
    output wire [15:0] m_payload_len,
    output wire status_valid,
    output wire [3:0] status_error
);

    // Buffer for incoming bytes (max 512)
    reg [7:0] bytes[0:511];
    reg [9:0] n;                  // number of bytes received so far
    reg [9:0] ptr;                // pointer for output payload byte
    reg [3:0] state;
    reg [15:0] cycle_cnt;         // timeout counter for status delay check
    
    // Status register
    reg status_valid_reg;
    reg [3:0] status_error_reg;
    
    // Combinational error checking
    wire [3:0] error_code;
    reg [3:0] error_code_stored;   // stored at end of frame
    
    // Internal signals from parser
    wire hdr_ready;
    wire parse_ready;
    wire [15:0] parsed_length;
    
    // Combinational error detection (purely combinational, uses current n and bytes)
    function integer word16(input integer offset);
        begin
            word16 = {bytes[offset], bytes[offset+1]};
        end
    endfunction
    
    function [15:0] fold(input [31:0] value);
        reg [16:0] v;
        begin
            v = value[15:0] + value[31:16];
            fold = v[15:0] + v[16];
        end
    endfunction
    
    wire [15:0] ip_len_w;
    assign ip_len_w = word16(2);
    
    wire [3:0] err1;
    assign err1 = (n < 28 || n > 512 || bytes[0] != 8'h45 || bytes[9] != 8'd17 || 
                   (bytes[6] & 8'h3f) != 0 || bytes[7] != 0) ? 4'd1 : 4'd0;
    
    wire [15:0] udp_len_w;
    assign udp_len_w = word16(24);
    
    wire [3:0] err2;
    assign err2 = (err1 == 0 && (ip_len_w != n || udp_len_w != ip_len_w - 20 || udp_len_w < 9 || udp_len_w > 264)) ? 4'd2 : 4'd0;
    
    // Compute IP header checksum (20 bytes)
    reg [31:0] ip_sum;
    reg [31:0] udp_sum;
    integer j;
    
    always @(*) begin
        ip_sum = 0;
        for (j = 0; j < 20; j = j + 2) begin
            ip_sum = ip_sum + word16(j);
        end
    end
    
    wire [3:0] err3;
    assign err3 = (err1 == 0 && err2 == 0 && fold(ip_sum) != 16'hffff) ? 4'd3 : 4'd0;
    
    // Compute UDP checksum
    always @(*) begin
        udp_sum = 0;
        // Pseudo header: source IP
        for (j = 12; j < 20; j = j + 2) begin
            udp_sum = udp_sum + word16(j);
        end
        // Protocol (17)
        udp_sum = udp_sum + 32'd17;
        // UDP length
        udp_sum = udp_sum + udp_len_w;
        // UDP header + payload
        for (j = 20; j < 512; j = j + 2) begin
            if (j < n) begin
                if (j + 1 < n)
                    udp_sum = udp_sum + word16(j);
                else
                    udp_sum = udp_sum + {bytes[j], 8'd0}; // pad odd last byte
            end
        end
    end
    
    wire [3:0] err4;
    assign err4 = (err1 == 0 && err2 == 0 && err3 == 0 && 
                   word16(26) != 0 && fold(udp_sum) != 16'hffff) ? 4'd4 : 4'd0;
    
    wire [3:0] err5;
    assign err5 = (err1 == 0 && err2 == 0 && err3 == 0 && err4 == 0 && 
                   ({bytes[16], bytes[17], bytes[18], bytes[19]} != 32'h0a000002 || word16(22) != 16'd9000)) ? 4'd5 : 4'd0;
    
    assign error_code = err1 ? err1 : 
                        err2 ? err2 : 
                        err3 ? err3 : 
                        err4 ? err4 : 
                        err5 ? err5 : 4'd0;
    
    // Ready for input only in state 0 (idle/collecting)
    assign s_ready = !rst && (state == 0);
    
    assign status_valid = status_valid_reg;
    assign status_error = status_error_reg;
    assign m_payload_len = parsed_length - 8;
    
    always @(posedge clk) begin
        if (rst) begin
            state <= 0;
            n <= 0;
            ptr <= 20;
            status_valid_reg <= 0;
            status_error_reg <= 0;
            cycle_cnt <= 0;
            error_code_stored <= 0;
        end else begin
            status_valid_reg <= 1'b0;
            
            case (state)
                0: begin
                    if (s_valid && s_ready) begin
                        if (n < 512)
                            bytes[n] <= s_data;
                        n <= n + 1;
                        if (s_last) begin
                            state <= 1;
                            error_code_stored <= error_code;
                            cycle_cnt <= 0;
                        end
                    end
                end
                
                1: begin
                    // Emit status
                    status_valid_reg <= 1'b1;
                    status_error_reg <= error_code_stored;
                    if (error_code_stored == 0) begin
                        state <= 2;  // Start header handshake with parser
                        ptr <= 20;
                        cycle_cnt <= 0;
                    end else begin
                        state <= 0;  // Reject, go back to idle
                        n <= 0;
                    end
                end
                
                2: begin
                    if (hdr_ready)
                        state <= 3;
                    cycle_cnt <= cycle_cnt + 1;
                end
                
                3: begin
                    if (parse_ready) begin
                        if (ptr == n - 1)
                            state <= 4;
                        else
                            ptr <= ptr + 1;
                    end
                end
                
                4: begin
                    if (m_valid && m_ready && m_last) begin
                        state <= 0;
                        n <= 0;
                    end
                end
                
                default: state <= 0;
            endcase
        end
    end
    
    udp_ip_rx parser(
        .clk(clk),
        .rst(rst),
        .s_ip_hdr_valid(state == 2),
        .s_ip_hdr_ready(hdr_ready),
        .s_eth_dest_mac(48'b0),
        .s_eth_src_mac(48'b0),
        .s_eth_type(16'h0800),
        .s_ip_version(bytes[0][7:4]),
        .s_ip_ihl(bytes[0][3:0]),
        .s_ip_dscp(bytes[1][7:2]),
        .s_ip_ecn(bytes[1][1:0]),
        .s_ip_length({bytes[2], bytes[3]}),
        .s_ip_identification({bytes[4], bytes[5]}),
        .s_ip_flags(bytes[6][7:5]),
        .s_ip_fragment_offset({bytes[6][4:0], bytes[7]}),
        .s_ip_ttl(bytes[8]),
        .s_ip_protocol(bytes[9]),
        .s_ip_header_checksum({bytes[10], bytes[11]}),
        .s_ip_source_ip({bytes[12], bytes[13], bytes[14], bytes[15]}),
        .s_ip_dest_ip({bytes[16], bytes[17], bytes[18], bytes[19]}),
        .s_ip_payload_axis_tdata(bytes[ptr]),
        .s_ip_payload_axis_tvalid(state == 3),
        .s_ip_payload_axis_tready(parse_ready),
        .s_ip_payload_axis_tlast(ptr == n - 1),
        .s_ip_payload_axis_tuser(1'b0),
        .m_udp_hdr_ready(1'b1),
        .m_ip_source_ip(m_src_ip),
        .m_udp_source_port(m_src_port),
        .m_udp_dest_port(m_dst_port),
        .m_udp_length(parsed_length),
        .m_udp_payload_axis_tdata(m_data),
        .m_udp_payload_axis_tvalid(m_valid),
        .m_udp_payload_axis_tready(m_ready),
        .m_udp_payload_axis_tlast(m_last)
    );

endmodule
