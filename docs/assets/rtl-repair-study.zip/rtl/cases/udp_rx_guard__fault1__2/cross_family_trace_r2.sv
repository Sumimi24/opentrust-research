module udp_rx_guard(
    input wire clk,
    input wire rst,
    input wire [7:0] s_data,
    input wire s_valid,
    output wire s_ready,
    input wire s_last,
    output wire [7:0] m_data,
    output wire m_valid,
    input wire m_ready,
    output wire m_last,
    output wire [31:0] m_src_ip,
    output wire [15:0] m_src_port,
    output wire [15:0] m_dst_port,
    output wire [15:0] m_payload_len,
    output wire status_valid,
    output wire [3:0] status_error
);

    // Buffer for incoming bytes (max 512)
    reg [7:0] bytes[0:511];
    reg [9:0] n;                  // number of bytes received so far
    reg [9:0] ptr;                // pointer for output payload byte
    reg [3:0] state;
    
    // Status register
    reg status_valid_reg;
    reg [3:0] status_error_reg;
    
    // Stored error code
    reg [3:0] error_code_stored;
    
    // Parser interface signals
    reg s_ip_hdr_valid_reg;
    wire s_ip_hdr_ready;
    reg s_ip_payload_axis_tvalid_reg;
    wire s_ip_payload_axis_tready;
    
    // Parser outputs
    wire [31:0] m_ip_source_ip;
    wire [15:0] m_udp_source_port;
    wire [15:0] m_udp_dest_port;
    wire [15:0] m_udp_length;
    wire [7:0] m_udp_payload_axis_tdata;
    wire m_udp_payload_axis_tvalid;
    wire m_udp_payload_axis_tlast;
    
    // Combinational error detection functions
    function [15:0] word16(input integer offset);
        begin
            word16 = {bytes[offset], bytes[offset+1]};
        end
    endfunction
    
    function [15:0] fold(input [31:0] value);
        reg [16:0] v;
        begin
            v = value[15:0] + value[31:16];
            fold = v[15:0] + v[16];
        end
    endfunction
    
    // IP header checksum calculation
    reg [31:0] ip_sum;
    integer i;
    
    always @(*) begin
        ip_sum = 0;
        for (i = 0; i < 20; i = i + 2) begin
            ip_sum = ip_sum + word16(i);
        end
    end
    
    // UDP checksum calculation (pseudo-header + UDP header + payload)
    reg [31:0] udp_sum;
    integer j;
    reg [15:0] udp_len;
    reg [9:0] payload_end;
    
    always @(*) begin
        udp_len = word16(24);
        payload_end = 20 + udp_len;
        if (payload_end > n) payload_end = n;
        
        udp_sum = 0;
        // Pseudo-header: source IP
        udp_sum = udp_sum + word16(12);
        udp_sum = udp_sum + word16(14);
        // Pseudo-header: dest IP
        udp_sum = udp_sum + word16(16);
        udp_sum = udp_sum + word16(18);
        // Pseudo-header: protocol (17) + UDP length
        udp_sum = udp_sum + 32'd17;
        udp_sum = udp_sum + udp_len;
        // UDP header + payload
        for (j = 20; j < 512 && j < payload_end; j = j + 2) begin
            if (j + 1 < payload_end)
                udp_sum = udp_sum + word16(j);
            else
                udp_sum = udp_sum + {bytes[j], 8'd0};
        end
    end
    
    // Error detection (combinational)
    wire [15:0] ip_len_w;
    wire [15:0] udp_len_w;
    wire [3:0] err1;
    wire [3:0] err2;
    wire [3:0] err3;
    wire [3:0] err4;
    wire [3:0] err5;
    wire [3:0] error_code;
    
    assign ip_len_w = word16(2);
    assign udp_len_w = word16(24);
    
    assign err1 = (n < 28 || n > 512 || bytes[0][7:4] != 4'd4 || bytes[0][3:0] != 4'd5 || 
                   bytes[9] != 8'd17 || bytes[6][5] != 1'b0 || bytes[6][4:0] != 5'b0 || bytes[7] != 8'b0) ? 4'd1 : 4'd0;
    
    assign err2 = (err1 == 0 && (ip_len_w != n || udp_len_w != ip_len_w - 20 || udp_len_w < 9 || udp_len_w > 264)) ? 4'd2 : 4'd0;
    
    assign err3 = (err1 == 0 && err2 == 0 && fold(ip_sum) != 16'hffff) ? 4'd3 : 4'd0;
    
    assign err4 = (err1 == 0 && err2 == 0 && err3 == 0 && 
                   word16(26) != 16'd0 && fold(udp_sum) != 16'hffff) ? 4'd4 : 4'd0;
    
    assign err5 = (err1 == 0 && err2 == 0 && err3 == 0 && err4 == 0 && 
                   ({bytes[16], bytes[17], bytes[18], bytes[19]} != 32'h0a000002 || word16(22) != 16'd9000)) ? 4'd5 : 4'd0;
    
    assign error_code = err1 ? err1 : 
                        err2 ? err2 : 
                        err3 ? err3 : 
                        err4 ? err4 : 
                        err5 ? err5 : 4'd0;
    
    // Output assignments
    assign s_ready = !rst && (state == 0);
    assign status_valid = status_valid_reg;
    assign status_error = status_error_reg;
    
    // Parser outputs
    assign m_data = m_udp_payload_axis_tdata;
    assign m_valid = m_udp_payload_axis_tvalid && (state == 4);
    assign m_last = m_udp_payload_axis_tlast && (state == 4);
    assign m_src_ip = m_ip_source_ip;
    assign m_src_port = m_udp_source_port;
    assign m_dst_port = m_udp_dest_port;
    assign m_payload_len = m_udp_length - 16'd8;
    
    // State machine
    always @(posedge clk) begin
        if (rst) begin
            state <= 0;
            n <= 0;
            ptr <= 0;
            status_valid_reg <= 0;
            status_error_reg <= 0;
            error_code_stored <= 0;
            s_ip_hdr_valid_reg <= 0;
            s_ip_payload_axis_tvalid_reg <= 0;
        end else begin
            status_valid_reg <= 0;
            
            case (state)
                0: begin // IDLE: receiving bytes
                    if (s_valid && s_ready) begin
                        if (n < 512)
                            bytes[n] <= s_data;
                        n <= n + 1;
                        if (s_last) begin
                            error_code_stored <= error_code;
                            state <= 1;
                        end
                    end
                end
                
                1: begin // EMIT_STATUS
                    status_valid_reg <= 1;
                    status_error_reg <= error_code_stored;
                    if (error_code_stored == 0) begin
                        state <= 2; // Start parser header handshake
                        s_ip_hdr_valid_reg <= 1;
                    end else begin
                        state <= 0; // Reject, rearm immediately
                        n <= 0;
                    end
                end
                
                2: begin // PARSER_HDR_HANDSHAKE
                    if (s_ip_hdr_ready) begin
                        s_ip_hdr_valid_reg <= 0;
                        state <= 3;
                        s_ip_payload_axis_tvalid_reg <= 1;
                        ptr <= 20;
                    end
                end
                
                3: begin // PARSER_PAYLOAD
                    if (s_ip_payload_axis_tready) begin
                        if (ptr == n - 1) begin
                            s_ip_payload_axis_tvalid_reg <= 0;
                            state <= 4;
                        end else begin
                            ptr <= ptr + 1;
                        end
                    end
                end
                
                4: begin // OUTPUT_PAYLOAD
                    if (m_valid && m_ready && m_last) begin
                        state <= 0;
                        n <= 0;
                        ptr <= 0;
                    end
                end
                
                default: state <= 0;
            endcase
        end
    end
    
    // Instantiate upstream parser
    udp_ip_rx parser(
        .clk(clk),
        .rst(rst),
        .s_ip_hdr_valid(s_ip_hdr_valid_reg),
        .s_ip_hdr_ready(s_ip_hdr_ready),
        .s_eth_dest_mac(48'b0),
        .s_eth_src_mac(48'b0),
        .s_eth_type(16'h0800),
        .s_ip_version(bytes[0][7:4]),
        .s_ip_ihl(bytes[0][3:0]),
        .s_ip_dscp(bytes[1][7:2]),
        .s_ip_ecn(bytes[1][1:0]),
        .s_ip_length({bytes[2], bytes[3]}),
        .s_ip_identification({bytes[4], bytes[5]}),
        .s_ip_flags(bytes[6][7:5]),
        .s_ip_fragment_offset({bytes[6][4:0], bytes[7]}),
        .s_ip_ttl(bytes[8]),
        .s_ip_protocol(bytes[9]),
        .s_ip_header_checksum({bytes[10], bytes[11]}),
        .s_ip_source_ip({bytes[12], bytes[13], bytes[14], bytes[15]}),
        .s_ip_dest_ip({bytes[16], bytes[17], bytes[18], bytes[19]}),
        .s_ip_payload_axis_tdata(bytes[ptr]),
        .s_ip_payload_axis_tvalid(s_ip_payload_axis_tvalid_reg),
        .s_ip_payload_axis_tready(s_ip_payload_axis_tready),
        .s_ip_payload_axis_tlast(ptr == n - 1),
        .s_ip_payload_axis_tuser(1'b0),
        .m_udp_hdr_valid(),
        .m_udp_hdr_ready(1'b1),
        .m_eth_dest_mac(),
        .m_eth_src_mac(),
        .m_eth_type(),
        .m_ip_version(),
        .m_ip_ihl(),
        .m_ip_dscp(),
        .m_ip_ecn(),
        .m_ip_length(),
        .m_ip_identification(),
        .m_ip_flags(),
        .m_ip_fragment_offset(),
        .m_ip_ttl(),
        .m_ip_protocol(),
        .m_ip_header_checksum(),
        .m_ip_source_ip(m_ip_source_ip),
        .m_ip_dest_ip(),
        .m_udp_source_port(m_udp_source_port),
        .m_udp_dest_port(m_udp_dest_port),
        .m_udp_length(m_udp_length),
        .m_udp_checksum(),
        .m_udp_payload_axis_tdata(m_udp_payload_axis_tdata),
        .m_udp_payload_axis_tvalid(m_udp_payload_axis_tvalid),
        .m_udp_payload_axis_tready(m_ready && (state == 4)),
        .m_udp_payload_axis_tlast(m_udp_payload_axis_tlast),
        .m_udp_payload_axis_tuser()
    );

endmodule
