module udp_rx_guard(
    input wire clk,
    input wire rst,
    input wire [7:0] s_data,
    input wire s_valid,
    output wire s_ready,
    input wire s_last,
    output wire [7:0] m_data,
    output wire m_valid,
    input wire m_ready,
    output wire m_last,
    output wire [31:0] m_src_ip,
    output wire [15:0] m_src_port,
    output wire [15:0] m_dst_port,
    output wire [15:0] m_payload_len,
    output wire status_valid,
    output wire [3:0] status_error
);

    localparam ST_RECV       = 3'd0;
    localparam ST_STATUS     = 3'd1;
    localparam ST_FEED_HDR   = 3'd2;
    localparam ST_FEED_PAY   = 3'd3;
    localparam ST_DRAIN_OUT  = 3'd4;

    reg [2:0] state_reg = ST_RECV;

    reg [7:0] frame_mem[0:511];
    reg [9:0] rx_count_reg = 10'd0;
    reg oversize_reg = 1'b0;

    reg [9:0] feed_ptr_reg = 10'd0;

    reg status_valid_reg = 1'b0;
    reg [3:0] status_error_reg = 4'd0;
    reg [3:0] frame_error_reg = 4'd0;

    reg [31:0] src_ip_reg = 32'd0;
    reg [15:0] src_port_reg = 16'd0;
    reg [15:0] dst_port_reg = 16'd0;
    reg [15:0] payload_len_reg = 16'd0;

    reg s_ip_hdr_valid_reg = 1'b0;
    wire s_ip_hdr_ready;
    reg s_ip_payload_axis_tvalid_reg = 1'b0;
    wire s_ip_payload_axis_tready;

    wire m_udp_hdr_valid;
    wire [31:0] p_m_ip_source_ip;
    wire [15:0] p_m_udp_source_port;
    wire [15:0] p_m_udp_dest_port;
    wire [15:0] p_m_udp_length;
    wire [7:0] p_m_udp_payload_axis_tdata;
    wire p_m_udp_payload_axis_tvalid;
    wire p_m_udp_payload_axis_tlast;

    wire [7:0] cur_feed_data = frame_mem[feed_ptr_reg];
    wire cur_feed_last = (feed_ptr_reg == rx_count_reg-1);

    reg [3:0] calc_error;
    reg [15:0] ip_total_length;
    reg [15:0] udp_length;
    reg [15:0] udp_checksum_field;
    reg [31:0] dst_ip;
    reg [15:0] dst_port_hdr;
    reg [15:0] src_port_hdr;
    reg [31:0] src_ip_hdr;
    reg [31:0] sum32;
    reg [31:0] sum32_udp;
    reg [15:0] fold16;
    reg [9:0] actual_len;
    reg [15:0] payload_len_calc;
    integer k;

    always @(*) begin
        actual_len = rx_count_reg;

        ip_total_length = {frame_mem[2], frame_mem[3]};
        udp_length = {frame_mem[24], frame_mem[25]};
        udp_checksum_field = {frame_mem[26], frame_mem[27]};
        src_ip_hdr = {frame_mem[12], frame_mem[13], frame_mem[14], frame_mem[15]};
        dst_ip = {frame_mem[16], frame_mem[17], frame_mem[18], frame_mem[19]};
        src_port_hdr = {frame_mem[20], frame_mem[21]};
        dst_port_hdr = {frame_mem[22], frame_mem[23]};

        calc_error = 4'd0;

        if (actual_len < 10'd28 ||
            oversize_reg ||
            frame_mem[0][7:4] != 4'd4 ||
            frame_mem[0][3:0] != 4'd5 ||
            frame_mem[9] != 8'd17 ||
            frame_mem[6][5] != 1'b0 ||
            frame_mem[6][4:0] != 5'd0 ||
            frame_mem[7] != 8'd0) begin
            calc_error = 4'd1;
        end else begin
            payload_len_calc = udp_length - 16'd8;
            if (ip_total_length != actual_len ||
                udp_length != ip_total_length - 16'd20 ||
                payload_len_calc < 16'd1 ||
                payload_len_calc > 16'd256) begin
                calc_error = 4'd2;
            end else begin
                sum32 = 32'd0;
                for (k = 0; k < 20; k = k + 2) begin
                    sum32 = sum32 + {frame_mem[k], frame_mem[k+1]};
                end
                while (sum32[31:16] != 0) begin
                    sum32 = {16'd0, sum32[15:0]} + sum32[31:16];
                end
                fold16 = sum32[15:0];
                if (fold16 != 16'hffff) begin
                    calc_error = 4'd3;
                end else begin
                    if (udp_checksum_field != 16'd0) begin
                        sum32_udp = 32'd0;
                        sum32_udp = sum32_udp + {frame_mem[12], frame_mem[13]};
                        sum32_udp = sum32_udp + {frame_mem[14], frame_mem[15]};
                        sum32_udp = sum32_udp + {frame_mem[16], frame_mem[17]};
                        sum32_udp = sum32_udp + {frame_mem[18], frame_mem[19]};
                        sum32_udp = sum32_udp + 16'h0011;
                        sum32_udp = sum32_udp + udp_length;

                        for (k = 20; k < 512; k = k + 2) begin
                            if (k < 20 + udp_length) begin
                                if (k + 1 < 20 + udp_length) begin
                                    sum32_udp = sum32_udp + {frame_mem[k], frame_mem[k+1]};
                                end else begin
                                    sum32_udp = sum32_udp + {frame_mem[k], 8'h00};
                                end
                            end
                        end

                        while (sum32_udp[31:16] != 0) begin
                            sum32_udp = {16'd0, sum32_udp[15:0]} + sum32_udp[31:16];
                        end
                        fold16 = sum32_udp[15:0];
                        if (fold16 != 16'hffff) begin
                            calc_error = 4'd4;
                        end else if (dst_ip != 32'h0a000002 || dst_port_hdr != 16'd9000) begin
                            calc_error = 4'd5;
                        end else begin
                            calc_error = 4'd0;
                        end
                    end else begin
                        if (dst_ip != 32'h0a000002 || dst_port_hdr != 16'd9000) begin
                            calc_error = 4'd5;
                        end else begin
                            calc_error = 4'd0;
                        end
                    end
                end
            end
        end
    end

    assign s_ready = (state_reg == ST_RECV) && !rst;

    assign status_valid = status_valid_reg;
    assign status_error = status_error_reg;

    assign m_data = p_m_udp_payload_axis_tdata;
    assign m_valid = (state_reg == ST_DRAIN_OUT) ? p_m_udp_payload_axis_tvalid : 1'b0;
    assign m_last = (state_reg == ST_DRAIN_OUT) ? p_m_udp_payload_axis_tlast : 1'b0;

    assign m_src_ip = src_ip_reg;
    assign m_src_port = src_port_reg;
    assign m_dst_port = dst_port_reg;
    assign m_payload_len = payload_len_reg;

    always @(posedge clk) begin
        if (rst) begin
            state_reg <= ST_RECV;
            rx_count_reg <= 10'd0;
            oversize_reg <= 1'b0;
            feed_ptr_reg <= 10'd0;
            status_valid_reg <= 1'b0;
            status_error_reg <= 4'd0;
            frame_error_reg <= 4'd0;
            src_ip_reg <= 32'd0;
            src_port_reg <= 16'd0;
            dst_port_reg <= 16'd0;
            payload_len_reg <= 16'd0;
            s_ip_hdr_valid_reg <= 1'b0;
            s_ip_payload_axis_tvalid_reg <= 1'b0;
        end else begin
            status_valid_reg <= 1'b0;

            case (state_reg)
                ST_RECV: begin
                    s_ip_hdr_valid_reg <= 1'b0;
                    s_ip_payload_axis_tvalid_reg <= 1'b0;

                    if (s_valid) begin
                        if (rx_count_reg < 10'd512) begin
                            frame_mem[rx_count_reg] <= s_data;
                        end else begin
                            oversize_reg <= 1'b1;
                        end

                        if (s_last) begin
                            if (rx_count_reg >= 10'd512) begin
                                frame_error_reg <= 4'd1;
                            end else begin
                                frame_error_reg <= calc_error;
                            end
                            state_reg <= ST_STATUS;
                        end

                        if (rx_count_reg < 10'd513) begin
                            rx_count_reg <= rx_count_reg + 10'd1;
                        end
                    end
                end

                ST_STATUS: begin
                    status_valid_reg <= 1'b1;
                    status_error_reg <= frame_error_reg;

                    if (frame_error_reg == 4'd0) begin
                        src_ip_reg <= {frame_mem[12], frame_mem[13], frame_mem[14], frame_mem[15]};
                        src_port_reg <= {frame_mem[20], frame_mem[21]};
                        dst_port_reg <= {frame_mem[22], frame_mem[23]};
                        payload_len_reg <= {frame_mem[24], frame_mem[25]} - 16'd8;
                        s_ip_hdr_valid_reg <= 1'b1;
                        state_reg <= ST_FEED_HDR;
                    end else begin
                        rx_count_reg <= 10'd0;
                        oversize_reg <= 1'b0;
                        state_reg <= ST_RECV;
                    end
                end

                ST_FEED_HDR: begin
                    if (s_ip_hdr_valid_reg && s_ip_hdr_ready) begin
                        s_ip_hdr_valid_reg <= 1'b0;
                        s_ip_payload_axis_tvalid_reg <= 1'b1;
                        feed_ptr_reg <= 10'd20;
                        state_reg <= ST_FEED_PAY;
                    end
                end

                ST_FEED_PAY: begin
                    if (s_ip_payload_axis_tvalid_reg && s_ip_payload_axis_tready) begin
                        if (cur_feed_last) begin
                            s_ip_payload_axis_tvalid_reg <= 1'b0;
                            state_reg <= ST_DRAIN_OUT;
                        end else begin
                            feed_ptr_reg <= feed_ptr_reg + 10'd1;
                        end
                    end
                end

                ST_DRAIN_OUT: begin
                    if (p_m_udp_payload_axis_tvalid && m_ready && p_m_udp_payload_axis_tlast) begin
                        rx_count_reg <= 10'd0;
                        oversize_reg <= 1'b0;
                        state_reg <= ST_RECV;
                    end
                end

                default: begin
                    state_reg <= ST_RECV;
                end
            endcase
        end
    end

    udp_ip_rx parser_inst (
        .clk(clk),
        .rst(rst),

        .s_ip_hdr_valid(s_ip_hdr_valid_reg),
        .s_ip_hdr_ready(s_ip_hdr_ready),

        .s_eth_dest_mac(48'd0),
        .s_eth_src_mac(48'd0),
        .s_eth_type(16'h0800),
        .s_ip_version(frame_mem[0][7:4]),
        .s_ip_ihl(frame_mem[0][3:0]),
        .s_ip_dscp(frame_mem[1][7:2]),
        .s_ip_ecn(frame_mem[1][1:0]),
        .s_ip_length({frame_mem[2], frame_mem[3]}),
        .s_ip_identification({frame_mem[4], frame_mem[5]}),
        .s_ip_flags(frame_mem[6][7:5]),
        .s_ip_fragment_offset({frame_mem[6][4:0], frame_mem[7]}),
        .s_ip_ttl(frame_mem[8]),
        .s_ip_protocol(frame_mem[9]),
        .s_ip_header_checksum({frame_mem[10], frame_mem[11]}),
        .s_ip_source_ip({frame_mem[12], frame_mem[13], frame_mem[14], frame_mem[15]}),
        .s_ip_dest_ip({frame_mem[16], frame_mem[17], frame_mem[18], frame_mem[19]}),
        .s_ip_payload_axis_tdata(cur_feed_data),
        .s_ip_payload_axis_tvalid(s_ip_payload_axis_tvalid_reg),
        .s_ip_payload_axis_tready(s_ip_payload_axis_tready),
        .s_ip_payload_axis_tlast(cur_feed_last),
        .s_ip_payload_axis_tuser(1'b0),

        .m_udp_hdr_valid(m_udp_hdr_valid),
        .m_udp_hdr_ready(1'b1),

        .m_eth_dest_mac(),
        .m_eth_src_mac(),
        .m_eth_type(),
        .m_ip_version(),
        .m_ip_ihl(),
        .m_ip_dscp(),
        .m_ip_ecn(),
        .m_ip_length(),
        .m_ip_identification(),
        .m_ip_flags(),
        .m_ip_fragment_offset(),
        .m_ip_ttl(),
        .m_ip_protocol(),
        .m_ip_header_checksum(),
        .m_ip_source_ip(p_m_ip_source_ip),
        .m_ip_dest_ip(),
        .m_udp_source_port(p_m_udp_source_port),
        .m_udp_dest_port(p_m_udp_dest_port),
        .m_udp_length(p_m_udp_length),
        .m_udp_checksum(),
        .m_udp_payload_axis_tdata(p_m_udp_payload_axis_tdata),
        .m_udp_payload_axis_tvalid(p_m_udp_payload_axis_tvalid),
        .m_udp_payload_axis_tready((state_reg == ST_DRAIN_OUT) ? m_ready : 1'b0),
        .m_udp_payload_axis_tlast(p_m_udp_payload_axis_tlast),
        .m_udp_payload_axis_tuser()
    );

endmodule
