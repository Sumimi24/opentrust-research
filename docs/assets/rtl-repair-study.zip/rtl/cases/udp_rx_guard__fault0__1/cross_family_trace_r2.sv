`timescale 1ns/1ps
`default_nettype none

module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
output wire s_ready,
input wire s_valid,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

reg [7:0] buf [0:511];
reg [9:0] byte_cnt;
reg last_seen;
reg oversize;
reg [2:0] state;
reg status_valid_r;
reg [3:0] status_error_r;
reg [3:0] err_code;
reg [9:0] out_ptr;
reg [9:0] out_end;
reg out_active;
reg out_last_byte;
reg [31:0] r_src_ip;
reg [15:0] r_src_port;
reg [15:0] r_dst_port;
reg [15:0] r_payload_len;

localparam S_IDLE=0, S_RECV=1, S_DRAIN=2, S_CHECK=3, S_STATUS=4, S_OUT=5;

wire [15:0] w16_0  = {buf[0],  buf[1]};
wire [15:0] w16_2  = {buf[2],  buf[3]};
wire [15:0] w16_4  = {buf[4],  buf[5]};
wire [15:0] w16_6  = {buf[6],  buf[7]};
wire [15:0] w16_8  = {buf[8],  buf[9]};
wire [15:0] w16_10 = {buf[10], buf[11]};
wire [15:0] w16_12 = {buf[12], buf[13]};
wire [15:0] w16_14 = {buf[14], buf[15]};
wire [15:0] w16_16 = {buf[16], buf[17]};
wire [15:0] w16_18 = {buf[18], buf[19]};
wire [15:0] w16_20 = {buf[20], buf[21]};
wire [15:0] w16_22 = {buf[22], buf[23]};
wire [15:0] w16_24 = {buf[24], buf[25]};
wire [15:0] w16_26 = {buf[26], buf[27]};
wire [15:0] w16_28 = {buf[28], buf[29]};
wire [15:0] w16_30 = {buf[30], buf[31]};
wire [15:0] w16_32 = {buf[32], buf[33]};
wire [15:0] w16_34 = {buf[34], buf[35]};
wire [15:0] w16_36 = {buf[36], buf[37]};
wire [15:0] w16_38 = {buf[38], buf[39]};
wire [15:0] w16_40 = {buf[40], buf[41]};
wire [15:0] w16_42 = {buf[42], buf[43]};
wire [15:0] w16_44 = {buf[44], buf[45]};
wire [15:0] w16_46 = {buf[46], buf[47]};
wire [15:0] w16_48 = {buf[48], buf[49]};
wire [15:0] w16_50 = {buf[50], buf[51]};
wire [15:0] w16_52 = {buf[52], buf[53]};
wire [15:0] w16_54 = {buf[54], buf[55]};
wire [15:0] w16_56 = {buf[56], buf[57]};
wire [15:0] w16_58 = {buf[58], buf[59]};
wire [15:0] w16_60 = {buf[60], buf[61]};
wire [15:0] w16_62 = {buf[62], buf[63]};
wire [15:0] w16_64 = {buf[64], buf[65]};
wire [15:0] w16_66 = {buf[66], buf[67]};
wire [15:0] w16_68 = {buf[68], buf[69]};
wire [15:0] w16_70 = {buf[70], buf[71]};
wire [15:0] w16_72 = {buf[72], buf[73]};
wire [15:0] w16_74 = {buf[74], buf[75]};
wire [15:0] w16_76 = {buf[76], buf[77]};
wire [15:0] w16_78 = {buf[78], buf[79]};
wire [15:0] w16_80 = {buf[80], buf[81]};
wire [15:0] w16_82 = {buf[82], buf[83]};
wire [15:0] w16_84 = {buf[84], buf[85]};
wire [15:0] w16_86 = {buf[86], buf[87]};
wire [15:0] w16_88 = {buf[88], buf[89]};
wire [15:0] w16_90 = {buf[90], buf[91]};
wire [15:0] w16_92 = {buf[92], buf[93]};
wire [15:0] w16_94 = {buf[94], buf[95]};
wire [15:0] w16_96 = {buf[96], buf[97]};
wire [15:0] w16_98 = {buf[98], buf[99]};
wire [15:0] w16_100 = {buf[100], buf[101]};
wire [15:0] w16_102 = {buf[102], buf[103]};
wire [15:0] w16_104 = {buf[104], buf[105]};
wire [15:0] w16_106 = {buf[106], buf[107]};
wire [15:0] w16_108 = {buf[108], buf[109]};
wire [15:0] w16_110 = {buf[110], buf[111]};
wire [15:0] w16_112 = {buf[112], buf[113]};
wire [15:0] w16_114 = {buf[114], buf[115]};
wire [15:0] w16_116 = {buf[116], buf[117]};
wire [15:0] w16_118 = {buf[118], buf[119]};
wire [15:0] w16_120 = {buf[120], buf[121]};
wire [15:0] w16_122 = {buf[122], buf[123]};
wire [15:0] w16_124 = {buf[124], buf[125]};
wire [15:0] w16_126 = {buf[126], buf[127]};
wire [15:0] w16_128 = {buf[128], buf[129]};
wire [15:0] w16_130 = {buf[130], buf[131]};
wire [15:0] w16_132 = {buf[132], buf[133]};
wire [15:0] w16_134 = {buf[134], buf[135]};
wire [15:0] w16_136 = {buf[136], buf[137]};
wire [15:0] w16_138 = {buf[138], buf[139]};
wire [15:0] w16_140 = {buf[140], buf[141]};
wire [15:0] w16_142 = {buf[142], buf[143]};
wire [15:0] w16_144 = {buf[144], buf[145]};
wire [15:0] w16_146 = {buf[146], buf[147]};
wire [15:0] w16_148 = {buf[148], buf[149]};
wire [15:0] w16_150 = {buf[150], buf[151]};
wire [15:0] w16_152 = {buf[152], buf[153]};
wire [15:0] w16_154 = {buf[154], buf[155]};
wire [15:0] w16_156 = {buf[156], buf[157]};
wire [15:0] w16_158 = {buf[158], buf[159]};
wire [15:0] w16_160 = {buf[160], buf[161]};
wire [15:0] w16_162 = {buf[162], buf[163]};
wire [15:0] w16_164 = {buf[164], buf[165]};
wire [15:0] w16_166 = {buf[166], buf[167]};
wire [15:0] w16_168 = {buf[168], buf[169]};
wire [15:0] w16_170 = {buf[170], buf[171]};
wire [15:0] w16_172 = {buf[172], buf[173]};
wire [15:0] w16_174 = {buf[174], buf[175]};
wire [15:0] w16_176 = {buf[176], buf[177]};
wire [15:0] w16_178 = {buf[178], buf[179]};
wire [15:0] w16_180 = {buf[180], buf[181]};
wire [15:0] w16_182 = {buf[182], buf[183]};
wire [15:0] w16_184 = {buf[184], buf[185]};
wire [15:0] w16_186 = {buf[186], buf[187]};
wire [15:0] w16_188 = {buf[188], buf[189]};
wire [15:0] w16_190 = {buf[190], buf[191]};
wire [15:0] w16_192 = {buf[192], buf[193]};
wire [15:0] w16_194 = {buf[194], buf[195]};
wire [15:0] w16_196 = {buf[196], buf[197]};
wire [15:0] w16_198 = {buf[198], buf[199]};
wire [15:0] w16_200 = {buf[200], buf[201]};
wire [15:0] w16_202 = {buf[202], buf[203]};
wire [15:0] w16_204 = {buf[204], buf[205]};
wire [15:0] w16_206 = {buf[206], buf[207]};
wire [15:0] w16_208 = {buf[208], buf[209]};
wire [15:0] w16_210 = {buf[210], buf[211]};
wire [15:0] w16_212 = {buf[212], buf[213]};
wire [15:0] w16_214 = {buf[214], buf[215]};
wire [15:0] w16_216 = {buf[216], buf[217]};
wire [15:0] w16_218 = {buf[218], buf[219]};
wire [15:0] w16_220 = {buf[220], buf[221]};
wire [15:0] w16_222 = {buf[222], buf[223]};
wire [15:0] w16_224 = {buf[224], buf[225]};
wire [15:0] w16_226 = {buf[226], buf[227]};
wire [15:0] w16_228 = {buf[228], buf[229]};
wire [15:0] w16_230 = {buf[230], buf[231]};
wire [15:0] w16_232 = {buf[232], buf[233]};
wire [15:0] w16_234 = {buf[234], buf[235]};
wire [15:0] w16_236 = {buf[236], buf[237]};
wire [15:0] w16_238 = {buf[238], buf[239]};
wire [15:0] w16_240 = {buf[240], buf[241]};
wire [15:0] w16_242 = {buf[242], buf[243]};
wire [15:0] w16_244 = {buf[244], buf[245]};
wire [15:0] w16_246 = {buf[246], buf[247]};
wire [15:0] w16_248 = {buf[248], buf[249]};
wire [15:0] w16_250 = {buf[250], buf[251]};
wire [15:0] w16_252 = {buf[252], buf[253]};
wire [15:0] w16_254 = {buf[254], buf[255]};
wire [15:0] w16_256 = {buf[256], buf[257]};
wire [15:0] w16_258 = {buf[258], buf[259]};
wire [15:0] w16_260 = {buf[260], buf[261]};
wire [15:0] w16_262 = {buf[262], buf[263]};
wire [15:0] w16_264 = {buf[264], buf[265]};
wire [15:0] w16_266 = {buf[266], buf[267]};
wire [15:0] w16_268 = {buf[268], buf[269]};
wire [15:0] w16_270 = {buf[270], buf[271]};
wire [15:0] w16_272 = {buf[272], buf[273]};
wire [15:0] w16_274 = {buf[274], buf[275]};
wire [15:0] w16_276 = {buf[276], buf[277]};
wire [15:0] w16_278 = {buf[278], buf[279]};
wire [15:0] w16_280 = {buf[280], buf[281]};
wire [15:0] w16_282 = {buf[282], buf[283]};

wire [31:0] ip_total_length = w16_2;
wire [31:0] udp_length      = w16_24;
wire [31:0] payload_length  = udp_length - 32'd8;

wire [17:0] ip_sum = {2'b0, w16_0} + {2'b0, w16_2} + {2'b0, w16_4} + {2'b0, w16_6} + {2'b0, w16_8} +
                     {2'b0, w16_10} + {2'b0, w16_12} + {2'b0, w16_14} + {2'b0, w16_16} + {2'b0, w16_18};
wire [16:0] ip_fold1 = ip_sum[15:0] + {1'b0, ip_sum[17:16]};
wire [15:0] ip_folded = ip_fold1[15:0] + {15'b0, ip_fold1[16]};

wire [31:0] pseudo_sum = {16'b0, w16_12} + {16'b0, w16_14} +
                         {16'b0, w16_16} + {16'b0, w16_18} +
                         32'd17 + udp_length;
wire [31:0] udp_hdr_sum = {16'b0, w16_20} + {16'b0, w16_22} +
                          {16'b0, w16_24} + {16'b0, w16_26};

function [31:0] udp_data_sum_f(input [31:0] plen);
    integer i;
    reg [31:0] sum;
    begin
        sum = 32'd0;
        for (i = 0; i < 128; i = i + 1) begin
            if (plen > (i * 2)) begin
                sum = sum + {16'b0, buf[28 + i*2], buf[28 + i*2 + 1]};
            end
        end
        if ((plen & 1) != 0) begin
            sum = sum + {16'b0, buf[28 + plen - 1], 8'b0};
        end
        udp_data_sum_f = sum;
    end
endfunction

wire [31:0] udp_data_sum = udp_data_sum_f(payload_length);

wire [31:0] udp_full_sum = pseudo_sum + udp_hdr_sum + udp_data_sum;
wire [16:0] udp_f1 = udp_full_sum[15:0] + udp_full_sum[31:16];
wire [15:0] udp_folded = udp_f1[15:0] + {15'b0, udp_f1[16]};

assign s_ready = (state == S_IDLE || state == S_RECV || state == S_DRAIN) && !rst;
assign status_valid = status_valid_r;
assign status_error = status_error_r;

assign m_valid = out_active && (state == S_OUT);
assign m_data = buf[out_ptr];
assign m_last = out_last_byte;
assign m_src_ip = r_src_ip;
assign m_src_port = r_src_port;
assign m_dst_port = r_dst_port;
assign m_payload_len = r_payload_len;

always @(posedge clk) begin
    if (rst) begin
        state <= S_IDLE;
        byte_cnt <= 0;
        last_seen <= 0;
        oversize <= 0;
        status_valid_r <= 0;
        status_error_r <= 0;
        out_active <= 0;
    end else begin
        status_valid_r <= 0;
        case (state)
            S_IDLE: begin
                if (s_valid && s_ready) begin
                    if (!oversize && byte_cnt < 512)
                        buf[byte_cnt] <= s_data;
                    byte_cnt <= byte_cnt + 1;
                    if (byte_cnt >= 512)
                        oversize <= 1;
                    if (s_last) begin
                        last_seen <= 1;
                        state <= S_CHECK;
                    end else begin
                        state <= S_RECV;
                    end
                end
            end
            S_RECV: begin
                if (s_valid && s_ready) begin
                    if (!oversize && byte_cnt < 512)
                        buf[byte_cnt] <= s_data;
                    byte_cnt <= byte_cnt + 1;
                    if (byte_cnt >= 512)
                        oversize <= 1;
                    if (s_last) begin
                        last_seen <= 1;
                        state <= S_CHECK;
                    end
                end
            end
            S_DRAIN: begin
                if (s_valid && s_ready) begin
                    if (s_last) begin
                        last_seen <= 1;
                        state <= S_CHECK;
                    end
                end
            end
            S_CHECK: begin
                err_code <= 0;
                if (oversize || byte_cnt > 512)
                    err_code <= 1;
                else if (byte_cnt < 28)
                    err_code <= 1;
                else if (buf[0][7:4] != 4)
                    err_code <= 1;
                else if (buf[0][3:0] != 5)
                    err_code <= 1;
                else if (buf[9] != 17)
                    err_code <= 1;
                else if (buf[6][5])
                    err_code <= 1;
                else if ({buf[6][4:0], buf[7]} != 0)
                    err_code <= 1;
                else if (ip_total_length != byte_cnt)
                    err_code <= 2;
                else if (udp_length != ip_total_length - 32'd20)
                    err_code <= 2;
                else if (payload_length < 1 || payload_length > 256)
                    err_code <= 2;
                else if (ip_folded != 16'hffff)
                    err_code <= 3;
                else if (w16_26 != 0 && udp_folded != 16'hffff)
                    err_code <= 4;
                else if ({buf[16],buf[17],buf[18],buf[19]} != 32'h0a000002)
                    err_code <= 5;
                else if (w16_22 != 16'd9000)
                    err_code <= 5;

                r_src_ip <= {buf[12],buf[13],buf[14],buf[15]};
                r_src_port <= w16_20;
                r_dst_port <= w16_22;
                r_payload_len <= payload_length[15:0];

                state <= S_STATUS;
            end
            S_STATUS: begin
                status_valid_r <= 1;
                status_error_r <= err_code;
                if (err_code == 0) begin
                    out_ptr <= 28;
                    out_end <= 28 + payload_length[9:0] - 1;
                    out_active <= 1;
                    out_last_byte <= (payload_length == 1);
                    state <= S_OUT;
                end else begin
                    byte_cnt <= 0;
                    last_seen <= 0;
                    oversize <= 0;
                    out_active <= 0;
                    state <= S_IDLE;
                end
            end
            S_OUT: begin
                if (m_valid && m_ready) begin
                    if (out_last_byte) begin
                        out_active <= 0;
                        byte_cnt <= 0;
                        last_seen <= 0;
                        oversize <= 0;
                        state <= S_IDLE;
                    end else begin
                        out_ptr <= out_ptr + 1;
                        out_last_byte <= (out_ptr + 1 == out_end);
                    end
                end
            end
            default: state <= S_IDLE;
        endcase
    end
end

endmodule
