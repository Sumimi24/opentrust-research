`timescale 1ns/1ps
`default_nettype none

module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output reg s_ready,
input wire s_last,
output reg [7:0] m_data,
output reg m_valid,
input wire m_ready,
output reg m_last,
output reg [31:0] m_src_ip,
output reg [15:0] m_src_port,
output reg [15:0] m_dst_port,
output reg [15:0] m_payload_len,
output reg status_valid,
output reg [3:0] status_error);

reg [7:0] buf [0:511];
reg [9:0] byte_cnt;
reg oversize;
reg [2:0] state;
reg [3:0] err_code;
reg [9:0] out_ptr;
reg [9:0] out_end;
reg out_active;

localparam S_IDLE=0, S_RECV=1, S_CHECK=3, S_STATUS=4, S_OUT=5;

wire [15:0] w16_0  = {buf[0],  buf[1]};
wire [15:0] w16_2  = {buf[2],  buf[3]};
wire [15:0] w16_4  = {buf[4],  buf[5]};
wire [15:0] w16_6  = {buf[6],  buf[7]};
wire [15:0] w16_8  = {buf[8],  buf[9]};
wire [15:0] w16_10 = {buf[10], buf[11]};
wire [15:0] w16_12 = {buf[12], buf[13]};
wire [15:0] w16_14 = {buf[14], buf[15]};
wire [15:0] w16_16 = {buf[16], buf[17]};
wire [15:0] w16_18 = {buf[18], buf[19]};
wire [15:0] w16_20 = {buf[20], buf[21]};
wire [15:0] w16_22 = {buf[22], buf[23]};
wire [15:0] w16_24 = {buf[24], buf[25]};
wire [15:0] w16_26 = {buf[26], buf[27]};

wire [31:0] ip_total_length = {16'b0, w16_2};
wire [31:0] udp_length      = {16'b0, w16_24};
wire [31:0] payload_length  = udp_length - 32'd8;

wire [17:0] ip_sum = w16_0 + w16_2 + w16_4 + w16_6 + w16_8 +
                     w16_10 + w16_12 + w16_14 + w16_16 + w16_18;
wire [16:0] ip_fold1 = ip_sum[15:0] + {1'b0, ip_sum[17:16]};
wire [15:0] ip_folded = ip_fold1[15:0] + {15'b0, ip_fold1[16]};

wire [31:0] pseudo_sum = {16'b0, w16_12} + {16'b0, w16_14} +
                         {16'b0, w16_16} + {16'b0, w16_18} +
                         32'd17 + udp_length;
wire [31:0] udp_hdr_sum = w16_20 + w16_22 + w16_24 + w16_26;

reg [31:0] udp_data_sum;

integer i;
always @(*) begin
    udp_data_sum = 32'd0;
    if (payload_length > 0 && payload_length <= 256) begin
        for (i = 0; i < 256; i = i + 2) begin
            if (i < payload_length) begin
                if (i + 1 < payload_length)
                    udp_data_sum = udp_data_sum + {16'b0, buf[28+i], buf[28+i+1]};
                else
                    udp_data_sum = udp_data_sum + {16'b0, buf[28+i], 8'b0};
            end
        end
    end
end

wire [31:0] udp_full_sum = pseudo_sum + udp_hdr_sum + udp_data_sum;
wire [16:0] udp_f1 = udp_full_sum[15:0] + udp_full_sum[31:16];
wire [15:0] udp_folded = udp_f1[15:0] + {15'b0, udp_f1[16]};

always @(posedge clk) begin
    if (rst) begin
        state <= S_IDLE;
        byte_cnt <= 0;
        oversize <= 0;
        status_valid <= 0;
        status_error <= 0;
        out_active <= 0;
        m_valid <= 0;
        s_ready <= 1;
    end else begin
        case (state)
            S_IDLE: begin
                status_valid <= 0;
                m_valid <= 0;
                s_ready <= 1;
                byte_cnt <= 0;
                oversize <= 0;
                out_active <= 0;
                if (s_valid) begin
                    if (byte_cnt < 512)
                        buf[byte_cnt] <= s_data;
                    byte_cnt <= byte_cnt + 1;
                    if (byte_cnt >= 512)
                        oversize <= 1;
                    if (s_last) begin
                        s_ready <= 0;
                        state <= S_CHECK;
                    end else begin
                        state <= S_RECV;
                    end
                end
            end
            S_RECV: begin
                s_ready <= 1;
                if (s_valid) begin
                    if (byte_cnt < 512)
                        buf[byte_cnt] <= s_data;
                    byte_cnt <= byte_cnt + 1;
                    if (byte_cnt >= 512)
                        oversize <= 1;
                    if (s_last) begin
                        s_ready <= 0;
                        state <= S_CHECK;
                    end
                end
            end
            S_CHECK: begin
                s_ready <= 0;
                err_code <= 0;
                if (oversize || byte_cnt > 512)
                    err_code <= 1;
                else if (byte_cnt < 28)
                    err_code <= 1;
                else if (buf[0][7:4] != 4)
                    err_code <= 1;
                else if (buf[0][3:0] != 5)
                    err_code <= 1;
                else if (buf[9] != 17)
                    err_code <= 1;
                else if (buf[6][5])
                    err_code <= 1;
                else if ({buf[6][4:0], buf[7]} != 0)
                    err_code <= 1;
                else if (ip_total_length != {22'b0, byte_cnt})
                    err_code <= 2;
                else if (udp_length != ip_total_length - 32'd20)
                    err_code <= 2;
                else if (payload_length < 1 || payload_length > 256)
                    err_code <= 2;
                else if (ip_folded != 16'hffff)
                    err_code <= 3;
                else if (w16_26 != 0 && udp_folded != 16'hffff)
                    err_code <= 4;
                else if ({buf[16],buf[17],buf[18],buf[19]} != 32'h0a000002)
                    err_code <= 5;
                else if (w16_22 != 9000)
                    err_code <= 5;

                m_src_ip <= {buf[12],buf[13],buf[14],buf[15]};
                m_src_port <= w16_20;
                m_dst_port <= w16_22;
                m_payload_len <= payload_length[15:0];

                state <= S_STATUS;
            end
            S_STATUS: begin
                status_valid <= 1;
                status_error <= err_code;
                s_ready <= 0;
                m_valid <= 0;
                if (err_code == 0) begin
                    out_ptr <= 28;
                    out_end <= 28 + payload_length[9:0] - 10'd1;
                    out_active <= 1;
                    state <= S_OUT;
                end else begin
                    out_active <= 0;
                    state <= S_IDLE;
                end
            end
            S_OUT: begin
                status_valid <= 0;
                s_ready <= 0;
                m_valid <= out_active;
                m_data <= buf[out_ptr];
                m_last <= (out_ptr == out_end);
                if (m_valid && m_ready) begin
                    if (out_ptr == out_end) begin
                        out_active <= 0;
                        m_valid <= 0;
                        state <= S_IDLE;
                    end else begin
                        out_ptr <= out_ptr + 1;
                    end
                end
            end
            default: state <= S_IDLE;
        endcase
    end
end

endmodule
