`timescale 1ns/1ps
`default_nettype none

module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
output wire s_ready,
input wire s_valid,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

reg [7:0] buf [0:511];
reg [9:0] byte_cnt;
reg drain_cnt;
reg last_seen;
reg oversize;
reg [2:0] state;
reg status_valid_r;
reg [3:0] status_error_r;
reg [3:0] err_code;
reg [9:0] out_ptr;
reg [9:0] out_end;
reg out_active;
reg out_last_byte;
reg [31:0] r_src_ip;
reg [15:0] r_src_port;
reg [15:0] r_dst_port;
reg [15:0] r_payload_len;

localparam S_IDLE=0, S_RECV=1, S_DRAIN=2, S_CHECK=3, S_STATUS=4, S_OUT=5;

wire [15:0] w16_0  = {buf[0],  buf[1]};
wire [15:0] w16_2  = {buf[2],  buf[3]};
wire [15:0] w16_4  = {buf[4],  buf[5]};
wire [15:0] w16_6  = {buf[6],  buf[7]};
wire [15:0] w16_8  = {buf[8],  buf[9]};
wire [15:0] w16_10 = {buf[10], buf[11]};
wire [15:0] w16_12 = {buf[12], buf[13]};
wire [15:0] w16_14 = {buf[14], buf[15]};
wire [15:0] w16_16 = {buf[16], buf[17]};
wire [15:0] w16_18 = {buf[18], buf[19]};
wire [15:0] w16_20 = {buf[20], buf[21]};
wire [15:0] w16_22 = {buf[22], buf[23]};
wire [15:0] w16_24 = {buf[24], buf[25]};
wire [15:0] w16_26 = {buf[26], buf[27]};

wire [31:0] ip_total_length = w16_2;
wire [31:0] udp_length      = w16_24;
wire [31:0] payload_length  = udp_length - 32'd8;

wire [17:0] ip_sum = w16_0 + w16_2 + w16_4 + w16_6 + w16_8 +
                     w16_10 + w16_12 + w16_14 + w16_16 + w16_18;
wire [16:0] ip_fold1 = ip_sum[15:0] + {1'b0, ip_sum[17:16]};
wire [15:0] ip_folded = ip_fold1[15:0] + {15'b0, ip_fold1[16]};

wire [31:0] pseudo_sum = {16'b0, w16_12} + {16'b0, w16_14} +
                         {16'b0, w16_16} + {16'b0, w16_18} +
                         32'd17 + udp_length;
wire [31:0] udp_hdr_sum = w16_20 + w16_22 + w16_24 + w16_26;
wire [31:0] udp_data_sum = (payload_length >= 32'd1)  ? {16'b0, w16_28} : 32'd0 +
                           (payload_length >= 32'd3)  ? {16'b0, w16_30} : 32'd0 +
                           (payload_length >= 32'd5)  ? {16'b0, w16_32} : 32'd0 +
                           (payload_length >= 32'd7)  ? {16'b0, w16_34} : 32'd0 +
                           (payload_length >= 32'd9)  ? {16'b0, w16_36} : 32'd0 +
                           (payload_length >= 32'd11) ? {16'b0, w16_38} : 32'd0 +
                           (payload_length >= 32'd13) ? {16'b0, w16_40} : 32'd0 +
                           (payload_length >= 32'd15) ? {16'b0, w16_42} : 32'd0 +
                           (payload_length >= 32'd17) ? {16'b0, w16_44} : 32'd0 +
                           (payload_length >= 32'd19) ? {16'b0, w16_46} : 32'd0 +
                           (payload_length >= 32'd21) ? {16'b0, w16_48} : 32'd0 +
                           (payload_length >= 32'd23) ? {16'b0, w16_50} : 32'd0 +
                           (payload_length >= 32'd25) ? {16'b0, w16_52} : 32'd0 +
                           (payload_length >= 32'd27) ? {16'b0, w16_54} : 32'd0 +
                           (payload_length >= 32'd29) ? {16'b0, w16_56} : 32'd0 +
                           (payload_length >= 32'd31) ? {16'b0, w16_58} : 32'd0 +
                           (payload_length >= 32'd33) ? {16'b0, w16_60} : 32'd0 +
                           (payload_length >= 32'd35) ? {16'b0, w16_62} : 32'd0 +
                           (payload_length >= 32'd37) ? {16'b0, w16_64} : 32'd0 +
                           (payload_length >= 32'd39) ? {16'b0, w16_66} : 32'd0 +
                           (payload_length >= 32'd41) ? {16'b0, w16_68} : 32'd0 +
                           (payload_length >= 32'd43) ? {16'b0, w16_70} : 32'd0 +
                           (payload_length >= 32'd45) ? {16'b0, w16_72} : 32'd0 +
                           (payload_length >= 32'd47) ? {16'b0, w16_74} : 32'd0 +
                           (payload_length >= 32'd49) ? {16'b0, w16_76} : 32'd0 +
                           (payload_length >= 32'd51) ? {16'b0, w16_78} : 32'd0 +
                           (payload_length >= 32'd53) ? {16'b0, w16_80} : 32'd0 +
                           (payload_length >= 32'd55) ? {16'b0, w16_82} : 32'd0 +
                           (payload_length >= 32'd57) ? {16'b0, w16_84} : 32'd0 +
                           (payload_length >= 32'd59) ? {16'b0, w16_86} : 32'd0 +
                           (payload_length >= 32'd61) ? {16'b0, w16_88} : 32'd0 +
                           (payload_length >= 32'd63) ? {16'b0, w16_90} : 32'd0 +
                           (payload_length >= 32'd65) ? {16'b0, w16_92} : 32'd0 +
                           (payload_length >= 32'd67) ? {16'b0, w16_94} : 32'd0 +
                           (payload_length >= 32'd69) ? {16'b0, w16_96} : 32'd0 +
                           (payload_length >= 32'd71) ? {16'b0, w16_98} : 32'd0 +
                           (payload_length >= 32'd73) ? {16'b0, w16_100}: 32'd0 +
                           (payload_length >= 32'd75) ? {16'b0, w16_102}: 32'd0 +
                           (payload_length >= 32'd77) ? {16'b0, w16_104}: 32'd0 +
                           (payload_length >= 32'd79) ? {16'b0, w16_106}: 32'd0 +
                           (payload_length >= 32'd81) ? {16'b0, w16_108}: 32'd0 +
                           (payload_length >= 32'd83) ? {16'b0, w16_110}: 32'd0 +
                           (payload_length >= 32'd85) ? {16'b0, w16_112}: 32'd0 +
                           (payload_length >= 32'd87) ? {16'b0, w16_114}: 32'd0 +
                           (payload_length >= 32'd89) ? {16'b0, w16_116}: 32'd0 +
                           (payload_length >= 32'd91) ? {16'b0, w16_118}: 32'd0 +
                           (payload_length >= 32'd93) ? {16'b0, w16_120}: 32'd0 +
                           (payload_length >= 32'd95) ? {16'b0, w16_122}: 32'd0 +
                           (payload_length >= 32'd97) ? {16'b0, w16_124}: 32'd0 +
                           (payload_length >= 32'd99) ? {16'b0, w16_126}: 32'd0 +
                           (payload_length >= 32'd101)? {16'b0, w16_128}: 32'd0 +
                           (payload_length >= 32'd103)? {16'b0, w16_130}: 32'd0 +
                           (payload_length >= 32'd105)? {16'b0, w16_132}: 32'd0 +
                           (payload_length >= 32'd107)? {16'b0, w16_134}: 32'd0 +
                           (payload_length >= 32'd109)? {16'b0, w16_136}: 32'd0 +
                           (payload_length >= 32'd111)? {16'b0, w16_138}: 32'd0 +
                           (payload_length >= 32'd113)? {16'b0, w16_140}: 32'd0 +
                           (payload_length >= 32'd115)? {16'b0, w16_142}: 32'd0 +
                           (payload_length >= 32'd117)? {16'b0, w16_144}: 32'd0 +
                           (payload_length >= 32'd119)? {16'b0, w16_146}: 32'd0 +
                           (payload_length >= 32'd121)? {16'b0, w16_148}: 32'd0 +
                           (payload_length >= 32'd123)? {16'b0, w16_150}: 32'd0 +
                           (payload_length >= 32'd125)? {16'b0, w16_152}: 32'd0 +
                           (payload_length >= 32'd127)? {16'b0, w16_154}: 32'd0 +
                           (payload_length >= 32'd129)? {16'b0, w16_156}: 32'd0 +
                           (payload_length >= 32'd131)? {16'b0, w16_158}: 32'd0 +
                           (payload_length >= 32'd133)? {16'b0, w16_160}: 32'd0 +
                           (payload_length >= 32'd135)? {16'b0, w16_162}: 32'd0 +
                           (payload_length >= 32'd137)? {16'b0, w16_164}: 32'd0 +
                           (payload_length >= 32'd139)? {16'b0, w16_166}: 32'd0 +
                           (payload_length >= 32'd141)? {16'b0, w16_168}: 32'd0 +
                           (payload_length >= 32'd143)? {16'b0, w16_170}: 32'd0 +
                           (payload_length >= 32'd145)? {16'b0, w16_172}: 32'd0 +
                           (payload_length >= 32'd147)? {16'b0, w16_174}: 32'd0 +
                           (payload_length >= 32'd149)? {16'b0, w16_176}: 32'd0 +
                           (payload_length >= 32'd151)? {16'b0, w16_178}: 32'd0 +
                           (payload_length >= 32'd153)? {16'b0, w16_180}: 32'd0 +
                           (payload_length >= 32'd155)? {16'b0, w16_182}: 32'd0 +
                           (payload_length >= 32'd157)? {16'b0, w16_184}: 32'd0 +
                           (payload_length >= 32'd159)? {16'b0, w16_186}: 32'd0 +
                           (payload_length >= 32'd161)? {16'b0, w16_188}: 32'd0 +
                           (payload_length >= 32'd163)? {16'b0, w16_190}: 32'd0 +
                           (payload_length >= 32'd165)? {16'b0, w16_192}: 32'd0 +
                           (payload_length >= 32'd167)? {16'b0, w16_194}: 32'd0 +
                           (payload_length >= 32'd169)? {16'b0, w16_196}: 32'd0 +
                           (payload_length >= 32'd171)? {16'b0, w16_198}: 32'd0 +
                           (payload_length >= 32'd173)? {16'b0, w16_200}: 32'd0 +
                           (payload_length >= 32'd175)? {16'b0, w16_202}: 32'd0 +
                           (payload_length >= 32'd177)? {16'b0, w16_204}: 32'd0 +
                           (payload_length >= 32'd179)? {16'b0, w16_206}: 32'd0 +
                           (payload_length >= 32'd181)? {16'b0, w16_208}: 32'd0 +
                           (payload_length >= 32'd183)? {16'b0, w16_210}: 32'd0 +
                           (payload_length >= 32'd185)? {16'b0, w16_212}: 32'd0 +
                           (payload_length >= 32'd187)? {16'b0, w16_214}: 32'd0 +
                           (payload_length >= 32'd189)? {16'b0, w16_216}: 32'd0 +
                           (payload_length >= 32'd191)? {16'b0, w16_218}: 32'd0 +
                           (payload_length >= 32'd193)? {16'b0, w16_220}: 32'd0 +
                           (payload_length >= 32'd195)? {16'b0, w16_222}: 32'd0 +
                           (payload_length >= 32'd197)? {16'b0, w16_224}: 32'd0 +
                           (payload_length >= 32'd199)? {16'b0, w16_226}: 32'd0 +
                           (payload_length >= 32'd201)? {16'b0, w16_228}: 32'd0 +
                           (payload_length >= 32'd203)? {16'b0, w16_230}: 32'd0 +
                           (payload_length >= 32'd205)? {16'b0, w16_232}: 32'd0 +
                           (payload_length >= 32'd207)? {16'b0, w16_234}: 32'd0 +
                           (payload_length >= 32'd209)? {16'b0, w16_236}: 32'd0 +
                           (payload_length >= 32'd211)? {16'b0, w16_238}: 32'd0 +
                           (payload_length >= 32'd213)? {16'b0, w16_240}: 32'd0 +
                           (payload_length >= 32'd215)? {16'b0, w16_242}: 32'd0 +
                           (payload_length >= 32'd217)? {16'b0, w16_244}: 32'd0 +
                           (payload_length >= 32'd219)? {16'b0, w16_246}: 32'd0 +
                           (payload_length >= 32'd221)? {16'b0, w16_248}: 32'd0 +
                           (payload_length >= 32'd223)? {16'b0, w16_250}: 32'd0 +
                           (payload_length >= 32'd225)? {16'b0, w16_252}: 32'd0 +
                           (payload_length >= 32'd227)? {16'b0, w16_254}: 32'd0 +
                           (payload_length >= 32'd229)? {16'b0, w16_256}: 32'd0 +
                           (payload_length >= 32'd231)? {16'b0, w16_258}: 32'd0 +
                           (payload_length >= 32'd233)? {16'b0, w16_260}: 32'd0 +
                           (payload_length >= 32'd235)? {16'b0, w16_262}: 32'd0 +
                           (payload_length >= 32'd237)? {16'b0, w16_264}: 32'd0 +
                           (payload_length >= 32'd239)? {16'b0, w16_266}: 32'd0 +
                           (payload_length >= 32'd241)? {16'b0, w16_268}: 32'd0 +
                           (payload_length >= 32'd243)? {16'b0, w16_270}: 32'd0 +
                           (payload_length >= 32'd245)? {16'b0, w16_272}: 32'd0 +
                           (payload_length >= 32'd247)? {16'b0, w16_274}: 32'd0 +
                           (payload_length >= 32'd249)? {16'b0, w16_276}: 32'd0 +
                           (payload_length >= 32'd251)? {16'b0, w16_278}: 32'd0 +
                           (payload_length >= 32'd253)? {16'b0, w16_280}: 32'd0 +
                           (payload_length >= 32'd255)? {16'b0, w16_282}: 32'd0 +
                           ((payload_length & 32'd1) != 0) ? {buf[28 + payload_length - 1], 8'b0} : 32'd0;

wire [31:0] udp_full_sum = pseudo_sum + udp_hdr_sum + udp_data_sum;
wire [16:0] udp_f1 = udp_full_sum[15:0] + udp_full_sum[31:16];
wire [15:0] udp_folded = udp_f1[15:0] + {15'b0, udp_f1[16]};

assign s_ready = (state == S_IDLE || state == S_RECV || state == S_DRAIN) && !rst;
assign status_valid = status_valid_r;
assign status_error = status_error_r;

assign m_valid = out_active && (state == S_OUT);
assign m_data = buf[out_ptr];
assign m_last = out_last_byte;
assign m_src_ip = r_src_ip;
assign m_src_port = r_src_port;
assign m_dst_port = r_dst_port;
assign m_payload_len = r_payload_len;

always @(posedge clk) begin
    if (rst) begin
        state <= S_IDLE;
        byte_cnt <= 0;
        last_seen <= 0;
        oversize <= 0;
        status_valid_r <= 0;
        status_error_r <= 0;
        out_active <= 0;
    end else begin
        status_valid_r <= 0;
        case (state)
            S_IDLE: begin
                if (s_valid && s_ready) begin
                    if (!oversize && byte_cnt < 512)
                        buf[byte_cnt] <= s_data;
                    byte_cnt <= byte_cnt + 1;
                    if (byte_cnt >= 512)
                        oversize <= 1;
                    if (s_last) begin
                        last_seen <= 1;
                        state <= S_CHECK;
                    end else begin
                        state <= S_RECV;
                    end
                end
            end
            S_RECV: begin
                if (s_valid && s_ready) begin
                    if (!oversize && byte_cnt < 512)
                        buf[byte_cnt] <= s_data;
                    byte_cnt <= byte_cnt + 1;
                    if (byte_cnt >= 512)
                        oversize <= 1;
                    if (s_last) begin
                        last_seen <= 1;
                        state <= S_CHECK;
                    end
                end
            end
            S_DRAIN: begin
                if (s_valid && s_ready) begin
                    if (s_last) begin
                        last_seen <= 1;
                        state <= S_CHECK;
                    end
                end
            end
            S_CHECK: begin
                err_code <= 0;
                if (oversize || byte_cnt > 512)
                    err_code <= 1;
                else if (byte_cnt < 28)
                    err_code <= 1;
                else if (buf[0][7:4] != 4)
                    err_code <= 1;
                else if (buf[0][3:0] != 5)
                    err_code <= 1;
                else if (buf[9] != 17)
                    err_code <= 1;
                else if (buf[6][5])
                    err_code <= 1;
                else if ({buf[6][4:0], buf[7]} != 0)
                    err_code <= 1;
                else if (ip_total_length != byte_cnt)
                    err_code <= 2;
                else if (udp_length != ip_total_length - 32'd20)
                    err_code <= 2;
                else if (payload_length < 1 || payload_length > 256)
                    err_code <= 2;
                else if (ip_folded != 16'hffff)
                    err_code <= 3;
                else if (w16_26 != 0 && udp_folded != 16'hffff)
                    err_code <= 4;
                else if ({buf[16],buf[17],buf[18],buf[19]} != 32'h0a000002)
                    err_code <= 5;
                else if (w16_22 != 9000)
                    err_code <= 5;

                r_src_ip <= {buf[12],buf[13],buf[14],buf[15]};
                r_src_port <= w16_20;
                r_dst_port <= w16_22;
                r_payload_len <= payload_length[15:0];

                state <= S_STATUS;
            end
            S_STATUS: begin
                status_valid_r <= 1;
                status_error_r <= err_code;
                if (err_code == 0) begin
                    out_ptr <= 28;
                    out_end <= 28 + payload_length[9:0] - 1;
                    out_active <= 1;
                    out_last_byte <= (payload_length == 1);
                    state <= S_OUT;
                end else begin
                    byte_cnt <= 0;
                    last_seen <= 0;
                    oversize <= 0;
                    out_active <= 0;
                    state <= S_IDLE;
                end
            end
            S_OUT: begin
                if (m_valid && m_ready) begin
                    if (out_last_byte) begin
                        out_active <= 0;
                        byte_cnt <= 0;
                        last_seen <= 0;
                        oversize <= 0;
                        state <= S_IDLE;
                    end else begin
                        out_ptr <= out_ptr + 1;
                        out_last_byte <= (out_ptr + 1 == out_end);
                    end
                end
            end
            default: state <= S_IDLE;
        endcase
    end
end

endmodule
