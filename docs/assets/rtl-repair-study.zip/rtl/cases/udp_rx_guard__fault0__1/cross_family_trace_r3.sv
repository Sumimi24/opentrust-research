`timescale 1ns/1ps
`default_nettype none

module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
output wire s_ready,
input wire s_valid,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

reg [7:0] buf [0:511];
reg [9:0] byte_cnt;
reg last_seen;
reg oversize;
reg [2:0] state;
reg status_valid_r;
reg [3:0] status_error_r;
reg [3:0] err_code;
reg [9:0] out_ptr;
reg [9:0] out_end;
reg out_active;
reg out_last_byte;
reg [31:0] r_src_ip;
reg [15:0] r_src_port;
reg [15:0] r_dst_port;
reg [15:0] r_payload_len;

localparam S_IDLE=3'd0, S_RECV=3'd1, S_DRAIN=3'd2, S_CHECK=3'd3, S_STATUS=3'd4, S_OUT=3'd5;

wire [15:0] w16_0  = {buf[0],  buf[1]};
wire [15:0] w16_2  = {buf[2],  buf[3]};
wire [15:0] w16_4  = {buf[4],  buf[5]};
wire [15:0] w16_6  = {buf[6],  buf[7]};
wire [15:0] w16_8  = {buf[8],  buf[9]};
wire [15:0] w16_10 = {buf[10], buf[11]};
wire [15:0] w16_12 = {buf[12], buf[13]};
wire [15:0] w16_14 = {buf[14], buf[15]};
wire [15:0] w16_16 = {buf[16], buf[17]};
wire [15:0] w16_18 = {buf[18], buf[19]};
wire [15:0] w16_20 = {buf[20], buf[21]};
wire [15:0] w16_22 = {buf[22], buf[23]};
wire [15:0] w16_24 = {buf[24], buf[25]};
wire [15:0] w16_26 = {buf[26], buf[27]};

wire [15:0] ip_total_length = w16_2;
wire [15:0] udp_length = w16_24;
wire [15:0] payload_length = udp_length - 16'd8;

wire [17:0] ip_sum = {2'b0, w16_0} + {2'b0, w16_2} + {2'b0, w16_4} + {2'b0, w16_6} + {2'b0, w16_8} +
                     {2'b0, w16_10} + {2'b0, w16_12} + {2'b0, w16_14} + {2'b0, w16_16} + {2'b0, w16_18};
wire [16:0] ip_fold1 = ip_sum[15:0] + {1'b0, ip_sum[17:16]};
wire [15:0] ip_folded = ip_fold1[15:0] + {15'b0, ip_fold1[16]};

wire [31:0] pseudo_sum = {16'b0, w16_12} + {16'b0, w16_14} +
                         {16'b0, w16_16} + {16'b0, w16_18} +
                         32'd17 + {16'b0, udp_length};
wire [31:0] udp_hdr_sum = {16'b0, w16_20} + {16'b0, w16_22} +
                          {16'b0, w16_24} + {16'b0, w16_26};

reg [31:0] udp_data_sum;
reg [9:0] i;
always @(*) begin
    udp_data_sum = 32'd0;
    for (i = 0; i < 256; i = i + 1) begin
        if ((i < 128) && ({9'b0, i, 1'b0} < {1'b0, payload_length})) begin
            udp_data_sum = udp_data_sum + {16'b0, buf[28 + {i, 1'b0}], buf[28 + {i, 1'b0} + 1]};
        end
    end
    if (payload_length[0]) begin
        udp_data_sum = udp_data_sum + {16'b0, buf[28 + payload_length[8:0] - 1], 8'b0};
    end
end

wire [31:0] udp_full_sum = pseudo_sum + udp_hdr_sum + udp_data_sum;
wire [16:0] udp_f1 = udp_full_sum[15:0] + udp_full_sum[31:16];
wire [15:0] udp_folded = udp_f1[15:0] + {15'b0, udp_f1[16]};

assign s_ready = (state == S_IDLE || state == S_RECV || state == S_DRAIN) && !rst;
assign status_valid = status_valid_r;
assign status_error = status_error_r;

assign m_valid = out_active && (state == S_OUT);
assign m_data = buf[out_ptr];
assign m_last = out_last_byte;
assign m_src_ip = r_src_ip;
assign m_src_port = r_src_port;
assign m_dst_port = r_dst_port;
assign m_payload_len = r_payload_len;

always @(posedge clk) begin
    if (rst) begin
        state <= S_IDLE;
        byte_cnt <= 10'd0;
        last_seen <= 1'b0;
        oversize <= 1'b0;
        status_valid_r <= 1'b0;
        status_error_r <= 4'd0;
        out_active <= 1'b0;
    end else begin
        status_valid_r <= 1'b0;
        case (state)
            S_IDLE: begin
                if (s_valid && s_ready) begin
                    if (!oversize && byte_cnt < 10'd512)
                        buf[byte_cnt] <= s_data;
                    byte_cnt <= byte_cnt + 10'd1;
                    if (byte_cnt >= 10'd511)
                        oversize <= 1'b1;
                    if (s_last) begin
                        last_seen <= 1'b1;
                        state <= S_CHECK;
                    end else begin
                        state <= S_RECV;
                    end
                end
            end
            S_RECV: begin
                if (s_valid && s_ready) begin
                    if (!oversize && byte_cnt < 10'd512)
                        buf[byte_cnt] <= s_data;
                    byte_cnt <= byte_cnt + 10'd1;
                    if (byte_cnt >= 10'd511)
                        oversize <= 1'b1;
                    if (s_last) begin
                        last_seen <= 1'b1;
                        state <= S_CHECK;
                    end
                end
            end
            S_DRAIN: begin
                if (s_valid && s_ready) begin
                    if (s_last) begin
                        last_seen <= 1'b1;
                        state <= S_CHECK;
                    end
                end
            end
            S_CHECK: begin
                err_code <= 4'd0;
                if (oversize || byte_cnt > 10'd512)
                    err_code <= 4'd1;
                else if (byte_cnt < 10'd28)
                    err_code <= 4'd1;
                else if (buf[0][7:4] != 4'd4)
                    err_code <= 4'd1;
                else if (buf[0][3:0] != 4'd5)
                    err_code <= 4'd1;
                else if (buf[9] != 8'd17)
                    err_code <= 4'd1;
                else if (buf[6][5])
                    err_code <= 4'd1;
                else if ({buf[6][4:0], buf[7]} != 13'd0)
                    err_code <= 4'd1;
                else if (ip_total_length != byte_cnt[15:0])
                    err_code <= 4'd2;
                else if (udp_length != ip_total_length - 16'd20)
                    err_code <= 4'd2;
                else if (payload_length < 16'd1 || payload_length > 16'd256)
                    err_code <= 4'd2;
                else if (ip_folded != 16'hffff)
                    err_code <= 4'd3;
                else if (w16_26 != 16'd0 && udp_folded != 16'hffff)
                    err_code <= 4'd4;
                else if ({buf[16],buf[17],buf[18],buf[19]} != 32'h0a000002)
                    err_code <= 4'd5;
                else if (w16_22 != 16'd9000)
                    err_code <= 4'd5;

                r_src_ip <= {buf[12],buf[13],buf[14],buf[15]};
                r_src_port <= w16_20;
                r_dst_port <= w16_22;
                r_payload_len <= payload_length;

                state <= S_STATUS;
            end
            S_STATUS: begin
                status_valid_r <= 1'b1;
                status_error_r <= err_code;
                if (err_code == 4'd0) begin
                    out_ptr <= 10'd28;
                    out_end <= 10'd28 + payload_len_calc;
                    out_active <= 1'b1;
                    out_last_byte <= (payload_length == 16'd1);
                    state <= S_OUT;
                end else begin
                    byte_cnt <= 10'd0;
                    last_seen <= 1'b0;
                    oversize <= 1'b0;
                    out_active <= 1'b0;
                    state <= S_IDLE;
                end
            end
            S_OUT: begin
                if (m_valid && m_ready) begin
                    if (out_last_byte) begin
                        out_active <= 1'b0;
                        byte_cnt <= 10'd0;
                        last_seen <= 1'b0;
                        oversize <= 1'b0;
                        state <= S_IDLE;
                    end else begin
                        out_ptr <= out_ptr + 10'd1;
                        out_last_byte <= (out_ptr + 10'd1 == out_end);
                    end
                end
            end
            default: state <= S_IDLE;
        endcase
    end
end

wire [9:0] payload_len_calc = payload_length[9:0] - 10'd1;

endmodule
