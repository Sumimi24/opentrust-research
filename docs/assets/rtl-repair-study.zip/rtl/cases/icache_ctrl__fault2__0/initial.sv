module icache_ctrl(
input wire clk_i,
input wire rst_ni,
input wire req_i,
input wire branch_i,
input wire [31:0] addr_i,
input wire ready_i,
output wire valid_o,
output wire [31:0] rdata_o,
output wire [31:0] addr_o,
output wire err_o,
output wire instr_req_o,
input wire instr_gnt_i,
output wire [31:0] instr_addr_o,
input wire [31:0] instr_rdata_i,
input wire instr_err_i,
input wire instr_rvalid_i,
input wire icache_inval_i,
output wire busy_o);

import ibex_pkg::*;

wire [1:0] tag_req;
wire [1:0] data_req;
wire tag_write;
wire data_write;
wire [7:0] tag_addr;
wire [7:0] data_addr;
wire [21:0] tag_wdata;
wire [63:0] data_wdata;

reg [21:0] tag_rdata_q [0:1];
reg [63:0] data_rdata_q [0:1];

reg [21:0] tag_mem0 [0:255];
reg [21:0] tag_mem1 [0:255];
reg [63:0] data_mem0 [0:255];
reg [63:0] data_mem1 [0:255];

always @(posedge clk_i) begin
  if (tag_req[0]) begin
    tag_rdata_q[0] <= tag_mem0[tag_addr];
    if (tag_write) tag_mem0[tag_addr] <= tag_wdata;
  end
  if (tag_req[1]) begin
    tag_rdata_q[1] <= tag_mem1[tag_addr];
    if (tag_write) tag_mem1[tag_addr] <= tag_wdata;
  end
  if (data_req[0]) begin
    data_rdata_q[0] <= data_mem0[data_addr];
    if (data_write) data_mem0[data_addr] <= data_wdata;
  end
  if (data_req[1]) begin
    data_rdata_q[1] <= data_mem1[data_addr];
    if (data_write) data_mem1[data_addr] <= data_wdata;
  end
end

wire core_valid;
wire [31:0] core_rdata;
wire [31:0] core_addr;
wire core_err;
wire core_instr_req;
wire [31:0] core_instr_addr;
wire core_busy;

reg hold_valid_q;
reg [31:0] hold_rdata_q;
reg [31:0] hold_addr_q;
reg hold_err_q;
reg saw_error_q;

wire out_valid = hold_valid_q | (core_valid & ~saw_error_q);
wire out_err   = hold_valid_q ? hold_err_q  : core_err;
wire [31:0] out_rdata = hold_valid_q ? hold_rdata_q : core_rdata;
wire [31:0] out_addr  = hold_valid_q ? hold_addr_q  : core_addr;

wire consume_out = out_valid & ready_i & ~branch_i;

always @(posedge clk_i or negedge rst_ni) begin
  if (!rst_ni) begin
    hold_valid_q <= 1'b0;
    hold_rdata_q <= 32'h0;
    hold_addr_q  <= 32'h0;
    hold_err_q   <= 1'b0;
    saw_error_q  <= 1'b0;
  end else begin
    if (branch_i) begin
      hold_valid_q <= 1'b0;
      saw_error_q  <= 1'b0;
    end else begin
      if (hold_valid_q) begin
        if (ready_i) begin
          hold_valid_q <= 1'b0;
          if (hold_err_q) saw_error_q <= 1'b1;
        end
      end else if (core_valid & ~saw_error_q) begin
        if (ready_i) begin
          if (core_err) saw_error_q <= 1'b1;
        end else begin
          hold_valid_q <= 1'b1;
          hold_rdata_q <= core_rdata;
          hold_addr_q  <= core_addr;
          hold_err_q   <= core_err;
        end
      end
    end
  end
end

assign valid_o = out_valid & ~saw_error_q;
assign rdata_o = out_rdata;
assign addr_o  = out_addr;
assign err_o   = out_err & ~saw_error_q;

ibex_icache #(
  .ICacheECC(0),
  .ResetAll(1),
  .BranchCache(0),
  .TweakInfection(0)
) core (
  .clk_i(clk_i),
  .rst_ni(rst_ni),
  .req_i(req_i),
  .branch_i(branch_i),
  .addr_i({addr_i[31:2], 2'b00}),
  .ready_i((~hold_valid_q & ready_i & ~saw_error_q) | branch_i),
  .valid_o(core_valid),
  .rdata_o(core_rdata),
  .addr_o(core_addr),
  .err_o(core_err),
  .instr_req_o(core_instr_req),
  .instr_gnt_i(instr_gnt_i),
  .instr_addr_o(core_instr_addr),
  .instr_rdata_i(instr_rdata_i),
  .instr_err_i(instr_err_i),
  .instr_rvalid_i(instr_rvalid_i),
  .icache_inval_i(icache_inval_i),
  .busy_o(core_busy),
  .ic_tag_req_o(tag_req),
  .ic_tag_write_o(tag_write),
  .ic_tag_addr_o(tag_addr),
  .ic_tag_wdata_o(tag_wdata),
  .ic_tag_rdata_i(tag_rdata_q),
  .ic_data_req_o(data_req),
  .ic_data_write_o(data_write),
  .ic_data_addr_o(data_addr),
  .ic_data_wdata_o(data_wdata),
  .ic_data_rdata_i(data_rdata_q),
  .ic_scr_key_valid_i(1'b1),
  .icache_enable_i(1'b1)
);

assign instr_req_o  = core_instr_req;
assign instr_addr_o = {core_instr_addr[31:2], 2'b00};
assign busy_o       = core_busy | hold_valid_q;

endmodule
