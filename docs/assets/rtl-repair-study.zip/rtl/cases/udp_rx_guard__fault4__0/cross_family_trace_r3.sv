`timescale 1ns / 1ps
`default_nettype none

module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output reg s_ready,
input wire s_last,
output reg [7:0] m_data,
output reg m_valid,
input wire m_ready,
output reg m_last,
output reg [31:0] m_src_ip,
output reg [15:0] m_src_port,
output reg [15:0] m_dst_port,
output reg [15:0] m_payload_len,
output reg status_valid,
output reg [3:0] status_error);

localparam ST_IDLE   = 3'd0;
localparam ST_RECV   = 3'd1;
localparam ST_CALC   = 3'd2;
localparam ST_STATUS = 3'd3;
localparam ST_OUT    = 3'd4;

reg [2:0] state;
reg [9:0] byte_cnt;
reg [9:0] out_ptr;
reg oversize;
reg [7:0] buf [0:511];

wire [15:0] ip_hdr_csum;
wire [15:0] udp_csum;

function [15:0] ones_add;
    input [15:0] a;
    input [15:0] b;
    reg [16:0] sum;
    begin
        sum = a + b;
        ones_add = sum[15:0] + sum[16];
    end
endfunction

wire [15:0] ip_hdr_word [0:9];
assign ip_hdr_word[0] = {buf[0], buf[1]};
assign ip_hdr_word[1] = {buf[2], buf[3]};
assign ip_hdr_word[2] = {buf[4], buf[5]};
assign ip_hdr_word[3] = {buf[6], buf[7]};
assign ip_hdr_word[4] = {buf[8], buf[9]};
assign ip_hdr_word[5] = {buf[10], buf[11]};
assign ip_hdr_word[6] = {buf[12], buf[13]};
assign ip_hdr_word[7] = {buf[14], buf[15]};
assign ip_hdr_word[8] = {buf[16], buf[17]};
assign ip_hdr_word[9] = {buf[18], buf[19]};

wire [15:0] ip_hdr_csum_s0 = ones_add(ip_hdr_word[0], ip_hdr_word[1]);
wire [15:0] ip_hdr_csum_s1 = ones_add(ip_hdr_csum_s0, ip_hdr_word[2]);
wire [15:0] ip_hdr_csum_s2 = ones_add(ip_hdr_csum_s1, ip_hdr_word[3]);
wire [15:0] ip_hdr_csum_s3 = ones_add(ip_hdr_csum_s2, ip_hdr_word[4]);
wire [15:0] ip_hdr_csum_s4 = ones_add(ip_hdr_csum_s3, ip_hdr_word[5]);
wire [15:0] ip_hdr_csum_s5 = ones_add(ip_hdr_csum_s4, ip_hdr_word[6]);
wire [15:0] ip_hdr_csum_s6 = ones_add(ip_hdr_csum_s5, ip_hdr_word[7]);
wire [15:0] ip_hdr_csum_s7 = ones_add(ip_hdr_csum_s6, ip_hdr_word[8]);
wire [15:0] ip_hdr_csum_s8 = ones_add(ip_hdr_csum_s7, ip_hdr_word[9]);
assign ip_hdr_csum = ~ip_hdr_csum_s8;

wire [15:0] ip_total_length = {buf[2], buf[3]};
wire [15:0] udp_length = {buf[24], buf[25]};
wire [15:0] payload_len = udp_length - 16'd8;
wire [31:0] src_ip = {buf[12], buf[13], buf[14], buf[15]};
wire [31:0] dst_ip = {buf[16], buf[17], buf[18], buf[19]};
wire [15:0] src_port = {buf[20], buf[21]};
wire [15:0] dst_port = {buf[22], buf[23]};

wire version_check = (buf[0][7:4] == 4'd4);
wire ihl_check = (buf[0][3:0] == 4'd5);
wire protocol_check = (buf[9] == 8'd17);
wire fragment_check = !buf[6][5] && ({buf[6][4:0], buf[7]} == 13'd0);
wire size_min_check = (byte_cnt >= 10'd28);
wire size_max_check = (byte_cnt <= 10'd512);
wire ip_len_match = (ip_total_length == byte_cnt);
wire udp_len_match = (udp_length == (ip_total_length - 16'd20));
wire plen_range_check = (payload_len >= 16'd1) && (payload_len <= 16'd256);
wire ip_csum_ok = (ip_hdr_csum == 16'hffff);
wire dst_ip_match = (dst_ip == 32'h0a000002);
wire dst_port_match = (dst_port == 16'd9000);

wire has_error1;
wire has_error2;
wire has_error3;
wire has_error4;
wire has_error5;
wire has_error;
wire [3:0] error_code;

assign has_error1 = !(version_check && ihl_check && protocol_check && fragment_check && size_min_check && size_max_check);
assign has_error2 = !(ip_len_match && udp_len_match && plen_range_check);
assign has_error3 = !ip_csum_ok;
assign has_error5 = !dst_ip_match || !dst_port_match;

wire [15:0] udp_csum_check;
reg [16:0] pseudo_sum_partial;
reg [19:0] udp_data_sum;
reg [9:0] ii;

always @* begin
    pseudo_sum_partial = 0;
    pseudo_sum_partial = ones_add(src_ip[31:16], src_ip[15:0]);
    pseudo_sum_partial = ones_add(pseudo_sum_partial, dst_ip[31:16]);
    pseudo_sum_partial = ones_add(pseudo_sum_partial, dst_ip[15:0]);
    pseudo_sum_partial = ones_add(pseudo_sum_partial, 16'h0011);
    pseudo_sum_partial = ones_add(pseudo_sum_partial, udp_length);
    
    udp_data_sum = 0;
    for (ii = 0; ii < 256; ii = ii + 2) begin
        if (ii + 20 < byte_cnt) begin
            if (ii + 21 < byte_cnt)
                udp_data_sum = udp_data_sum + {buf[20 + ii], buf[21 + ii]};
            else
                udp_data_sum = udp_data_sum + {buf[20 + ii], 8'h00};
        end
    end
    udp_data_sum = udp_data_sum + {buf[20], buf[21]} + {buf[22], buf[23]} + {buf[24], buf[25]} + {buf[26], buf[27]};
end

wire [16:0] full_sum = pseudo_sum_partial + udp_data_sum[15:0] + udp_data_sum[16];
wire [15:0] folded_sum = full_sum[15:0] + full_sum[16];
assign udp_csum_check = ~folded_sum;

wire udp_csum_zero = ({buf[26], buf[27]} == 16'h0000);
wire udp_csum_ok = udp_csum_zero || (udp_csum_check == 16'hffff);

assign has_error4 = !udp_csum_ok;

assign has_error = has_error1 || has_error2 || has_error3 || has_error4 || has_error5;
assign error_code = has_error1 ? 4'd1 :
                    has_error2 ? 4'd2 :
                    has_error3 ? 4'd3 :
                    has_error4 ? 4'd4 :
                    has_error5 ? 4'd5 : 4'd0;

always @(posedge clk) begin
    if (rst) begin
        state <= ST_IDLE;
        byte_cnt <= 10'd0;
        out_ptr <= 10'd0;
        oversize <= 1'b0;
        s_ready <= 1'b0;
        m_valid <= 1'b0;
        m_data <= 8'd0;
        m_last <= 1'b0;
        m_src_ip <= 32'd0;
        m_src_port <= 16'd0;
        m_dst_port <= 16'd0;
        m_payload_len <= 16'd0;
        status_valid <= 1'b0;
        status_error <= 4'd0;
    end else begin
        status_valid <= 1'b0;
        
        case (state)
            ST_IDLE: begin
                byte_cnt <= 10'd0;
                oversize <= 1'b0;
                s_ready <= 1'b1;
                state <= ST_RECV;
            end
            
            ST_RECV: begin
                s_ready <= 1'b1;
                if (s_valid && s_ready) begin
                    if (!oversize && byte_cnt < 10'd512)
                        buf[byte_cnt] <= s_data;
                    else if (byte_cnt >= 10'd512)
                        oversize <= 1'b1;
                    
                    byte_cnt <= byte_cnt + 10'd1;
                    
                    if (s_last) begin
                        s_ready <= 1'b0;
                        state <= ST_CALC;
                    end
                end
            end
            
            ST_CALC: begin
                state <= ST_STATUS;
            end
            
            ST_STATUS: begin
                status_valid <= 1'b1;
                status_error <= error_code;
                if (!has_error) begin
                    m_src_ip <= src_ip;
                    m_src_port <= src_port;
                    m_dst_port <= dst_port;
                    m_payload_len <= payload_len;
                    out_ptr <= 10'd20;
                    state <= ST_OUT;
                end else begin
                    state <= ST_IDLE;
                end
            end
            
            ST_OUT: begin
                m_valid <= 1'b1;
                m_data <= buf[out_ptr];
                m_last <= (out_ptr == (byte_cnt - 10'd1));
                
                if (m_ready) begin
                    if (m_last) begin
                        m_valid <= 1'b0;
                        state <= ST_IDLE;
                    end else begin
                        out_ptr <= out_ptr + 10'd1;
                    end
                end
            end
            
            default: state <= ST_IDLE;
        endcase
    end
end

endmodule
`default_nettype wire
