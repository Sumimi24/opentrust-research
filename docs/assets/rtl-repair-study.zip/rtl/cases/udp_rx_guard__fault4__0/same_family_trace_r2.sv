`timescale 1ns / 1ps
`default_nettype none

module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

localparam ST_RECV   = 2'd0;
localparam ST_STATUS = 2'd1;
localparam ST_OUT    = 2'd2;

reg [1:0] state_reg;

reg [7:0] frame_mem[0:511];

reg [9:0] rx_count_reg;
reg oversize_reg;

reg [3:0] status_error_reg;
reg status_valid_reg;

reg [31:0] out_src_ip_reg;
reg [15:0] out_src_port_reg;
reg [15:0] out_dst_port_reg;
reg [15:0] out_payload_len_reg;

reg out_valid_reg;
reg [7:0] out_data_reg;
reg out_last_reg;

reg [8:0] out_index_reg;
reg [8:0] out_len_reg;

reg have_accepted_reg;

assign s_ready = (state_reg == ST_RECV) && !have_accepted_reg;

assign m_data = out_data_reg;
assign m_valid = out_valid_reg;
assign m_last = out_last_reg;
assign m_src_ip = out_src_ip_reg;
assign m_src_port = out_src_port_reg;
assign m_dst_port = out_dst_port_reg;
assign m_payload_len = out_payload_len_reg;
assign status_valid = status_valid_reg;
assign status_error = status_error_reg;

integer i;
integer sum;
integer udp_sum;
integer actual_len;
integer ip_len;
integer udp_len;
integer payload_len_i;
integer err_i;
reg [15:0] ip_fold;
reg [15:0] udp_fold;
reg [31:0] dst_ip_v;
reg [31:0] src_ip_v;
reg [15:0] src_port_v;
reg [15:0] dst_port_v;

always @(posedge clk) begin
    if (rst) begin
        state_reg <= ST_RECV;
        rx_count_reg <= 10'd0;
        oversize_reg <= 1'b0;
        status_error_reg <= 4'd0;
        status_valid_reg <= 1'b0;
        out_src_ip_reg <= 32'd0;
        out_src_port_reg <= 16'd0;
        out_dst_port_reg <= 16'd0;
        out_payload_len_reg <= 16'd0;
        out_valid_reg <= 1'b0;
        out_data_reg <= 8'd0;
        out_last_reg <= 1'b0;
        out_index_reg <= 9'd0;
        out_len_reg <= 9'd0;
        have_accepted_reg <= 1'b0;
    end else begin
        status_valid_reg <= 1'b0;

        if (out_valid_reg && m_ready) begin
            if (out_last_reg) begin
                out_valid_reg <= 1'b0;
                out_last_reg <= 1'b0;
                have_accepted_reg <= 1'b0;
                state_reg <= ST_RECV;
                rx_count_reg <= 10'd0;
                oversize_reg <= 1'b0;
            end else begin
                out_index_reg <= out_index_reg + 9'd1;
                out_data_reg <= frame_mem[28 + out_index_reg + 9'd1];
                out_last_reg <= ((out_index_reg + 9'd1) == (out_len_reg - 9'd1));
            end
        end

        case (state_reg)
            ST_RECV: begin
                if (s_valid && s_ready) begin
                    if (!oversize_reg && rx_count_reg < 10'd512) begin
                        frame_mem[rx_count_reg] <= s_data;
                    end

                    if (!s_last) begin
                        if (!oversize_reg) begin
                            if (rx_count_reg == 10'd511) begin
                                oversize_reg <= 1'b1;
                            end else begin
                                rx_count_reg <= rx_count_reg + 10'd1;
                            end
                        end
                    end else begin
                        actual_len = oversize_reg ? 513 : (rx_count_reg + 1);
                        ip_len = {frame_mem[2], frame_mem[3]};
                        udp_len = {frame_mem[24], frame_mem[25]};
                        payload_len_i = udp_len - 8;
                        dst_ip_v = {frame_mem[16], frame_mem[17], frame_mem[18], frame_mem[19]};
                        src_ip_v = {frame_mem[12], frame_mem[13], frame_mem[14], frame_mem[15]};
                        src_port_v = {frame_mem[20], frame_mem[21]};
                        dst_port_v = {frame_mem[22], frame_mem[23]};
                        err_i = 0;

                        if (actual_len < 28 || actual_len > 512 || {frame_mem[0][7:4]} != 4 || {frame_mem[0][3:0]} != 5 ||
                            frame_mem[9] != 8'd17 || frame_mem[6][5] != 1'b1 && {frame_mem[6][4:0], frame_mem[7]} != 13'd0 ? 1'b1 : frame_mem[6][5] || ({frame_mem[6][4:0], frame_mem[7]} != 13'd0)) begin
                            err_i = 1;
                        end else if (ip_len != actual_len || udp_len != (ip_len - 20) || payload_len_i < 1 || payload_len_i > 256) begin
                            err_i = 2;
                        end else begin
                            sum = 0;
                            for (i = 0; i < 20; i = i + 2) begin
                                sum = sum + {frame_mem[i], frame_mem[i+1]};
                            end
                            sum = (sum & 16'hffff) + (sum >> 16);
                            sum = (sum & 16'hffff) + (sum >> 16);
                            ip_fold = sum[15:0];
                            if (ip_fold != 16'hffff) begin
                                err_i = 3;
                            end else begin
                                if ({frame_mem[26], frame_mem[27]} != 16'h0000) begin
                                    udp_sum = 0;
                                    udp_sum = udp_sum + {frame_mem[12], frame_mem[13]};
                                    udp_sum = udp_sum + {frame_mem[14], frame_mem[15]};
                                    udp_sum = udp_sum + {frame_mem[16], frame_mem[17]};
                                    udp_sum = udp_sum + {frame_mem[18], frame_mem[19]};
                                    udp_sum = udp_sum + 16'h0011;
                                    udp_sum = udp_sum + udp_len[15:0];
                                    for (i = 20; i < actual_len; i = i + 2) begin
                                        if (i + 1 < actual_len) begin
                                            udp_sum = udp_sum + {frame_mem[i], frame_mem[i+1]};
                                        end else begin
                                            udp_sum = udp_sum + {frame_mem[i], 8'h00};
                                        end
                                    end
                                    udp_sum = (udp_sum & 16'hffff) + (udp_sum >> 16);
                                    udp_sum = (udp_sum & 16'hffff) + (udp_sum >> 16);
                                    udp_sum = (udp_sum & 16'hffff) + (udp_sum >> 16);
                                    udp_fold = udp_sum[15:0];
                                    if (udp_fold != 16'hffff) begin
                                        err_i = 4;
                                    end else if (dst_ip_v != 32'h0a000002 || dst_port_v != 16'd9000) begin
                                        err_i = 5;
                                    end
                                end else if (dst_ip_v != 32'h0a000002 || dst_port_v != 16'd9000) begin
                                    err_i = 5;
                                end
                            end
                        end

                        status_valid_reg <= 1'b1;
                        status_error_reg <= err_i[3:0];

                        if (err_i == 0) begin
                            out_src_ip_reg <= src_ip_v;
                            out_src_port_reg <= src_port_v;
                            out_dst_port_reg <= dst_port_v;
                            out_payload_len_reg <= payload_len_i[15:0];
                            out_len_reg <= payload_len_i[8:0];
                            out_index_reg <= 9'd0;
                            out_data_reg <= frame_mem[28];
                            out_last_reg <= (payload_len_i == 1);
                            out_valid_reg <= 1'b1;
                            have_accepted_reg <= 1'b1;
                            state_reg <= ST_OUT;
                        end else begin
                            rx_count_reg <= 10'd0;
                            oversize_reg <= 1'b0;
                            state_reg <= ST_RECV;
                        end
                    end
                end
            end

            ST_OUT: begin
            end

            default: begin
                state_reg <= ST_RECV;
            end
        endcase
    end
end

endmodule
`default_nettype wire
