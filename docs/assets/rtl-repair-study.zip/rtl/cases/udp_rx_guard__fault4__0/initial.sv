`timescale 1ns / 1ps
`default_nettype none

module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

reg [7:0] bytes[0:511];

localparam ST_RECV       = 3'd0;
localparam ST_STATUS     = 3'd1;
localparam ST_HDR        = 3'd2;
localparam ST_PAYLOAD_IN = 3'd3;
localparam ST_DRAIN      = 3'd4;

reg [2:0] state_reg;
reg [9:0] n_reg;
reg oversize_reg;
reg [9:0] ptr_reg;

reg status_valid_reg;
reg [3:0] status_error_reg;

reg [15:0] ip_total_length_reg;
reg [15:0] udp_length_reg;
reg [15:0] payload_len_reg;
reg [3:0] error_code_reg;

reg [31:0] src_ip_hold_reg;
reg [15:0] src_port_hold_reg;
reg [15:0] dst_port_hold_reg;
reg [15:0] payload_len_hold_reg;

wire [15:0] b_word_2   = {bytes[2],  bytes[3]};
wire [15:0] b_word_4   = {bytes[4],  bytes[5]};
wire [15:0] b_word_6   = {bytes[6],  bytes[7]};
wire [15:0] b_word_10  = {bytes[10], bytes[11]};
wire [15:0] b_word_12  = {bytes[12], bytes[13]};
wire [15:0] b_word_14  = {bytes[14], bytes[15]};
wire [15:0] b_word_16  = {bytes[16], bytes[17]};
wire [15:0] b_word_18  = {bytes[18], bytes[19]};
wire [15:0] b_word_20  = {bytes[20], bytes[21]};
wire [15:0] b_word_22  = {bytes[22], bytes[23]};
wire [15:0] b_word_24  = {bytes[24], bytes[25]};
wire [15:0] b_word_26  = {bytes[26], bytes[27]};

integer ip_sum_int;
integer udp_sum_int;
integer i_int;
integer actual_len_int;
integer error_code_int;
integer ip_len_int;
integer udp_len_int;
integer payload_len_int;

always @* begin
    actual_len_int = n_reg;
    ip_len_int = b_word_2;
    udp_len_int = b_word_24;
    payload_len_int = udp_len_int - 16'd8;
    error_code_int = 0;

    if (actual_len_int < 28 || oversize_reg || bytes[0][7:4] != 4 || bytes[0][3:0] != 5 || bytes[9] != 8'd17 || bytes[6][5] || {bytes[6][4:0], bytes[7]} != 13'd0) begin
        error_code_int = 1;
    end else if (ip_len_int != actual_len_int || udp_len_int != (ip_len_int - 16'd20) || payload_len_int < 1 || payload_len_int > 256) begin
        error_code_int = 2;
    end else begin
        ip_sum_int = 0;
        ip_sum_int = ip_sum_int + {bytes[0],  bytes[1]};
        ip_sum_int = ip_sum_int + b_word_2;
        ip_sum_int = ip_sum_int + b_word_4;
        ip_sum_int = ip_sum_int + b_word_6;
        ip_sum_int = ip_sum_int + {bytes[8],  bytes[9]};
        ip_sum_int = ip_sum_int + b_word_10;
        ip_sum_int = ip_sum_int + b_word_12;
        ip_sum_int = ip_sum_int + b_word_14;
        ip_sum_int = ip_sum_int + b_word_16;
        ip_sum_int = ip_sum_int + b_word_18;
        ip_sum_int = (ip_sum_int & 16'hffff) + (ip_sum_int >> 16);
        ip_sum_int = (ip_sum_int & 16'hffff) + (ip_sum_int >> 16);

        if ((ip_sum_int & 16'hffff) != 16'hffff) begin
            error_code_int = 3;
        end else begin
            if (b_word_26 != 16'h0000) begin
                udp_sum_int = 0;
                udp_sum_int = udp_sum_int + b_word_12;
                udp_sum_int = udp_sum_int + b_word_14;
                udp_sum_int = udp_sum_int + b_word_16;
                udp_sum_int = udp_sum_int + b_word_18;
                udp_sum_int = udp_sum_int + 16'h0011;
                udp_sum_int = udp_sum_int + udp_len_int;

                for (i_int = 20; i_int < 512; i_int = i_int + 2) begin
                    if (i_int < actual_len_int) begin
                        if (i_int + 1 < actual_len_int) begin
                            udp_sum_int = udp_sum_int + {bytes[i_int], bytes[i_int+1]};
                        end else begin
                            udp_sum_int = udp_sum_int + {bytes[i_int], 8'h00};
                        end
                    end
                end

                udp_sum_int = (udp_sum_int & 16'hffff) + (udp_sum_int >> 16);
                udp_sum_int = (udp_sum_int & 16'hffff) + (udp_sum_int >> 16);
                udp_sum_int = (udp_sum_int & 16'hffff) + (udp_sum_int >> 16);

                if ((udp_sum_int & 16'hffff) != 16'hffff) begin
                    error_code_int = 4;
                end else if ({bytes[16], bytes[17], bytes[18], bytes[19]} != 32'h0a000002 || b_word_22 != 16'd9000) begin
                    error_code_int = 5;
                end
            end else if ({bytes[16], bytes[17], bytes[18], bytes[19]} != 32'h0a000002 || b_word_22 != 16'd9000) begin
                error_code_int = 5;
            end
        end
    end
end

wire parser_hdr_ready;
wire parser_payload_ready;
wire [31:0] parser_src_ip;
wire [15:0] parser_src_port;
wire [15:0] parser_dst_port;
wire [15:0] parser_udp_length;
wire [7:0] parser_m_data;
wire parser_m_valid;
wire parser_m_last;

assign s_ready = (state_reg == ST_RECV);

assign status_valid = status_valid_reg;
assign status_error = status_error_reg;

assign m_data = parser_m_data;
assign m_valid = (state_reg == ST_DRAIN) ? parser_m_valid : 1'b0;
assign m_last = parser_m_last;

assign m_src_ip = src_ip_hold_reg;
assign m_src_port = src_port_hold_reg;
assign m_dst_port = dst_port_hold_reg;
assign m_payload_len = payload_len_hold_reg;

always @(posedge clk) begin
    if (rst) begin
        state_reg <= ST_RECV;
        n_reg <= 10'd0;
        oversize_reg <= 1'b0;
        ptr_reg <= 10'd20;
        status_valid_reg <= 1'b0;
        status_error_reg <= 4'd0;
        ip_total_length_reg <= 16'd0;
        udp_length_reg <= 16'd0;
        payload_len_reg <= 16'd0;
        error_code_reg <= 4'd0;
        src_ip_hold_reg <= 32'd0;
        src_port_hold_reg <= 16'd0;
        dst_port_hold_reg <= 16'd0;
        payload_len_hold_reg <= 16'd0;
    end else begin
        status_valid_reg <= 1'b0;

        case (state_reg)
            ST_RECV: begin
                if (s_valid && s_ready) begin
                    if (!oversize_reg && n_reg < 10'd512) begin
                        bytes[n_reg] <= s_data;
                    end
                    if (!oversize_reg && n_reg == 10'd511 && !s_last) begin
                        oversize_reg <= 1'b1;
                    end
                    if (!oversize_reg && n_reg < 10'd512) begin
                        n_reg <= n_reg + 10'd1;
                    end

                    if (s_last) begin
                        if (!oversize_reg && n_reg < 10'd512) begin
                            ip_total_length_reg <= b_word_2;
                            udp_length_reg <= b_word_24;
                            payload_len_reg <= b_word_24 - 16'd8;
                        end
                        state_reg <= ST_STATUS;
                    end
                end
            end

            ST_STATUS: begin
                status_valid_reg <= 1'b1;
                status_error_reg <= error_code_int[3:0];
                error_code_reg <= error_code_int[3:0];

                if (error_code_int == 0) begin
                    src_ip_hold_reg <= parser_src_ip;
                    src_port_hold_reg <= parser_src_port;
                    dst_port_hold_reg <= parser_dst_port;
                    payload_len_hold_reg <= payload_len_reg;
                    ptr_reg <= 10'd20;
                    state_reg <= ST_HDR;
                end else begin
                    n_reg <= 10'd0;
                    oversize_reg <= 1'b0;
                    ptr_reg <= 10'd20;
                    ip_total_length_reg <= 16'd0;
                    udp_length_reg <= 16'd0;
                    payload_len_reg <= 16'd0;
                    state_reg <= ST_RECV;
                end
            end

            ST_HDR: begin
                src_ip_hold_reg <= parser_src_ip;
                src_port_hold_reg <= parser_src_port;
                dst_port_hold_reg <= parser_dst_port;
                payload_len_hold_reg <= payload_len_reg;
                if (parser_hdr_ready) begin
                    state_reg <= ST_PAYLOAD_IN;
                end
            end

            ST_PAYLOAD_IN: begin
                src_ip_hold_reg <= parser_src_ip;
                src_port_hold_reg <= parser_src_port;
                dst_port_hold_reg <= parser_dst_port;
                payload_len_hold_reg <= payload_len_reg;
                if (parser_payload_ready) begin
                    if (ptr_reg == n_reg - 1) begin
                        state_reg <= ST_DRAIN;
                    end else begin
                        ptr_reg <= ptr_reg + 10'd1;
                    end
                end
            end

            ST_DRAIN: begin
                if (parser_m_valid && m_ready && parser_m_last) begin
                    n_reg <= 10'd0;
                    oversize_reg <= 1'b0;
                    ptr_reg <= 10'd20;
                    ip_total_length_reg <= 16'd0;
                    udp_length_reg <= 16'd0;
                    payload_len_reg <= 16'd0;
                    state_reg <= ST_RECV;
                end
            end

            default: begin
                state_reg <= ST_RECV;
            end
        endcase
    end
end

udp_ip_rx parser(
    .clk(clk),
    .rst(rst),

    .s_ip_hdr_valid(state_reg == ST_HDR),
    .s_ip_hdr_ready(parser_hdr_ready),

    .s_eth_dest_mac(48'd0),
    .s_eth_src_mac(48'd0),
    .s_eth_type(16'h0800),

    .s_ip_version(bytes[0][7:4]),
    .s_ip_ihl(bytes[0][3:0]),
    .s_ip_dscp(bytes[1][7:2]),
    .s_ip_ecn(bytes[1][1:0]),
    .s_ip_length({bytes[2], bytes[3]}),
    .s_ip_identification({bytes[4], bytes[5]}),
    .s_ip_flags(bytes[6][7:5]),
    .s_ip_fragment_offset({bytes[6][4:0], bytes[7]}),
    .s_ip_ttl(bytes[8]),
    .s_ip_protocol(bytes[9]),
    .s_ip_header_checksum({bytes[10], bytes[11]}),
    .s_ip_source_ip({bytes[12], bytes[13], bytes[14], bytes[15]}),
    .s_ip_dest_ip({bytes[16], bytes[17], bytes[18], bytes[19]}),

    .s_ip_payload_axis_tdata(bytes[ptr_reg]),
    .s_ip_payload_axis_tvalid(state_reg == ST_PAYLOAD_IN),
    .s_ip_payload_axis_tready(parser_payload_ready),
    .s_ip_payload_axis_tlast(ptr_reg == n_reg - 1),
    .s_ip_payload_axis_tuser(1'b0),

    .m_udp_hdr_ready(1'b1),
    .m_udp_hdr_valid(),
    .m_eth_dest_mac(),
    .m_eth_src_mac(),
    .m_eth_type(),
    .m_ip_version(),
    .m_ip_ihl(),
    .m_ip_dscp(),
    .m_ip_ecn(),
    .m_ip_length(),
    .m_ip_identification(),
    .m_ip_flags(),
    .m_ip_fragment_offset(),
    .m_ip_ttl(),
    .m_ip_protocol(),
    .m_ip_header_checksum(),
    .m_ip_source_ip(parser_src_ip),
    .m_ip_dest_ip(),
    .m_udp_source_port(parser_src_port),
    .m_udp_dest_port(parser_dst_port),
    .m_udp_length(parser_udp_length),
    .m_udp_checksum(),

    .m_udp_payload_axis_tdata(parser_m_data),
    .m_udp_payload_axis_tvalid(parser_m_valid),
    .m_udp_payload_axis_tready((state_reg == ST_DRAIN) ? m_ready : 1'b0),
    .m_udp_payload_axis_tlast(parser_m_last),
    .m_udp_payload_axis_tuser()
);

endmodule
`default_nettype wire
