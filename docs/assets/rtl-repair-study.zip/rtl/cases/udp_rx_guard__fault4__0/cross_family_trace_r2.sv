`timescale 1ns / 1ps
`default_nettype none

module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

reg [7:0] buf[0:511];

localparam ST_IDLE   = 3'd0;
localparam ST_RECV   = 3'd1;
localparam ST_STATUS = 3'd2;
localparam ST_OUT    = 3'd3;

reg [2:0] state;
reg [9:0] byte_cnt;
reg [9:0] out_ptr;
reg oversize;

reg status_valid_r;
reg [3:0] status_error_r;

reg [31:0] hold_src_ip;
reg [15:0] hold_src_port;
reg [15:0] hold_dst_port;
reg [15:0] hold_payload_len;

reg [15:0] ip_total_length;
reg [15:0] udp_length;

wire [7:0] b0  = (byte_cnt > 10'd0)  ? buf[0]  : 8'd0;
wire [7:0] b1  = (byte_cnt > 10'd1)  ? buf[1]  : 8'd0;
wire [7:0] b2  = (byte_cnt > 10'd2)  ? buf[2]  : 8'd0;
wire [7:0] b3  = (byte_cnt > 10'd3)  ? buf[3]  : 8'd0;
wire [7:0] b4  = (byte_cnt > 10'd4)  ? buf[4]  : 8'd0;
wire [7:0] b5  = (byte_cnt > 10'd5)  ? buf[5]  : 8'd0;
wire [7:0] b6  = (byte_cnt > 10'd6)  ? buf[6]  : 8'd0;
wire [7:0] b7  = (byte_cnt > 10'd7)  ? buf[7]  : 8'd0;
wire [7:0] b8  = (byte_cnt > 10'd8)  ? buf[8]  : 8'd0;
wire [7:0] b9  = (byte_cnt > 10'd9)  ? buf[9]  : 8'd0;
wire [7:0] b10 = (byte_cnt > 10'd10) ? buf[10] : 8'd0;
wire [7:0] b11 = (byte_cnt > 10'd11) ? buf[11] : 8'd0;
wire [7:0] b12 = (byte_cnt > 10'd12) ? buf[12] : 8'd0;
wire [7:0] b13 = (byte_cnt > 10'd13) ? buf[13] : 8'd0;
wire [7:0] b14 = (byte_cnt > 10'd14) ? buf[14] : 8'd0;
wire [7:0] b15 = (byte_cnt > 10'd15) ? buf[15] : 8'd0;
wire [7:0] b16 = (byte_cnt > 10'd16) ? buf[16] : 8'd0;
wire [7:0] b17 = (byte_cnt > 10'd17) ? buf[17] : 8'd0;
wire [7:0] b18 = (byte_cnt > 10'd18) ? buf[18] : 8'd0;
wire [7:0] b19 = (byte_cnt > 10'd19) ? buf[19] : 8'd0;
wire [7:0] b20 = (byte_cnt > 10'd20) ? buf[20] : 8'd0;
wire [7:0] b21 = (byte_cnt > 10'd21) ? buf[21] : 8'd0;
wire [7:0] b22 = (byte_cnt > 10'd22) ? buf[22] : 8'd0;
wire [7:0] b23 = (byte_cnt > 10'd23) ? buf[23] : 8'd0;
wire [7:0] b24 = (byte_cnt > 10'd24) ? buf[24] : 8'd0;
wire [7:0] b25 = (byte_cnt > 10'd25) ? buf[25] : 8'd0;
wire [7:0] b26 = (byte_cnt > 10'd26) ? buf[26] : 8'd0;
wire [7:0] b27 = (byte_cnt > 10'd27) ? buf[27] : 8'd0;

wire [15:0] w2  = {b2,  b3};
wire [15:0] w4  = {b4,  b5};
wire [15:0] w6  = {b6,  b7};
wire [15:0] w10 = {b10, b11};
wire [15:0] w12 = {b12, b13};
wire [15:0] w14 = {b14, b15};
wire [15:0] w16 = {b16, b17};
wire [15:0] w18 = {b18, b19};
wire [15:0] w20 = {b20, b21};
wire [15:0] w22 = {b22, b23};
wire [15:0] w24 = {b24, b25};
wire [15:0] w26 = {b26, b27};

wire [31:0] dst_ip_w = {b16, b17, b18, b19};
wire [31:0] src_ip_w = {b12, b13, b14, b15};

integer ec;
integer ip_s;
integer udp_s;
integer ii;
integer alen;
integer iplen;
integer udplen;
integer plen;

always @* begin
    alen  = byte_cnt;
    iplen = w2;
    udplen= w24;
    plen  = udplen - 16'd8;
    ec    = 0;

    if (alen < 28 || oversize || b0[7:4] != 4'd4 || b0[3:0] != 4'd5 || b9 != 8'd17 || b6[5] || {b6[4:0], b7} != 13'd0)
        ec = 1;
    else if (iplen != alen || udplen != (iplen - 16'd20) || plen < 1 || plen > 256)
        ec = 2;
    else begin
        ip_s = 0;
        ip_s = ip_s + {b0, b1};
        ip_s = ip_s + w2;
        ip_s = ip_s + w4;
        ip_s = ip_s + w6;
        ip_s = ip_s + {b8, b9};
        ip_s = ip_s + w10;
        ip_s = ip_s + w12;
        ip_s = ip_s + w14;
        ip_s = ip_s + w16;
        ip_s = ip_s + w18;
        ip_s = (ip_s & 16'hffff) + (ip_s >> 16);
        ip_s = (ip_s & 16'hffff) + (ip_s >> 16);
        if ((ip_s & 16'hffff) != 16'hffff)
            ec = 3;
        else begin
            if (w26 != 16'h0000) begin
                udp_s = 0;
                udp_s = udp_s + w12;
                udp_s = udp_s + w14;
                udp_s = udp_s + w16;
                udp_s = udp_s + w18;
                udp_s = udp_s + 16'h0011;
                udp_s = udp_s + udplen;
                for (ii = 20; ii < 512; ii = ii + 2) begin
                    if (ii < alen) begin
                        if (ii + 1 < alen)
                            udp_s = udp_s + {buf[ii], buf[ii+1]};
                        else
                            udp_s = udp_s + {buf[ii], 8'h00};
                    end
                end
                udp_s = (udp_s & 16'hffff) + (udp_s >> 16);
                udp_s = (udp_s & 16'hffff) + (udp_s >> 16);
                udp_s = (udp_s & 16'hffff) + (udp_s >> 16);
                if ((udp_s & 16'hffff) != 16'hffff)
                    ec = 4;
                else if (dst_ip_w != 32'h0a000002 || w22 != 16'd9000)
                    ec = 5;
            end else begin
                if (dst_ip_w != 32'h0a000002 || w22 != 16'd9000)
                    ec = 5;
            end
        end
    end
end

assign s_ready      = (state == ST_RECV);
assign status_valid = status_valid_r;
assign status_error = status_error_r;

assign m_data        = (state == ST_OUT) ? buf[out_ptr] : 8'd0;
assign m_valid       = (state == ST_OUT);
assign m_last        = (state == ST_OUT) && (out_ptr == byte_cnt - 10'd1);
assign m_src_ip      = hold_src_ip;
assign m_src_port    = hold_src_port;
assign m_dst_port    = hold_dst_port;
assign m_payload_len = hold_payload_len;

always @(posedge clk) begin
    if (rst) begin
        state          <= ST_IDLE;
        byte_cnt       <= 10'd0;
        out_ptr        <= 10'd0;
        oversize       <= 1'b0;
        status_valid_r <= 1'b0;
        status_error_r <= 4'd0;
        hold_src_ip    <= 32'd0;
        hold_src_port  <= 16'd0;
        hold_dst_port  <= 16'd0;
        hold_payload_len<=16'd0;
        ip_total_length<= 16'd0;
        udp_length     <= 16'd0;
    end else begin
        status_valid_r <= 1'b0;

        case (state)
            ST_IDLE: begin
                byte_cnt <= 10'd0;
                oversize <= 1'b0;
                state    <= ST_RECV;
            end

            ST_RECV: begin
                if (s_valid && s_ready) begin
                    if (!oversize && byte_cnt < 10'd512)
                        buf[byte_cnt] <= s_data;
                    if (!oversize && byte_cnt == 10'd511 && !s_last)
                        oversize <= 1'b1;
                    if (!oversize && byte_cnt < 10'd512)
                        byte_cnt <= byte_cnt + 10'd1;
                    if (s_last) begin
                        ip_total_length <= w2;
                        udp_length    <= w24;
                        state         <= ST_STATUS;
                    end
                end
            end

            ST_STATUS: begin
                status_valid_r <= 1'b1;
                status_error_r <= ec[3:0];
                if (ec == 0) begin
                    hold_src_ip     <= src_ip_w;
                    hold_src_port   <= w20;
                    hold_dst_port   <= w22;
                    hold_payload_len<= udp_length - 16'd8;
                    out_ptr         <= 10'd20;
                    state           <= ST_OUT;
                end else begin
                    state <= ST_IDLE;
                end
            end

            ST_OUT: begin
                if (m_valid && m_ready) begin
                    if (m_last)
                        state <= ST_IDLE;
                    else
                        out_ptr <= out_ptr + 10'd1;
                end
            end

            default: state <= ST_IDLE;
        endcase
    end
end

endmodule
`default_nettype wire
