module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

reg [7:0] bytes[0:511];

localparam [2:0]
    ST_IDLE      = 3'd0,
    ST_RECV      = 3'd1,
    ST_STATUS    = 3'd2,
    ST_SEND_HDR  = 3'd3,
    ST_SEND_PAY  = 3'd4;

reg [2:0] state_reg = ST_IDLE;

reg [9:0] rx_count_reg = 10'd0;
reg [9:0] frame_len_reg = 10'd0;
reg oversize_reg = 1'b0;

reg [9:0] send_ptr_reg = 10'd0;

reg status_valid_reg = 1'b0;
reg [3:0] status_error_reg = 4'd0;

reg [31:0] src_ip_reg = 32'd0;
reg [15:0] src_port_reg = 16'd0;
reg [15:0] dst_port_reg = 16'd0;
reg [15:0] payload_len_reg = 16'd0;

wire parser_hdr_ready;
wire parser_payload_ready;
wire [31:0] parser_src_ip;
wire [15:0] parser_src_port;
wire [15:0] parser_dst_port;
wire [15:0] parser_udp_length;
wire [7:0] parser_m_data;
wire parser_m_valid;
wire parser_m_last;

function automatic [15:0] get_word16;
    input integer offset;
    begin
        get_word16 = {bytes[offset], bytes[offset+1]};
    end
endfunction

function automatic [16:0] fold17;
    input [31:0] sum;
    reg [31:0] t;
    begin
        t = sum;
        t = (t[15:0] + t[31:16]);
        t = (t[15:0] + t[31:16]);
        fold17 = t[16:0];
    end
endfunction

reg [3:0] computed_error;
reg [15:0] ip_total_len;
reg [15:0] udp_len_chk;
reg [15:0] udp_payload_len_chk;
reg [31:0] ip_sum_acc;
reg [31:0] udp_sum_acc;
reg [16:0] ip_folded;
reg [16:0] udp_folded;
integer j;

always @* begin
    computed_error = 4'd0;
    ip_total_len = 16'd0;
    udp_len_chk = 16'd0;
    udp_payload_len_chk = 16'd0;
    ip_sum_acc = 32'd0;
    udp_sum_acc = 32'd0;
    ip_folded = 17'd0;
    udp_folded = 17'd0;

    if (frame_len_reg >= 4)
        ip_total_len = get_word16(2);
    if (frame_len_reg >= 26)
        udp_len_chk = get_word16(24);
    if (udp_len_chk >= 16'd8)
        udp_payload_len_chk = udp_len_chk - 16'd8;
    else
        udp_payload_len_chk = 16'd0;

    if (frame_len_reg < 10'd28 ||
        frame_len_reg > 10'd512 ||
        bytes[0][7:4] != 4'd4 ||
        bytes[0][3:0] != 4'd5 ||
        bytes[9] != 8'd17 ||
        bytes[6][5] != 1'b1 ||
        bytes[6][6] != 1'b0 ||
        bytes[6][4:0] != 5'd0 ||
        bytes[7] != 8'd0 ||
        oversize_reg) begin
        computed_error = 4'd1;
    end else begin
        if (ip_total_len != frame_len_reg ||
            udp_len_chk != (ip_total_len - 16'd20) ||
            udp_payload_len_chk < 16'd1 ||
            udp_payload_len_chk > 16'd256) begin
            computed_error = 4'd2;
        end else begin
            ip_sum_acc = 32'd0;
            for (j = 0; j < 20; j = j + 2)
                ip_sum_acc = ip_sum_acc + get_word16(j);
            ip_folded = fold17(ip_sum_acc);
            if (ip_folded != 17'h0ffff) begin
                computed_error = 4'd3;
            end else begin
                udp_sum_acc = 32'd0;
                udp_sum_acc = udp_sum_acc + get_word16(12);
                udp_sum_acc = udp_sum_acc + get_word16(14);
                udp_sum_acc = udp_sum_acc + get_word16(16);
                udp_sum_acc = udp_sum_acc + get_word16(18);
                udp_sum_acc = udp_sum_acc + 16'h0011;
                udp_sum_acc = udp_sum_acc + udp_len_chk;

                for (j = 20; j < 512; j = j + 2) begin
                    if (j < (20 + udp_len_chk)) begin
                        udp_sum_acc = udp_sum_acc + {bytes[j], ((j+1) < (20 + udp_len_chk)) ? bytes[j+1] : 8'h00};
                    end
                end

                udp_folded = fold17(udp_sum_acc);

                if (get_word16(26) != 16'h0000 && udp_folded != 17'h0ffff) begin
                    computed_error = 4'd4;
                end else begin
                    if ({bytes[16], bytes[17], bytes[18], bytes[19]} != 32'h0a000002 ||
                        get_word16(22) != 16'd9000) begin
                        computed_error = 4'd5;
                    end
                end
            end
        end
    end
end

assign s_ready = !rst && ((state_reg == ST_IDLE) || (state_reg == ST_RECV));

assign status_valid = status_valid_reg;
assign status_error = status_error_reg;

assign m_data = parser_m_data;
assign m_valid = (state_reg == ST_SEND_PAY) ? parser_m_valid : 1'b0;
assign m_last = parser_m_last;

assign m_src_ip = src_ip_reg;
assign m_src_port = src_port_reg;
assign m_dst_port = dst_port_reg;
assign m_payload_len = payload_len_reg;

always @(posedge clk) begin
    if (rst) begin
        state_reg <= ST_IDLE;
        rx_count_reg <= 10'd0;
        frame_len_reg <= 10'd0;
        oversize_reg <= 1'b0;
        send_ptr_reg <= 10'd0;
        status_valid_reg <= 1'b0;
        status_error_reg <= 4'd0;
        src_ip_reg <= 32'd0;
        src_port_reg <= 16'd0;
        dst_port_reg <= 16'd0;
        payload_len_reg <= 16'd0;
    end else begin
        status_valid_reg <= 1'b0;

        case (state_reg)
            ST_IDLE: begin
                rx_count_reg <= 10'd0;
                frame_len_reg <= 10'd0;
                oversize_reg <= 1'b0;
                send_ptr_reg <= 10'd0;
                if (s_valid) begin
                    if (10'd0 < 10'd512)
                        bytes[0] <= s_data;
                    rx_count_reg <= 10'd1;
                    if (s_last) begin
                        frame_len_reg <= 10'd1;
                        state_reg <= ST_STATUS;
                    end else begin
                        state_reg <= ST_RECV;
                    end
                end
            end

            ST_RECV: begin
                if (s_valid) begin
                    if (rx_count_reg < 10'd512)
                        bytes[rx_count_reg] <= s_data;
                    else
                        oversize_reg <= 1'b1;

                    if (s_last) begin
                        frame_len_reg <= rx_count_reg + 10'd1;
                        if (rx_count_reg >= 10'd512)
                            oversize_reg <= 1'b1;
                        state_reg <= ST_STATUS;
                    end
                    rx_count_reg <= rx_count_reg + 10'd1;
                end
            end

            ST_STATUS: begin
                status_valid_reg <= 1'b1;
                status_error_reg <= computed_error;
                if (computed_error == 4'd0) begin
                    src_ip_reg <= {bytes[12], bytes[13], bytes[14], bytes[15]};
                    src_port_reg <= get_word16(20);
                    dst_port_reg <= get_word16(22);
                    payload_len_reg <= get_word16(24) - 16'd8;
                    send_ptr_reg <= 10'd20;
                    state_reg <= ST_SEND_HDR;
                end else begin
                    state_reg <= ST_IDLE;
                end
            end

            ST_SEND_HDR: begin
                if (parser_hdr_ready) begin
                    send_ptr_reg <= 10'd20;
                    state_reg <= ST_SEND_PAY;
                end
            end

            ST_SEND_PAY: begin
                if (parser_payload_ready) begin
                    if (send_ptr_reg == frame_len_reg - 10'd1) begin
                        state_reg <= ST_IDLE;
                        rx_count_reg <= 10'd0;
                        frame_len_reg <= 10'd0;
                        send_ptr_reg <= 10'd0;
                    end else begin
                        send_ptr_reg <= send_ptr_reg + 10'd1;
                    end
                end
            end

            default: begin
                state_reg <= ST_IDLE;
            end
        endcase
    end
end

udp_ip_rx parser (
    .clk(clk),
    .rst(rst),

    .s_ip_hdr_valid(state_reg == ST_SEND_HDR),
    .s_ip_hdr_ready(parser_hdr_ready),

    .s_eth_dest_mac(48'd0),
    .s_eth_src_mac(48'd0),
    .s_eth_type(16'h0800),

    .s_ip_version(bytes[0][7:4]),
    .s_ip_ihl(bytes[0][3:0]),
    .s_ip_dscp(bytes[1][7:2]),
    .s_ip_ecn(bytes[1][1:0]),
    .s_ip_length({bytes[2], bytes[3]}),
    .s_ip_identification({bytes[4], bytes[5]}),
    .s_ip_flags(bytes[6][7:5]),
    .s_ip_fragment_offset({bytes[6][4:0], bytes[7]}),
    .s_ip_ttl(bytes[8]),
    .s_ip_protocol(bytes[9]),
    .s_ip_header_checksum({bytes[10], bytes[11]}),
    .s_ip_source_ip({bytes[12], bytes[13], bytes[14], bytes[15]}),
    .s_ip_dest_ip({bytes[16], bytes[17], bytes[18], bytes[19]}),

    .s_ip_payload_axis_tdata(bytes[send_ptr_reg]),
    .s_ip_payload_axis_tvalid(state_reg == ST_SEND_PAY),
    .s_ip_payload_axis_tready(parser_payload_ready),
    .s_ip_payload_axis_tlast(send_ptr_reg == frame_len_reg - 10'd1),
    .s_ip_payload_axis_tuser(1'b0),

    .m_udp_hdr_ready(1'b1),

    .m_eth_dest_mac(),
    .m_eth_src_mac(),
    .m_eth_type(),
    .m_ip_version(),
    .m_ip_ihl(),
    .m_ip_dscp(),
    .m_ip_ecn(),
    .m_ip_length(),
    .m_ip_identification(),
    .m_ip_flags(),
    .m_ip_fragment_offset(),
    .m_ip_ttl(),
    .m_ip_protocol(),
    .m_ip_header_checksum(),
    .m_ip_source_ip(parser_src_ip),
    .m_ip_dest_ip(),
    .m_udp_source_port(parser_src_port),
    .m_udp_dest_port(parser_dst_port),
    .m_udp_length(parser_udp_length),
    .m_udp_checksum(),
    .m_udp_payload_axis_tdata(parser_m_data),
    .m_udp_payload_axis_tvalid(parser_m_valid),
    .m_udp_payload_axis_tready(m_ready),
    .m_udp_payload_axis_tlast(parser_m_last),
    .m_udp_payload_axis_tuser()
);

endmodule
