module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error
);

reg [7:0] buf_mem[0:511];

localparam [1:0]
    ST_IDLE   = 2'd0,
    ST_RECV   = 2'd1,
    ST_STATUS = 2'd2,
    ST_SEND   = 2'd3;

reg [1:0] state_reg;

reg [9:0] rx_len_reg;
reg oversize_reg;

reg [3:0] status_error_reg;
reg status_valid_reg;

reg [31:0] src_ip_reg;
reg [15:0] src_port_reg;
reg [15:0] dst_port_reg;
reg [15:0] payload_len_reg;

reg [9:0] out_ptr_reg;
reg [9:0] out_end_reg;
reg out_valid_reg;
reg [7:0] out_data_reg;
reg out_last_reg;

reg parser_hdr_valid_reg;
reg parser_payload_valid_reg;
reg parser_payload_last_reg;
reg [7:0] parser_payload_data_reg;
reg parser_active_reg;

wire parser_hdr_ready;
wire parser_payload_ready;

wire [31:0] p_src_ip;
wire [15:0] p_src_port;
wire [15:0] p_dst_port;
wire [15:0] p_udp_length;
wire [7:0] p_tdata;
wire p_tvalid;
wire p_tlast;

function automatic [15:0] rd16;
    input integer idx;
    begin
        rd16 = {buf_mem[idx], buf_mem[idx+1]};
    end
endfunction

function automatic [31:0] rd32;
    input integer idx;
    begin
        rd32 = {buf_mem[idx], buf_mem[idx+1], buf_mem[idx+2], buf_mem[idx+3]};
    end
endfunction

function automatic [15:0] fold16;
    input [31:0] sum;
    reg [31:0] t;
    begin
        t = sum;
        t = (t[15:0] + t[31:16]);
        t = (t[15:0] + t[31:16]);
        t = (t[15:0] + t[31:16]);
        fold16 = t[15:0];
    end
endfunction

reg [3:0] computed_error;
reg [15:0] ip_total_len;
reg [15:0] udp_len;
reg [15:0] udp_payload_len;
reg [31:0] sum_ip;
reg [31:0] sum_udp;
reg [15:0] folded_ip;
reg [15:0] folded_udp;
integer i;

always @* begin
    computed_error = 4'd0;
    ip_total_len = 16'd0;
    udp_len = 16'd0;
    udp_payload_len = 16'd0;
    sum_ip = 32'd0;
    sum_udp = 32'd0;
    folded_ip = 16'd0;
    folded_udp = 16'd0;

    if (rx_len_reg >= 10'd4)
        ip_total_len = rd16(2);
    if (rx_len_reg >= 10'd26)
        udp_len = rd16(24);
    if (udp_len >= 16'd8)
        udp_payload_len = udp_len - 16'd8;

    if (rx_len_reg < 10'd28 ||
        oversize_reg ||
        buf_mem[0][7:4] != 4'd4 ||
        buf_mem[0][3:0] != 4'd5 ||
        buf_mem[9] != 8'd17 ||
        buf_mem[6][5] != 1'b0 ||
        {buf_mem[6][4:0], buf_mem[7]} != 13'd0) begin
        computed_error = 4'd1;
    end else if (ip_total_len != rx_len_reg ||
                 udp_len != (ip_total_len - 16'd20) ||
                 udp_payload_len < 16'd1 ||
                 udp_payload_len > 16'd256) begin
        computed_error = 4'd2;
    end else begin
        sum_ip = 32'd0;
        for (i = 0; i < 20; i = i + 2)
            sum_ip = sum_ip + rd16(i);
        folded_ip = fold16(sum_ip);
        if (folded_ip != 16'hffff) begin
            computed_error = 4'd3;
        end else begin
            if (rd16(26) != 16'h0000) begin
                sum_udp = 32'd0;
                sum_udp = sum_udp + rd16(12);
                sum_udp = sum_udp + rd16(14);
                sum_udp = sum_udp + rd16(16);
                sum_udp = sum_udp + rd16(18);
                sum_udp = sum_udp + 16'h0011;
                sum_udp = sum_udp + udp_len;
                for (i = 20; i < (20 + udp_len); i = i + 2) begin
                    if (i + 1 < (20 + udp_len))
                        sum_udp = sum_udp + {buf_mem[i], buf_mem[i+1]};
                    else
                        sum_udp = sum_udp + {buf_mem[i], 8'h00};
                end
                folded_udp = fold16(sum_udp);
                if (folded_udp != 16'hffff)
                    computed_error = 4'd4;
            end
            if (computed_error == 4'd0 &&
                (rd32(16) != 32'h0a000002 || rd16(22) != 16'd9000))
                computed_error = 4'd5;
        end
    end
end

assign s_ready = !rst && (state_reg == ST_IDLE || state_reg == ST_RECV);

assign m_data = out_data_reg;
assign m_valid = out_valid_reg;
assign m_last = out_last_reg;
assign m_src_ip = src_ip_reg;
assign m_src_port = src_port_reg;
assign m_dst_port = dst_port_reg;
assign m_payload_len = payload_len_reg;
assign status_valid = status_valid_reg;
assign status_error = status_error_reg;

always @(posedge clk) begin
    if (rst) begin
        state_reg <= ST_IDLE;
        rx_len_reg <= 10'd0;
        oversize_reg <= 1'b0;
        status_error_reg <= 4'd0;
        status_valid_reg <= 1'b0;
        src_ip_reg <= 32'd0;
        src_port_reg <= 16'd0;
        dst_port_reg <= 16'd0;
        payload_len_reg <= 16'd0;
        out_ptr_reg <= 10'd0;
        out_end_reg <= 10'd0;
        out_valid_reg <= 1'b0;
        out_data_reg <= 8'd0;
        out_last_reg <= 1'b0;
        parser_hdr_valid_reg <= 1'b0;
        parser_payload_valid_reg <= 1'b0;
        parser_payload_last_reg <= 1'b0;
        parser_payload_data_reg <= 8'd0;
        parser_active_reg <= 1'b0;
    end else begin
        status_valid_reg <= 1'b0;

        if (out_valid_reg && m_ready)
            out_valid_reg <= 1'b0;

        parser_hdr_valid_reg <= 1'b0;
        parser_payload_valid_reg <= 1'b0;

        case (state_reg)
            ST_IDLE: begin
                rx_len_reg <= 10'd0;
                oversize_reg <= 1'b0;
                if (s_valid) begin
                    if (s_last) begin
                        buf_mem[0] <= s_data;
                        rx_len_reg <= 10'd1;
                        state_reg <= ST_STATUS;
                    end else begin
                        buf_mem[0] <= s_data;
                        rx_len_reg <= 10'd1;
                        state_reg <= ST_RECV;
                    end
                end
            end

            ST_RECV: begin
                if (s_valid) begin
                    if (rx_len_reg < 10'd512)
                        buf_mem[rx_len_reg] <= s_data;
                    else
                        oversize_reg <= 1'b1;

                    if (s_last) begin
                        if (rx_len_reg >= 10'd512)
                            oversize_reg <= 1'b1;
                        rx_len_reg <= rx_len_reg + 10'd1;
                        state_reg <= ST_STATUS;
                    end else begin
                        rx_len_reg <= rx_len_reg + 10'd1;
                    end
                end
            end

            ST_STATUS: begin
                status_valid_reg <= 1'b1;
                status_error_reg <= computed_error;
                if (computed_error == 4'd0) begin
                    src_ip_reg <= rd32(12);
                    src_port_reg <= rd16(20);
                    dst_port_reg <= rd16(22);
                    payload_len_reg <= rd16(24) - 16'd8;
                    out_ptr_reg <= 10'd20;
                    out_end_reg <= rx_len_reg;
                    parser_active_reg <= 1'b0;
                    state_reg <= ST_SEND;
                end else begin
                    state_reg <= ST_IDLE;
                end
            end

            ST_SEND: begin
                if (!parser_active_reg) begin
                    parser_hdr_valid_reg <= 1'b1;
                    if (parser_hdr_ready) begin
                        parser_active_reg <= 1'b1;
                        out_ptr_reg <= 10'd20;
                    end
                end else begin
                    if (out_ptr_reg < out_end_reg) begin
                        parser_payload_valid_reg <= 1'b1;
                        parser_payload_data_reg <= buf_mem[out_ptr_reg];
                        parser_payload_last_reg <= (out_ptr_reg == out_end_reg-10'd1);
                        if (parser_payload_ready) begin
                            out_ptr_reg <= out_ptr_reg + 10'd1;
                            if (out_ptr_reg == out_end_reg-10'd1) begin
                                parser_active_reg <= 1'b0;
                                state_reg <= ST_IDLE;
                            end
                        end
                    end
                end

                if (!out_valid_reg && p_tvalid) begin
                    out_valid_reg <= 1'b1;
                    out_data_reg <= p_tdata;
                    out_last_reg <= p_tlast;
                end
            end

            default: begin
                state_reg <= ST_IDLE;
            end
        endcase
    end
end

udp_ip_rx parser_inst (
    .clk(clk),
    .rst(rst),

    .s_ip_hdr_valid(parser_hdr_valid_reg),
    .s_ip_hdr_ready(parser_hdr_ready),

    .s_eth_dest_mac(48'd0),
    .s_eth_src_mac(48'd0),
    .s_eth_type(16'h0800),

    .s_ip_version(buf_mem[0][7:4]),
    .s_ip_ihl(buf_mem[0][3:0]),
    .s_ip_dscp(buf_mem[1][7:2]),
    .s_ip_ecn(buf_mem[1][1:0]),
    .s_ip_length(rd16(2)),
    .s_ip_identification(rd16(4)),
    .s_ip_flags(buf_mem[6][7:5]),
    .s_ip_fragment_offset({buf_mem[6][4:0], buf_mem[7]}),
    .s_ip_ttl(buf_mem[8]),
    .s_ip_protocol(buf_mem[9]),
    .s_ip_header_checksum(rd16(10)),
    .s_ip_source_ip(rd32(12)),
    .s_ip_dest_ip(rd32(16)),

    .s_ip_payload_axis_tdata(parser_payload_data_reg),
    .s_ip_payload_axis_tvalid(parser_payload_valid_reg),
    .s_ip_payload_axis_tready(parser_payload_ready),
    .s_ip_payload_axis_tlast(parser_payload_last_reg),
    .s_ip_payload_axis_tuser(1'b0),

    .m_udp_hdr_ready(1'b1),

    .m_eth_dest_mac(),
    .m_eth_src_mac(),
    .m_eth_type(),
    .m_ip_version(),
    .m_ip_ihl(),
    .m_ip_dscp(),
    .m_ip_ecn(),
    .m_ip_length(),
    .m_ip_identification(),
    .m_ip_flags(),
    .m_ip_fragment_offset(),
    .m_ip_ttl(),
    .m_ip_protocol(),
    .m_ip_header_checksum(),
    .m_ip_source_ip(p_src_ip),
    .m_ip_dest_ip(),
    .m_udp_source_port(p_src_port),
    .m_udp_dest_port(p_dst_port),
    .m_udp_length(p_udp_length),
    .m_udp_checksum(),
    .m_udp_payload_axis_tdata(p_tdata),
    .m_udp_payload_axis_tvalid(p_tvalid),
    .m_udp_payload_axis_tready(!out_valid_reg || m_ready),
    .m_udp_payload_axis_tlast(p_tlast),
    .m_udp_payload_axis_tuser()
);

endmodule
