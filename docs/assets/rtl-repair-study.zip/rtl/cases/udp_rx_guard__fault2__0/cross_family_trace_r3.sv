module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

// State encoding
localparam S_IDLE = 3'd0;
localparam S_RECV = 3'd1;
localparam S_CHECK = 3'd2;
localparam S_STATUS = 3'd3;
localparam S_OUTPUT = 3'd4;

reg [7:0] buf[0:511];
reg [9:0] byte_cnt;
reg [9:0] frame_len;
reg is_oversize;

reg [2:0] state;
reg [3:0] error_code;
reg status_v;

reg [31:0] src_ip_r;
reg [15:0] src_port_r;
reg [15:0] dst_port_r;
reg [15:0] payload_len_r;

reg [9:0] out_idx;
reg [9:0] out_end;

wire input_accepted = (state == S_IDLE) || (state == S_RECV);

assign s_ready = input_accepted;

assign status_valid = status_v;
assign status_error = error_code;

assign m_data   = buf[out_idx];
assign m_valid  = (state == S_OUTPUT) && (out_idx < out_end);
assign m_last   = (state == S_OUTPUT) && (out_idx == (out_end - 10'd1));
assign m_src_ip = src_ip_r;
assign m_src_port = src_port_r;
assign m_dst_port = dst_port_r;
assign m_payload_len = payload_len_r;

// Combinational functions for reading 16-bit words from buffer
function [15:0] word_at;
    input [9:0] addr;
    begin
        word_at = {buf[addr], buf[addr+10'd1]};
    end
endfunction

// Error check logic
reg [3:0] check_result;
reg [15:0] ip_total_len;
reg [15:0] udp_total_len;
reg [15:0] pay_len;
reg [31:0] ip_chk_acc;
reg [31:0] udp_chk_acc;
reg [16:0] ip_fold;
reg [16:0] udp_fold;
integer i;

always @* begin
    check_result = 4'd0;
    ip_total_len = 16'd0;
    udp_total_len = 16'd0;
    pay_len = 16'd0;
    ip_chk_acc = 32'd0;
    udp_chk_acc = 32'd0;
    ip_fold = 17'd0;
    udp_fold = 17'd0;

    if (frame_len >= 10'd4)
        ip_total_len = word_at(10'd2);
    if (frame_len >= 10'd26)
        udp_total_len = word_at(10'd24);
    if (udp_total_len >= 16'd8)
        pay_len = udp_total_len - 16'd8;

    // Error 1 checks: basic header sanity
    if (is_oversize || (frame_len < 10'd28) || (frame_len > 10'd512) ||
        (buf[0][7:4] != 4'd4) || (buf[0][3:0] != 4'd5) ||
        (buf[9] != 8'd17) || (buf[6][5] == 1'b1) || ({buf[6][4:0], buf[7]} != 13'd0))
        check_result = 4'd1;
    // Error 2 checks: length consistency
    else if ((ip_total_len != frame_len) || (udp_total_len != (ip_total_len - 16'd20)) ||
             (pay_len < 16'd1) || (pay_len > 16'd256))
        check_result = 4'd2;
    else begin
        // Error 3: IP header checksum
        ip_chk_acc = 32'd0;
        for (i = 0; i < 20; i = i + 2)
            ip_chk_acc = ip_chk_acc + {16'd0, word_at(i[9:0])};
        ip_fold = {1'b0, ip_chk_acc[15:0]} + {1'b0, ip_chk_acc[31:16]};
        ip_fold = {1'b0, ip_fold[15:0]} + {16'd0, ip_fold[16]};
        if (~ip_fold[15:0] != 16'd0)
            check_result = 4'd3;
        else begin
            // Error 4: UDP checksum (if non-zero)
            udp_chk_acc = 32'd0;
            // Pseudo-header: src IP (2 words)
            udp_chk_acc = udp_chk_acc + {16'd0, word_at(10'd12)};
            udp_chk_acc = udp_chk_acc + {16'd0, word_at(10'd14)};
            // dst IP (2 words)
            udp_chk_acc = udp_chk_acc + {16'd0, word_at(10'd16)};
            udp_chk_acc = udp_chk_acc + {16'd0, word_at(10'd18)};
            // zero, protocol
            udp_chk_acc = udp_chk_acc + 32'h0011;
            // UDP length
            udp_chk_acc = udp_chk_acc + {16'd0, udp_total_len};
            // UDP header + payload
            for (i = 20; i < 20 + udp_total_len; i = i + 2) begin
                if ((i + 1) < (20 + udp_total_len))
                    udp_chk_acc = udp_chk_acc + {16'd0, word_at(i[9:0])};
                else
                    udp_chk_acc = udp_chk_acc + {16'd0, buf[i], 8'd0};
            end
            udp_fold = {1'b0, udp_chk_acc[15:0]} + {1'b0, udp_chk_acc[31:16]};
            udp_fold = {1'b0, udp_fold[15:0]} + {16'd0, udp_fold[16]};
            if ((word_at(10'd26) != 16'd0) && (~udp_fold[15:0] != 16'd0))
                check_result = 4'd4;
            // Error 5: destination filter
            else if ((word_at(10'd16) != 16'h0A00) || (word_at(10'd18) != 16'h0002) || (word_at(10'd22) != 16'h2328))
                check_result = 4'd5;
        end
    end
end

always @(posedge clk) begin
    if (rst) begin
        state <= S_IDLE;
        byte_cnt <= 10'd0;
        frame_len <= 10'd0;
        is_oversize <= 1'b0;
        status_v <= 1'b0;
        error_code <= 4'd0;
    end else begin
        status_v <= 1'b0;
        case (state)
            S_IDLE: begin
                byte_cnt <= 10'd0;
                is_oversize <= 1'b0;
                if (s_valid && input_accepted) begin
                    buf[0] <= s_data;
                    byte_cnt <= 10'd1;
                    if (s_last) begin
                        frame_len <= 10'd1;
                        state <= S_CHECK;
                    end else begin
                        state <= S_RECV;
                    end
                end
            end
            S_RECV: begin
                if (s_valid && input_accepted) begin
                    if (byte_cnt < 10'd512)
                        buf[byte_cnt] <= s_data;
                    else
                        is_oversize <= 1'b1;
                    byte_cnt <= byte_cnt + 10'd1;
                    if (s_last) begin
                        frame_len <= byte_cnt + 10'd1;
                        if (byte_cnt >= 10'd512)
                            is_oversize <= 1'b1;
                        state <= S_CHECK;
                    end
                end
            end
            S_CHECK: begin
                state <= S_STATUS;
            end
            S_STATUS: begin
                status_v <= 1'b1;
                error_code <= check_result;
                if (check_result == 4'd0) begin
                    src_ip_r <= {buf[12], buf[13], buf[14], buf[15]};
                    src_port_r <= word_at(10'd20);
                    dst_port_r <= word_at(10'd22);
                    payload_len_r <= word_at(10'd24) - 16'd8;
                    out_idx <= 10'd28;
                    out_end <= frame_len;
                    state <= S_OUTPUT;
                end else begin
                    state <= S_IDLE;
                end
            end
            S_OUTPUT: begin
                if (m_valid && m_ready) begin
                    if (out_idx == (out_end - 10'd1))
                        state <= S_IDLE;
                    else
                        out_idx <= out_idx + 10'd1;
                end
            end
            default: state <= S_IDLE;
        endcase
    end
end

endmodule
