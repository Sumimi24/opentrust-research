module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

reg [7:0] buf [0:511];
reg [9:0] rx_cnt;
reg [9:0] frame_len;
reg oversize;

localparam S_IDLE=0, S_RECV=1, S_CHK=2, S_STAT=3, S_OUT=4;
reg [2:0] state;

reg [3:0] err_code;
reg stat_v;

reg [31:0] r_src_ip;
reg [15:0] r_sport;
reg [15:0] r_dport;
reg [15:0] r_plen;

reg [9:0] out_ptr;
reg [9:0] pay_end;

wire accept_in = (state == S_IDLE || state == S_RECV) && !rst;
assign s_ready = accept_in;

assign status_valid = stat_v;
assign status_error = err_code;

assign m_data = buf[out_ptr];
assign m_valid = (state == S_OUT) && (out_ptr < pay_end);
assign m_last = (out_ptr == pay_end - 10'd1);
assign m_src_ip = r_src_ip;
assign m_src_port = r_sport;
assign m_dst_port = r_dport;
assign m_payload_len = r_plen;

function automatic [15:0] rd16;
    input integer idx;
    begin
        rd16 = {buf[idx], buf[idx+1]};
    end
endfunction

reg [31:0] ip_acc;
reg [31:0] udp_acc;
reg [16:0] ip_f;
reg [16:0] udp_f;
integer i;
reg [15:0] ip_tot;
reg [15:0] udp_tot;
reg [15:0] udp_pay;
reg [3:0] chk_err;

always @* begin
    chk_err = 4'd0;
    ip_tot = 16'd0;
    udp_tot = 16'd0;
    udp_pay = 16'd0;
    ip_acc = 32'd0;
    udp_acc = 32'd0;
    ip_f = 17'd0;
    udp_f = 17'd0;

    if (frame_len >= 10'd4)
        ip_tot = rd16(2);
    if (frame_len >= 10'd26)
        udp_tot = rd16(24);
    udp_pay = (udp_tot >= 16'd8) ? (udp_tot - 16'd8) : 16'd0;

    if (oversize || frame_len < 10'd28 || frame_len > 10'd512 ||
        buf[0][7:4] != 4'd4 || buf[0][3:0] != 4'd5 ||
        buf[9] != 8'd17 || buf[6][5] || {buf[6][4:0], buf[7]} != 13'd0) begin
        chk_err = 4'd1;
    end else if (ip_tot != frame_len || udp_tot != (ip_tot - 16'd20) ||
               udp_pay < 16'd1 || udp_pay > 16'd256) begin
        chk_err = 4'd2;
    end else begin
        ip_acc = 32'd0;
        for (i = 0; i < 20; i = i + 2)
            ip_acc = ip_acc + rd16(i);
        ip_f = ip_acc[15:0] + ip_acc[31:16];
        ip_f = ip_f[15:0] + ip_f[16];
        if (ip_f != 17'hFFFF)
            chk_err = 4'd3;
        else begin
            udp_acc = 32'd0;
            udp_acc = udp_acc + rd16(12) + rd16(14) + rd16(16) + rd16(18);
            udp_acc = udp_acc + 32'h0011 + udp_tot;
            for (i = 20; i < 20 + udp_tot; i = i + 2) begin
                udp_acc = udp_acc + {buf[i], (i+1 < 20+udp_tot) ? buf[i+1] : 8'h00};
            end
            udp_f = udp_acc[15:0] + udp_acc[31:16];
            udp_f = udp_f[15:0] + udp_f[16];
            if (rd16(26) != 16'd0 && udp_f != 17'hFFFF)
                chk_err = 4'd4;
            else if ({buf[16],buf[17],buf[18],buf[19]} != 32'h0A000002 || rd16(22) != 16'd9000)
                chk_err = 4'd5;
        end
    end
end

always @(posedge clk) begin
    if (rst) begin
        state <= S_IDLE;
        rx_cnt <= 10'd0;
        frame_len <= 10'd0;
        oversize <= 1'b0;
        stat_v <= 1'b0;
        err_code <= 4'd0;
    end else begin
        stat_v <= 1'b0;
        case (state)
            S_IDLE: begin
                rx_cnt <= 10'd0;
                oversize <= 1'b0;
                if (s_valid && accept_in) begin
                    buf[0] <= s_data;
                    rx_cnt <= 10'd1;
                    if (s_last) begin
                        frame_len <= 10'd1;
                        state <= S_CHK;
                    end else begin
                        state <= S_RECV;
                    end
                end
            end
            S_RECV: begin
                if (s_valid && accept_in) begin
                    if (rx_cnt < 10'd512)
                        buf[rx_cnt] <= s_data;
                    else
                        oversize <= 1'b1;
                    rx_cnt <= rx_cnt + 10'd1;
                    if (s_last) begin
                        frame_len <= rx_cnt + 10'd1;
                        if (rx_cnt >= 10'd512) oversize <= 1'b1;
                        state <= S_CHK;
                    end
                end
            end
            S_CHK: begin
                state <= S_STAT;
            end
            S_STAT: begin
                stat_v <= 1'b1;
                err_code <= chk_err;
                if (chk_err == 4'd0) begin
                    r_src_ip <= {buf[12],buf[13],buf[14],buf[15]};
                    r_sport <= rd16(20);
                    r_dport <= rd16(22);
                    r_plen <= rd16(24) - 16'd8;
                    out_ptr <= 10'd28;
                    pay_end <= frame_len;
                    state <= S_OUT;
                end else begin
                    state <= S_IDLE;
                end
            end
            S_OUT: begin
                if (m_valid && m_ready) begin
                    if (out_ptr == pay_end - 10'd1)
                        state <= S_IDLE;
                    else
                        out_ptr <= out_ptr + 10'd1;
                end
            end
            default: state <= S_IDLE;
        endcase
    end
end

endmodule
