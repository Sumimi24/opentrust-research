`timescale 1ns/1ps
`default_nettype none

module dma_write(
input wire clk,
input wire rst,
input wire [15:0] desc_addr,
input wire [15:0] desc_len,
input wire [7:0] desc_tag,
input wire desc_valid,
output wire desc_ready,
input wire [31:0] s_data,
input wire [3:0] s_keep,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [15:0] status_len,
output wire [7:0] status_tag,
output wire [3:0] status_error,
output wire status_valid,
output wire [3:0] m_axi_awid,
output wire [15:0] m_axi_awaddr,
output wire [7:0] m_axi_awlen,
output wire [2:0] m_axi_awsize,
output wire [1:0] m_axi_awburst,
output wire m_axi_awlock,
output wire [3:0] m_axi_awcache,
output wire [2:0] m_axi_awprot,
output wire m_axi_awvalid,
input wire m_axi_awready,
output wire [31:0] m_axi_wdata,
output wire [3:0] m_axi_wstrb,
output wire m_axi_wlast,
output wire m_axi_wvalid,
input wire m_axi_wready,
input wire [3:0] m_axi_bid,
input wire [1:0] m_axi_bresp,
input wire m_axi_bvalid,
output wire m_axi_bready);

reg [2:0] state;
localparam S_IDLE = 3'd0;
localparam S_AW   = 3'd1;
localparam S_W    = 3'd2;
localparam S_B    = 3'd3;
localparam S_STAT = 3'd4;

reg [15:0] r_addr;
reg [15:0] r_rem;
reg [15:0] r_desc_len;
reg [7:0]  r_desc_tag;
reg [3:0]  r_err;

reg [15:0] b_base;
reg [3:0]  b_beats;
reg [3:0]  b_first_mask;
reg [3:0]  b_last_mask;
reg        b_is_last;

reg [3:0]  w_beat;
reg        w_active;
reg        w_last_seen;
reg [31:0] w_data;
reg [3:0]  w_keep;
reg        w_has_data;

wire [3:0] w_strb;
assign w_strb = !w_active ? 4'd0 :
                (w_beat == 4'd0) ? (w_keep & ~b_first_mask) :
                (w_beat == (b_beats - 4'd1)) ? (w_keep & b_last_mask) :
                w_keep;

reg [15:0] debug_cur_addr;
reg [15:0] debug_rem;

assign desc_ready       = (state == S_IDLE) && !rst;
assign status_len       = r_desc_len;
assign status_tag       = r_desc_tag;
assign status_error     = r_err;
assign status_valid     = (state == S_STAT);

assign m_axi_awid       = 4'd0;
assign m_axi_awaddr     = r_addr;
assign m_axi_awlen      = b_beats - 8'd1;
assign m_axi_awsize     = 3'd2;
assign m_axi_awburst    = 2'b01;
assign m_axi_awlock     = 1'b0;
assign m_axi_awcache    = 4'd3;
assign m_axi_awprot     = 3'd0;
assign m_axi_awvalid    = (state == S_AW);

assign m_axi_wdata      = w_data;
assign m_axi_wstrb      = w_strb;
assign m_axi_wlast      = (w_beat == (b_beats - 4'd1));
assign m_axi_wvalid     = (state == S_W) && w_active && w_has_data;
assign s_ready          = (state == S_W) && w_active && !w_has_data && !w_last_seen;

assign m_axi_bready = (state == S_B);

function automatic [3:0] ceil_div4(input [15:0] val);
    begin
        if (val[1:0] == 2'b00) ceil_div4 = val[15:2];
        else ceil_div4 = val[15:2] + 4'd1;
    end
endfunction

function automatic [3:0] num_beats(input [15:0] bytes, input [3:0] offset);
    begin
        num_beats = ceil_div4(bytes + {12'd0, offset});
    end
endfunction

always @(posedge clk) begin
    if (rst) begin
        state <= S_IDLE;
        r_err <= 4'd0;
        w_active <= 1'b0;
        w_has_data <= 1'b0;
        w_last_seen <= 1'b0;
        debug_cur_addr <= 16'd0;
        debug_rem <= 16'd0;
    end else begin
        case (state)
            S_IDLE: begin
                if (desc_valid && desc_ready) begin
                    r_addr     <= desc_addr;
                    r_rem      <= desc_len;
                    r_desc_len <= desc_len;
                    r_desc_tag <= desc_tag;
                    r_err      <= 4'd0;
                    w_active   <= 1'b0;
                    w_has_data <= 1'b0;
                    w_last_seen<= 1'b0;
                    state      <= S_AW;
                end
            end
            S_AW: begin
                if (m_axi_awvalid && m_axi_awready) begin
                    state <= S_W;
                end
            end
            S_W: begin
                if (s_valid && s_ready) begin
                    w_data     <= s_data;
                    w_keep     <= s_keep;
                    w_has_data <= 1'b1;
                    if (s_last) w_last_seen <= 1'b1;
                end
                if (m_axi_wvalid && m_axi_wready) begin
                    w_has_data <= 1'b0;
                    if (m_axi_wlast) begin
                        w_active <= 1'b0;
                        state    <= S_B;
                    end else begin
                        w_beat   <= w_beat + 4'd1;
                    end
                end
            end
            S_B: begin
                if (m_axi_bvalid && m_axi_bready) begin
                    if (m_axi_bresp == 2'b11) r_err <= 4'd7;
                    else if (m_axi_bresp == 2'b10 && r_err != 4'd7) r_err <= 4'd6;
                    if (b_is_last) state <= S_STAT;
                    else         state <= S_AW;
                end
            end
            S_STAT: begin
                state <= S_IDLE;
            end
            default: state <= S_IDLE;
        endcase

        if ((state == S_IDLE && desc_valid && desc_ready) ||
            (state == S_B && m_axi_bvalid && m_axi_bready && !b_is_last)) begin
            begin
                reg [3:0]  off;
                reg [15:0] page_space;
                reg [15:0] max_burst_bytes;
                reg [15:0] burst_bytes;
                reg [3:0]  last_off;
                reg [3:0]  beats;

                if (state == S_IDLE) begin
                    debug_cur_addr = desc_addr;
                    debug_rem      = desc_len;
                end else begin
                    debug_cur_addr = debug_cur_addr + {12'd0, b_beats, 2'd0};
                    debug_rem      = debug_rem - {12'd0, b_beats, 2'd0};
                end

                off = debug_cur_addr[1:0];
                page_space = 16'h1000 - {debug_cur_addr[11:2], 2'b00};
                max_burst_bytes = (debug_rem < page_space) ? debug_rem : page_space;
                if (max_burst_bytes > 16'd64) max_burst_bytes = 16'd64;

                burst_bytes = max_burst_bytes;
                beats = num_beats(burst_bytes, off);
                
                if (off != 4'd0 && beats > 4'd1) begin
                    burst_bytes = {12'd0, beats, 2'd0} - {12'd0, off};
                    if (burst_bytes > debug_rem) burst_bytes = debug_rem;
                end

                last_off = off + burst_bytes[1:0];

                b_base       = debug_cur_addr;
                b_beats      = beats;
                b_first_mask = (off == 4'd0) ? 4'd0 : (4'd1 << off) - 4'd1;
                if (last_off == 4'd0) b_last_mask = 4'hF;
                else if (last_off < 4'd4) b_last_mask = (4'd1 << last_off) - 4'd1;
                else b_last_mask = 4'hF;
                b_is_last    = (burst_bytes >= debug_rem);

                r_addr <= debug_cur_addr;

                w_beat     <= 4'd0;
                w_active   <= 1'b1;
                w_has_data <= 1'b0;
                w_last_seen<= 1'b0;
            end
        end
    end
end

endmodule
