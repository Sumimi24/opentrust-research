module icache_ctrl(
input wire clk_i,
input wire rst_ni,
input wire req_i,
input wire branch_i,
input wire [31:0] addr_i,
input wire ready_i,
output reg valid_o,
output reg [31:0] rdata_o,
output reg [31:0] addr_o,
output reg err_o,
output reg instr_req_o,
input wire instr_gnt_i,
output reg [31:0] instr_addr_o,
input wire [31:0] instr_rdata_i,
input wire instr_err_i,
input wire instr_rvalid_i,
input wire icache_inval_i,
output reg busy_o);

import ibex_pkg::*;

localparam IDLE = 2'd0;
localparam DRAIN = 2'd1;
localparam INVAL = 2'd2;

reg [1:0] state_q, state_d;
reg [5:0] outstanding_q, outstanding_d;
reg [31:0] rdata_q;
reg [31:0] addr_q;
reg err_q;
reg valid_q;
reg drain_valid_q;
reg drain_err_q;
reg [31:0] drain_rdata_q;
reg [31:0] drain_addr_q;
reg inval_pending_q;

wire [1:0] tag_req;
wire [1:0] data_req;
wire tag_write;
wire data_write;
wire [7:0] tag_addr;
wire [7:0] data_addr;
wire [21:0] tag_wdata;
wire [63:0] data_wdata;

reg [21:0] tag_rdata_q [0:1];
reg [63:0] data_rdata_q [0:1];
reg [21:0] tag_mem0 [0:255];
reg [21:0] tag_mem1 [0:255];
reg [63:0] data_mem0 [0:255];
reg [63:0] data_mem1 [0:255];

wire [31:0] core_addr_o;
wire core_valid_o;
wire [31:0] core_rdata_o;
wire core_err_o;
wire core_instr_req_o;
wire [31:0] core_instr_addr_o;
wire core_busy_o;

ibex_icache #(
  .ICacheECC(0),
  .ResetAll(1),
  .BranchCache(0),
  .TweakInfection(0)
) core (
  .clk_i(clk_i),
  .rst_ni(rst_ni),
  .req_i(req_i & (state_q == IDLE)),
  .branch_i(branch_i),
  .addr_i({addr_i[31:2], 2'b00}),
  .ready_i(ready_i & (state_q == IDLE)),
  .valid_o(core_valid_o),
  .rdata_o(core_rdata_o),
  .addr_o(core_addr_o),
  .err_o(core_err_o),
  .instr_req_o(core_instr_req_o),
  .instr_gnt_i(instr_gnt_i & (state_q == IDLE)),
  .instr_addr_o(core_instr_addr_o),
  .instr_rdata_i(instr_rdata_i),
  .instr_err_i(instr_err_i),
  .instr_rvalid_i(instr_rvalid_i & (state_q == IDLE)),
  .icache_inval_i(icache_inval_i),
  .busy_o(core_busy_o),
  .ic_tag_req_o(tag_req),
  .ic_tag_write_o(tag_write),
  .ic_tag_addr_o(tag_addr),
  .ic_tag_wdata_o(tag_wdata),
  .ic_tag_rdata_i(tag_rdata_q),
  .ic_data_req_o(data_req),
  .ic_data_write_o(data_write),
  .ic_data_addr_o(data_addr),
  .ic_data_wdata_o(data_wdata),
  .ic_data_rdata_i(data_rdata_q),
  .ic_scr_key_valid_i(1'b1),
  .icache_enable_i(1'b1)
);

wire drain_response_matches;
assign drain_response_matches = instr_rvalid_i && ((drain_addr_q[31:2] == instr_addr_o[31:2]) || (valid_q && addr_q[31:2] == instr_addr_o[31:2]));

integer i;
always @(posedge clk_i or negedge rst_ni) begin
  if (!rst_ni) begin
    state_q <= IDLE;
    outstanding_q <= 6'd0;
    valid_q <= 1'b0;
    err_q <= 1'b0;
    rdata_q <= 32'd0;
    addr_q <= 32'd0;
    drain_valid_q <= 1'b0;
    drain_err_q <= 1'b0;
    drain_rdata_q <= 32'd0;
    drain_addr_q <= 32'd0;
    inval_pending_q <= 1'b0;
    tag_rdata_q[0] <= 22'h0;
    tag_rdata_q[1] <= 22'h0;
    data_rdata_q[0] <= 64'h0;
    data_rdata_q[1] <= 64'h0;
    for (i = 0; i < 256; i = i + 1) begin
      tag_mem0[i] <= 22'h0;
      tag_mem1[i] <= 22'h0;
      data_mem0[i] <= 64'h0;
      data_mem1[i] <= 64'h0;
    end
  end else begin
    state_q <= state_d;
    outstanding_q <= outstanding_d;

    if (state_q == IDLE) begin
      if (core_valid_o && ready_i) begin
        valid_q <= 1'b0;
      end else if (core_valid_o && !ready_i) begin
        valid_q <= core_valid_o;
        err_q <= core_err_o;
        rdata_q <= core_rdata_o;
        addr_q <= core_addr_o;
      end

      if (core_err_o && core_valid_o && ready_i) begin
        drain_valid_q <= core_err_o;
        drain_err_q <= core_err_o;
        drain_rdata_q <= core_rdata_o;
        drain_addr_q <= core_addr_o;
      end
    end else if (state_q == DRAIN) begin
      if (instr_rvalid_i) begin
        if (valid_q && (addr_q[31:2] == instr_addr_o[31:2])) begin
          valid_q <= 1'b0;
        end
        if (drain_valid_q && (drain_addr_q[31:2] == instr_addr_o[31:2])) begin
          drain_valid_q <= 1'b0;
        end
      end
    end

    if (branch_i || icache_inval_i) begin
      drain_valid_q <= 1'b0;
      drain_err_q <= 1'b0;
      valid_q <= 1'b0;
    end

    if (icache_inval_i && (state_q == IDLE)) begin
      inval_pending_q <= 1'b1;
    end else if (state_q == INVAL && !core_busy_o) begin
      inval_pending_q <= 1'b0;
    end

    if (tag_req[0]) begin
      tag_rdata_q[0] <= tag_mem0[tag_addr];
      if (tag_write) tag_mem0[tag_addr] <= tag_wdata;
    end
    if (tag_req[1]) begin
      tag_rdata_q[1] <= tag_mem1[tag_addr];
      if (tag_write) tag_mem1[tag_addr] <= tag_wdata;
    end
    if (data_req[0]) begin
      data_rdata_q[0] <= data_mem0[data_addr];
      if (data_write) data_mem0[data_addr] <= data_wdata;
    end
    if (data_req[1]) begin
      data_rdata_q[1] <= data_mem1[data_addr];
      if (data_write) data_mem1[data_addr] <= data_wdata;
    end
  end
end

always @* begin
  state_d = state_q;
  outstanding_d = outstanding_q;

  case (state_q)
    IDLE: begin
      if (inval_pending_q) begin
        state_d = INVAL;
        outstanding_d = outstanding_q;
      end else if (core_err_o && core_valid_o && ready_i) begin
        state_d = DRAIN;
        outstanding_d = outstanding_q + (core_instr_req_o && instr_gnt_i ? 1 : 0) - (instr_rvalid_i ? 1 : 0);
      end else if (!req_i && (outstanding_q != 6'd0 || core_busy_o)) begin
        state_d = DRAIN;
      end else begin
        outstanding_d = outstanding_q + (core_instr_req_o && instr_gnt_i ? 1 : 0) - (instr_rvalid_i ? 1 : 0);
      end
    end
    DRAIN: begin
      if (branch_i) begin
        state_d = IDLE;
        outstanding_d = 6'd0;
      end else if (instr_rvalid_i) begin
        outstanding_d = outstanding_q - 6'd1;
        if (outstanding_q == 6'd1 && !valid_q && !drain_valid_q) begin
          state_d = IDLE;
        end
      end else begin
        outstanding_d = outstanding_q;
      end
    end
    INVAL: begin
      if (!core_busy_o) begin
        state_d = IDLE;
        outstanding_d = 6'd0;
      end else begin
        outstanding_d = outstanding_q + (core_instr_req_o && instr_gnt_i && (state_q == INVAL) ? 1 : 0) - (instr_rvalid_i ? 1 : 0);
      end
    end
    default: state_d = IDLE;
  endcase
end

always @* begin
  valid_o = 1'b0;
  rdata_o = 32'd0;
  addr_o = 32'd0;
  err_o = 1'b0;
  instr_req_o = 1'b0;
  instr_addr_o = 32'd0;
  busy_o = 1'b0;

  case (state_q)
    IDLE: begin
      valid_o = core_valid_o;
      rdata_o = core_rdata_o;
      addr_o = core_addr_o;
      err_o = core_err_o;
      instr_req_o = core_instr_req_o;
      instr_addr_o = {core_instr_addr_o[31:2], 2'b00};
      busy_o = core_busy_o | (outstanding_q != 6'd0);
    end
    DRAIN: begin
      if (valid_q) begin
        valid_o = 1'b1;
        rdata_o = rdata_q;
        addr_o = addr_q;
        err_o = err_q;
      end else if (drain_valid_q) begin
        valid_o = 1'b1;
        rdata_o = drain_rdata_q;
        addr_o = drain_addr_q;
        err_o = drain_err_q;
      end else if (instr_rvalid_i) begin
        valid_o = 1'b1;
        rdata_o = instr_rdata_i;
        addr_o = {addr_q[31:2], 2'b00};
        err_o = instr_err_i;
      end
      busy_o = (outstanding_q != 6'd0) || valid_q || drain_valid_q;
      instr_req_o = 1'b0;
      instr_addr_o = 32'd0;
    end
    INVAL: begin
      busy_o = 1'b1;
      instr_req_o = core_instr_req_o;
      instr_addr_o = {core_instr_addr_o[31:2], 2'b00};
    end
    default: begin
      busy_o = 1'b0;
    end
  endcase
end

endmodule
