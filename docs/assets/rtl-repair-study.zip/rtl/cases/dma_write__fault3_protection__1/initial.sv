`timescale 1ns/1ps
`default_nettype none

module dma_write(
input wire clk,
input wire rst,
input wire [15:0] desc_addr,
input wire [15:0] desc_len,
input wire [7:0] desc_tag,
input wire desc_valid,
output wire desc_ready,
input wire [31:0] s_data,
input wire [3:0] s_keep,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [15:0] status_len,
output wire [7:0] status_tag,
output wire [3:0] status_error,
output wire status_valid,
output wire [3:0] m_axi_awid,
output wire [15:0] m_axi_awaddr,
output wire [7:0] m_axi_awlen,
output wire [2:0] m_axi_awsize,
output wire [1:0] m_axi_awburst,
output wire m_axi_awlock,
output wire [3:0] m_axi_awcache,
output wire [2:0] m_axi_awprot,
output wire m_axi_awvalid,
input wire m_axi_awready,
output wire [31:0] m_axi_wdata,
output wire [3:0] m_axi_wstrb,
output wire m_axi_wlast,
output wire m_axi_wvalid,
input wire m_axi_wready,
input wire [3:0] m_axi_bid,
input wire [1:0] m_axi_bresp,
input wire m_axi_bvalid,
output wire m_axi_bready);

reg [2:0] state;
localparam S_IDLE = 3'd0, S_RUN = 3'd1, S_STATUS = 3'd2;

reg [15:0] r_addr, r_len, r_bytes_left;
reg [7:0]  r_tag;
reg        r_s_last_seen;
reg [3:0]  r_err;

reg [3:0]  aw_beats, w_beat_cnt;
reg [15:0] aw_addr_val;
reg        aw_pending, w_active, w_done;
reg        b_pending;
reg [3:0]  b_count;

wire can_accept = (state == S_IDLE) && !aw_pending && !w_active && !b_pending && (b_count == 4'd0);
assign desc_ready = can_accept;

assign status_len   = r_len;
assign status_tag   = r_tag;
assign status_error = r_err;
assign status_valid = (state == S_STATUS);

assign m_axi_awid    = 4'd0;
assign m_axi_awaddr  = aw_addr_val;
assign m_axi_awlen   = aw_beats - 4'd1;
assign m_axi_awsize  = 3'd2;
assign m_axi_awburst = 2'b01;
assign m_axi_awlock  = 1'b0;
assign m_axi_awcache = 4'd3;
assign m_axi_awprot  = 3'd0;
assign m_axi_awvalid = aw_pending;

assign m_axi_wdata  = s_data;
assign m_axi_wlast  = w_active && (w_beat_cnt == aw_beats - 4'd1);
assign m_axi_wvalid = w_active && s_valid && !w_done;
assign s_ready      = w_active && m_axi_wready && !w_done;

wire first_wbeat = w_active && (w_beat_cnt == 4'd0);
wire last_wbeat  = w_active && (w_beat_cnt == aw_beats - 4'd1);
wire [3:0] mask_lo = first_wbeat ? (4'hF << r_addr[1:0]) : 4'hF;
wire [3:0] mask_hi = last_wbeat  ? ~(4'hF << ((r_bytes_left - 16'd1) & 16'd3)) : 4'hF;
assign m_axi_wstrb = s_keep & mask_lo & mask_hi;

assign m_axi_bready = b_pending;

always @(posedge clk) begin
    if (rst) begin
        state         <= S_IDLE;
        r_addr        <= 16'd0;
        r_len         <= 16'd0;
        r_bytes_left  <= 16'd0;
        r_tag         <= 8'd0;
        r_s_last_seen <= 1'b0;
        r_err         <= 4'd0;
        aw_pending    <= 1'b0;
        aw_beats      <= 4'd0;
        aw_addr_val   <= 16'd0;
        w_active      <= 1'b0;
        w_beat_cnt    <= 4'd0;
        w_done        <= 1'b0;
        b_pending     <= 1'b0;
        b_count       <= 4'd0;
    end else begin
        case (state)
            S_IDLE: begin
                if (can_accept && desc_valid && desc_ready) begin
                    r_addr        <= desc_addr;
                    r_len         <= desc_len;
                    r_bytes_left  <= desc_len;
                    r_tag         <= desc_tag;
                    r_s_last_seen <= 1'b0;
                    r_err         <= 4'd0;
                    state         <= S_RUN;
                end
            end
            S_RUN: begin
                if (!aw_pending && !w_active && !b_pending && r_bytes_left > 16'd0) begin
                    automatic logic [15:0] off      = r_addr & 16'd3;
                    automatic logic [15:0] space    = 16'd4096 - (r_addr & 16'd4095);
                    automatic logic [15:0] max_b    = (space + 16'd3) >> 2;
                    automatic logic [15:0] need_b   = (r_bytes_left + off + 16'd3) >> 2;
                    automatic logic [3:0]  nb       = (need_b > max_b) ? max_b[3:0] : need_b[3:0];
                    if (nb > 4'd16) nb = 4'd16;
                    if (nb < 4'd1)  nb = 4'd1;
                    aw_beats    <= nb;
                    aw_addr_val <= r_addr;
                    aw_pending  <= 1'b1;
                    w_active    <= 1'b1;
                    w_beat_cnt  <= 4'd0;
                    w_done      <= 1'b0;
                    b_pending   <= 1'b1;
                    b_count     <= b_count + 4'd1;
                end
                if (aw_pending && m_axi_awready) begin
                    aw_pending <= 1'b0;
                end
                if (w_active && !w_done && s_valid && m_axi_wready) begin
                    automatic logic [3:0] cb = $countones(s_keep);
                    w_beat_cnt <= w_beat_cnt + 4'd1;
                    if (first_wbeat) begin
                        automatic logic [15:0] fb = cb - r_addr[1:0];
                        r_bytes_left <= r_bytes_left - fb;
                    end else begin
                        r_bytes_left <= r_bytes_left - cb;
                    end
                    if (s_last) r_s_last_seen <= 1'b1;
                    if (last_wbeat) begin
                        w_done   <= 1'b1;
                        w_active <= 1'b0;
                        r_addr   <= (r_addr & ~16'd3) + {aw_beats, 2'b00};
                    end
                end
                if (b_pending && m_axi_bvalid && m_axi_bready) begin
                    b_pending <= 1'b0;
                    b_count   <= b_count - 4'd1;
                    if (m_axi_bresp == 2'b11) begin
                        r_err <= 4'd7;
                    end else if (m_axi_bresp == 2'b10 && r_err != 4'd7) begin
                        r_err <= 4'd6;
                    end
                end
                if (r_bytes_left == 16'd0 && !aw_pending && !w_active && !b_pending) begin
                    state <= S_STATUS;
                end
            end
            S_STATUS: begin
                state <= S_IDLE;
            end
            default: state <= S_IDLE;
        endcase
    end
end

endmodule
