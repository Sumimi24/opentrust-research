`timescale 1ns/1ps
`default_nettype none

module dma_write(
input wire clk,
input wire rst,
input wire [15:0] desc_addr,
input wire [15:0] desc_len,
input wire [7:0] desc_tag,
input wire desc_valid,
output wire desc_ready,
input wire [31:0] s_data,
input wire [3:0] s_keep,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [15:0] status_len,
output wire [7:0] status_tag,
output wire [3:0] status_error,
output wire status_valid,
output wire [3:0] m_axi_awid,
output wire [15:0] m_axi_awaddr,
output wire [7:0] m_axi_awlen,
output wire [2:0] m_axi_awsize,
output wire [1:0] m_axi_awburst,
output wire m_axi_awlock,
output wire [3:0] m_axi_awcache,
output wire [2:0] m_axi_awprot,
output wire m_axi_awvalid,
input wire m_axi_awready,
output wire [31:0] m_axi_wdata,
output wire [3:0] m_axi_wstrb,
output wire m_axi_wlast,
output wire m_axi_wvalid,
input wire m_axi_wready,
input wire [3:0] m_axi_bid,
input wire [1:0] m_axi_bresp,
input wire m_axi_bvalid,
output wire m_axi_bready);

localparam S_IDLE   = 2'd0;
localparam S_RUN    = 2'd1;
localparam S_STATUS = 2'd2;

reg [1:0] state;
reg [15:0] r_addr;
reg [15:0] r_len;
reg [15:0] r_bytes_left;
reg [7:0]  r_tag;
reg [3:0]  r_err;

reg        aw_pending;
reg [3:0]  aw_beats;
reg [15:0] aw_addr_val;

reg        w_active;
reg [3:0]  w_beat_cnt;
reg        w_done;
reg        w_last_beat_taken;

reg        b_pending;
reg [3:0]  b_count;

wire can_accept = (state == S_IDLE) && !aw_pending && !w_active && !b_pending && (b_count == 4'd0);
assign desc_ready = can_accept;

assign status_len   = r_len;
assign status_tag   = r_tag;
assign status_error = r_err;
assign status_valid = (state == S_STATUS);

assign m_axi_awid    = 4'd0;
assign m_axi_awaddr  = aw_addr_val;
assign m_axi_awlen   = aw_beats - 4'd1;
assign m_axi_awsize  = 3'd2;
assign m_axi_awburst = 2'b01;
assign m_axi_awlock  = 1'b0;
assign m_axi_awcache = 4'd3;
assign m_axi_awprot  = 3'd0;
assign m_axi_awvalid = aw_pending;

assign m_axi_wdata  = s_data;

wire is_first_beat = w_active && (w_beat_cnt == 4'd0);
wire is_last_beat  = w_active && (w_beat_cnt == aw_beats - 4'd1);

wire [3:0] first_mask = (r_addr[1:0] == 2'd0) ? 4'hF :
                         (r_addr[1:0] == 2'd1) ? 4'hE :
                         (r_addr[1:0] == 2'd2) ? 4'hC : 4'h8;

wire [3:0] last_mask;
wire [15:0] rem = r_bytes_left;
assign last_mask = (rem[1:0] == 2'd1) ? 4'h1 :
                    (rem[1:0] == 2'd2) ? 4'h3 :
                    (rem[1:0] == 2'd3) ? 4'h7 : 4'hF;

wire [3:0] strb_mask = is_first_beat ? first_mask :
                        is_last_beat  ? last_mask  : 4'hF;

assign m_axi_wstrb  = s_keep & strb_mask;
assign m_axi_wlast  = is_last_beat && !w_last_beat_taken;
assign m_axi_wvalid = w_active && s_valid && !w_done;
assign s_ready      = w_active && m_axi_wready && !w_done;

assign m_axi_bready = b_pending;

function [3:0] count_ones(input [3:0] vec);
    count_ones = vec[0] + vec[1] + vec[2] + vec[3];
endfunction

always @(posedge clk) begin
    if (rst) begin
        state          <= S_IDLE;
        r_addr         <= 16'd0;
        r_len          <= 16'd0;
        r_bytes_left   <= 16'd0;
        r_tag          <= 8'd0;
        r_err          <= 4'd0;
        aw_pending     <= 1'b0;
        aw_beats       <= 4'd0;
        aw_addr_val    <= 16'd0;
        w_active       <= 1'b0;
        w_beat_cnt     <= 4'd0;
        w_done         <= 1'b0;
        w_last_beat_taken <= 1'b0;
        b_pending      <= 1'b0;
        b_count        <= 4'd0;
    end else begin
        case (state)
            S_IDLE: begin
                if (can_accept && desc_valid && desc_ready) begin
                    r_addr       <= desc_addr;
                    r_len        <= desc_len;
                    r_bytes_left <= desc_len;
                    r_tag        <= desc_tag;
                    r_err        <= 4'd0;
                    state        <= S_RUN;
                end
            end

            S_RUN: begin
                if (!aw_pending && !w_active && !b_pending && r_bytes_left > 16'd0) begin
                    reg [15:0] start_addr;
                    reg [3:0]  offset;
                    reg [15:0] space_left;
                    reg [15:0] max_beats_fpga;
                    reg [15:0] need_beats;
                    reg [3:0]  nb;

                    start_addr = r_addr;
                    offset = start_addr[1:0];
                    space_left = 16'd4096 - (start_addr & 16'd4095);
                    max_beats_fpga = (space_left + 16'd3) >> 2;
                    need_beats = (r_bytes_left + {14'd0, offset} + 16'd3) >> 2;

                    if (need_beats > max_beats_fpga)
                        need_beats = max_beats_fpga;
                    if (need_beats > 16'd16)
                        need_beats = 16'd16;
                    nb = need_beats[3:0];

                    aw_beats    <= nb;
                    aw_addr_val <= start_addr;
                    aw_pending  <= 1'b1;
                    w_active    <= 1'b1;
                    w_beat_cnt  <= 4'd0;
                    w_done      <= 1'b0;
                    w_last_beat_taken <= 1'b0;
                    b_pending   <= 1'b1;
                    b_count     <= b_count + 4'd1;
                end

                if (aw_pending && m_axi_awready)
                    aw_pending <= 1'b0;

                if (w_active && !w_done && s_valid && m_axi_wready) begin
                    reg [15:0] strb_cnt;
                    strb_cnt = {12'd0, count_ones(s_keep & strb_mask)};

                    if (is_last_beat)
                        w_last_beat_taken <= 1'b1;

                    w_beat_cnt <= w_beat_cnt + 4'd1;
                    r_bytes_left <= r_bytes_left - strb_cnt;

                    if (is_last_beat) begin
                        w_done   <= 1'b1;
                        w_active <= 1'b0;
                        r_addr   <= (start_addr_next & ~16'd3) + {aw_beats, 2'b00};
                    end
                end

                if (b_pending && m_axi_bvalid && m_axi_bready) begin
                    b_pending <= 1'b0;
                    b_count   <= b_count - 4'd1;
                    if (m_axi_bresp == 2'b11)
                        r_err <= 4'd7;
                    else if (m_axi_bresp == 2'b10 && r_err != 4'd7)
                        r_err <= 4'd6;
                end

                if (r_bytes_left == 16'd0 && !aw_pending && !w_active && !b_pending)
                    state <= S_STATUS;
            end

            S_STATUS: begin
                state <= S_IDLE;
            end

            default: state <= S_IDLE;
        endcase
    end
end

reg [15:0] start_addr_next;
always @(*) begin
    start_addr_next = r_addr;
end

endmodule
