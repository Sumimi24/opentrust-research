module dma_write(
input wire clk,
input wire rst,
input wire [15:0] desc_addr,
input wire [15:0] desc_len,
input wire [7:0] desc_tag,
input wire desc_valid,
output wire desc_ready,
input wire [31:0] s_data,
input wire [3:0] s_keep,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [15:0] status_len,
output wire [7:0] status_tag,
output wire [3:0] status_error,
output wire status_valid,
output wire [3:0] m_axi_awid,
output wire [15:0] m_axi_awaddr,
output wire [7:0] m_axi_awlen,
output wire [2:0] m_axi_awsize,
output wire [1:0] m_axi_awburst,
output wire m_axi_awlock,
output wire [3:0] m_axi_awcache,
output wire [2:0] m_axi_awprot,
output wire m_axi_awvalid,
input wire m_axi_awready,
output wire [31:0] m_axi_wdata,
output wire [3:0] m_axi_wstrb,
output wire m_axi_wlast,
output wire m_axi_wvalid,
input wire m_axi_wready,
input wire [3:0] m_axi_bid,
input wire [1:0] m_axi_bresp,
input wire m_axi_bvalid,
output wire m_axi_bready
);

reg active_reg = 1'b0;
reg seen_slverr_reg = 1'b0;
reg seen_decerr_reg = 1'b0;

wire core_desc_ready;
wire [15:0] core_status_len;
wire [7:0] core_status_tag;
wire [3:0] core_status_error;
wire core_status_valid;

wire [3:0] core_awid;
wire [15:0] core_awaddr;
wire [7:0] core_awlen;
wire [2:0] core_awsize;
wire [1:0] core_awburst;
wire core_awlock;
wire [3:0] core_awcache;
wire [2:0] core_awprot;
wire core_awvalid;
wire [31:0] core_wdata;
wire [3:0] core_wstrb;
wire core_wlast;
wire core_wvalid;
wire core_bready;

assign desc_ready = core_desc_ready && !active_reg && !rst;

assign status_len = core_status_len;
assign status_tag = core_status_tag;
assign status_valid = core_status_valid;
assign status_error = seen_decerr_reg ? 4'd7 : (seen_slverr_reg ? 4'd6 : core_status_error);

assign m_axi_awid = core_awid;
assign m_axi_awaddr = core_awaddr;
assign m_axi_awlen = core_awlen;
assign m_axi_awsize = core_awsize;
assign m_axi_awburst = core_awburst;
assign m_axi_awlock = core_awlock;
assign m_axi_awcache = core_awcache;
assign m_axi_awprot = core_awvalid ? core_awprot : 3'b000;
assign m_axi_awvalid = core_awvalid;

assign m_axi_wdata = core_wdata;
assign m_axi_wstrb = core_wstrb;
assign m_axi_wlast = core_wlast;
assign m_axi_wvalid = core_wvalid;
assign m_axi_bready = core_bready;

always @(posedge clk) begin
    if (rst) begin
        active_reg <= 1'b0;
        seen_slverr_reg <= 1'b0;
        seen_decerr_reg <= 1'b0;
    end else begin
        if (core_status_valid) begin
            active_reg <= 1'b0;
        end

        if (desc_valid && desc_ready) begin
            active_reg <= 1'b1;
            seen_slverr_reg <= 1'b0;
            seen_decerr_reg <= 1'b0;
        end

        if (m_axi_bvalid && core_bready) begin
            if (m_axi_bresp == 2'b10) begin
                seen_slverr_reg <= 1'b1;
            end
            if (m_axi_bresp == 2'b11) begin
                seen_decerr_reg <= 1'b1;
            end
        end
    end
end

axi_dma_wr #(
    .AXI_DATA_WIDTH(32),
    .AXI_ADDR_WIDTH(16),
    .AXI_STRB_WIDTH(4),
    .AXI_ID_WIDTH(4),
    .AXIS_DATA_WIDTH(32),
    .AXIS_KEEP_WIDTH(4),
    .LEN_WIDTH(16),
    .TAG_WIDTH(8),
    .ENABLE_UNALIGNED(1)
)
core (
    .clk(clk),
    .rst(rst),
    .s_axis_write_desc_addr(desc_addr),
    .s_axis_write_desc_len(desc_len),
    .s_axis_write_desc_tag(desc_tag),
    .s_axis_write_desc_valid(desc_valid && !active_reg),
    .s_axis_write_desc_ready(core_desc_ready),
    .m_axis_write_desc_status_len(core_status_len),
    .m_axis_write_desc_status_tag(core_status_tag),
    .m_axis_write_desc_status_error(core_status_error),
    .m_axis_write_desc_status_valid(core_status_valid),
    .s_axis_write_data_tdata(s_data),
    .s_axis_write_data_tkeep(s_keep),
    .s_axis_write_data_tvalid(s_valid),
    .s_axis_write_data_tready(s_ready),
    .s_axis_write_data_tlast(s_last),
    .s_axis_write_data_tid(8'd0),
    .s_axis_write_data_tdest(8'd0),
    .s_axis_write_data_tuser(1'b0),
    .enable(1'b1),
    .abort(1'b0),
    .m_axi_awid(core_awid),
    .m_axi_awaddr(core_awaddr),
    .m_axi_awlen(core_awlen),
    .m_axi_awsize(core_awsize),
    .m_axi_awburst(core_awburst),
    .m_axi_awlock(core_awlock),
    .m_axi_awcache(core_awcache),
    .m_axi_awprot(core_awprot),
    .m_axi_awvalid(core_awvalid),
    .m_axi_awready(m_axi_awready),
    .m_axi_wdata(core_wdata),
    .m_axi_wstrb(core_wstrb),
    .m_axi_wlast(core_wlast),
    .m_axi_wvalid(core_wvalid),
    .m_axi_wready(m_axi_wready),
    .m_axi_bid(m_axi_bid),
    .m_axi_bresp(m_axi_bresp),
    .m_axi_bvalid(m_axi_bvalid),
    .m_axi_bready(core_bready)
);

endmodule
