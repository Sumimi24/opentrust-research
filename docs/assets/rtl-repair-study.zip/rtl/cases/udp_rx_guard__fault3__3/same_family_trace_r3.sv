module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

reg [7:0] bytes[0:511];
reg [9:0] n;
reg [2:0] state;
reg status_valid_reg;
reg [3:0] status_error_reg;
reg [31:0] m_src_ip_reg;
reg [15:0] m_src_port_reg;
reg [15:0] m_dst_port_reg;
reg [15:0] m_payload_len_reg;
reg [7:0] m_data_reg;
reg m_valid_reg;
reg m_last_reg;
reg [16:0] ip_sum;
reg [17:0] udp_sum;
reg [15:0] checksum_acc;
reg [17:0] udp_checksum_acc;
reg [9:0] checksum_cnt;
reg [9:0] udp_checksum_cnt;
reg checksum_done;
reg udp_checksum_done;
reg [9:0] payload_total;
reg [9:0] output_cnt;
reg [9:0] ptr;
reg [3:0] error_code;
reg [15:0] temp16;
reg [16:0] temp17;
reg [15:0] ip_len;
reg [15:0] udp_len;
reg [15:0] payload_len_calc;

localparam ST_IDLE = 3'd0;
localparam ST_CHECKSUM = 3'd1;
localparam ST_UDPCHECK = 3'd2;
localparam ST_STATUS = 3'd3;
localparam ST_OUTPUT = 3'd4;
localparam ST_DRAIN = 3'd5;

assign s_ready = !rst && (state == ST_IDLE);

assign status_valid = status_valid_reg;
assign status_error = status_error_reg;

assign m_src_ip = m_src_ip_reg;
assign m_src_port = m_src_port_reg;
assign m_dst_port = m_dst_port_reg;
assign m_payload_len = m_payload_len_reg;
assign m_data = m_data_reg;
assign m_valid = m_valid_reg;
assign m_last = m_last_reg;

integer i;

always @(posedge clk) begin
    if (rst) begin
        state <= ST_IDLE;
        n <= 10'd0;
        status_valid_reg <= 1'b0;
        status_error_reg <= 4'd0;
        m_src_ip_reg <= 32'd0;
        m_src_port_reg <= 16'd0;
        m_dst_port_reg <= 16'd0;
        m_payload_len_reg <= 16'd0;
        m_data_reg <= 8'd0;
        m_valid_reg <= 1'b0;
        m_last_reg <= 1'b0;
        checksum_acc <= 16'd0;
        udp_checksum_acc <= 18'd0;
        checksum_cnt <= 10'd0;
        udp_checksum_cnt <= 10'd0;
        checksum_done <= 1'b0;
        udp_checksum_done <= 1'b0;
        payload_total <= 10'd0;
        output_cnt <= 10'd0;
        ptr <= 10'd0;
        error_code <= 4'd0;
        for (i = 0; i < 512; i = i + 1) begin
            bytes[i] <= 8'd0;
        end
    end else begin
        status_valid_reg <= 1'b0;
        
        case (state)
            ST_IDLE: begin
                m_valid_reg <= 1'b0;
                m_last_reg <= 1'b0;
                if (s_valid && s_ready) begin
                    if (n < 10'd512) begin
                        bytes[n] <= s_data;
                    end
                    n <= n + 10'd1;
                    if (s_last) begin
                        state <= ST_CHECKSUM;
                        checksum_cnt <= 10'd0;
                        checksum_acc <= 16'd0;
                        checksum_done <= 1'b0;
                    end
                end
            end
            
            ST_CHECKSUM: begin
                if (!checksum_done) begin
                    if (checksum_cnt < 10'd20) begin
                        case (checksum_cnt)
                            10'd0: checksum_acc <= {bytes[0], bytes[1]};
                            10'd2: checksum_acc <= checksum_acc + {bytes[2], bytes[3]};
                            10'd4: checksum_acc <= checksum_acc + {bytes[4], bytes[5]};
                            10'd6: checksum_acc <= checksum_acc + {bytes[6], bytes[7]};
                            10'd8: checksum_acc <= checksum_acc + {bytes[8], bytes[9]};
                            10'd10: checksum_acc <= checksum_acc + {bytes[10], bytes[11]};
                            10'd12: checksum_acc <= checksum_acc + {bytes[12], bytes[13]};
                            10'd14: checksum_acc <= checksum_acc + {bytes[14], bytes[15]};
                            10'd16: checksum_acc <= checksum_acc + {bytes[16], bytes[17]};
                            10'd18: checksum_acc <= checksum_acc + {bytes[18], bytes[19]};
                        endcase
                        checksum_cnt <= checksum_cnt + 10'd2;
                    end else begin
                        checksum_done <= 1'b1;
                    end
                end else begin
                    temp17 = checksum_acc[15:0] + checksum_acc[16];
                    ip_sum = temp17[15:0] + temp17[16];
                    
                    ip_len = {bytes[2], bytes[3]};
                    udp_len = {bytes[24], bytes[25]};
                    payload_len_calc = udp_len - 16'd8;
                    
                    error_code <= 4'd0;
                    
                    if (n < 10'd28) begin
                        error_code <= 4'd1;
                    end else if (n > 10'd512) begin
                        error_code <= 4'd1;
                    end else if (bytes[0][7:4] != 4'd4) begin
                        error_code <= 4'd1;
                    end else if (bytes[0][3:0] != 4'd5) begin
                        error_code <= 4'd1;
                    end else if (bytes[9] != 8'd17) begin
                        error_code <= 4'd1;
                    end else if (bytes[6][5]) begin
                        error_code <= 4'd1;
                    end else if ({bytes[6][4:0], bytes[7]} != 13'd0) begin
                        error_code <= 4'd1;
                    end else if (ip_len != n[9:0]) begin
                        error_code <= 4'd2;
                    end else if (udp_len != ip_len - 16'd20) begin
                        error_code <= 4'd2;
                    end else if (payload_len_calc < 16'd1 || payload_len_calc > 16'd256) begin
                        error_code <= 4'd2;
                    end else if (ip_sum != 16'hffff) begin
                        error_code <= 4'd3;
                    end
                    
                    if (error_code != 4'd0) begin
                        state <= ST_STATUS;
                    end else begin
                        state <= ST_UDPCHECK;
                        udp_checksum_cnt <= 10'd0;
                        udp_checksum_acc <= 18'd0;
                        udp_checksum_done <= 1'b0;
                    end
                end
            end
            
            ST_UDPCHECK: begin
                if (!udp_checksum_done) begin
                    if (udp_checksum_cnt == 10'd0) begin
                        udp_checksum_acc <= {bytes[12], bytes[13]};
                        udp_checksum_cnt <= 10'd2;
                    end else if (udp_checksum_cnt == 10'd2) begin
                        udp_checksum_acc <= udp_checksum_acc + {bytes[14], bytes[15]};
                        udp_checksum_cnt <= 10'd4;
                    end else if (udp_checksum_cnt == 10'd4) begin
                        udp_checksum_acc <= udp_checksum_acc + {bytes[16], bytes[17]};
                        udp_checksum_cnt <= 10'd6;
                    end else if (udp_checksum_cnt == 10'd6) begin
                        udp_checksum_acc <= udp_checksum_acc + {bytes[18], bytes[19]};
                        udp_checksum_cnt <= 10'd8;
                    end else if (udp_checksum_cnt == 10'd8) begin
                        udp_checksum_acc <= udp_checksum_acc + 16'd17;
                        udp_checksum_cnt <= 10'd10;
                    end else if (udp_checksum_cnt == 10'd10) begin
                        udp_checksum_acc <= udp_checksum_acc + udp_len;
                        udp_checksum_cnt <= 10'd12;
                    end else if (udp_checksum_cnt < n) begin
                        if (udp_checksum_cnt + 10'd1 < n) begin
                            udp_checksum_acc <= udp_checksum_acc + {bytes[udp_checksum_cnt], bytes[udp_checksum_cnt + 10'd1]};
                            udp_checksum_cnt <= udp_checksum_cnt + 10'd2;
                        end else begin
                            udp_checksum_acc <= udp_checksum_acc + {bytes[udp_checksum_cnt], 8'd0};
                            udp_checksum_cnt <= udp_checksum_cnt + 10'd2;
                        end
                    end else begin
                        udp_checksum_done <= 1'b1;
                    end
                end else begin
                    if ({bytes[26], bytes[27]} == 16'd0) begin
                        error_code <= 4'd0;
                    end else begin
                        temp17 = udp_checksum_acc[15:0] + udp_checksum_acc[17:16];
                        udp_sum = temp17[15:0] + temp17[16];
                        if (udp_sum != 16'hffff) begin
                            error_code <= 4'd4;
                        end else begin
                            error_code <= 4'd0;
                        end
                    end
                    
                    if (error_code == 4'd0) begin
                        if ({bytes[16], bytes[17], bytes[18], bytes[19]} != 32'h0a000002) begin
                            error_code <= 4'd5;
                        end else if ({bytes[22], bytes[23]} != 16'd9000) begin
                            error_code <= 4'd5;
                        end
                    end
                    
                    state <= ST_STATUS;
                end
            end
            
            ST_STATUS: begin
                status_valid_reg <= 1'b1;
                status_error_reg <= error_code;
                
                if (error_code == 4'd0) begin
                    m_src_ip_reg <= {bytes[12], bytes[13], bytes[14], bytes[15]};
                    m_src_port_reg <= {bytes[20], bytes[21]};
                    m_dst_port_reg <= {bytes[22], bytes[23]};
                    m_payload_len_reg <= payload_len_calc;
                    payload_total <= payload_len_calc[9:0];
                    output_cnt <= 10'd0;
                    ptr <= 10'd28;
                    state <= ST_OUTPUT;
                end else begin
                    state <= ST_IDLE;
                    n <= 10'd0;
                end
            end
            
            ST_OUTPUT: begin
                if (output_cnt < payload_total) begin
                    m_data_reg <= bytes[ptr];
                    m_valid_reg <= 1'b1;
                    m_last_reg <= (output_cnt == payload_total - 10'd1);
                    
                    if (m_ready) begin
                        ptr <= ptr + 10'd1;
                        output_cnt <= output_cnt + 10'd1;
                        if (output_cnt == payload_total - 10'd1) begin
                            m_valid_reg <= 1'b0;
                            m_last_reg <= 1'b0;
                            state <= ST_DRAIN;
                        end
                    end
                end else begin
                    m_valid_reg <= 1'b0;
                    m_last_reg <= 1'b0;
                    state <= ST_DRAIN;
                end
            end
            
            ST_DRAIN: begin
                m_valid_reg <= 1'b0;
                m_last_reg <= 1'b0;
                state <= ST_IDLE;
                n <= 10'd0;
            end
            
            default: begin
                state <= ST_IDLE;
                n <= 10'd0;
            end
        endcase
    end
end

endmodule
