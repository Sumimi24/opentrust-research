module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

reg [7:0] bytes[0:511];
reg [9:0] n, ptr;
reg [2:0] state;
reg status_valid_reg;
reg [3:0] status_error_reg;
reg [31:0] m_src_ip_reg;
reg [15:0] m_src_port_reg;
reg [15:0] m_dst_port_reg;
reg [15:0] m_payload_len_reg;
reg [7:0] m_data_reg;
reg m_valid_reg;
reg m_last_reg;
reg [16:0] ip_sum;
reg [17:0] udp_sum;
reg [9:0] ip_len, udp_len;
reg [3:0] error_code;
reg [9:0] j;
reg [16:0] temp_sum;
reg [15:0] word_val;
reg [9:0] payload_len_calc;

wire [15:0] word16_2_3 = {bytes[2], bytes[3]};
wire [15:0] word16_4_5 = {bytes[4], bytes[5]};
wire [15:0] word16_6_7 = {bytes[6], bytes[7]};
wire [15:0] word16_10_11 = {bytes[10], bytes[11]};
wire [15:0] word16_12_13 = {bytes[12], bytes[13]};
wire [15:0] word16_14_15 = {bytes[14], bytes[15]};
wire [15:0] word16_16_17 = {bytes[16], bytes[17]};
wire [15:0] word16_18_19 = {bytes[18], bytes[19]};
wire [15:0] word16_20_21 = {bytes[20], bytes[21]};
wire [15:0] word16_22_23 = {bytes[22], bytes[23]};
wire [15:0] word16_24_25 = {bytes[24], bytes[25]};

wire [31:0] src_ip = {bytes[12], bytes[13], bytes[14], bytes[15]};
wire [31:0] dst_ip = {bytes[16], bytes[17], bytes[18], bytes[19]};
wire [15:0] src_port = {bytes[20], bytes[21]};
wire [15:0] dst_port = {bytes[22], bytes[23]};
wire [15:0] udp_length = {bytes[24], bytes[25]};

wire [3:0] version = bytes[0][7:4];
wire [3:0] ihl = bytes[0][3:0];
wire mf = bytes[6][5];
wire [12:0] frag_offset = {bytes[6][4:0], bytes[7]};
wire [7:0] protocol = bytes[9];

reg [15:0] checksum_acc;
reg [17:0] udp_checksum_acc;
reg [9:0] checksum_cnt;
reg [9:0] udp_checksum_cnt;
reg checksum_done;
reg udp_checksum_done;

reg [9:0] payload_cnt;
reg [9:0] payload_total;
reg [9:0] output_cnt;

localparam ST_IDLE = 3'd0;
localparam ST_CHECKSUM = 3'd1;
localparam ST_UDPCHECK = 3'd2;
localparam ST_STATUS = 3'd3;
localparam ST_OUTPUT = 3'd4;
localparam ST_DRAIN = 3'd5;

assign s_ready = !rst && (state == ST_IDLE) && !(status_valid_reg && !status_error_reg && state != ST_IDLE);

assign status_valid = status_valid_reg;
assign status_error = status_error_reg;

assign m_src_ip = m_src_ip_reg;
assign m_src_port = m_src_port_reg;
assign m_dst_port = m_dst_port_reg;
assign m_payload_len = m_payload_len_reg;
assign m_data = m_data_reg;
assign m_valid = m_valid_reg;
assign m_last = m_last_reg;

always @(posedge clk) begin
    if (rst) begin
        state <= ST_IDLE;
        n <= 10'd0;
        ptr <= 10'd0;
        status_valid_reg <= 1'b0;
        status_error_reg <= 4'd0;
        m_src_ip_reg <= 32'd0;
        m_src_port_reg <= 16'd0;
        m_dst_port_reg <= 16'd0;
        m_payload_len_reg <= 16'd0;
        m_data_reg <= 8'd0;
        m_valid_reg <= 1'b0;
        m_last_reg <= 1'b0;
        checksum_acc <= 16'd0;
        udp_checksum_acc <= 18'd0;
        checksum_cnt <= 10'd0;
        udp_checksum_cnt <= 10'd0;
        checksum_done <= 1'b0;
        udp_checksum_done <= 1'b0;
        payload_cnt <= 10'd0;
        payload_total <= 10'd0;
        output_cnt <= 10'd0;
        error_code <= 4'd0;
    end else begin
        status_valid_reg <= 1'b0;
        
        case (state)
            ST_IDLE: begin
                m_valid_reg <= 1'b0;
                m_last_reg <= 1'b0;
                if (s_valid && s_ready) begin
                    if (n < 10'd512) begin
                        bytes[n] <= s_data;
                    end
                    n <= n + 10'd1;
                    if (s_last) begin
                        state <= ST_CHECKSUM;
                        checksum_cnt <= 10'd0;
                        checksum_acc <= 16'd0;
                        checksum_done <= 1'b0;
                    end
                end
            end
            
            ST_CHECKSUM: begin
                if (!checksum_done) begin
                    if (checksum_cnt < 10'd20) begin
                        if (checksum_cnt == 10'd0) begin
                            checksum_acc <= {bytes[0], bytes[1]};
                        end else if (checksum_cnt == 10'd2) begin
                            checksum_acc <= checksum_acc + {bytes[2], bytes[3]};
                        end else if (checksum_cnt == 10'd4) begin
                            checksum_acc <= checksum_acc + {bytes[4], bytes[5]};
                        end else if (checksum_cnt == 10'd6) begin
                            checksum_acc <= checksum_acc + {bytes[6], bytes[7]};
                        end else if (checksum_cnt == 10'd8) begin
                            checksum_acc <= checksum_acc + {bytes[8], bytes[9]};
                        end else if (checksum_cnt == 10'd10) begin
                            checksum_acc <= checksum_acc + {bytes[10], bytes[11]};
                        end else if (checksum_cnt == 10'd12) begin
                            checksum_acc <= checksum_acc + {bytes[12], bytes[13]};
                        end else if (checksum_cnt == 10'd14) begin
                            checksum_acc <= checksum_acc + {bytes[14], bytes[15]};
                        end else if (checksum_cnt == 10'd16) begin
                            checksum_acc <= checksum_acc + {bytes[16], bytes[17]};
                        end else if (checksum_cnt == 10'd18) begin
                            checksum_acc <= checksum_acc + {bytes[18], bytes[19]};
                        end
                        checksum_cnt <= checksum_cnt + 10'd2;
                    end else begin
                        checksum_done <= 1'b1;
                    end
                end else begin
                    temp_sum = checksum_acc[15:0] + checksum_acc[16];
                    ip_sum = temp_sum[15:0] + temp_sum[16];
                    
                    ip_len = word16_2_3;
                    udp_len = word16_24_25;
                    payload_len_calc = udp_len - 10'd8;
                    
                    error_code <= 4'd0;
                    
                    if (n < 10'd28 || n > 10'd512 || version != 4'd4 || ihl != 4'd5 || protocol != 8'd17 || mf || frag_offset != 13'd0) begin
                        error_code <= 4'd1;
                        state <= ST_STATUS;
                    end else if (ip_len != n || udp_len != ip_len - 10'd20 || payload_len_calc < 10'd1 || payload_len_calc > 10'd256) begin
                        error_code <= 4'd2;
                        state <= ST_STATUS;
                    end else if (ip_sum != 16'hffff) begin
                        error_code <= 4'd3;
                        state <= ST_STATUS;
                    end else begin
                        state <= ST_UDPCHECK;
                        udp_checksum_cnt <= 10'd0;
                        udp_checksum_acc <= 18'd0;
                        udp_checksum_done <= 1'b0;
                    end
                end
            end
            
            ST_UDPCHECK: begin
                if (!udp_checksum_done) begin
                    if (udp_checksum_cnt == 10'd0) begin
                        udp_checksum_acc <= {bytes[12], bytes[13]};
                    end else if (udp_checksum_cnt == 10'd2) begin
                        udp_checksum_acc <= udp_checksum_acc + {bytes[14], bytes[15]};
                    end else if (udp_checksum_cnt == 10'd4) begin
                        udp_checksum_acc <= udp_checksum_acc + {bytes[16], bytes[17]};
                    end else if (udp_checksum_cnt == 10'd6) begin
                        udp_checksum_acc <= udp_checksum_acc + {bytes[18], bytes[19]};
                    end else if (udp_checksum_cnt == 10'd8) begin
                        udp_checksum_acc <= udp_checksum_acc + 16'd0 + 16'd17;
                    end else if (udp_checksum_cnt == 10'd10) begin
                        udp_checksum_acc <= udp_checksum_acc + udp_len;
                    end else if (udp_checksum_cnt < n) begin
                        if (udp_checksum_cnt + 10'd1 < n) begin
                            udp_checksum_acc <= udp_checksum_acc + {bytes[udp_checksum_cnt], bytes[udp_checksum_cnt + 10'd1]};
                            udp_checksum_cnt <= udp_checksum_cnt + 10'd2;
                        end else begin
                            udp_checksum_acc <= udp_checksum_acc + {bytes[udp_checksum_cnt], 8'd0};
                            udp_checksum_cnt <= udp_checksum_cnt + 10'd2;
                        end
                    end else begin
                        udp_checksum_done <= 1'b1;
                    end
                end else begin
                    temp_sum = udp_checksum_acc[15:0] + udp_checksum_acc[17:16];
                    udp_sum = temp_sum[15:0] + temp_sum[16];
                    
                    if (word16_24_25 == 16'd0) begin
                        error_code <= 4'd0;
                    end else begin
                        if (udp_sum != 16'hffff) begin
                            error_code <= 4'd4;
                        end else begin
                            error_code <= 4'd0;
                        end
                    end
                    
                    if (error_code == 4'd0) begin
                        if (dst_ip != 32'h0a000002 || dst_port != 16'd9000) begin
                            error_code <= 4'd5;
                        end
                    end
                    
                    state <= ST_STATUS;
                end
            end
            
            ST_STATUS: begin
                status_valid_reg <= 1'b1;
                status_error_reg <= error_code;
                
                if (error_code == 4'd0) begin
                    m_src_ip_reg <= src_ip;
                    m_src_port_reg <= src_port;
                    m_dst_port_reg <= dst_port;
                    m_payload_len_reg <= payload_len_calc;
                    payload_total <= payload_len_calc;
                    output_cnt <= 10'd0;
                    ptr <= 10'd28;
                    state <= ST_OUTPUT;
                end else begin
                    state <= ST_IDLE;
                    n <= 10'd0;
                end
            end
            
            ST_OUTPUT: begin
                if (output_cnt < payload_total) begin
                    m_data_reg <= bytes[ptr];
                    m_valid_reg <= 1'b1;
                    m_last_reg <= (output_cnt == payload_total - 10'd1);
                    
                    if (m_ready) begin
                        ptr <= ptr + 10'd1;
                        output_cnt <= output_cnt + 10'd1;
                        if (output_cnt == payload_total - 10'd1) begin
                            m_valid_reg <= 1'b0;
                            m_last_reg <= 1'b0;
                            state <= ST_DRAIN;
                        end
                    end
                end else begin
                    m_valid_reg <= 1'b0;
                    m_last_reg <= 1'b0;
                    state <= ST_DRAIN;
                end
            end
            
            ST_DRAIN: begin
                m_valid_reg <= 1'b0;
                m_last_reg <= 1'b0;
                state <= ST_IDLE;
                n <= 10'd0;
            end
            
            default: begin
                state <= ST_IDLE;
                n <= 10'd0;
            end
        endcase
    end
end

endmodule
