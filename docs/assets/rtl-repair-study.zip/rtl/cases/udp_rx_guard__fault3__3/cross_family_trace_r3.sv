`timescale 1ns/1ps
`default_nettype none

module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error
);

localparam ST_IDLE     = 3'd0;
localparam ST_COLLECT  = 3'd1;
localparam ST_CLASSIFY = 3'd2;
localparam ST_OUTPUT   = 3'd3;

reg [2:0] state_reg;

reg [7:0] frame_mem[0:511];
reg [9:0] frame_len_reg;
reg oversize_reg;

reg [3:0] status_error_reg;
reg status_valid_reg;

reg [31:0] out_src_ip_reg;
reg [15:0] out_src_port_reg;
reg [15:0] out_dst_port_reg;
reg [15:0] out_payload_len_reg;

reg [9:0] out_index_reg;
reg out_active_reg;
reg [7:0] m_data_reg;
reg m_valid_reg;
reg m_last_reg;

wire busy_output;
assign busy_output = (state_reg == ST_OUTPUT) || out_active_reg;
assign s_ready = !rst && (state_reg == ST_IDLE || state_reg == ST_COLLECT) && !busy_output;

assign m_data = m_data_reg;
assign m_valid = m_valid_reg;
assign m_last = m_last_reg;
assign m_src_ip = out_src_ip_reg;
assign m_src_port = out_src_port_reg;
assign m_dst_port = out_dst_port_reg;
assign m_payload_len = out_payload_len_reg;
assign status_valid = status_valid_reg;
assign status_error = status_error_reg;

always @(posedge clk) begin
    if (rst) begin
        state_reg <= ST_IDLE;
        frame_len_reg <= 10'd0;
        oversize_reg <= 1'b0;
        status_error_reg <= 4'd0;
        status_valid_reg <= 1'b0;
        out_src_ip_reg <= 32'd0;
        out_src_port_reg <= 16'd0;
        out_dst_port_reg <= 16'd0;
        out_payload_len_reg <= 16'd0;
        out_index_reg <= 10'd0;
        out_active_reg <= 1'b0;
        m_data_reg <= 8'd0;
        m_valid_reg <= 1'b0;
        m_last_reg <= 1'b0;
    end else begin
        status_valid_reg <= 1'b0;

        if (out_active_reg) begin
            m_valid_reg <= 1'b1;
            m_data_reg <= frame_mem[10'd28 + out_index_reg];
            m_last_reg <= (out_index_reg == out_payload_len_reg - 16'd1);
            if (m_ready) begin
                if (out_index_reg == out_payload_len_reg - 16'd1) begin
                    out_active_reg <= 1'b0;
                    m_valid_reg <= 1'b0;
                    m_last_reg <= 1'b0;
                    state_reg <= ST_IDLE;
                    frame_len_reg <= 10'd0;
                    oversize_reg <= 1'b0;
                end else begin
                    out_index_reg <= out_index_reg + 10'd1;
                end
            end
        end else begin
            m_valid_reg <= 1'b0;
            m_last_reg <= 1'b0;

            case (state_reg)
                ST_IDLE: begin
                    frame_len_reg <= 10'd0;
                    oversize_reg <= 1'b0;
                    if (s_valid && s_ready) begin
                        frame_mem[0] <= s_data;
                        frame_len_reg <= 10'd1;
                        if (s_last) begin
                            state_reg <= ST_CLASSIFY;
                        end else begin
                            state_reg <= ST_COLLECT;
                        end
                    end
                end

                ST_COLLECT: begin
                    if (s_valid && s_ready) begin
                        if (frame_len_reg < 10'd512) begin
                            frame_mem[frame_len_reg] <= s_data;
                        end else begin
                            oversize_reg <= 1'b1;
                        end
                        frame_len_reg <= frame_len_reg + 10'd1;
                        if (s_last) begin
                            state_reg <= ST_CLASSIFY;
                        end
                    end
                end

                ST_CLASSIFY: begin
                    automatic reg [3:0] cerr = 4'd0;
                    automatic reg [31:0] c_src_ip = 32'd0;
                    automatic reg [15:0] c_src_port = 16'd0;
                    automatic reg [15:0] c_dst_port = 16'd0;
                    automatic reg [15:0] c_plen = 16'd0;
                    automatic reg c_accept = 1'b0;

                    automatic reg [15:0] ip_totlen = 16'd0;
                    automatic reg [15:0] udp_len = 16'd0;
                    automatic reg [15:0] udp_cksum = 16'd0;
                    automatic reg [31:0] v_src_ip = 32'd0;
                    automatic reg [31:0] v_dst_ip = 32'd0;
                    automatic reg [15:0] v_sport = 16'd0;
                    automatic reg [15:0] v_dport = 16'd0;
                    automatic reg [15:0] v_plen = 16'd0;
                    automatic reg [31:0] sum32 = 32'd0;
                    automatic reg [15:0] folded16 = 16'd0;
                    automatic reg [15:0] w = 16'd0;
                    automatic integer j;

                    if ((frame_len_reg < 10'd28) || oversize_reg ||
                        (frame_mem[0][7:4] != 4'd4) ||
                        (frame_mem[0][3:0] != 4'd5) ||
                        (frame_mem[9] != 8'd17) ||
                        (frame_mem[6][5] != 1'b0) ||
                        ({frame_mem[6][4:0], frame_mem[7]} != 13'd0)) begin
                        cerr = 4'd1;
                    end else begin
                        ip_totlen = {frame_mem[2], frame_mem[3]};
                        udp_len = {frame_mem[24], frame_mem[25]};
                        v_plen = udp_len - 16'd8;

                        if ((ip_totlen != frame_len_reg) ||
                            (udp_len != (ip_totlen - 16'd20)) ||
                            (v_plen < 16'd1) ||
                            (v_plen > 16'd256)) begin
                            cerr = 4'd2;
                        end else begin
                            sum32 = 32'd0;
                            for (j = 0; j < 20; j = j + 2) begin
                                w = {frame_mem[j[9:0]], frame_mem[j[9:0]+10'd1]};
                                sum32 = sum32 + w;
                            end
                            while (sum32[31:16] != 16'd0) begin
                                sum32 = sum32[15:0] + sum32[31:16];
                            end
                            folded16 = sum32[15:0];
                            if (folded16 != 16'hffff) begin
                                cerr = 4'd3;
                            end else begin
                                udp_cksum = {frame_mem[26], frame_mem[27]};
                                if (udp_cksum != 16'd0) begin
                                    sum32 = 32'd0;
                                    sum32 = sum32 + {frame_mem[12], frame_mem[13]};
                                    sum32 = sum32 + {frame_mem[14], frame_mem[15]};
                                    sum32 = sum32 + {frame_mem[16], frame_mem[17]};
                                    sum32 = sum32 + {frame_mem[18], frame_mem[19]};
                                    sum32 = sum32 + 16'h0011;
                                    sum32 = sum32 + udp_len;
                                    for (j = 20; j < 20 + udp_len; j = j + 2) begin
                                        if (j + 1 < 20 + udp_len) begin
                                            w = {frame_mem[j[9:0]], frame_mem[j[9:0]+10'd1]};
                                        end else begin
                                            w = {frame_mem[j[9:0]], 8'h00};
                                        end
                                        sum32 = sum32 + w;
                                    end
                                    while (sum32[31:16] != 16'd0) begin
                                        sum32 = sum32[15:0] + sum32[31:16];
                                    end
                                    folded16 = sum32[15:0];
                                    if (folded16 != 16'hffff) begin
                                        cerr = 4'd4;
                                    end
                                end
                                if (cerr == 4'd0) begin
                                    v_dst_ip = {frame_mem[16], frame_mem[17], frame_mem[18], frame_mem[19]};
                                    v_dport = {frame_mem[22], frame_mem[23]};
                                    if ((v_dst_ip != 32'h0a000002) || (v_dport != 16'd9000)) begin
                                        cerr = 4'd5;
                                    end else begin
                                        c_src_ip = {frame_mem[12], frame_mem[13], frame_mem[14], frame_mem[15]};
                                        c_src_port = {frame_mem[20], frame_mem[21]};
                                        c_dst_port = v_dport;
                                        c_plen = v_plen;
                                        c_accept = 1'b1;
                                    end
                                end
                            end
                        end
                    end

                    status_error_reg <= cerr;
                    status_valid_reg <= 1'b1;

                    if (c_accept) begin
                        out_src_ip_reg <= c_src_ip;
                        out_src_port_reg <= c_src_port;
                        out_dst_port_reg <= c_dst_port;
                        out_payload_len_reg <= c_plen;
                        out_index_reg <= 10'd0;
                        out_active_reg <= 1'b1;
                        state_reg <= ST_OUTPUT;
                    end else begin
                        state_reg <= ST_IDLE;
                        frame_len_reg <= 10'd0;
                        oversize_reg <= 1'b0;
                    end
                end

                ST_OUTPUT: begin
                    if (!out_active_reg) begin
                        state_reg <= ST_IDLE;
                    end
                end

                default: begin
                    state_reg <= ST_IDLE;
                end
            endcase
        end
    end
end

endmodule
