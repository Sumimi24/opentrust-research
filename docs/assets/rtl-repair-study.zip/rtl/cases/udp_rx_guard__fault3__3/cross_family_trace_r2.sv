module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error
);

localparam ST_IDLE        = 3'd0;
localparam ST_COLLECT     = 3'd1;
localparam ST_CLASSIFY    = 3'd2;
localparam ST_STATUS      = 3'd3;
localparam ST_OUTPUT      = 3'd4;

reg [2:0] state_reg;

reg [7:0] frame_mem[0:511];
reg [9:0] frame_len_reg;
reg oversize_reg;

reg [3:0] status_error_reg;
reg status_valid_reg;

reg [31:0] out_src_ip_reg;
reg [15:0] out_src_port_reg;
reg [15:0] out_dst_port_reg;
reg [15:0] out_payload_len_reg;

reg [9:0] out_index_reg;
reg out_active_reg;
reg [7:0] m_data_reg;
reg m_valid_reg;
reg m_last_reg;

reg [3:0] classify_error;
reg [31:0] classify_src_ip;
reg [15:0] classify_src_port;
reg [15:0] classify_dst_port;
reg [15:0] classify_payload_len;
reg classify_accept;

reg [15:0] ip_total_length;
reg [15:0] udp_length;
reg [15:0] udp_checksum_field;
reg [31:0] src_ip_v;
reg [31:0] dst_ip_v;
reg [15:0] src_port_v;
reg [15:0] dst_port_v;
reg [15:0] payload_len_v;

reg [31:0] sum32;
reg [15:0] folded16;
reg [15:0] w;
integer i;

wire busy_output;
assign busy_output = (state_reg == ST_OUTPUT) || out_active_reg;
assign s_ready = !rst && (state_reg == ST_IDLE || state_reg == ST_COLLECT) && !busy_output;

assign m_data = m_data_reg;
assign m_valid = m_valid_reg;
assign m_last = m_last_reg;
assign m_src_ip = out_src_ip_reg;
assign m_src_port = out_src_port_reg;
assign m_dst_port = out_dst_port_reg;
assign m_payload_len = out_payload_len_reg;
assign status_valid = status_valid_reg;
assign status_error = status_error_reg;

always @(posedge clk) begin
    if (rst) begin
        state_reg <= ST_IDLE;
        frame_len_reg <= 10'd0;
        oversize_reg <= 1'b0;
        status_error_reg <= 4'd0;
        status_valid_reg <= 1'b0;
        out_src_ip_reg <= 32'd0;
        out_src_port_reg <= 16'd0;
        out_dst_port_reg <= 16'd0;
        out_payload_len_reg <= 16'd0;
        out_index_reg <= 10'd0;
        out_active_reg <= 1'b0;
        m_data_reg <= 8'd0;
        m_valid_reg <= 1'b0;
        m_last_reg <= 1'b0;
    end else begin
        status_valid_reg <= 1'b0;

        if (out_active_reg) begin
            m_valid_reg <= 1'b1;
            m_data_reg <= frame_mem[10'd28 + out_index_reg];
            m_last_reg <= (out_index_reg == out_payload_len_reg - 16'd1);
            if (m_ready) begin
                if (out_index_reg == out_payload_len_reg - 16'd1) begin
                    out_active_reg <= 1'b0;
                    m_valid_reg <= 1'b0;
                    m_last_reg <= 1'b0;
                    state_reg <= ST_IDLE;
                    frame_len_reg <= 10'd0;
                    oversize_reg <= 1'b0;
                end else begin
                    out_index_reg <= out_index_reg + 10'd1;
                end
            end
        end else begin
            m_valid_reg <= 1'b0;
            m_last_reg <= 1'b0;

            case (state_reg)
                ST_IDLE: begin
                    frame_len_reg <= 10'd0;
                    oversize_reg <= 1'b0;
                    if (s_valid && s_ready) begin
                        frame_mem[0] <= s_data;
                        frame_len_reg <= 10'd1;
                        if (s_last) begin
                            state_reg <= ST_CLASSIFY;
                        end else begin
                            state_reg <= ST_COLLECT;
                        end
                    end
                end

                ST_COLLECT: begin
                    if (s_valid && s_ready) begin
                        if (frame_len_reg < 10'd512) begin
                            frame_mem[frame_len_reg] <= s_data;
                        end else begin
                            oversize_reg <= 1'b1;
                        end
                        frame_len_reg <= frame_len_reg + 10'd1;
                        if (s_last) begin
                            state_reg <= ST_CLASSIFY;
                        end
                    end
                end

                ST_CLASSIFY: begin
                    classify_error = 4'd0;
                    classify_src_ip = 32'd0;
                    classify_src_port = 16'd0;
                    classify_dst_port = 16'd0;
                    classify_payload_len = 16'd0;
                    classify_accept = 1'b0;

                    ip_total_length = 16'd0;
                    udp_length = 16'd0;
                    udp_checksum_field = 16'd0;
                    src_ip_v = 32'd0;
                    dst_ip_v = 32'd0;
                    src_port_v = 16'd0;
                    dst_port_v = 16'd0;
                    payload_len_v = 16'd0;

                    if ((frame_len_reg < 10'd28) || oversize_reg ||
                        (frame_mem[0][7:4] != 4'd4) ||
                        (frame_mem[0][3:0] != 4'd5) ||
                        (frame_mem[9] != 8'd17) ||
                        (frame_mem[6][5] != 1'b0) ||
                        ({frame_mem[6][4:0], frame_mem[7]} != 13'd0)) begin
                        classify_error = 4'd1;
                    end else begin
                        ip_total_length = {frame_mem[2], frame_mem[3]};
                        udp_length = {frame_mem[24], frame_mem[25]};
                        payload_len_v = {frame_mem[24], frame_mem[25]} - 16'd8;

                        if ((ip_total_length != frame_len_reg) ||
                            (udp_length != (ip_total_length - 16'd20)) ||
                            (payload_len_v < 16'd1) ||
                            (payload_len_v > 16'd256)) begin
                            classify_error = 4'd2;
                        end else begin
                            sum32 = 32'd0;
                            for (i = 0; i < 20; i = i + 2) begin
                                w = {frame_mem[i[9:0]], frame_mem[(i+1)]};
                                sum32 = sum32 + w;
                            end
                            while (sum32[31:16] != 16'd0) begin
                                sum32 = sum32[15:0] + sum32[31:16];
                            end
                            folded16 = sum32[15:0];
                            if (folded16 != 16'hffff) begin
                                classify_error = 4'd3;
                            end else begin
                                udp_checksum_field = {frame_mem[26], frame_mem[27]};
                                if (udp_checksum_field != 16'd0) begin
                                    sum32 = 32'd0;
                                    sum32 = sum32 + {frame_mem[12], frame_mem[13]};
                                    sum32 = sum32 + {frame_mem[14], frame_mem[15]};
                                    sum32 = sum32 + {frame_mem[16], frame_mem[17]};
                                    sum32 = sum32 + {frame_mem[18], frame_mem[19]};
                                    sum32 = sum32 + 16'h0011;
                                    sum32 = sum32 + {frame_mem[24], frame_mem[25]};
                                    for (i = 20; i < 20 + udp_length; i = i + 2) begin
                                        if (i + 1 < 20 + udp_length) begin
                                            w = {frame_mem[i[9:0]], frame_mem[(i+1)]};
                                        end else begin
                                            w = {frame_mem[i[9:0]], 8'h00};
                                        end
                                        sum32 = sum32 + w;
                                    end
                                    while (sum32[31:16] != 16'd0) begin
                                        sum32 = sum32[15:0] + sum32[31:16];
                                    end
                                    folded16 = sum32[15:0];
                                    if (folded16 != 16'hffff) begin
                                        classify_error = 4'd4;
                                    end
                                end
                                if (classify_error == 4'd0) begin
                                    dst_ip_v = {frame_mem[16], frame_mem[17], frame_mem[18], frame_mem[19]};
                                    dst_port_v = {frame_mem[22], frame_mem[23]};
                                    if ((dst_ip_v != 32'h0a000002) || (dst_port_v != 16'd9000)) begin
                                        classify_error = 4'd5;
                                    end else begin
                                        classify_src_ip = {frame_mem[12], frame_mem[13], frame_mem[14], frame_mem[15]};
                                        classify_src_port = {frame_mem[20], frame_mem[21]};
                                        classify_dst_port = dst_port_v;
                                        classify_payload_len = payload_len_v;
                                        classify_accept = 1'b1;
                                    end
                                end
                            end
                        end
                    end

                    status_error_reg <= classify_error;
                    status_valid_reg <= 1'b1;

                    if (classify_accept) begin
                        out_src_ip_reg <= classify_src_ip;
                        out_src_port_reg <= classify_src_port;
                        out_dst_port_reg <= classify_dst_port;
                        out_payload_len_reg <= classify_payload_len;
                        out_index_reg <= 10'd0;
                        out_active_reg <= 1'b1;
                        state_reg <= ST_OUTPUT;
                    end else begin
                        state_reg <= ST_IDLE;
                        frame_len_reg <= 10'd0;
                        oversize_reg <= 1'b0;
                    end
                end

                ST_STATUS: begin
                    state_reg <= ST_IDLE;
                end

                ST_OUTPUT: begin
                    if (!out_active_reg) begin
                        state_reg <= ST_IDLE;
                    end
                end

                default: begin
                    state_reg <= ST_IDLE;
                end
            endcase
        end
    end
end

endmodule
