module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error
);

localparam ST_RECV    = 3'd0;
localparam ST_CLASS   = 3'd1;
localparam ST_STATUS  = 3'd2;
localparam ST_OUT     = 3'd3;

reg [2:0] state_reg = ST_RECV;

reg [7:0] frame_mem [0:511];

reg [9:0] frame_len_reg = 10'd0;
reg oversize_reg = 1'b0;

reg [3:0] error_reg = 4'd0;

reg [15:0] ip_total_length_reg = 16'd0;
reg [15:0] udp_length_reg = 16'd0;
reg [15:0] udp_payload_len_reg = 16'd0;

reg [31:0] src_ip_reg = 32'd0;
reg [31:0] dst_ip_reg = 32'd0;
reg [15:0] src_port_reg = 16'd0;
reg [15:0] dst_port_reg = 16'd0;

reg [8:0] out_index_reg = 9'd0;
reg [7:0] m_data_reg = 8'd0;
reg m_valid_reg = 1'b0;
reg m_last_reg = 1'b0;
reg [31:0] m_src_ip_reg = 32'd0;
reg [15:0] m_src_port_reg = 16'd0;
reg [15:0] m_dst_port_reg = 16'd0;
reg [15:0] m_payload_len_reg = 16'd0;

reg status_valid_reg = 1'b0;
reg [3:0] status_error_reg = 4'd0;

integer i;
reg [31:0] sum32;
reg [15:0] fold16;
reg [15:0] udp_checksum_field;
reg [15:0] ip_word;
reg [15:0] udp_word;
reg [8:0] payload_start;
reg [8:0] payload_end;
reg [3:0] next_error;

assign s_ready = (state_reg == ST_RECV);
assign m_data = m_data_reg;
assign m_valid = m_valid_reg;
assign m_last = m_last_reg;
assign m_src_ip = m_src_ip_reg;
assign m_src_port = m_src_port_reg;
assign m_dst_port = m_dst_port_reg;
assign m_payload_len = m_payload_len_reg;
assign status_valid = status_valid_reg;
assign status_error = status_error_reg;

always @(posedge clk) begin
    if (rst) begin
        state_reg <= ST_RECV;
        frame_len_reg <= 10'd0;
        oversize_reg <= 1'b0;
        error_reg <= 4'd0;
        ip_total_length_reg <= 16'd0;
        udp_length_reg <= 16'd0;
        udp_payload_len_reg <= 16'd0;
        src_ip_reg <= 32'd0;
        dst_ip_reg <= 32'd0;
        src_port_reg <= 16'd0;
        dst_port_reg <= 16'd0;
        out_index_reg <= 9'd0;
        m_data_reg <= 8'd0;
        m_valid_reg <= 1'b0;
        m_last_reg <= 1'b0;
        m_src_ip_reg <= 32'd0;
        m_src_port_reg <= 16'd0;
        m_dst_port_reg <= 16'd0;
        m_payload_len_reg <= 16'd0;
        status_valid_reg <= 1'b0;
        status_error_reg <= 4'd0;
    end else begin
        status_valid_reg <= 1'b0;

        if (m_valid_reg && m_ready) begin
            if (m_last_reg) begin
                m_valid_reg <= 1'b0;
                m_last_reg <= 1'b0;
                state_reg <= ST_RECV;
                frame_len_reg <= 10'd0;
                oversize_reg <= 1'b0;
            end else begin
                out_index_reg <= out_index_reg + 9'd1;
                m_data_reg <= frame_mem[28 + out_index_reg + 9'd1];
                m_last_reg <= ((out_index_reg + 9'd1) == (udp_payload_len_reg - 16'd1));
            end
        end

        case (state_reg)
            ST_RECV: begin
                if (s_valid) begin
                    if (frame_len_reg < 10'd512) begin
                        frame_mem[frame_len_reg] <= s_data;
                    end else begin
                        oversize_reg <= 1'b1;
                    end

                    if (s_last) begin
                        if (frame_len_reg >= 10'd512) begin
                            oversize_reg <= 1'b1;
                        end
                        frame_len_reg <= frame_len_reg + 10'd1;
                        state_reg <= ST_CLASS;
                    end else begin
                        frame_len_reg <= frame_len_reg + 10'd1;
                    end
                end
            end

            ST_CLASS: begin
                next_error = 4'd0;

                ip_total_length_reg <= {frame_mem[2], frame_mem[3]};
                udp_length_reg <= {frame_mem[24], frame_mem[25]};
                udp_payload_len_reg <= {frame_mem[24], frame_mem[25]} - 16'd8;
                src_ip_reg <= {frame_mem[12], frame_mem[13], frame_mem[14], frame_mem[15]};
                dst_ip_reg <= {frame_mem[16], frame_mem[17], frame_mem[18], frame_mem[19]};
                src_port_reg <= {frame_mem[20], frame_mem[21]};
                dst_port_reg <= {frame_mem[22], frame_mem[23]};

                if (frame_len_reg < 10'd28 || oversize_reg || frame_len_reg > 10'd512) begin
                    next_error = 4'd1;
                end else if (frame_mem[0][7:4] != 4'h4) begin
                    next_error = 4'd1;
                end else if (frame_mem[0][3:0] != 4'h5) begin
                    next_error = 4'd1;
                end else if (frame_mem[9] != 8'd17) begin
                    next_error = 4'd1;
                end else if (frame_mem[6][5] != 1'b0 || frame_mem[6][4:0] != 5'd0 || frame_mem[7] != 8'd0) begin
                    next_error = 4'd1;
                end else if ({frame_mem[2], frame_mem[3]} != frame_len_reg) begin
                    next_error = 4'd2;
                end else if ({frame_mem[24], frame_mem[25]} != ({frame_mem[2], frame_mem[3]} - 16'd20)) begin
                    next_error = 4'd2;
                end else if (({frame_mem[24], frame_mem[25]} - 16'd8) < 16'd1 || ({frame_mem[24], frame_mem[25]} - 16'd8) > 16'd256) begin
                    next_error = 4'd2;
                end else begin
                    sum32 = 32'd0;
                    for (i = 0; i < 20; i = i + 2) begin
                        ip_word = {frame_mem[i], frame_mem[i+1]};
                        sum32 = sum32 + ip_word;
                    end
                    while (sum32[31:16] != 16'd0) begin
                        sum32 = sum32[15:0] + sum32[31:16];
                    end
                    fold16 = sum32[15:0];
                    if (fold16 != 16'hffff) begin
                        next_error = 4'd3;
                    end else begin
                        udp_checksum_field = {frame_mem[26], frame_mem[27]};
                        if (udp_checksum_field != 16'd0) begin
                            sum32 = 32'd0;
                            sum32 = sum32 + {frame_mem[12], frame_mem[13]};
                            sum32 = sum32 + {frame_mem[14], frame_mem[15]};
                            sum32 = sum32 + {frame_mem[16], frame_mem[17]};
                            sum32 = sum32 + {frame_mem[18], frame_mem[19]};
                            sum32 = sum32 + 16'h0011;
                            sum32 = sum32 + {frame_mem[24], frame_mem[25]};
                            for (i = 20; i < frame_len_reg; i = i + 2) begin
                                if (i + 1 < frame_len_reg) begin
                                    udp_word = {frame_mem[i], frame_mem[i+1]};
                                end else begin
                                    udp_word = {frame_mem[i], 8'h00};
                                end
                                sum32 = sum32 + udp_word;
                            end
                            while (sum32[31:16] != 16'd0) begin
                                sum32 = sum32[15:0] + sum32[31:16];
                            end
                            fold16 = sum32[15:0];
                            if (fold16 != 16'hffff) begin
                                next_error = 4'd4;
                            end else if ({frame_mem[16], frame_mem[17], frame_mem[18], frame_mem[19]} != 32'h0a000002 ||
                                         {frame_mem[22], frame_mem[23]} != 16'd9000) begin
                                next_error = 4'd5;
                            end
                        end else if ({frame_mem[16], frame_mem[17], frame_mem[18], frame_mem[19]} != 32'h0a000002 ||
                                     {frame_mem[22], frame_mem[23]} != 16'd9000) begin
                            next_error = 4'd5;
                        end
                    end
                end

                error_reg <= next_error;
                status_error_reg <= next_error;
                status_valid_reg <= 1'b1;
                state_reg <= ST_STATUS;
            end

            ST_STATUS: begin
                if (error_reg == 4'd0) begin
                    m_src_ip_reg <= src_ip_reg;
                    m_src_port_reg <= src_port_reg;
                    m_dst_port_reg <= dst_port_reg;
                    m_payload_len_reg <= udp_payload_len_reg;
                    out_index_reg <= 9'd0;
                    m_data_reg <= frame_mem[28];
                    m_last_reg <= (udp_payload_len_reg == 16'd1);
                    m_valid_reg <= 1'b1;
                    state_reg <= ST_OUT;
                end else begin
                    frame_len_reg <= 10'd0;
                    oversize_reg <= 1'b0;
                    state_reg <= ST_RECV;
                end
            end

            ST_OUT: begin
            end

            default: begin
                state_reg <= ST_RECV;
            end
        endcase
    end
end

endmodule
