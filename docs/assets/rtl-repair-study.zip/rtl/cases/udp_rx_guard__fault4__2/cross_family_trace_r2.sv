module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

reg [7:0] bytes[0:511];
integer n, ptr, state;
reg status_valid_reg;
reg [3:0] status_error_reg;

function automatic [15:0] word16(input integer offset);
    word16 = {bytes[offset], bytes[offset+1]};
endfunction

function automatic [15:0] fold16(input [31:0] value);
    reg [16:0] v;
    v = value[15:0] + value[31:16];
    fold16 = v[15:0] + v[16];
endfunction

reg [15:0] ip_sum;
reg [31:0] udp_sum;
reg [15:0] udp_len_calc;
reg [15:0] ip_len_calc;
reg [3:0] error_code;

wire [7:0] parsed_data;
wire       parsed_valid;
wire       parsed_ready;
wire       parsed_last;
wire [31:0] parsed_src_ip;
wire [15:0] parsed_src_port;
wire [15:0] parsed_dst_port;
wire [15:0] parsed_length;

reg        payload_fifo_valid;
reg [7:0]  payload_fifo_data;
reg        payload_fifo_last;
reg [31:0] payload_fifo_src_ip;
reg [15:0] payload_fifo_src_port;
reg [15:0] payload_fifo_dst_port;
reg [15:0] payload_fifo_len;

assign m_data         = payload_fifo_data;
assign m_valid        = payload_fifo_valid;
assign m_last         = payload_fifo_last;
assign m_src_ip       = payload_fifo_src_ip;
assign m_src_port     = payload_fifo_src_port;
assign m_dst_port     = payload_fifo_dst_port;
assign m_payload_len  = payload_fifo_len;
assign status_valid   = status_valid_reg;
assign status_error   = status_error_reg;

reg hdr_ready;
reg parse_ready;

udp_ip_rx parser(
    .clk(clk),
    .rst(rst),
    .s_ip_hdr_valid(state == 2),
    .s_ip_hdr_ready(hdr_ready),
    .s_eth_dest_mac(48'b0),
    .s_eth_src_mac(48'b0),
    .s_eth_type(16'h0800),
    .s_ip_version(bytes[0][7:4]),
    .s_ip_ihl(bytes[0][3:0]),
    .s_ip_dscp(bytes[1][7:2]),
    .s_ip_ecn(bytes[1][1:0]),
    .s_ip_length({bytes[2], bytes[3]}),
    .s_ip_identification({bytes[4], bytes[5]}),
    .s_ip_flags(bytes[6][7:5]),
    .s_ip_fragment_offset({bytes[6][4:0], bytes[7]}),
    .s_ip_ttl(bytes[8]),
    .s_ip_protocol(bytes[9]),
    .s_ip_header_checksum({bytes[10], bytes[11]}),
    .s_ip_source_ip({bytes[12], bytes[13], bytes[14], bytes[15]}),
    .s_ip_dest_ip({bytes[16], bytes[17], bytes[18], bytes[19]}),
    .s_ip_payload_axis_tdata(bytes[ptr]),
    .s_ip_payload_axis_tvalid(state == 3),
    .s_ip_payload_axis_tready(parse_ready),
    .s_ip_payload_axis_tlast(ptr == n-1),
    .s_ip_payload_axis_tuser(1'b0),
    .m_udp_hdr_ready(1'b1),
    .m_ip_source_ip(parsed_src_ip),
    .m_udp_source_port(parsed_src_port),
    .m_udp_dest_port(parsed_dst_port),
    .m_udp_length(parsed_length),
    .m_udp_payload_axis_tdata(parsed_data),
    .m_udp_payload_axis_tvalid(parsed_valid),
    .m_udp_payload_axis_tready(parsed_ready),
    .m_udp_payload_axis_tlast(parsed_last)
);

assign parsed_ready = !payload_fifo_valid || m_ready;

integer i;
reg [31:0] temp_sum;

always @(posedge clk) begin
    if (rst) begin
        state <= 0;
        n <= 0;
        ptr <= 20;
        status_valid_reg <= 0;
        status_error_reg <= 0;
        payload_fifo_valid <= 0;
        s_ready_reg <= 1;
        hdr_ready <= 0;
        parse_ready <= 0;
        error_code <= 0;
        ip_sum <= 0;
        udp_sum <= 0;
    end else begin
        status_valid_reg <= 0;
        hdr_ready <= 0;
        parse_ready <= 0;

        case (state)
        0: begin
            if (s_valid) begin
                if (n < 512)
                    bytes[n] <= s_data;
                n <= n + 1;
                if (s_last) begin
                    state <= 1;
                    s_ready_reg <= 0;
                end
            end
        end

        1: begin
            error_code <= 0;
            ip_len_calc = {bytes[2], bytes[3]};
            udp_len_calc = {bytes[24], bytes[25]};
            
            if (n < 28 || n > 512)
                error_code <= 1;
            else if (bytes[0][7:4] != 4 || bytes[0][3:0] != 5)
                error_code <= 1;
            else if (bytes[9] != 17)
                error_code <= 1;
            else if (bytes[6][5] != 0 || bytes[6][4:0] != 0 || bytes[7] != 0)
                error_code <= 1;
            else if (ip_len_calc != n[15:0])
                error_code <= 2;
            else if (udp_len_calc != ip_len_calc - 20)
                error_code <= 2;
            else if (udp_len_calc < 9 || udp_len_calc > 264)
                error_code <= 2;
            else begin
                ip_sum = 0;
                for (i = 0; i < 20; i = i + 2) begin
                    ip_sum = ip_sum + word16(i);
                end
                if (fold16({16'b0, ip_sum}) != 16'hFFFF)
                    error_code <= 3;
                else begin
                    temp_sum = 0;
                    for (i = 12; i < 20; i = i + 2) begin
                        temp_sum = temp_sum + word16(i);
                    end
                    temp_sum = temp_sum + 17 + udp_len_calc;
                    for (i = 20; i < n; i = i + 2) begin
                        if (i + 1 < n)
                            temp_sum = temp_sum + word16(i);
                        else
                            temp_sum = temp_sum + {bytes[i], 8'b0};
                    end
                    if ({bytes[26], bytes[27]} != 0) begin
                        if (fold16(temp_sum[31:16] + temp_sum[15:0]) != 16'hFFFF)
                            error_code <= 4;
                    end
                    if ({bytes[16], bytes[17], bytes[18], bytes[19]} != 32'h0a000002)
                        error_code <= 5;
                    else if ({bytes[22], bytes[23]} != 9000)
                        error_code <= 5;
                end
            end
            
            status_valid_reg <= 1;
            status_error_reg <= error_code;
            if (error_code == 0) begin
                state <= 2;
                ptr <= 20;
            end else begin
                state <= 0;
                n <= 0;
                s_ready_reg <= 1;
            end
        end

        2: begin
            hdr_ready <= 1;
            state <= 3;
        end

        3: begin
            parse_ready <= 1;
            if (ptr == n - 1)
                state <= 4;
            else
                ptr <= ptr + 1;
        end

        4: begin
            if (parsed_valid && (payload_fifo_valid == 0 || m_ready)) begin
                payload_fifo_data <= parsed_data;
                payload_fifo_last <= parsed_last;
                payload_fifo_src_ip <= parsed_src_ip;
                payload_fifo_src_port <= parsed_src_port;
                payload_fifo_dst_port <= parsed_dst_port;
                payload_fifo_len <= parsed_length - 8;
                payload_fifo_valid <= 1;
                if (parsed_last)
                    state <= 5;
            end
        end

        5: begin
            if (m_ready) begin
                if (payload_fifo_last) begin
                    payload_fifo_valid <= 0;
                    state <= 0;
                    n <= 0;
                    s_ready_reg <= 1;
                end
            end
        end

        default: state <= 0;
        endcase
    end
end

reg s_ready_reg;
assign s_ready = s_ready_reg && !rst;

endmodule
