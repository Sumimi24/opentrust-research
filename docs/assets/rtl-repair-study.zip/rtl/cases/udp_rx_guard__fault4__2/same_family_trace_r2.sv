module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

reg [7:0] bytes[0:511];
integer n, ptr, state, j;
reg status_valid_reg;
reg [3:0] status_error_reg;

function integer word16(input integer offset);
    word16 = {bytes[offset], bytes[offset+1]};
endfunction

function integer fold(input integer value);
    integer v;
    v = (value & 16'hFFFF) + (value >> 16);
    fold = (v & 16'hFFFF) + (v >> 16);
endfunction

wire [7:0] parsed_data;
wire       parsed_valid;
wire       parsed_ready;
wire       parsed_last;
wire [31:0] parsed_src_ip;
wire [15:0] parsed_src_port;
wire [15:0] parsed_dst_port;
wire [15:0] parsed_length;

reg        payload_fifo_valid;
reg [7:0]  payload_fifo_data;
reg        payload_fifo_last;
reg [31:0] payload_fifo_src_ip;
reg [15:0] payload_fifo_src_port;
reg [15:0] payload_fifo_dst_port;
reg [15:0] payload_fifo_len;

assign m_data         = payload_fifo_data;
assign m_valid        = payload_fifo_valid;
assign m_last         = payload_fifo_last;
assign m_src_ip       = payload_fifo_src_ip;
assign m_src_port     = payload_fifo_src_port;
assign m_dst_port     = payload_fifo_dst_port;
assign m_payload_len  = payload_fifo_len;
assign status_valid   = status_valid_reg;
assign status_error   = status_error_reg;

wire hdr_ready, parse_ready;
wire [3:0] error_code;

assign s_ready = !rst && (state == 0);

always @* begin
    reg [3:0] ec;
    integer ip_len, udp_len, ip_sum, udp_sum, payload_len;
    ip_len = word16(2);
    udp_len = word16(24);
    payload_len = udp_len - 8;
    ip_sum = 0;
    udp_sum = 0;
    ec = 4'd0;
    if (n < 28 || n > 512 || bytes[0] != 8'h45 || bytes[9] != 17 || (bytes[6] & 8'h3f) != 0 || bytes[7] != 0)
        ec = 4'd1;
    else if (ip_len != n || udp_len != ip_len - 20 || payload_len < 1 || payload_len > 256)
        ec = 4'd2;
    else begin
        for (j = 0; j < 20; j = j + 2) ip_sum = ip_sum + word16(j);
        if (fold(ip_sum) != 16'hFFFF)
            ec = 4'd3;
        else begin
            for (j = 12; j < 20; j = j + 2) udp_sum = udp_sum + word16(j);
            udp_sum = udp_sum + 16'd17 + {16'd0, udp_len};
            for (j = 20; j < n; j = j + 2) begin
                udp_sum = udp_sum + {bytes[j], (j+1 < n) ? bytes[j+1] : 8'd0};
            end
            if (word16(26) != 16'd0 && fold(udp_sum) != 16'hFFFF)
                ec = 4'd4;
            if ({bytes[16], bytes[17], bytes[18], bytes[19]} != 32'h0a000002 || word16(22) != 16'd9000)
                ec = 4'd5;
        end
    end
    assign error_code = ec;
end

udp_ip_rx parser(
    .clk(clk),
    .rst(rst),
    .s_ip_hdr_valid(state == 2),
    .s_ip_hdr_ready(hdr_ready),
    .s_eth_dest_mac(48'b0),
    .s_eth_src_mac(48'b0),
    .s_eth_type(16'h0800),
    .s_ip_version(bytes[0][7:4]),
    .s_ip_ihl(bytes[0][3:0]),
    .s_ip_dscp(bytes[1][7:2]),
    .s_ip_ecn(bytes[1][1:0]),
    .s_ip_length({bytes[2], bytes[3]}),
    .s_ip_identification({bytes[4], bytes[5]}),
    .s_ip_flags(bytes[6][7:5]),
    .s_ip_fragment_offset({bytes[6][4:0], bytes[7]}),
    .s_ip_ttl(bytes[8]),
    .s_ip_protocol(bytes[9]),
    .s_ip_header_checksum({bytes[10], bytes[11]}),
    .s_ip_source_ip({bytes[12], bytes[13], bytes[14], bytes[15]}),
    .s_ip_dest_ip({bytes[16], bytes[17], bytes[18], bytes[19]}),
    .s_ip_payload_axis_tdata(bytes[ptr]),
    .s_ip_payload_axis_tvalid(state == 3),
    .s_ip_payload_axis_tready(parse_ready),
    .s_ip_payload_axis_tlast(ptr == n-1),
    .s_ip_payload_axis_tuser(1'b0),
    .m_udp_hdr_ready(1'b1),
    .m_ip_source_ip(parsed_src_ip),
    .m_udp_source_port(parsed_src_port),
    .m_udp_dest_port(parsed_dst_port),
    .m_udp_length(parsed_length),
    .m_udp_payload_axis_tdata(parsed_data),
    .m_udp_payload_axis_tvalid(parsed_valid),
    .m_udp_payload_axis_tready(parsed_ready),
    .m_udp_payload_axis_tlast(parsed_last)
);

assign parsed_ready = !payload_fifo_valid || m_ready;

always @(posedge clk) begin
    if (rst) begin
        state <= 0;
        n <= 0;
        ptr <= 20;
        status_valid_reg <= 0;
        status_error_reg <= 0;
        payload_fifo_valid <= 0;
    end else begin
        status_valid_reg <= 0;

        case (state)
        0: begin
            if (s_valid && s_ready) begin
                if (n < 512)
                    bytes[n] <= s_data;
                n <= n + 1;
                if (s_last)
                    state <= 1;
            end
        end

        1: begin
            status_valid_reg <= 1;
            status_error_reg <= error_code;
            if (error_code == 0) begin
                state <= 2;
                ptr <= 20;
            end else begin
                state <= 0;
                n <= 0;
            end
        end

        2: if (hdr_ready)
            state <= 3;

        3: begin
            if (parse_ready) begin
                if (ptr == n - 1)
                    state <= 4;
                else
                    ptr <= ptr + 1;
            end
        end

        4: begin
            if (parsed_valid && (payload_fifo_valid == 0 || m_ready)) begin
                payload_fifo_data <= parsed_data;
                payload_fifo_last <= parsed_last;
                payload_fifo_src_ip <= parsed_src_ip;
                payload_fifo_src_port <= parsed_src_port;
                payload_fifo_dst_port <= parsed_dst_port;
                payload_fifo_len <= parsed_length - 16'd8;
                payload_fifo_valid <= 1;
                if (parsed_last)
                    state <= 5;
            end
        end

        5: begin
            if (payload_fifo_valid && m_ready) begin
                if (payload_fifo_last) begin
                    payload_fifo_valid <= 0;
                    state <= 0;
                    n <= 0;
                end else begin
                    payload_fifo_valid <= 0;
                end
            end
        end

        default: state <= 0;
        endcase
    end
end

endmodule
