module icache_ctrl(
input wire clk_i,
input wire rst_ni,
input wire req_i,
input wire branch_i,
input wire [31:0] addr_i,
input wire ready_i,
output wire valid_o,
output wire [31:0] rdata_o,
output wire [31:0] addr_o,
output wire err_o,
output wire instr_req_o,
input wire instr_gnt_i,
output wire [31:0] instr_addr_o,
input wire [31:0] instr_rdata_i,
input wire instr_err_i,
input wire instr_rvalid_i,
input wire icache_inval_i,
output wire busy_o);

localparam integer NSETS = 8;
localparam integer NWORDS = 8;
localparam integer OQDEPTH = 32;
localparam integer TAGW = 27;

reg [31:0] cache_data [0:NWORDS-1];
reg [TAGW-1:0] cache_tag [0:NWORDS-1];
reg cache_valid [0:NWORDS-1];

reg [31:0] out_data [0:OQDEPTH-1];
reg [31:0] out_addr_q [0:OQDEPTH-1];
reg out_err_q [0:OQDEPTH-1];
reg [5:0] out_head;
reg [5:0] out_tail;
reg [5:0] out_count;

reg [31:0] req_addr_q [0:OQDEPTH-1];
reg [5:0] req_head;
reg [5:0] req_tail;
reg [5:0] req_count;

reg [31:0] pc_q;
reg branch_seen_q;
reg poisoned_q;
reg inval_pending_q;

reg [31:0] miss_addr_q;
reg miss_pending_q;

integer i;

wire out_valid_w;
wire [31:0] out_data_w;
wire [31:0] out_addr_w;
wire out_err_w;

assign out_valid_w = (out_count != 0);
assign out_data_w = out_data[out_head[4:0]];
assign out_addr_w = out_addr_q[out_head[4:0]];
assign out_err_w  = out_err_q[out_head[4:0]];

assign valid_o = out_valid_w;
assign rdata_o = out_data_w;
assign addr_o  = out_addr_w;
assign err_o   = out_err_w;

wire [2:0] cache_index_w;
wire [TAGW-1:0] cache_tag_w;
wire cache_hit_w;

assign cache_index_w = pc_q[4:2];
assign cache_tag_w = pc_q[31:5];
assign cache_hit_w = cache_valid[cache_index_w] && (cache_tag[cache_index_w] == cache_tag_w);

assign instr_req_o = miss_pending_q;
assign instr_addr_o = {miss_addr_q[31:2], 2'b00};

assign busy_o = (req_count != 0) || (out_count != 0) || miss_pending_q || inval_pending_q;

always @(posedge clk_i or negedge rst_ni) begin
    reg [31:0] branch_addr_v;
    reg [2:0] idx_v;
    reg [TAGW-1:0] tag_v;
    reg accept_output_v;
    reg [31:0] issue_addr_v;
    if (!rst_ni) begin
        for (i = 0; i < NWORDS; i = i + 1) begin
            cache_data[i] <= 32'h0;
            cache_tag[i] <= {TAGW{1'b0}};
            cache_valid[i] <= 1'b0;
        end
        for (i = 0; i < OQDEPTH; i = i + 1) begin
            out_data[i] <= 32'h0;
            out_addr_q[i] <= 32'h0;
            out_err_q[i] <= 1'b0;
            req_addr_q[i] <= 32'h0;
        end
        out_head <= 6'd0;
        out_tail <= 6'd0;
        out_count <= 6'd0;
        req_head <= 6'd0;
        req_tail <= 6'd0;
        req_count <= 6'd0;
        pc_q <= 32'h0;
        branch_seen_q <= 1'b0;
        poisoned_q <= 1'b0;
        inval_pending_q <= 1'b0;
        miss_addr_q <= 32'h0;
        miss_pending_q <= 1'b0;
    end else begin
        if (icache_inval_i) begin
            for (i = 0; i < NWORDS; i = i + 1) begin
                cache_valid[i] <= 1'b0;
            end
            inval_pending_q <= 1'b1;
        end else begin
            inval_pending_q <= 1'b0;
        end

        if (branch_i) begin
            branch_addr_v = {addr_i[31:2], 2'b00};
            pc_q <= branch_addr_v;
            branch_seen_q <= 1'b1;
            poisoned_q <= 1'b0;
            out_head <= 6'd0;
            out_tail <= 6'd0;
            out_count <= 6'd0;
            req_head <= 6'd0;
            req_tail <= 6'd0;
            req_count <= 6'd0;
            miss_pending_q <= 1'b0;
            miss_addr_q <= branch_addr_v;
        end else begin
            if (out_valid_w && ready_i) begin
                out_head <= out_head + 6'd1;
                out_count <= out_count - 6'd1;
                if (!out_err_w) begin
                    pc_q <= out_addr_w + 32'd4;
                end else begin
                    poisoned_q <= 1'b1;
                end
            end

            accept_output_v = branch_seen_q && !poisoned_q && (out_count < OQDEPTH) && (req_count < OQDEPTH);

            if (accept_output_v && !out_valid_w && !miss_pending_q && req_i) begin
                idx_v = pc_q[4:2];
                tag_v = pc_q[31:5];
                if (cache_valid[idx_v] && (cache_tag[idx_v] == tag_v)) begin
                    out_data[out_tail[4:0]] <= cache_data[idx_v];
                    out_addr_q[out_tail[4:0]] <= pc_q;
                    out_err_q[out_tail[4:0]] <= 1'b0;
                    out_tail <= out_tail + 6'd1;
                    out_count <= out_count + 6'd1;
                end else begin
                    miss_pending_q <= 1'b1;
                    miss_addr_q <= pc_q;
                end
            end

            if (miss_pending_q && instr_req_o && instr_gnt_i && (req_count < OQDEPTH)) begin
                issue_addr_v = {miss_addr_q[31:2], 2'b00};
                req_addr_q[req_tail[4:0]] <= issue_addr_v;
                req_tail <= req_tail + 6'd1;
                req_count <= req_count + 6'd1;
                miss_pending_q <= 1'b0;
            end

            if (instr_rvalid_i && (req_count != 0)) begin
                idx_v = req_addr_q[req_head[4:0]][4:2];
                tag_v = req_addr_q[req_head[4:0]][31:5];
                if (!instr_err_i) begin
                    cache_data[idx_v] <= instr_rdata_i;
                    cache_tag[idx_v] <= tag_v;
                    cache_valid[idx_v] <= 1'b1;
                end
                if ((out_count < OQDEPTH) && !poisoned_q) begin
                    out_data[out_tail[4:0]] <= instr_rdata_i;
                    out_addr_q[out_tail[4:0]] <= req_addr_q[req_head[4:0]];
                    out_err_q[out_tail[4:0]] <= instr_err_i;
                    out_tail <= out_tail + 6'd1;
                    out_count <= out_count + 6'd1;
                end
                req_head <= req_head + 6'd1;
                req_count <= req_count - 6'd1;
            end
        end
    end
end

endmodule
