`timescale 1ns/1ps
`default_nettype none

module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

localparam S_IDLE = 3'd0;
localparam S_RECV = 3'd1;
localparam S_CHK  = 3'd2;
localparam S_STAT = 3'd3;
localparam S_OUT  = 3'd4;

reg [7:0] buf_mem [0:511];
reg [9:0] byte_cnt;
reg [2:0] state;
reg [3:0] err_code;
reg [9:0] out_ptr;
reg [9:0] out_end;
reg [31:0] r_src_ip;
reg [15:0] r_src_port;
reg [15:0] r_dst_port;
reg [15:0] r_payload_len;
reg [7:0] r_m_data;
reg r_m_valid;
reg r_m_last;
reg r_status_valid;
reg [3:0] r_status_error;

wire [15:0] ip_total_len = {buf_mem[2], buf_mem[3]};
wire [15:0] udp_len = {buf_mem[24], buf_mem[25]};
wire [15:0] udp_checksum = {buf_mem[26], buf_mem[27]};
wire [31:0] dst_ip = {buf_mem[16], buf_mem[17], buf_mem[18], buf_mem[19]};
wire [15:0] dst_port = {buf_mem[22], buf_mem[23]};

assign s_ready = !rst && (state == S_IDLE || state == S_RECV);
assign status_valid = r_status_valid;
assign status_error = r_status_error;
assign m_valid = r_m_valid;
assign m_data = r_m_data;
assign m_last = r_m_last;
assign m_src_ip = r_src_ip;
assign m_src_port = r_src_port;
assign m_dst_port = r_dst_port;
assign m_payload_len = r_payload_len;

function automatic [15:0] ones_complement_sum;
    input [31:0] a;
    reg [16:0] sum;
    begin
        sum = a[15:0] + a[31:16];
        sum = sum + sum[16];
        ones_complement_sum = sum[15:0];
    end
endfunction

integer i;
reg [31:0] sum_acc;
reg [15:0] sum_result;

always @(posedge clk) begin
    if (rst) begin
        state <= S_IDLE;
        byte_cnt <= 10'd0;
        err_code <= 4'd0;
        out_ptr <= 10'd0;
        out_end <= 10'd0;
        r_src_ip <= 32'd0;
        r_src_port <= 16'd0;
        r_dst_port <= 16'd0;
        r_payload_len <= 16'd0;
        r_m_data <= 8'd0;
        r_m_valid <= 1'b0;
        r_m_last <= 1'b0;
        r_status_valid <= 1'b0;
        r_status_error <= 4'd0;
    end else begin
        r_status_valid <= 1'b0;
        
        case (state)
            S_IDLE: begin
                r_m_valid <= 1'b0;
                r_m_last <= 1'b0;
                if (s_valid && s_ready) begin
                    buf_mem[0] <= s_data;
                    byte_cnt <= 10'd1;
                    if (s_last)
                        state <= S_CHK;
                    else
                        state <= S_RECV;
                end
            end

            S_RECV: begin
                if (s_valid && s_ready) begin
                    if (byte_cnt < 10'd512)
                        buf_mem[byte_cnt] <= s_data;
                    byte_cnt <= byte_cnt + 10'd1;
                    if (s_last)
                        state <= S_CHK;
                end
            end

            S_CHK: begin
                err_code <= 4'd0;
                
                if (byte_cnt < 10'd28 || byte_cnt > 10'd512) begin
                    err_code <= 4'd1;
                end else if (buf_mem[0][7:4] != 4'd4 || buf_mem[0][3:0] != 4'd5) begin
                    err_code <= 4'd1;
                end else if (buf_mem[9] != 8'd17) begin
                    err_code <= 4'd1;
                end else if (buf_mem[6][5] || ({buf_mem[6][4:0], buf_mem[7]} != 13'd0)) begin
                    err_code <= 4'd1;
                end else if (ip_total_len != {10'd0, byte_cnt}) begin
                    err_code <= 4'd2;
                end else if (udp_len != ip_total_len - 16'd20) begin
                    err_code <= 4'd2;
                end else if ((udp_len < 16'd9) || (udp_len > 16'd264)) begin
                    err_code <= 4'd2;
                end else begin
                    sum_acc = 32'd0;
                    for (i = 0; i < 20; i = i + 2) begin
                        sum_acc = sum_acc + {buf_mem[i], buf_mem[i+1]};
                    end
                    sum_result = ones_complement_sum(sum_acc);
                    if (sum_result != 16'hFFFF) begin
                        err_code <= 4'd3;
                    end else if (udp_checksum != 16'd0) begin
                        sum_acc = 32'd0;
                        for (i = 12; i < 20; i = i + 2) begin
                            sum_acc = sum_acc + {buf_mem[i], buf_mem[i+1]};
                        end
                        sum_acc = sum_acc + 16'd17 + udp_len;
                        for (i = 20; i < byte_cnt; i = i + 2) begin
                            if (i + 1 < byte_cnt)
                                sum_acc = sum_acc + {buf_mem[i], buf_mem[i+1]};
                            else
                                sum_acc = sum_acc + {buf_mem[i], 8'h00};
                        end
                        sum_result = ones_complement_sum(sum_acc);
                        if (sum_result != 16'hFFFF) begin
                            err_code <= 4'd4;
                        end else if (dst_ip != 32'h0a000002) begin
                            err_code <= 4'd5;
                        end else if (dst_port != 16'd9000) begin
                            err_code <= 4'd5;
                        end
                    end else begin
                        if (dst_ip != 32'h0a000002) begin
                            err_code <= 4'd5;
                        end else if (dst_port != 16'd9000) begin
                            err_code <= 4'd5;
                        end
                    end
                end
                state <= S_STAT;
            end

            S_STAT: begin
                r_status_valid <= 1'b1;
                r_status_error <= err_code;
                if (err_code == 4'd0) begin
                    r_src_ip <= {buf_mem[12], buf_mem[13], buf_mem[14], buf_mem[15]};
                    r_src_port <= {buf_mem[20], buf_mem[21]};
                    r_dst_port <= {buf_mem[22], buf_mem[23]};
                    r_payload_len <= udp_len - 16'd8;
                    out_ptr <= 10'd28;
                    out_end <= byte_cnt - 10'd1;
                    r_m_data <= buf_mem[28];
                    r_m_valid <= 1'b1;
                    r_m_last <= (10'd28 == byte_cnt - 10'd1);
                    state <= S_OUT;
                end else begin
                    byte_cnt <= 10'd0;
                    state <= S_IDLE;
                end
            end

            S_OUT: begin
                if (m_ready && r_m_valid) begin
                    if (out_ptr == out_end) begin
                        byte_cnt <= 10'd0;
                        r_m_valid <= 1'b0;
                        r_m_last <= 1'b0;
                        state <= S_IDLE;
                    end else begin
                        out_ptr <= out_ptr + 10'd1;
                        r_m_data <= buf_mem[out_ptr + 10'd1];
                        r_m_last <= (out_ptr + 10'd1 == out_end);
                    end
                end
            end

            default: begin
                state <= S_IDLE;
            end
        endcase
    end
end

endmodule
