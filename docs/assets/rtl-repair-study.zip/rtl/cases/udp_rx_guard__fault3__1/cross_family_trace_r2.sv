`timescale 1ns/1ps
`default_nettype none

module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

reg [7:0] buf [0:511];
reg [9:0] byte_cnt;
reg [2:0] state;
reg [3:0] err_code;
reg [9:0] out_ptr;
reg [9:0] out_end;
reg [31:0] r_src_ip;
reg [15:0] r_src_port;
reg [15:0] r_dst_port;
reg [15:0] r_payload_len;

localparam S_IDLE = 0;
localparam S_RECV = 1;
localparam S_CHK  = 2;
localparam S_STAT = 3;
localparam S_OUT  = 4;

assign s_ready = !rst && (state == S_IDLE || state == S_RECV);

assign status_valid = (state == S_STAT);
assign status_error = err_code;

assign m_valid = (state == S_OUT);
assign m_data = buf[out_ptr];
assign m_last  = (state == S_OUT) && (out_ptr == out_end);
assign m_src_ip   = r_src_ip;
assign m_src_port = r_src_port;
assign m_dst_port = r_dst_port;
assign m_payload_len = r_payload_len;

integer i;
reg [15:0] sum_word;
reg [31:0] sum_temp;
reg [15:0] ip_total_len;
reg [15:0] udp_len;

always @(posedge clk) begin
    if (rst) begin
        state    <= S_IDLE;
        byte_cnt <= 0;
        err_code <= 0;
        out_ptr  <= 0;
        out_end  <= 0;
        r_src_ip   <= 0;
        r_src_port <= 0;
        r_dst_port <= 0;
        r_payload_len <= 0;
    end else begin
        case (state)
            S_IDLE: begin
                if (s_valid) begin
                    buf[0] <= s_data;
                    byte_cnt <= 1;
                    if (s_last)
                        state <= S_CHK;
                    else
                        state <= S_RECV;
                end
            end

            S_RECV: begin
                if (s_valid) begin
                    if (byte_cnt < 512)
                        buf[byte_cnt] <= s_data;
                    byte_cnt <= byte_cnt + 1;
                    if (s_last)
                        state <= S_CHK;
                end
            end

            S_CHK: begin
                if (byte_cnt < 28 || byte_cnt > 512) begin
                    err_code <= 1;
                end else if (buf[0][7:4] != 4 || buf[0][3:0] != 5) begin
                    err_code <= 1;
                end else if (buf[9] != 17) begin
                    err_code <= 1;
                end else if (buf[6][5] || {buf[6][4:0], buf[7]} != 0) begin
                    err_code <= 1;
                end else begin
                    ip_total_len = {buf[2], buf[3]};
                    if (ip_total_len != byte_cnt) begin
                        err_code <= 2;
                    end else begin
                        udp_len = {buf[24], buf[25]};
                        if (udp_len != ip_total_len - 20) begin
                            err_code <= 2;
                        end else if ((udp_len - 8) < 1 || (udp_len - 8) > 256) begin
                            err_code <= 2;
                        end else begin
                            // IP header checksum
                            sum_temp = 0;
                            for (i = 0; i < 20; i = i + 2)
                                sum_temp = sum_temp + {buf[i], buf[i+1]};
                            sum_word = sum_temp[15:0] + sum_temp[31:16];
                            sum_word = sum_word + sum_word[16];
                            if (sum_word != 16'hFFFF) begin
                                err_code <= 3;
                            end else begin
                                // UDP checksum
                                sum_temp = 0;
                                // pseudo-header
                                for (i = 12; i < 20; i = i + 2)
                                    sum_temp = sum_temp + {buf[i], buf[i+1]};
                                sum_temp = sum_temp + 17 + udp_len;
                                // UDP header + payload
                                for (i = 20; i < byte_cnt; i = i + 2) begin
                                    if (i + 1 < byte_cnt)
                                        sum_temp = sum_temp + {buf[i], buf[i+1]};
                                    else
                                        sum_temp = sum_temp + {buf[i], 8'h00};
                                end
                                sum_word = sum_temp[15:0] + sum_temp[31:16];
                                sum_word = sum_word + sum_word[16];
                                if ({buf[26], buf[27]} != 0 && sum_word != 16'hFFFF) begin
                                    err_code <= 4;
                                end else if ({buf[16], buf[17], buf[18], buf[19]} != 32'h0a000002) begin
                                    err_code <= 5;
                                end else if ({buf[22], buf[23]} != 16'h2328) begin  // 9000 decimal
                                    err_code <= 5;
                                end else begin
                                    err_code <= 0;
                                end
                            end
                        end
                    end
                end
                state <= S_STAT;
            end

            S_STAT: begin
                if (err_code == 0) begin
                    r_src_ip   <= {buf[12], buf[13], buf[14], buf[15]};
                    r_src_port <= {buf[20], buf[21]};
                    r_dst_port <= {buf[22], buf[23]};
                    r_payload_len <= {buf[24], buf[25]} - 16'd8;
                    out_ptr  <= 28;
                    out_end  <= byte_cnt - 1;
                    state <= S_OUT;
                end else begin
                    byte_cnt <= 0;
                    state <= S_IDLE;
                end
            end

            S_OUT: begin
                if (m_ready) begin
                    if (out_ptr == out_end) begin
                        byte_cnt <= 0;
                        state <= S_IDLE;
                    end else begin
                        out_ptr <= out_ptr + 1;
                    end
                end
            end

            default: begin
                state <= S_IDLE;
            end
        endcase
    end
end

endmodule
