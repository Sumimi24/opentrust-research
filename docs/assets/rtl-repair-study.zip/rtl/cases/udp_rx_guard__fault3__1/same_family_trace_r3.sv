`timescale 1ns/1ps
`default_nettype none

module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output reg s_ready,
input wire s_last,
output reg [7:0] m_data,
output reg m_valid,
input wire m_ready,
output reg m_last,
output reg [31:0] m_src_ip,
output reg [15:0] m_src_port,
output reg [15:0] m_dst_port,
output reg [15:0] m_payload_len,
output reg status_valid,
output reg [3:0] status_error);

reg [7:0] buf [0:511];
reg [9:0] byte_cnt;
reg [2:0] state;
reg [3:0] err_code;
reg [9:0] out_ptr;
reg [9:0] out_end;

localparam S_IDLE = 3'd0;
localparam S_RECV = 3'd1;
localparam S_CHK  = 3'd2;
localparam S_STAT = 3'd3;
localparam S_OUT  = 3'd4;

integer n, ip_len, udp_len, pl_len, i, ip_sum, udp_sum, v;
reg [7:0] b0, b1, b6, b7, b9;
reg [15:0] w2, w22, w24;
reg [31:0] w16;

always @(posedge clk) begin
    if (rst) begin
        state <= S_IDLE;
        byte_cnt <= 10'd0;
        err_code <= 4'd0;
        out_ptr <= 10'd0;
        out_end <= 10'd0;
        s_ready <= 1'b0;
        m_valid <= 1'b0;
        m_last <= 1'b0;
        m_data <= 8'd0;
        m_src_ip <= 32'd0;
        m_src_port <= 16'd0;
        m_dst_port <= 16'd0;
        m_payload_len <= 16'd0;
        status_valid <= 1'b0;
        status_error <= 4'd0;
    end else begin
        case (state)
            S_IDLE: begin
                s_ready <= 1'b1;
                m_valid <= 1'b0;
                m_last <= 1'b0;
                status_valid <= 1'b0;
                status_error <= 4'd0;
                byte_cnt <= 10'd0;
                if (s_valid && s_ready) begin
                    buf[0] <= s_data;
                    byte_cnt <= 10'd1;
                    if (s_last)
                        state <= S_CHK;
                    else
                        state <= S_RECV;
                end
            end
            S_RECV: begin
                s_ready <= 1'b1;
                m_valid <= 1'b0;
                status_valid <= 1'b0;
                if (s_valid && s_ready) begin
                    if (byte_cnt < 10'd512)
                        buf[byte_cnt] <= s_data;
                    byte_cnt <= byte_cnt + 10'd1;
                    if (s_last)
                        state <= S_CHK;
                end
            end
            S_CHK: begin
                s_ready <= 1'b0;
                m_valid <= 1'b0;
                status_valid <= 1'b0;

                n = (byte_cnt > 10'd512) ? 512 : byte_cnt;
                b0 = buf[0];
                b1 = buf[1];
                b6 = buf[6];
                b7 = buf[7];
                b9 = buf[9];
                w2 = {buf[2], buf[3]};
                w16 = {buf[16], buf[17], buf[18], buf[19]};
                w22 = {buf[22], buf[23]};
                w24 = {buf[24], buf[25]};
                ip_len = w2;
                udp_len = w24;

                err_code = 4'd0;

                if (n < 28 || byte_cnt > 10'd512 || b0[7:4] != 4'd4 || b0[3:0] != 4'd5 ||
                    b9 != 8'd17 || b6[5] != 1'b0 || {b6[4:0], b7} != 13'd0) begin
                    err_code = 4'd1;
                end else begin
                    pl_len = udp_len - 8;
                    if (ip_len != n || udp_len != ip_len - 20 || pl_len < 1 || pl_len > 256) begin
                        err_code = 4'd2;
                    end else begin
                        ip_sum = 0;
                        for (i = 0; i < 20; i = i + 2)
                            ip_sum = ip_sum + {buf[i], buf[i+1]};
                        v = (ip_sum & 65535) + (ip_sum >> 16);
                        v = (v & 65535) + (v >> 16);
                        if (v != 65535) begin
                            err_code = 4'd3;
                        end else begin
                            udp_sum = 0;
                            for (i = 12; i < 20; i = i + 2)
                                udp_sum = udp_sum + {buf[i], buf[i+1]};
                            udp_sum = udp_sum + 17 + udp_len;
                            for (i = 20; i < n; i = i + 2) begin
                                if (i + 1 < n)
                                    udp_sum = udp_sum + {buf[i], buf[i+1]};
                                else
                                    udp_sum = udp_sum + {buf[i], 8'h00};
                            end
                            v = (udp_sum & 65535) + (udp_sum >> 16);
                            v = (v & 65535) + (v >> 16);
                            if (w24 != 16'd0 && v != 65535) begin
                                err_code = 4'd4;
                            end else if (w16 != 32'h0a000002 || w22 != 16'd9000) begin
                                err_code = 4'd5;
                            end else begin
                                err_code = 4'd0;
                            end
                        end
                    end
                end
                err_code <= err_code;
                state <= S_STAT;
            end
            S_STAT: begin
                s_ready <= 1'b0;
                m_valid <= 1'b0;
                status_valid <= 1'b1;
                status_error <= err_code;
                if (err_code == 4'd0) begin
                    m_src_ip <= {buf[12], buf[13], buf[14], buf[15]};
                    m_src_port <= {buf[20], buf[21]};
                    m_dst_port <= {buf[22], buf[23]};
                    m_payload_len <= {buf[24], buf[25]} - 16'd8;
                    out_ptr <= 10'd28;
                    out_end <= byte_cnt - 10'd1;
                    state <= S_OUT;
                end else begin
                    byte_cnt <= 10'd0;
                    state <= S_IDLE;
                end
            end
            S_OUT: begin
                s_ready <= 1'b0;
                status_valid <= 1'b0;
                m_valid <= 1'b1;
                m_data <= buf[out_ptr];
                m_last <= (out_ptr == out_end);
                if (m_valid && m_ready) begin
                    if (out_ptr == out_end) begin
                        m_valid <= 1'b0;
                        byte_cnt <= 10'd0;
                        state <= S_IDLE;
                    end else begin
                        out_ptr <= out_ptr + 10'd1;
                    end
                end
            end
            default: begin
                state <= S_IDLE;
                s_ready <= 1'b0;
                m_valid <= 1'b0;
                status_valid <= 1'b0;
            end
        endcase
    end
end

endmodule
