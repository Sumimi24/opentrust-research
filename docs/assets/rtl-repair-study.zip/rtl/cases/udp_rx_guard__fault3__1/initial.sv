`timescale 1ns/1ps
`default_nettype none

module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

reg [7:0] buf [0:511];
reg [9:0] byte_cnt;
reg [2:0] state;
reg [3:0] err_code;
reg [9:0] out_ptr;
reg [9:0] out_end;
reg [31:0] r_src_ip;
reg [15:0] r_src_port;
reg [15:0] r_dst_port;
reg [15:0] r_payload_len;

localparam S_IDLE=0, S_RECV=1, S_CHK=2, S_STAT=3, S_OUT=4;

assign s_ready = !rst && (state==S_IDLE || state==S_RECV);
assign status_valid = (state==S_STAT);
assign status_error = err_code;
assign m_valid = (state==S_OUT);
assign m_data = (state==S_OUT) ? buf[out_ptr] : 8'b0;
assign m_last = (state==S_OUT) ? (out_ptr==out_end) : 1'b0;
assign m_src_ip = r_src_ip;
assign m_src_port = r_src_port;
assign m_dst_port = r_dst_port;
assign m_payload_len = r_payload_len;

always @(posedge clk) begin
    if (rst) begin
        state <= S_IDLE;
        byte_cnt <= 0;
        err_code <= 0;
        out_ptr <= 0;
        out_end <= 0;
        r_src_ip <= 0;
        r_src_port <= 0;
        r_dst_port <= 0;
        r_payload_len <= 0;
    end else begin
        case (state)
            S_IDLE: begin
                if (s_valid) begin
                    if (!s_last) begin
                        buf[0] <= s_data;
                        byte_cnt <= 1;
                        state <= S_RECV;
                    end else begin
                        buf[0] <= s_data;
                        byte_cnt <= 1;
                        state <= S_CHK;
                    end
                end
            end
            S_RECV: begin
                if (s_valid) begin
                    if (byte_cnt < 512)
                        buf[byte_cnt] <= s_data;
                    byte_cnt <= byte_cnt + 1;
                    if (s_last)
                        state <= S_CHK;
                end
            end
            S_CHK: begin
                begin : chk_blk
                    integer n, ip_len, udp_len, pl_len, i, ip_sum, udp_sum, v;
                    reg [7:0] b0,b1,b6,b7,b9;
                    reg [15:0] w2,w22,w24;
                    reg [31:0] w16;
                    n = (byte_cnt > 512) ? 512 : byte_cnt;
                    b0 = buf[0]; b1 = buf[1]; b6 = buf[6]; b7 = buf[7]; b9 = buf[9];
                    w2 = {buf[2], buf[3]}; w16 = {buf[16], buf[17], buf[18], buf[19]};
                    w22 = {buf[22], buf[23]}; w24 = {buf[24], buf[25]};
                    ip_len = w2; udp_len = w24;
                    if (n < 28 || byte_cnt > 512 || b0[7:4] != 4 || b0[3:0] != 5 ||
                        b9 != 17 || b6[5] != 0 || {b6[4:0], b7} != 0)
                        err_code = 1;
                    else begin
                        pl_len = udp_len - 8;
                        if (ip_len != n || udp_len != ip_len - 20 || pl_len < 1 || pl_len > 256)
                            err_code = 2;
                        else begin
                            ip_sum = 0;
                            for (i = 0; i < 20; i = i + 2)
                                ip_sum = ip_sum + {buf[i], buf[i+1]};
                            v = (ip_sum & 65535) + (ip_sum >> 16);
                            v = (v & 65535) + (v >> 16);
                            if (v != 65535)
                                err_code = 3;
                            else begin
                                udp_sum = 0;
                                for (i = 12; i < 20; i = i + 2)
                                    udp_sum = udp_sum + {buf[i], buf[i+1]};
                                udp_sum = udp_sum + 17 + udp_len;
                                for (i = 20; i < n; i = i + 2)
                                    udp_sum = udp_sum + {buf[i], (i+1 < n) ? buf[i+1] : 8'h00};
                                v = (udp_sum & 65535) + (udp_sum >> 16);
                                v = (v & 65535) + (v >> 16);
                                if (w24 != 0 && v != 65535)
                                    err_code = 4;
                                else if (w16 != 32'h0a000002 || w22 != 9000)
                                    err_code = 5;
                                else
                                    err_code = 0;
                            end
                        end
                    end
                end
                state <= S_STAT;
            end
            S_STAT: begin
                if (err_code == 0) begin
                    r_src_ip <= {buf[12], buf[13], buf[14], buf[15]};
                    r_src_port <= {buf[20], buf[21]};
                    r_dst_port <= {buf[22], buf[23]};
                    r_payload_len <= {buf[24], buf[25]} - 16'd8;
                    out_ptr <= 28;
                    out_end <= byte_cnt - 1;
                    state <= S_OUT;
                end else begin
                    byte_cnt <= 0;
                    state <= S_IDLE;
                end
            end
            S_OUT: begin
                if (m_ready) begin
                    if (out_ptr == out_end) begin
                        byte_cnt <= 0;
                        state <= S_IDLE;
                    end else begin
                        out_ptr <= out_ptr + 1;
                    end
                end
            end
            default: state <= S_IDLE;
        endcase
    end
end

endmodule
