Looking at the failure, the issue is that the core is outputting `m_axi_awlen = 255` (256 beats) for a 1-byte transfer, which exceeds the maximum burst length of 16 beats. The problem is that I'm passing `desc_len - 1` to the core's `s_axis_write_desc_len` port, but the core expects a byte count, not a beat count.

Looking at the core interface, `s_axis_write_desc_len` should be the length in bytes (or similar), and the core should compute the burst length. But the core seems to be using the length directly as AWLEN.

Let me re-examine: the core's `s_axis_write_desc_len` is described as "length" - looking at typical AXI DMA cores, this is usually bytes-1. But the core is outputting AWLEN=255 for desc_len=1, which suggests the core is broken or I'm misunderstanding.

Actually, looking more carefully: the core is `axi_dma_wr` which is a standard corundum/verilog-axi style core. In those cores, `len` is typically bytes-1, and the core computes burst parameters.

But the failure shows AWLEN=255 when desc_len=1. This suggests the core is computing `awlen = len` directly, which is wrong.

Wait - I need to check if this is actually a different core. The parameters suggest it's a generic DMA writer. Let me look at what the core actually expects.

Given the failure pattern, it seems like the core expects `len` to be the number of beats-1, not bytes-1. But that doesn't match the interface description either.

Let me re-read: the core has `LEN_WIDTH(16)` and takes `s_axis_write_desc_len`. In many DMA cores, this is "number of bytes to transfer - 1".

But the output AWLEN=255 suggests the core is broken or I'm passing the wrong value. Actually, 255 = 0xFF, and desc_len=1, so desc_len-1=0. That's not 255.

Hmm, let me look at cycle 9: desc_len=1 was accepted in cycle 6. In cycle 9, awlen=255. This looks like the core is outputting uninitialized or wrong values.

Actually, I think I see the issue. The core might expect `len` as "number of bytes" not "bytes-1". Or there's a bug in how I'm connecting.

Wait - looking at the waveform: in cycle 6, desc_valid=1, desc_ready=1, so the descriptor is accepted. The descriptor has desc_len=1. In cycle 9, awlen=255 appears.

If the core expects "number of bytes", then passing 1 would give awlen=0 for a single beat. But we see 255.

Let me check: 255 in 8 bits is 0xFF. This could be if the core is using the full 16-bit length and computing bursts wrong.

Actually, I think the issue is that this particular core implementation has a bug or different interface. Let me try passing `desc_len` directly (not minus 1) and see if that helps, or check if there's a different interpretation.

Looking at the parameter `LEN_WIDTH(16)` and the fact that awlen is 8 bits, the core should be computing burst length from byte length.

Let me try: the core might expect "number of bytes" not "bytes-1". So I should pass `desc_len` instead of `desc_len - 1`.

But wait, 1 byte = 1 beat with wstrb=0b0001, so awlen should be 0. If I pass 1, and the core computes (len-1), that gives 0. 

Actually let me re-check: if desc_len=1, and I pass 1 to the core, and core does (len-1), awlen=0. That seems right.

But the output is 255, not 0. So something else is wrong.

Let me look more carefully. The core might be a specific implementation where `len` means "beats-1" directly. In that case, for 1 byte, I need to pass 0.

But I'm already passing desc_len-1 = 0 for desc_len=1. So why is awlen=255?

Unless... the core is in reset or not properly enabled? Let me check the enable signal - I tied it to 1'b1.

Or maybe the core has a bug where it outputs garbage when not ready? 

Actually, looking at cycle 9: s_ready=1, which means the core is ready for data. And awvalid=1 with awlen=255. This is a real output.

Let me reconsider: maybe the core interface is different. Looking at the name `axi_dma_wr`, this might be from the verilog-axi library. In that library, the DMA length is in bytes.

Let me check if there's an issue with how I'm handling the descriptor valid. I register the descriptor and then pass to core. Maybe I need to look at the timing more carefully.

Actually, I think I found it. Looking at the core instantiation, I have `.s_axis_write_desc_len(core_desc_len - 16'd1)`. But `core_desc_len` is registered, so this subtraction happens in the register assignment, not in the wire.

Wait no, that's `core_desc_len - 16'd1` in the port connection, which is correct.

Hmm, let me re-examine. In cycle 6, desc_valid=1, desc_ready=1, so descriptor is accepted. core_desc_len gets desc_len=1. In cycle 7, core_desc_valid becomes 1.

In cycle 9, we see awlen=255. This is 0xFF, which is -1 in signed 8-bit, or 255 in unsigned.

If core_desc_len=1, and I pass core_desc_len-1=0, but the core sees 255, maybe there's a width issue? No, LEN_WIDTH is 16.

Unless... the core is actually expecting "number of beats" directly, and for some reason it's seeing 0xFF00 or something? No, awlen is 8 bits.

Let me try a different approach: maybe the core expects the full byte count, not minus 1. Let me try `core_desc_len` instead of `core_desc_len - 16'd1`.

Actually wait - I need to re-read the original code more carefully. The user said "The pinned upstream core named in the code IS available unchanged at compile time." So there IS a core called `axi_dma_wr` available.

Looking at typical `axi_dma_wr` implementations (like from alexforencich/verilog-axi), the `s_axis_write_desc_len` is "Length in bytes". The core computes the burst length from this.

But in the failure, with desc_len=1, we get awlen=255. This is wrong.

Unless... the core in this environment is different. Let me assume the core expects "length in beats - 1" directly. Then for 1 byte, I need to pass 0. But I'm passing 0 and getting 255.

Hmm, 255 suggests the core is outputting all ones. Maybe the core isn't properly reset or there's a bug in my wrapper?

Let me check: in cycle 5, rst=0. The core should be out of reset. But maybe the core needs more cycles?

Actually, looking at the wrapper code I generated, I have `assign m_axi_awprot = 3'b000;` but the core has `.m_axi_awprot()` as an output (unconnected). That's a bug - I'm overriding the core's output.

Wait, let me check the core port list. I have:
```
.m_axi_awprot(),
```

So it's unconnected. But I also have:
```
output wire [2:0] m_axi_awprot,
```

And `assign m_axi_awprot = 3'b000;`

But the core drives this signal too! That's a conflict. The core drives m_axi_awprot as an output, and I'm driving it as an output with constant 0.

Actually no - looking more carefully, in my code I have:
```
.m_axi_awprot(),
```

So I'm not connecting the core's m_axi_awprot output. And I'm driving the module's m_axi_awprot output to 0.

But wait, the core might need to drive it. Let me check if the core has m_axi_awprot as input or output. In AXI, awprot is driven by master, so it's an output of the DMA core.

So the core should drive it. But I'm not connecting it, and driving the module output to 0.

Actually, looking at my code again:
```verilog
output wire [2:0] m_axi_awprot,
...
.m_axi_awprot(),
...
assign m_axi_awprot = 3'b000;
```

This is fine - I'm driving the module output, not connecting the core's output to it. But the core's m_axi_awprot is unconnected, which might be OK if the core doesn't use it or it's for debug.

But this shouldn't cause awlen to be wrong.

Let me think differently. The failure says "burst_length assert 256 <= 16". The checker is seeing a burst of 256 beats. With 4 bytes per beat, that's 1024 bytes. But desc_len=1.

Maybe the core is using a default value or is in a bad state. Let me check if I'm properly controlling the core.

Actually, I think I see a potential issue. The core has an `enable` input which I tied to 1. But maybe it also needs `abort` to be 0 (which I did). 

Let me look at the descriptor interface more carefully. The core has:
- s_axis_write_desc_addr
- s_axis_write_desc_len
- s_axis_write_desc_tag
- s_axis_write_desc_valid
- s_axis_write_desc_ready

And I connect:
- core_desc_addr (registered desc_addr)
- core_desc_len - 16'd1
- core_desc_tag
- core_desc_valid
- raw_desc_ready

The issue might be that `core_desc_len - 16'd1` is computed in the port connection, but `core_desc_len` is 16 bits, so `core_desc_len - 16'd1` when core_desc_len=0 would be 0xFFFF. But desc_len is at least 1, so core_desc_len >= 1, so core_desc_len - 1 >= 0.

Hmm, let me try a different hypothesis. Maybe the core expects the length in bytes, not beats-1. And the core internally computes burst length. If I pass 0 (for 1 byte), the core might interpret this as "no transfer" or have some bug.

Let me try passing `core_desc_len` directly without the -1.

Actually, looking at the failure more carefully: in cycle 9, awaddr=256, awlen=255, awvalid=1. This is a 256-beat burst starting at 256, which would end at 256+256*4-1 = 256+1023 = 1279. This crosses 4KB boundary? 256 is 0x100, next 4KB boundary is 0x1000=4096. 1279 < 4096, so no 4KB crossing issue. But 256 beats > 16 beats max.

If the core is computing burst length as (len + 3) / 4 - 1 for byte length to beat conversion, then for len=1: (1+3)/4 - 1 = 1-1 = 0. That should be right.

Unless the core is doing something like `len - 1` directly as awlen, treating len as beats. Then for len=1, awlen=0. But we see 255.

Wait - could it be that the core is using `len[7:0]` and my `core_desc_len - 1` when core_desc_len=1 gives 0, but if there's some timing issue where core_desc_len is 0 (uninitialized), then 0-1 = 0xFFFF, and [7:0] = 0xFF = 255?

Let me check: in cycle 6, desc_valid=1, desc_ready=1, so descriptor is accepted. core_desc_len gets desc_len=1. But core_desc_valid is set to 1.

In cycle 7, core_desc_valid=1, and the core should see len=0 (1-1). But maybe the core samples on the same cycle?

Actually, looking at my code:
```verilog
always @(posedge clk) begin
    if (rst) begin
        core_desc_valid <= 1'b0;
    end else begin
        if (desc_valid && desc_ready) begin
            core_desc_addr <= desc_addr;
            core_desc_len <= desc_len;
            core_desc_tag <= desc_tag;
            core_desc_valid <= 1'b1;
        end else if (raw_status_valid) begin
            core_desc_valid <= 1'b0;
        end
    end
end
```

And the connection: `.s_axis_write_desc_len(core_desc_len - 16'd1)`

So `core_desc_len - 16'd1` is a combinational expression using `core_desc_len`. When `core_desc_len` is updated in cycle 6, the expression `core_desc_len - 16'd1` becomes 0 in cycle 6.

But `core_desc_valid` is also set to 1 in cycle 6. So in cycle 6, the core sees valid=1, len=0.

However, the awlen=255 appears in cycle 9. That's 3 cycles later. This suggests the core has some internal pipeline.

Let me think... if the core is expecting "number of beats" and I give 0, it might treat 0 as 256 beats (wrapping). That's a common pattern in AXI - AWLEN=0 means 1 beat, AWLEN=255 means 256 beats.

So if the core expects "number of beats" (where 0 means 1 beat), and I give 0 (meaning 1 beat in my encoding), the core might interpret 0 as "1 beat" and output awlen=0. But we see 255.

Unless the core expects "number of beats - 1" (AXI encoding), and I give 0, the core passes through 0, meaning 1 beat. But we see 255.

Hmm, 255 means 256 beats in AXI. If the core is outputting 255, it's asking for 256 beats.

What if the core is broken or I'm using it wrong? Let me try a different interpretation: maybe `s_axis_write_desc_len` is "number of bytes" and the core has a bug, or I need to use it differently.

Actually, let me re-read the failure. The assertion is `assert 256 <= 16`, meaning the checker saw 256 beats but expected at most 16. 

Let me try changing to pass `core_desc_len` without -1, and also check if there's a width mismatch.

Actually, I think I need to look at this differently. The core might be from a specific library where the length interface is different. Let me assume the core wants "number of bytes" and computes bursts internally.

But with desc_len=1, we'd get 1 byte = 1 beat, awlen=0. Not 255.

Unless... the core is in a bad state because I'm not connecting all signals properly, or there's a reset issue.

Let me check: does the core have a reset? Yes, I connect rst. Is it active high? The spec says "Synchronous active-high rst", and I pass rst directly. 

Hmm, looking at my code, I have `assign desc_ready = raw_desc_ready && !active && !rst;`. This means desc_ready is 0 when rst=1. That's correct.

But I also have the core's `s_axis_write_desc_valid` connected to `core_desc_valid`, which I control. And `core_desc_valid` is set to 0 in reset.

Let me try a simpler approach: maybe I should not use the core at all, and implement the DMA directly? But the instructions say "The pinned upstream core named in the code IS available unchanged at compile time."

So I must use the core. Let me try to understand it better by looking at what could cause 255.

If `core_desc_len` is 0 (uninitialized at start), and I compute `core_desc_len - 1`, I get 0xFFFF. If the core takes lower 8 bits, that's 255.

But in cycle 6, I set `core_desc_len <= desc_len` where desc_len=1. So `core_desc_len` becomes 1.

Unless... the issue is that `core_desc_len` is not initialized, and in simulation, it starts as X. Then 1 - 1 = 0, which is fine. But if there's some X propagation...

Actually, let me check: in the first cycle after reset (cycle 5), what is core_desc_len? It's uninitialized (X). But I don't set core_desc_valid until cycle 6.

Hmm, but the expression `core_desc_len - 16'd1` is computed every cycle. If core_desc_len is X, then `core_desc_len - 16'd1` is X. 

But in cycle 6, core_desc_len becomes 1, so `core_desc_len - 16'd1` becomes 0.

Wait, I need to check if the core samples the len when valid is high, or if it uses it combinationally.

Actually, I think I found a potential issue. In my code, I have:
```verilog
assign desc_ready = raw_desc_ready && !active && !rst;
```

This means desc_ready depends on !active. And `active` is set when `desc_valid && desc_ready`. So there's a potential combinational loop or race condition.

Let me trace: initially active=0. desc_valid=1, raw_desc_ready=1 (from core), !active=1, !rst=1, so desc_ready=1. Then desc_valid && desc_ready = 1, so active becomes 1 in the next cycle.

That seems fine. But what if raw_desc_ready changes?

Actually, looking at the failure: in cycle 6, desc_ready=1, so descriptor is accepted. In cycle 7, active should be 1.

But looking at the output in cycle 7: desc_ready=0 (correct, active=1), s_ready=0.

In cycle 8: s_ready=0.

In cycle 9: s_ready=1, and awlen=255 appears.

So the core is outputting awlen=255 in cycle 9. This is 3 cycles after the descriptor was accepted.

I think the issue might be that the core expects a different format. Let me try without the -1: `.s_axis_write_desc_len(core_desc_len)`.

Or, maybe the core expects "number of beats - 1" in a different width format.

Let me try a different approach. What if I look at the core's ready signal? In cycle 6, raw_desc_ready must be 1 for desc_ready to be 1. The core is ready to accept a descriptor.

Then in cycle 7, core_desc_valid becomes 1. The core might not be ready anymore (raw_desc_ready becomes 0), which is fine.

But in cycle 9, the core outputs AW with len=255. This suggests the core is processing the descriptor.

Unless... the core is actually a different core than I think, and `s_axis_write_desc_len` is actually "number of beats - 1" in a 16-bit format, and the core uses the full 16 bits to compute something.

Or, maybe the core has a bug where it doesn't properly handle small transfers?

Let me try: what if I pass `core_desc_len` (1) instead of `core_desc_len - 1` (0)? Then the core sees 1. If the core treats this as "beats - 1", then awlen=1 means 2 beats. That's 8 bytes, but we only have 1 byte. Wrong direction.

If the core treats 1 as "bytes", and computes (1+3)/4 = 1 beat, awlen=0. That's correct.

But we see 255, not 0 or 1.

Let me try yet another hypothesis. What if the core's `s_axis_write_desc_len` is actually the AXI AWLEN directly? Then I should pass 0 for 1 beat. But I'm passing 0, and getting 255.

Unless... there's a bug in my code where `core_desc_len` is not actually 1 when I think it is.

Let me trace more carefully. In cycle 6:
- desc_valid=1, desc_ready=1, desc_len=1
- So `core_desc_len <= desc_len` happens, core_desc_len becomes 1
- `core_desc_valid <= 1'b1` happens

In cycle 7:
- core_desc_valid=1, core_desc_len=1
- `core_desc_len - 16'd1` = 0

In cycle 9:
- awlen=255 appears

Hmm, could there be a synchronization issue? Like, the core samples the descriptor in cycle 7, but `core_desc_len - 16'd1` is computed combinationally, so it should be 0.

Unless... the core uses `s_axis_write_desc_len` in a registered way, and there's some timing mismatch?

Actually, I think I need to check if the core has registered inputs or not. But I can't see the core code.

Let me try a different fix: what if I add a register stage for the length computation?

Actually, looking at the problem again: 255 = 0xFF. This is 8 bits all set. If the core is taking a 16-bit value and using only lower 8 bits, and the value is 0xFF?? or 0x??FF...

Wait, if `core_desc_len` is 16 bits and uninitialized (0xXXXX), and I subtract 1, I might get garbage. But once it's assigned to 1, it should be fine.

Unless... Verilog X propagation? If core_desc_len starts as X, and I do `core_desc_len - 16'd1`, I get X. Then in cycle 6, it becomes 1, so `1 - 1 = 0`. 

But what if the core has internal registers that sample the length, and they see X?

Actually, I think the issue might be simpler. Let me re-read my code:

```verilog
.s_axis_write_desc_len(core_desc_len - 16'd1),
```

This is a port connection. `core_desc_len` is a reg. `core_desc_len - 16'd1` creates a wire with the subtraction result.

If `core_desc_len` is uninitialized (X) at time 0, then `core_desc_len - 16'd1` is X. When `core_desc_len` becomes 1 in cycle 6, the subtraction result becomes 0.

But if the core samples this in a different cycle, or has some internal pipeline...

Actually, I wonder if the issue is that I'm using `core_desc_len` which is registered, but I should use `desc_len` directly? No, that would cause timing issues.

Let me try a different approach. What if the core expects "number of bytes" and I should NOT subtract 1? Let me try that.

Actually, looking at the failure again: in cycle 9, awvalid=1 with awlen=255. This is a valid AXI transfer request. The core is trying to do a 256-beat burst.

If the core is computing this from my length of 0 (1-1), maybe the core has a bug where 0 is treated as "maximum" or something?

Or, maybe I need to look at the core's documentation more carefully. The name `axi_dma_wr` suggests it's from the verilog-axi library by Alex Forencich. In that library, the DMA writer takes:

- s_axis_write_desc_addr: byte address
- s_axis_write_desc_len: length in bytes (not bytes-1)
- s_axis_write_desc_valid/ready

And it computes burst parameters automatically. The length is the actual byte count, not minus 1.

So I should pass `core_desc_len`, not `core_desc_len - 16'd1`.

But wait, that would mean for 1 byte, I pass 1. If the core computes beats = ceil(1/4) = 1, and awlen = beats-1 = 0, that's correct.

But we see 255, not 0. So that's not the issue either.

Unless... the core is different. Let me think about what core would output awlen=255.

If the core treats the input length as "beats - 1" directly, and I pass 0, the core should output 0. 

If the core treats input as "beats" (where 0 means 256), and I pass 0, the core outputs 255. That's a match!

So if the core expects "number of beats" with 0 meaning 256, and I pass `core_desc_len - 1` = 0, the core interprets this as 256 beats.

But that doesn't make sense for a DMA core - it should take byte addresses.

Unless the core is a low-level core that takes beat counts? Let me check the interface again.

Actually, looking at the core parameters: `LEN_WIDTH(16)`. This suggests the core can handle large lengths. If the core took beats directly with 0=256, LEN_WIDTH wouldn't need to be 16.

Hmm, let me try a different hypothesis. What if the core is outputting garbage because I'm not properly connecting some required signal?

Looking at my instantiation, I have:
- .s_axis_write_data_tid(8'b0),
- .s_axis_write_data_tdest(8'b0),
- .s_axis_write_data_tuser(1'b0),

These are tied to 0. Maybe the core needs them, or maybe they're optional.

Also, I have `.enable(1'b1)` and `.abort(1'b0)`.

Let me check if the core has any other required inputs...

Actually, I notice I have `.m_axi_awprot(),` unconnected. But I also have `assign m_axi_awprot = 3'b000;` for the module output. That's fine.

Wait, I think I see a potential issue. The core's `m_axi_awprot` is an output, but I'm not connecting it. Instead I'm driving the module output to 0. That's correct behavior - the core's internal awprot is unused.

But what if the core has a bug where it requires awprot to be connected? Unlikely.

Let me try yet another approach. What if I look at when the core is ready for data?

In cycle 9, s_ready=1. This means the core is ready to accept stream data. And awvalid=1 with awlen=255.

The core is trying to start a burst before receiving data? Or is this normal - AW channel can be issued before W data.

Actually, looking at AXI protocol, AW can be sent before W data. So the core is issuing AW first, which is fine.

But why 255? 

Let me think about the math again. If desc_len=1 byte, and the core wants to compute beats:
- beats = ceil(desc_len / 4) = 1 beat for 1-4 bytes
- awlen = beats - 1 = 0

So awlen should be 0.

If the core is outputting 255, either:
1. The core has a bug
2. I'm passing the wrong length
3. The core is in a bad state

Given that this is a "pinned upstream core", it's probably not buggy. So #2 or #3.

For #2, what length would give 255? If the core computes awlen = (len - 1) & 0xFF, and I pass len=0, then awlen=255. But I'm passing `core_desc_len - 1` where core_desc_len=1, so len=0.

Wait - if the core expects "number of bytes" and I pass 0, the core might compute beats = ceil(0/4) = 0, which is invalid, or treat 0 as special.

Or, if the core expects "number of bytes" with 0 meaning "maximum" or "use full buffer", that would explain it.

Let me try passing `core_desc_len` without the -1. For desc_len=1, I pass 1. Then beats = ceil(1/4) = 1, awlen = 0. 

But if the core does `awlen = len - 1` directly (treating len as beats), then awlen = 0. Good.

If the core does `awlen = (len + 3) / 4 - 1` (bytes to beats), then for len=1: (4)/4 - 1 = 1 - 1 = 0. Good.

So passing `core_desc_len` (not minus 1) seems like it should work if the core expects bytes.

Let me try this fix.

Actually, I want to double-check. The failure shows that with desc_len=1, awlen=255. If I change to pass desc_len directly (1), what happens?

If the core expects bytes: awlen = 0. Good.
If the core expects beats-1: awlen = 1, meaning 2 beats = 8 bytes. Bad, but not 255.
If the core expects beats (0=256): awlen = 0, meaning 1 beat. Good.

Hmm, passing 1 can't give 255. So if I pass `core_desc_len` and still see 255, then something else is wrong.

But let me try it anyway, it's the most likely fix.

Actually, wait. I need to re-examine. The core's interface is `s_axis_write_desc_len`. Looking at standard naming, this is likely "length in bytes". 

But in many DMA engines, the length is "bytes - 1" or there's a convention. Let me check the specific core.

Since I can't see the core code, let me infer from behavior. The core outputs awlen=255 when I pass 0. This suggests:
- The core treats 0 as a special value (maybe "infinite" or "max")
- OR the core has a bug where 0 causes wrap-around in some calculation

If I pass 1 instead of 0, and the core computes `awlen = len - 1`, I get 0. Good.
If the core computes `awlen = len` (treating as beats-1), I get 1 (2 beats). 

2 beats for 1 byte is wrong, but it's not 255. The test might fail differently, but let me try.

Actually, let me re-read the problem statement. It says "desc_len is 1..512 bytes". So desc_len is at least 1. And "Following the accepted descriptor, s_data/s_keep/s_last supply exactly desc_len bytes".

So for desc_len=1, I need to transfer 1 byte. That's 1 beat with WSTRB indicating which byte.

If I pass `core_desc_len` = 1 to the core, and the core treats it as beats, I get 1 beat. Good.
If the core treats it as bytes and computes beats=ceil(1/4)=1, I get 1 beat. Good.

So passing `core_desc_len` without -1 seems safer.

But wait, I also need to check the core's status output. The core outputs `m_axis_write_desc_status_len` which I connect to `status_len`. The spec says `status_len=desc_len`. 

If the core expects bytes-1 and I pass bytes, the status might be wrong. But let me first fix the AWLEN issue.

Let me try: `.s_axis_write_desc_len(core_desc_len)`

Actually, I want to check one more thing. In the failure, cycle 9 shows `m_axi_wstrb=1` and `m_axi_wdata=199`. This is correct for the first (and only) byte. But `m_axi_awlen=255` is wrong.

So the core has the right data, but wrong burst length. This suggests the core's data path is correct, but the AW channel computation is wrong.

Given that, I think the most likely issue is that the core expects "number of bytes" and I'm passing "bytes-1" = 0, which the core interprets as 0 or wraps to 255.

Let me change to `core_desc_len`.

Actually, one more check: what if the core uses `len == 0` as a special "idle" or "no transfer" state, and when it sees 0, it uses some default or uninitialized value?

That would explain why 0 gives 255 (uninitialized/garbage).

Let me try the fix: change `core_desc_len - 16'd1` to `core_desc_len`.

Hmm, but I want to be more careful. Let me also check if there are other issues.

Looking at my code, I have `raw_desc_ready` from the core. I use this to compute `desc_ready = raw_desc_ready && !active && !rst`. 

But I also register the descriptor and pass `core_desc_valid` to the core. The core's `s_axis_write_desc_ready` is `raw_desc_ready`.

There's a potential issue here: when I accept a descriptor (desc_valid && desc_ready), I set `core_desc_valid` in the next cycle. But the core might deassert `raw_desc_ready` in that cycle.

Actually, looking at typical AXI stream interfaces, ready can be combinationally dependent on valid. But since I'm registering, there might be a one-cycle gap.

Let me trace: cycle 6: desc_valid=1, raw_desc_ready=1 (assumed), !active=1, !rst=1, so desc_ready=1. Descriptor accepted. In my always block, I set core_desc_valid<=1 and core_desc_len<=desc_len.

Cycle 7: core_desc_valid=1, core_desc_len=1. The core sees valid=1, len=1 (or 0 if I use -1).

The core's raw_desc_ready might go low in cycle 7 because it's now processing.

This seems fine.

OK, let me try the fix: change to `core_desc_len` without -1.

Actually, I want to also check the status interface. The core outputs `m_axis_write_desc_status_len`. I connect this to `status_len`. The spec says `status_len=desc_len`.

If the core expects bytes and I pass bytes, it should return bytes. Good.

If the core expects bytes-1 and I pass bytes, it might return bytes or bytes-1 or something else.

But let me first fix the AWLEN issue.

Final decision: change `.s_axis_write_desc_len(core_desc_len - 16'd1)` to `.s_axis_write_desc_len(core_desc_len)`.

Wait, I need to also check if the core's length width is correct. `LEN_WIDTH(16)` and `core_desc_len` is 16 bits. Good.

Let me write the fix.

Actually, one more thought: what if the core is the `axi_dma_wr` from the Corundum project? Let me think about what that core expects.

In Corundum, the DMA engine typically takes descriptors with byte counts. The `axi_dma_wr` module there computes burst parameters.

But I'm not sure. Let me just try the fix.

Hmm, I also want to check if there might be an issue with how I'm handling the active signal. I use `active` to prevent accepting new descriptors while one is in progress. But the core has its own `s_axis_write_desc_ready` which should handle this.

Actually, looking more carefully: I set `active` when `desc_valid && desc_ready`, and clear it when `raw_status_valid`. This matches the descriptor lifetime.

But I also use `active` in `desc_ready = raw_desc_ready && !active && !rst`. This means when active=1, desc_ready=0 even if the core is ready. This is correct - I don't want to accept a new descriptor until the current one completes.

However, there's a subtlety: when the core finishes, it asserts `raw_status_valid`. In that cycle, I clear `active`. But `desc_ready` also depends on `!active`, so in the same cycle, `desc_ready` could be 1 if `raw_desc_ready` is 1.

This is fine - it's standard pipelining.

OK, I think the main issue is the -1. Let me fix that.

Actually, I want to double-check one thing. In the failure, `m_axi_awaddr=256`. This matches `desc_addr=256`. Good. `m_axi_awsize=2` (4 bytes). Good. `m_axi_awburst=1` (INCR). Good.

So the core is processing the descriptor, just with wrong length.

Let me also check: `m_axi_wstrb=1` in cycle 11. This is 0b0001, meaning only the first byte is valid. This is correct for little-endian, address 256 (aligned), first byte.

So the core's data path is correct. It's just the AWLEN that's wrong.

Given all this, I'm fairly confident the fix is to remove the `- 16'd1`.

Let me write the complete module with this fix.

module dma_write(
input wire clk,
input wire rst,
input wire [15:0] desc_addr,
input wire [15:0] desc_len,
input wire [7:0] desc_tag,
input wire desc_valid,
output wire desc_ready,
input wire [31:0] s_data,
input wire [3:0] s_keep,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [15:0] status_len,
output wire [7:0] status_tag,
output wire [3:0] status_error,
output wire status_valid,
output wire [3:0] m_axi_awid,
output wire [15:0] m_axi_awaddr,
output wire [7:0] m_axi_awlen,
output wire [2:0] m_axi_awsize,
output wire [1:0] m_axi_awburst,
output wire m_axi_awlock,
output wire [3:0] m_axi_awcache,
output wire [2:0] m_axi_awprot,
output wire m_axi_awvalid,
input wire m_axi_awready,
output wire [31:0] m_axi_wdata,
output wire [3:0] m_axi_wstrb,
output wire m_axi_wlast,
output wire m_axi_wvalid,
input wire m_axi_wready,
input wire [3:0] m_axi_bid,
input wire [1:0] m_axi_bresp,
input wire m_axi_bvalid,
output wire m_axi_bready);
assign m_axi_awprot = 3'b000;
reg active, seen_slverr, seen_decerr;
wire raw_desc_ready, raw_status_valid;
wire [3:0] raw_error;
assign desc_ready = raw_desc_ready && !active && !rst;
assign status_valid = raw_status_valid;
assign status_error = seen_decerr ? 4'd7 : (seen_slverr ? 4'd6 : raw_error);
always @(posedge clk) begin
    if (rst) begin
        active <= 1'b0;
        seen_slverr <= 1'b0;
        seen_decerr <= 1'b0;
    end else begin
        if (raw_status_valid) active <= 1'b0;
        if (desc_valid && desc_ready) begin
            active <= 1'b1;
            seen_slverr <= 1'b0;
            seen_decerr <= 1'b0;
        end
        if (m_axi_bvalid && m_axi_bready) begin
            if (m_axi_bresp == 2'b10) seen_slverr <= 1'b1;
            if (m_axi_bresp == 2'b11) seen_decerr <= 1'b1;
        end
    end
end
reg [15:0] core_desc_addr;
reg [15:0] core_desc_len;
reg [7:0] core_desc_tag;
reg core_desc_valid;
always @(posedge clk) begin
    if (rst) begin
        core_desc_valid <= 1'b0;
    end else begin
        if (desc_valid && desc_ready) begin
            core_desc_addr <= desc_addr;
            core_desc_len <= desc_len;
            core_desc_tag <= desc_tag;
            core_desc_valid <= 1'b1;
        end else if (raw_status_valid) begin
            core_desc_valid <= 1'b0;
        end
    end
end
axi_dma_wr #(
    .AXI_DATA_WIDTH(32),
    .AXI_ADDR_WIDTH(16),
    .AXI_STRB_WIDTH(4),
    .AXI_ID_WIDTH(4),
    .AXIS_DATA_WIDTH(32),
    .AXIS_KEEP_WIDTH(4),
    .LEN_WIDTH(16),
    .TAG_WIDTH(8),
    .ENABLE_UNALIGNED(1)
) core (
    .clk(clk),
    .rst(rst),
    .s_axis_write_desc_addr(core_desc_addr),
    .s_axis_write_desc_len(core_desc_len),
    .s_axis_write_desc_tag(core_desc_tag),
    .s_axis_write_desc_valid(core_desc_valid),
    .s_axis_write_desc_ready(raw_desc_ready),
    .m_axis_write_desc_status_len(status_len),
    .m_axis_write_desc_status_tag(status_tag),
    .m_axis_write_desc_status_error(raw_error),
    .m_axis_write_desc_status_valid(raw_status_valid),
    .s_axis_write_data_tdata(s_data),
    .s_axis_write_data_tkeep(s_keep),
    .s_axis_write_data_tvalid(s_valid),
    .s_axis_write_data_tready(s_ready),
    .s_axis_write_data_tlast(s_last),
    .s_axis_write_data_tid(8'b0),
    .s_axis_write_data_tdest(8'b0),
    .s_axis_write_data_tuser(1'b0),
    .enable(1'b1),
    .abort(1'b0),
    .m_axi_awid(m_axi_awid),
    .m_axi_awaddr(m_axi_awaddr),
    .m_axi_awlen(m_axi_awlen),
    .m_axi_awsize(m_axi_awsize),
    .m_axi_awburst(m_axi_awburst),
    .m_axi_awlock(m_axi_awlock),
    .m_axi_awcache(m_axi_awcache),
    .m_axi_awprot(),
    .m_axi_awvalid(m_axi_awvalid),
    .m_axi_awready(m_axi_awready),
    .m_axi_wdata(m_axi_wdata),
    .m_axi_wstrb(m_axi_wstrb),
    .m_axi_wlast(m_axi_wlast),
    .m_axi_wvalid(m_axi_wvalid),
    .m_axi_wready(m_axi_wready),
    .m_axi_bid(m_axi_bid),
    .m_axi_bresp(m_axi_bresp),
    .m_axi_bvalid(m_axi_bvalid),
    .m_axi_bready(m_axi_bready)
);
endmodule
