module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

reg [7:0] bytes[0:511];
reg [9:0] n, ptr;
reg [3:0] state;
reg status_valid_reg;
reg [3:0] status_error_reg;
reg [31:0] m_src_ip_reg;
reg [15:0] m_src_port_reg;
reg [15:0] m_dst_port_reg;
reg [15:0] m_payload_len_reg;
reg m_valid_reg;
reg m_last_reg;
reg [7:0] m_data_reg;

reg [17:0] ip_sum_reg;
reg [17:0] udp_sum_reg;
reg [15:0] ip_len_reg;
reg [15:0] udp_len_reg;
reg [15:0] udp_checksum_reg;
reg [9:0] calc_ptr;
reg calc_done;
reg [3:0] error_code_reg;

wire [15:0] word16_ip;
assign word16_ip = {bytes[calc_ptr], bytes[calc_ptr+1]};

wire [17:0] ip_sum_next;
wire [17:0] udp_sum_next;
wire [17:0] fold_ip;
wire [17:0] fold_udp;

assign fold_ip = (ip_sum_reg[15:0] + ip_sum_reg[17:16]);
assign fold_udp = (udp_sum_reg[15:0] + udp_sum_reg[17:16]);

localparam IDLE = 4'd0;
localparam RECEIVE = 4'd1;
localparam CALC_IP_SUM = 4'd2;
localparam CALC_UDP_PSEUDO = 4'd3;
localparam CALC_UDP_SUM = 4'd4;
localparam CHECK = 4'd5;
localparam OUTPUT_STATUS = 4'd6;
localparam OUTPUT_PAYLOAD = 4'd7;
localparam DRAIN_OVERSIZE = 4'd8;

wire [15:0] ip_total_length = {bytes[2], bytes[3]};
wire [15:0] udp_length = {bytes[24], bytes[25]};
wire [15:0] udp_checksum = {bytes[26], bytes[27]};
wire [31:0] dst_ip = {bytes[16], bytes[17], bytes[18], bytes[19]};
wire [15:0] dst_port = {bytes[22], bytes[23]};

wire version = bytes[0][7:4];
wire ihl = bytes[0][3:0];
wire mf = bytes[6][5];
wire [12:0] frag_offset = {bytes[6][4:0], bytes[7]};
wire protocol = bytes[9];

reg [9:0] payload_bytes;
reg [15:0] payload_len_check;

assign s_ready = !rst && (state == IDLE || state == RECEIVE || state == DRAIN_OVERSIZE);

assign status_valid = status_valid_reg;
assign status_error = status_error_reg;
assign m_src_ip = m_src_ip_reg;
assign m_src_port = m_src_port_reg;
assign m_dst_port = m_dst_port_reg;
assign m_payload_len = m_payload_len_reg;
assign m_data = m_data_reg;
assign m_valid = m_valid_reg;
assign m_last = m_last_reg;

always @(posedge clk) begin
    if (rst) begin
        state <= IDLE;
        n <= 10'd0;
        ptr <= 10'd20;
        status_valid_reg <= 1'b0;
        status_error_reg <= 4'd0;
        m_src_ip_reg <= 32'd0;
        m_src_port_reg <= 16'd0;
        m_dst_port_reg <= 16'd0;
        m_payload_len_reg <= 16'd0;
        m_valid_reg <= 1'b0;
        m_last_reg <= 1'b0;
        m_data_reg <= 8'd0;
        ip_sum_reg <= 18'd0;
        udp_sum_reg <= 18'd0;
        calc_ptr <= 10'd0;
        calc_done <= 1'b0;
        error_code_reg <= 4'd0;
        ip_len_reg <= 16'd0;
        udp_len_reg <= 16'd0;
        udp_checksum_reg <= 16'd0;
        payload_bytes <= 10'd0;
        payload_len_check <= 16'd0;
    end else begin
        status_valid_reg <= 1'b0;
        m_valid_reg <= 1'b0;
        
        case (state)
            IDLE: begin
                n <= 10'd0;
                ptr <= 10'd20;
                ip_sum_reg <= 18'd0;
                udp_sum_reg <= 18'd0;
                calc_ptr <= 10'd0;
                calc_done <= 1'b0;
                error_code_reg <= 4'd0;
                if (s_valid && s_ready) begin
                    bytes[0] <= s_data;
                    n <= 10'd1;
                    if (s_last) begin
                        state <= CALC_IP_SUM;
                    end else begin
                        state <= RECEIVE;
                    end
                end
            end
            
            RECEIVE: begin
                if (s_valid && s_ready) begin
                    if (n < 10'd512) begin
                        bytes[n] <= s_data;
                    end
                    n <= n + 10'd1;
                    if (s_last) begin
                        if (n >= 10'd511) begin
                            state <= DRAIN_OVERSIZE;
                        end else begin
                            state <= CALC_IP_SUM;
                        end
                    end else if (n == 10'd511) begin
                        state <= DRAIN_OVERSIZE;
                    end
                end
            end
            
            DRAIN_OVERSIZE: begin
                if (s_valid && s_ready && s_last) begin
                    state <= CALC_IP_SUM;
                    n <= 10'd512;
                end
            end
            
            CALC_IP_SUM: begin
                ip_len_reg <= ip_total_length;
                udp_len_reg <= udp_length;
                udp_checksum_reg <= udp_checksum;
                if (n < 10'd28) begin
                    error_code_reg <= 4'd1;
                    state <= OUTPUT_STATUS;
                end else if (n > 10'd512) begin
                    error_code_reg <= 4'd1;
                    state <= OUTPUT_STATUS;
                end else if (version != 4'd4) begin
                    error_code_reg <= 4'd1;
                    state <= OUTPUT_STATUS;
                end else if (ihl != 4'd5) begin
                    error_code_reg <= 4'd1;
                    state <= OUTPUT_STATUS;
                end else if (protocol != 8'd17) begin
                    error_code_reg <= 4'd1;
                    state <= OUTPUT_STATUS;
                end else if (mf || (frag_offset != 13'd0)) begin
                    error_code_reg <= 4'd1;
                    state <= OUTPUT_STATUS;
                end else begin
                    calc_ptr <= 10'd0;
                    ip_sum_reg <= 18'd0;
                    state <= CALC_UDP_PSEUDO;
                end
            end
            
            CALC_UDP_PSEUDO: begin
                if (calc_ptr < 10'd20) begin
                    ip_sum_reg <= ip_sum_reg + {2'b00, word16_ip};
                    calc_ptr <= calc_ptr + 10'd2;
                end else begin
                    ip_sum_reg <= (ip_sum_reg[15:0] + ip_sum_reg[17:16]) + ((ip_sum_reg[15:0] + ip_sum_reg[17:16]) >> 16);
                    if (ip_total_length != n[15:0]) begin
                        error_code_reg <= 4'd2;
                        state <= OUTPUT_STATUS;
                    end else if (udp_length != ip_total_length - 16'd20) begin
                        error_code_reg <= 4'd2;
                        state <= OUTPUT_STATUS;
                    end else begin
                        payload_len_check <= udp_length - 16'd8;
                        if (udp_length < 16'd9 || udp_length > 16'd264) begin
                            error_code_reg <= 4'd2;
                            state <= OUTPUT_STATUS;
                        end else begin
                            payload_bytes <= udp_length[9:0] - 10'd8;
                            if (fold_ip[15:0] != 16'hffff) begin
                                error_code_reg <= 4'd3;
                                state <= OUTPUT_STATUS;
                            end else begin
                                udp_sum_reg <= 18'd0;
                                calc_ptr <= 10'd12;
                                state <= CALC_UDP_SUM;
                            end
                        end
                    end
                end
            end
            
            CALC_UDP_SUM: begin
                if (calc_ptr < 10'd20) begin
                    udp_sum_reg <= udp_sum_reg + {2'b00, word16_ip};
                    calc_ptr <= calc_ptr + 10'd2;
                end else if (calc_ptr == 10'd20) begin
                    udp_sum_reg <= udp_sum_reg + {2'b00, 16'd17};
                    calc_ptr <= calc_ptr + 10'd2;
                end else if (calc_ptr == 10'd22) begin
                    udp_sum_reg <= udp_sum_reg + {2'b00, udp_len_reg};
                    calc_ptr <= 10'd28;
                end else if (calc_ptr >= 10'd28 && calc_ptr < n && calc_ptr < 10'd512) begin
                    if (calc_ptr + 10'd1 < n) begin
                        udp_sum_reg <= udp_sum_reg + {2'b00, {bytes[calc_ptr], bytes[calc_ptr+1]}};
                        calc_ptr <= calc_ptr + 10'd2;
                    end else begin
                        udp_sum_reg <= udp_sum_reg + {2'b00, {bytes[calc_ptr], 8'h00}};
                        calc_ptr <= 10'd512;
                    end
                end else begin
                    udp_sum_reg <= (udp_sum_reg[15:0] + udp_sum_reg[17:16]) + ((udp_sum_reg[15:0] + udp_sum_reg[17:16]) >> 16);
                    state <= CHECK;
                end
            end
            
            CHECK: begin
                if (udp_checksum_reg != 16'd0 && fold_udp[15:0] != 16'hffff) begin
                    error_code_reg <= 4'd4;
                    state <= OUTPUT_STATUS;
                end else if (dst_ip != 32'h0a000002) begin
                    error_code_reg <= 4'd5;
                    state <= OUTPUT_STATUS;
                end else if (dst_port != 16'd9000) begin
                    error_code_reg <= 4'd5;
                    state <= OUTPUT_STATUS;
                end else begin
                    error_code_reg <= 4'd0;
                    m_src_ip_reg <= {bytes[12], bytes[13], bytes[14], bytes[15]};
                    m_src_port_reg <= {bytes[20], bytes[21]};
                    m_dst_port_reg <= dst_port;
                    m_payload_len_reg <= payload_len_check;
                    ptr <= 10'd28;
                    state <= OUTPUT_STATUS;
                end
            end
            
            OUTPUT_STATUS: begin
                status_valid_reg <= 1'b1;
                status_error_reg <= error_code_reg;
                if (error_code_reg == 4'd0) begin
                    state <= OUTPUT_PAYLOAD;
                end else begin
                    state <= IDLE;
                end
            end
            
            OUTPUT_PAYLOAD: begin
                if (m_ready || !m_valid_reg) begin
                    if (ptr < n) begin
                        m_data_reg <= bytes[ptr];
                        m_valid_reg <= 1'b1;
                        if (ptr == n - 10'd1) begin
                            m_last_reg <= 1'b1;
                            ptr <= ptr + 10'd1;
                        end else begin
                            m_last_reg <= 1'b0;
                            ptr <= ptr + 10'd1;
                        end
                    end else if (m_valid_reg && m_ready && m_last_reg) begin
                        m_valid_reg <= 1'b0;
                        m_last_reg <= 1'b0;
                        state <= IDLE;
                    end else if (!m_valid_reg) begin
                        state <= IDLE;
                    end
                end else begin
                    m_valid_reg <= m_valid_reg;
                    m_data_reg <= m_data_reg;
                    m_last_reg <= m_last_reg;
                end
            end
            
            default: state <= IDLE;
        endcase
    end
end

endmodule
