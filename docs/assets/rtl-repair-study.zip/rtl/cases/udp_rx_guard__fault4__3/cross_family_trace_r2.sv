`timescale 1ns/1ps
module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error
);

localparam ST_IDLE       = 3'd0;
localparam ST_RECV       = 3'd1;
localparam ST_ANALYZE    = 3'd2;
localparam ST_STATUS     = 3'd3;
localparam ST_OUTPUT     = 3'd4;
localparam ST_DRAIN      = 3'd5;

reg [2:0] state_reg = ST_IDLE;

reg [7:0] frame_mem[0:511];

reg [9:0] frame_len_reg = 10'd0;
reg oversize_reg = 1'b0;

reg [3:0] status_error_reg = 4'd0;
reg status_valid_reg = 1'b0;

reg [31:0] m_src_ip_reg = 32'd0;
reg [15:0] m_src_port_reg = 16'd0;
reg [15:0] m_dst_port_reg = 16'd0;
reg [15:0] m_payload_len_reg = 16'd0;

reg [9:0] out_ptr_reg = 10'd0;
reg [9:0] out_end_reg = 10'd0;
reg out_active_reg = 1'b0;
reg [7:0] m_data_reg = 8'd0;
reg m_valid_reg = 1'b0;
reg m_last_reg = 1'b0;

wire holding_output;
assign holding_output = out_active_reg || m_valid_reg;

assign s_ready = !rst && (state_reg == ST_IDLE || state_reg == ST_RECV || state_reg == ST_DRAIN);

assign m_data = m_data_reg;
assign m_valid = m_valid_reg;
assign m_last = m_last_reg;
assign m_src_ip = m_src_ip_reg;
assign m_src_port = m_src_port_reg;
assign m_dst_port = m_dst_port_reg;
assign m_payload_len = m_payload_len_reg;
assign status_valid = status_valid_reg;
assign status_error = status_error_reg;

integer i;
reg [3:0] next_error;
reg [15:0] ip_total_length;
reg [15:0] udp_length;
reg [15:0] udp_checksum;
reg [15:0] udp_payload_length;
reg [31:0] dst_ip;
reg [31:0] src_ip_v;
reg [15:0] src_port_v;
reg [15:0] dst_port_v;
reg [17:0] sum;
reg [17:0] tmp;
reg [15:0] folded;
reg [9:0] udp_end;
reg [9:0] idx;

always @(posedge clk) begin
    if (rst) begin
        state_reg <= ST_IDLE;
        frame_len_reg <= 10'd0;
        oversize_reg <= 1'b0;
        status_error_reg <= 4'd0;
        status_valid_reg <= 1'b0;
        m_src_ip_reg <= 32'd0;
        m_src_port_reg <= 16'd0;
        m_dst_port_reg <= 16'd0;
        m_payload_len_reg <= 16'd0;
        out_ptr_reg <= 10'd0;
        out_end_reg <= 10'd0;
        out_active_reg <= 1'b0;
        m_data_reg <= 8'd0;
        m_valid_reg <= 1'b0;
        m_last_reg <= 1'b0;
    end else begin
        status_valid_reg <= 1'b0;

        if (m_valid_reg && m_ready) begin
            if (m_last_reg) begin
                m_valid_reg <= 1'b0;
                m_last_reg <= 1'b0;
                out_active_reg <= 1'b0;
                state_reg <= ST_IDLE;
            end else if (out_active_reg) begin
                m_data_reg <= frame_mem[out_ptr_reg];
                m_last_reg <= (out_ptr_reg == out_end_reg);
                m_valid_reg <= 1'b1;
                out_ptr_reg <= out_ptr_reg + 10'd1;
            end else begin
                m_valid_reg <= 1'b0;
                m_last_reg <= 1'b0;
            end
        end

        case (state_reg)
            ST_IDLE: begin
                if (!holding_output) begin
                    frame_len_reg <= 10'd0;
                    oversize_reg <= 1'b0;
                    if (s_valid) begin
                        frame_mem[0] <= s_data;
                        frame_len_reg <= 10'd1;
                        if (s_last) begin
                            state_reg <= ST_ANALYZE;
                        end else begin
                            state_reg <= ST_RECV;
                        end
                    end
                end
            end

            ST_RECV: begin
                if (s_valid) begin
                    if (!oversize_reg) begin
                        if (frame_len_reg < 10'd512) begin
                            frame_mem[frame_len_reg] <= s_data;
                            frame_len_reg <= frame_len_reg + 10'd1;
                        end else begin
                            oversize_reg <= 1'b1;
                        end
                    end
                    if (s_last) begin
                        state_reg <= ST_ANALYZE;
                    end
                end
            end

            ST_DRAIN: begin
                if (s_valid && s_last) begin
                    state_reg <= ST_ANALYZE;
                end
            end

            ST_ANALYZE: begin
                next_error = 4'd0;

                ip_total_length = {frame_mem[2], frame_mem[3]};
                udp_length = {frame_mem[24], frame_mem[25]};
                udp_checksum = {frame_mem[26], frame_mem[27]};
                udp_payload_length = udp_length - 16'd8;
                dst_ip = {frame_mem[16], frame_mem[17], frame_mem[18], frame_mem[19]};
                src_ip_v = {frame_mem[12], frame_mem[13], frame_mem[14], frame_mem[15]};
                src_port_v = {frame_mem[20], frame_mem[21]};
                dst_port_v = {frame_mem[22], frame_mem[23]};

                if (oversize_reg || (frame_len_reg < 10'd28) || (frame_len_reg > 10'd512) ||
                    (frame_mem[0][7:4] != 4'd4) ||
                    (frame_mem[0][3:0] != 4'd5) ||
                    (frame_mem[9] != 8'd17) ||
                    frame_mem[6][5] ||
                    ({frame_mem[6][4:0], frame_mem[7]} != 13'd0)) begin
                    next_error = 4'd1;
                end else if ((ip_total_length != frame_len_reg) ||
                             (udp_length != (ip_total_length - 16'd20)) ||
                             (udp_payload_length < 16'd1) ||
                             (udp_payload_length > 16'd256)) begin
                    next_error = 4'd2;
                end else begin
                    sum = 18'd0;
                    for (i = 0; i < 20; i = i + 2) begin
                        sum = sum + {2'b00, frame_mem[i], frame_mem[i+1]};
                    end
                    tmp = {2'b00, sum[15:0]} + sum[17:16];
                    tmp = {2'b00, tmp[15:0]} + tmp[17:16];
                    folded = tmp[15:0];
                    if (folded != 16'hffff) begin
                        next_error = 4'd3;
                    end else begin
                        if (udp_checksum != 16'd0) begin
                            sum = 18'd0;
                            sum = sum + {2'b00, frame_mem[12], frame_mem[13]};
                            sum = sum + {2'b00, frame_mem[14], frame_mem[15]};
                            sum = sum + {2'b00, frame_mem[16], frame_mem[17]};
                            sum = sum + {2'b00, frame_mem[18], frame_mem[19]};
                            sum = sum + 18'd17;
                            sum = sum + {2'b00, udp_length};

                            udp_end = 10'd28 + udp_length - 10'd1;
                            idx = 10'd20;
                            while (idx <= udp_end) begin
                                if (idx < udp_end) begin
                                    sum = sum + {2'b00, frame_mem[idx], frame_mem[idx+1]};
                                    idx = idx + 10'd2;
                                end else begin
                                    sum = sum + {2'b00, frame_mem[idx], 8'h00};
                                    idx = idx + 10'd1;
                                end
                            end

                            tmp = {2'b00, sum[15:0]} + sum[17:16];
                            tmp = {2'b00, tmp[15:0]} + tmp[17:16];
                            folded = tmp[15:0];
                            if (folded != 16'hffff) begin
                                next_error = 4'd4;
                            end
                        end

                        if (next_error == 4'd0) begin
                            if ((dst_ip != 32'h0a000002) || (dst_port_v != 16'd9000)) begin
                                next_error = 4'd5;
                            end
                        end
                    end
                end

                status_error_reg <= next_error;

                if (next_error == 4'd0) begin
                    m_src_ip_reg <= src_ip_v;
                    m_src_port_reg <= src_port_v;
                    m_dst_port_reg <= dst_port_v;
                    m_payload_len_reg <= udp_payload_length;
                    out_ptr_reg <= 10'd29;
                    out_end_reg <= 10'd28 + udp_payload_length - 10'd1;
                    out_active_reg <= 1'b0;
                end

                state_reg <= ST_STATUS;
            end

            ST_STATUS: begin
                status_valid_reg <= 1'b1;
                if (status_error_reg == 4'd0) begin
                    if (m_payload_len_reg != 16'd0) begin
                        m_data_reg <= frame_mem[10'd28];
                        m_last_reg <= (m_payload_len_reg == 16'd1);
                        m_valid_reg <= 1'b1;
                        out_active_reg <= (m_payload_len_reg != 16'd1);
                        state_reg <= (m_payload_len_reg == 16'd1) ? ST_OUTPUT : ST_OUTPUT;
                    end else begin
                        state_reg <= ST_IDLE;
                    end
                end else begin
                    state_reg <= ST_IDLE;
                end
            end

            ST_OUTPUT: begin
                if (!m_valid_reg && !out_active_reg) begin
                    state_reg <= ST_IDLE;
                end
            end

            default: begin
                state_reg <= ST_IDLE;
            end
        endcase

        if (state_reg == ST_RECV && s_valid && !s_last && !oversize_reg && frame_len_reg == 10'd512) begin
            oversize_reg <= 1'b1;
            state_reg <= ST_DRAIN;
        end
        if (state_reg == ST_RECV && oversize_reg && !s_last && s_valid) begin
            state_reg <= ST_DRAIN;
        end
    end
end

endmodule
