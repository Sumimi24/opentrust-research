module icache_ctrl(
input wire clk_i,
input wire rst_ni,
input wire req_i,
input wire branch_i,
input wire [31:0] addr_i,
input wire ready_i,
output wire valid_o,
output wire [31:0] rdata_o,
output wire [31:0] addr_o,
output wire err_o,
output wire instr_req_o,
input wire instr_gnt_i,
output wire [31:0] instr_addr_o,
input wire [31:0] instr_rdata_i,
input wire instr_err_i,
input wire instr_rvalid_i,
input wire icache_inval_i,
output wire busy_o);

  localparam int CACHE_LINES = 8;
  localparam int INDEX_W = 3;
  localparam int TAG_W = 27;
  localparam int FIFO_W = 6;
  localparam int MAX_OUTSTANDING = 32;

  reg [31:0] cache_data [0:CACHE_LINES-1];
  reg [TAG_W-1:0] cache_tag [0:CACHE_LINES-1];
  reg [CACHE_LINES-1:0] cache_valid;

  reg [31:0] out_data_q;
  reg [31:0] out_addr_q;
  reg        out_err_q;
  reg        out_valid_q;
  reg        error_mode_q;

  reg [31:0] pc_q;
  reg        stream_valid_q;
  reg [5:0]  branch_epoch_q;

  reg [31:0] req_addr_fifo [0:MAX_OUTSTANDING-1];
  reg [5:0]  req_epoch_fifo [0:MAX_OUTSTANDING-1];
  reg [FIFO_W-1:0] req_wr_ptr_q, req_rd_ptr_q;
  reg [5:0] req_count_q;

  reg [31:0] rsp_data_fifo [0:MAX_OUTSTANDING-1];
  reg [31:0] rsp_addr_fifo [0:MAX_OUTSTANDING-1];
  reg        rsp_err_fifo  [0:MAX_OUTSTANDING-1];
  reg [FIFO_W-1:0] rsp_wr_ptr_q, rsp_rd_ptr_q;
  reg [5:0] rsp_count_q;

  reg [31:0] miss_addr_q;
  reg        miss_pending_q;

  reg [31:0] fetch_addr_q;
  reg        fetch_pending_q;

  reg inval_pending_q;

  reg [31:0] issue_addr;
  reg issue_valid;
  reg issue_is_miss;
  reg hit_found;
  reg [31:0] hit_data;
  reg [INDEX_W-1:0] hit_idx;
  reg bus_can_issue;
  reg [INDEX_W-1:0] tmp_idx;
  reg [TAG_W-1:0] tmp_tag;
  integer i;

  wire consume_out = out_valid_q && ready_i && !branch_i;
  wire [INDEX_W-1:0] pc_index = pc_q[4:2];
  wire [TAG_W-1:0] pc_tag = pc_q[31:5];
  wire cache_hit_now = cache_valid[pc_index] && (cache_tag[pc_index] == pc_tag);
  wire fifo_room = (req_count_q < MAX_OUTSTANDING);
  wire rsp_avail = (rsp_count_q != 0);
  wire busy_int = (req_count_q != 0) || (rsp_count_q != 0) || out_valid_q || miss_pending_q || fetch_pending_q || inval_pending_q;

  assign valid_o = out_valid_q;
  assign rdata_o = out_data_q;
  assign addr_o  = out_addr_q;
  assign err_o   = out_err_q;

  assign instr_req_o = issue_valid;
  assign instr_addr_o = {issue_addr[31:2], 2'b00};

  assign busy_o = busy_int;

  always @(*) begin
    hit_found = 1'b0;
    hit_data = 32'b0;
    hit_idx = pc_index;

    if (stream_valid_q && !out_valid_q && !error_mode_q && cache_hit_now) begin
      hit_found = 1'b1;
      hit_data = cache_data[pc_index];
      hit_idx = pc_index;
    end

    issue_valid = 1'b0;
    issue_addr = 32'b0;
    issue_is_miss = 1'b0;

    bus_can_issue = stream_valid_q && req_i && !out_valid_q && !error_mode_q && fifo_room;

    if (bus_can_issue) begin
      if (miss_pending_q) begin
        if (pc_q == miss_addr_q) begin
          issue_valid = 1'b0;
        end else begin
          issue_valid = 1'b1;
          issue_addr = pc_q;
          issue_is_miss = 1'b0;
        end
      end else if (!cache_hit_now) begin
        issue_valid = 1'b1;
        issue_addr = pc_q;
        issue_is_miss = 1'b1;
      end else if (!fetch_pending_q) begin
        issue_valid = 1'b1;
        issue_addr = pc_q + 32'd4;
        issue_is_miss = 1'b0;
      end
    end
  end

  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      cache_valid <= {CACHE_LINES{1'b0}};
      out_data_q <= 32'b0;
      out_addr_q <= 32'b0;
      out_err_q <= 1'b0;
      out_valid_q <= 1'b0;
      error_mode_q <= 1'b0;
      pc_q <= 32'b0;
      stream_valid_q <= 1'b0;
      branch_epoch_q <= 6'b0;
      req_wr_ptr_q <= {FIFO_W{1'b0}};
      req_rd_ptr_q <= {FIFO_W{1'b0}};
      req_count_q <= 6'b0;
      rsp_wr_ptr_q <= {FIFO_W{1'b0}};
      rsp_rd_ptr_q <= {FIFO_W{1'b0}};
      rsp_count_q <= 6'b0;
      miss_addr_q <= 32'b0;
      miss_pending_q <= 1'b0;
      fetch_addr_q <= 32'b0;
      fetch_pending_q <= 1'b0;
      inval_pending_q <= 1'b0;
      for (i = 0; i < CACHE_LINES; i = i + 1) begin
        cache_data[i] <= 32'b0;
        cache_tag[i] <= {TAG_W{1'b0}};
      end
    end else begin
      if (icache_inval_i) begin
        cache_valid <= {CACHE_LINES{1'b0}};
        inval_pending_q <= 1'b1;
      end else begin
        inval_pending_q <= 1'b0;
      end

      if (branch_i) begin
        out_valid_q <= 1'b0;
        out_err_q <= 1'b0;
        error_mode_q <= 1'b0;
        pc_q <= {addr_i[31:2], 2'b00};
        stream_valid_q <= 1'b1;
        branch_epoch_q <= branch_epoch_q + 6'd1;
        miss_pending_q <= 1'b0;
        fetch_pending_q <= 1'b0;
      end else begin
        if (consume_out) begin
          out_valid_q <= 1'b0;
          out_err_q <= 1'b0;
          if (out_err_q) begin
            error_mode_q <= 1'b1;
          end else begin
            pc_q <= out_addr_q + 32'd4;
          end
        end

        if (!out_valid_q && !error_mode_q && stream_valid_q) begin
          if (hit_found) begin
            out_valid_q <= 1'b1;
            out_data_q <= hit_data;
            out_addr_q <= pc_q;
            out_err_q <= 1'b0;
          end else if (rsp_avail && (rsp_addr_fifo[rsp_rd_ptr_q] == pc_q)) begin
            out_valid_q <= 1'b1;
            out_data_q <= rsp_data_fifo[rsp_rd_ptr_q];
            out_addr_q <= rsp_addr_fifo[rsp_rd_ptr_q];
            out_err_q <= rsp_err_fifo[rsp_rd_ptr_q];
            rsp_rd_ptr_q <= rsp_rd_ptr_q + {{(FIFO_W-1){1'b0}},1'b1};
            rsp_count_q <= rsp_count_q - 6'd1;
            if (miss_pending_q && (miss_addr_q == pc_q))
              miss_pending_q <= 1'b0;
          end
        end
      end

      if (issue_valid && instr_gnt_i) begin
        req_addr_fifo[req_wr_ptr_q] <= issue_addr;
        req_epoch_fifo[req_wr_ptr_q] <= branch_epoch_q;
        req_wr_ptr_q <= req_wr_ptr_q + {{(FIFO_W-1){1'b0}},1'b1};
        req_count_q <= req_count_q + 6'd1;
        if (issue_is_miss) begin
          miss_pending_q <= 1'b1;
          miss_addr_q <= issue_addr;
        end else begin
          fetch_pending_q <= 1'b1;
          fetch_addr_q <= issue_addr;
        end
      end

      if (instr_rvalid_i && (req_count_q != 0)) begin
        tmp_idx = req_addr_fifo[req_rd_ptr_q][4:2];
        tmp_tag = req_addr_fifo[req_rd_ptr_q][31:5];

        if (req_epoch_fifo[req_rd_ptr_q] == branch_epoch_q) begin
          rsp_data_fifo[rsp_wr_ptr_q] <= instr_rdata_i;
          rsp_addr_fifo[rsp_wr_ptr_q] <= req_addr_fifo[req_rd_ptr_q];
          rsp_err_fifo[rsp_wr_ptr_q] <= instr_err_i;
          rsp_wr_ptr_q <= rsp_wr_ptr_q + {{(FIFO_W-1){1'b0}},1'b1};
          rsp_count_q <= rsp_count_q + 6'd1;

          if (!instr_err_i) begin
            cache_data[tmp_idx] <= instr_rdata_i;
            cache_tag[tmp_idx] <= tmp_tag;
            cache_valid[tmp_idx] <= 1'b1;
          end

          if (fetch_pending_q && (fetch_addr_q == req_addr_fifo[req_rd_ptr_q]))
            fetch_pending_q <= 1'b0;
          if (miss_pending_q && (miss_addr_q == req_addr_fifo[req_rd_ptr_q]))
            miss_pending_q <= 1'b0;
        end else begin
          if (fetch_pending_q && (fetch_addr_q == req_addr_fifo[req_rd_ptr_q]))
            fetch_pending_q <= 1'b0;
          if (miss_pending_q && (miss_addr_q == req_addr_fifo[req_rd_ptr_q]))
            miss_pending_q <= 1'b0;
        end

        req_rd_ptr_q <= req_rd_ptr_q + {{(FIFO_W-1){1'b0}},1'b1};
        req_count_q <= req_count_q - 6'd1;
      end
    end
  end

endmodule
