module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

localparam IDLE=0,RECV=1,VALIDATE=2,WAIT_HDR=3,OUTPUT=4,DONE=5,DRAIN=6;

reg [2:0] state;
reg [9:0] n,ptr;
reg [7:0] bytes[0:511];
reg [9:0] ip_len,udp_len;
reg [15:0] m_src_port_reg,m_dst_port_reg;
reg [31:0] m_src_ip_reg;
reg [15:0] m_payload_len_reg;
reg [3:0] error_code;
reg status_valid_reg;
reg [15:0] status_error_reg;
reg m_valid_reg,m_last_reg;
reg [7:0] m_data_reg;
reg [12:0] cycle_cnt;
reg draining;

function automatic [15:0] word16(input [8:0] offset);
    word16 = {bytes[offset],bytes[offset+1]};
endfunction

function automatic [15:0] fold16(input [31:0] val);
    reg [16:0] tmp;
    begin
        tmp = val[15:0] + val[31:16];
        fold16 = tmp[15:0] + tmp[16];
    end
endfunction

wire [15:0] ip_total_len = word16(2);
wire [15:0] udp_total_len = word16(24);
wire [15:0] udp_checksum = word16(26);

reg [31:0] ip_sum_acc;
reg [31:0] udp_sum_acc;
reg [9:0] udp_sum_cnt;
reg computing_ip_sum,computing_udp_sum;

always @(*) begin
    error_code = 4'd0;
    if (n < 28 || n > 512 || bytes[0][7:4] != 4'd4 || bytes[0][3:0] != 4'd5 || bytes[9] != 8'd17 || (bytes[6] & 8'h20) != 8'h00 || bytes[7] != 8'h00 || (bytes[6] & 8'h1f) != 8'h00)
        error_code = 4'd1;
    else if (ip_total_len != n[15:0] || udp_total_len != ip_total_len - 16'd20 || udp_total_len < 16'd9 || udp_total_len > 16'd264)
        error_code = 4'd2;
end

wire [31:0] ip_addr_check = {bytes[16],bytes[17],bytes[18],bytes[19]};
wire [15:0] udp_dst_port = word16(22);

wire ip_sum_done = !computing_ip_sum;
wire udp_sum_done = !computing_udp_sum;

assign s_ready = !rst && ((state == IDLE) || (state == RECV && !draining));

assign status_valid = status_valid_reg;
assign status_error = status_error_reg[3:0];

assign m_data = m_data_reg;
assign m_valid = m_valid_reg;
assign m_last = m_last_reg;
assign m_src_ip = m_src_ip_reg;
assign m_src_port = m_src_port_reg;
assign m_dst_port = m_dst_port_reg;
assign m_payload_len = m_payload_len_reg;

always @(posedge clk) begin
    if (rst) begin
        state <= IDLE;
        n <= 10'd0;
        ptr <= 10'd20;
        status_valid_reg <= 1'b0;
        status_error_reg <= 4'd0;
        m_valid_reg <= 1'b0;
        m_last_reg <= 1'b0;
        m_data_reg <= 8'd0;
        m_src_ip_reg <= 32'd0;
        m_src_port_reg <= 16'd0;
        m_dst_port_reg <= 16'd0;
        m_payload_len_reg <= 16'd0;
        ip_sum_acc <= 32'd0;
        udp_sum_acc <= 32'd0;
        udp_sum_cnt <= 10'd0;
        computing_ip_sum <= 1'b0;
        computing_udp_sum <= 1'b0;
        cycle_cnt <= 13'd0;
        draining <= 1'b0;
    end else begin
        status_valid_reg <= 1'b0;
        cycle_cnt <= cycle_cnt + 13'd1;
        
        case (state)
            IDLE: begin
                n <= 10'd0;
                ptr <= 10'd20;
                m_valid_reg <= 1'b0;
                m_last_reg <= 1'b0;
                cycle_cnt <= 13'd0;
                draining <= 1'b0;
                ip_sum_acc <= 32'd0;
                udp_sum_acc <= 32'd0;
                udp_sum_cnt <= 10'd0;
                computing_ip_sum <= 1'b0;
                computing_udp_sum <= 1'b0;
                if (s_valid && s_ready) begin
                    bytes[0] <= s_data;
                    n <= 10'd1;
                    if (s_last) begin
                        state <= VALIDATE;
                        computing_ip_sum <= 1'b1;
                    end else begin
                        state <= RECV;
                    end
                end
            end
            
            RECV: begin
                if (s_valid && s_ready) begin
                    if (n < 512) begin
                        bytes[n] <= s_data;
                    end
                    if (n < 10'd511) begin
                        n <= n + 10'd1;
                    end else begin
                        n <= 10'd512;
                    end
                    if (s_last) begin
                        if (n >= 10'd511) begin
                            draining <= 1'b1;
                            state <= DRAIN;
                        end else begin
                            state <= VALIDATE;
                            computing_ip_sum <= 1'b1;
                        end
                    end else if (n >= 10'd511) begin
                        draining <= 1'b1;
                    end
                end
            end
            
            DRAIN: begin
                if (s_valid && s_ready && s_last) begin
                    state <= VALIDATE;
                    draining <= 1'b0;
                    computing_ip_sum <= 1'b1;
                end
            end
            
            VALIDATE: begin
                if (computing_ip_sum) begin
                    if (ip_sum_acc == 32'd0) begin
                        ip_sum_acc <= {bytes[0],bytes[1]} + {bytes[2],bytes[3]} + {bytes[4],bytes[5]} + 
                                      {bytes[6],bytes[7]} + {bytes[8],bytes[9]} + {bytes[10],bytes[11]} +
                                      {bytes[12],bytes[13]} + {bytes[14],bytes[15]} + {bytes[16],bytes[17]} +
                                      {bytes[18],bytes[19]};
                    end else begin
                        computing_ip_sum <= 1'b0;
                        if (fold16(ip_sum_acc) != 16'hFFFF)
                            error_code <= 4'd3;
                        else if (udp_checksum != 16'd0)
                            computing_udp_sum <= 1'b1;
                    end
                end else if (computing_udp_sum) begin
                    if (udp_sum_cnt == 10'd0) begin
                        udp_sum_acc <= {bytes[12],bytes[13]} + {bytes[14],bytes[15]} + {bytes[16],bytes[17]} + {bytes[18],bytes[19]} +
                                       16'd0 + 16'd17 + udp_total_len;
                        udp_sum_cnt <= 10'd20;
                    end else begin
                        if (udp_sum_cnt < n) begin
                            if (udp_sum_cnt + 10'd1 < n) begin
                                udp_sum_acc <= udp_sum_acc + {bytes[udp_sum_cnt],bytes[udp_sum_cnt+1]};
                                udp_sum_cnt <= udp_sum_cnt + 10'd2;
                            end else begin
                                udp_sum_acc <= udp_sum_acc + {bytes[udp_sum_cnt],8'd0};
                                udp_sum_cnt <= n;
                            end
                        end else begin
                            computing_udp_sum <= 1'b0;
                        end
                    end
                end else begin
                    if (error_code == 4'd0) begin
                        if (udp_checksum != 16'd0 && fold16(udp_sum_acc) != 16'hFFFF)
                            error_code <= 4'd4;
                        else if (ip_addr_check != 32'h0A000002 || udp_dst_port != 16'd9000)
                            error_code <= 4'd5;
                    end
                    
                    status_valid_reg <= 1'b1;
                    status_error_reg <= error_code;
                    
                    if (error_code == 4'd0) begin
                        m_src_ip_reg <= {bytes[12],bytes[13],bytes[14],bytes[15]};
                        m_src_port_reg <= word16(20);
                        m_dst_port_reg <= word16(22);
                        m_payload_len_reg <= udp_total_len - 16'd8;
                        state <= OUTPUT;
                        ptr <= 10'd28;
                    end else begin
                        state <= IDLE;
                    end
                end
            end
            
            OUTPUT: begin
                if (!m_valid_reg || m_ready) begin
                    if (ptr < n) begin
                        m_data_reg <= bytes[ptr];
                        m_valid_reg <= 1'b1;
                        if (ptr == n - 10'd1) begin
                            m_last_reg <= 1'b1;
                            state <= DONE;
                        end else begin
                            ptr <= ptr + 10'd1;
                        end
                    end
                end
            end
            
            DONE: begin
                if (m_ready) begin
                    m_valid_reg <= 1'b0;
                    m_last_reg <= 1'b0;
                    state <= IDLE;
                end
            end
            
            default: state <= IDLE;
        endcase
    end
end

endmodule
