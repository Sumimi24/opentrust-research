`timescale 1ns/1ps
module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error
);

localparam ST_IDLE      = 3'd0;
localparam ST_RECV      = 3'd1;
localparam ST_VALIDATE  = 3'd2;
localparam ST_STATUS    = 3'd3;
localparam ST_OUTPUT    = 3'd4;
localparam ST_WAITDONE  = 3'd5;

reg [2:0] state_reg = ST_IDLE;

reg [7:0] buf_mem [0:511];
reg [8:0] recv_count_reg = 9'd0;
reg oversize_reg = 1'b0;

reg [8:0] frame_len_reg = 9'd0;
reg [15:0] ip_total_len_reg = 16'd0;
reg [15:0] udp_len_reg = 16'd0;
reg [15:0] udp_checksum_reg = 16'd0;
reg [31:0] dst_ip_reg = 32'd0;
reg [31:0] src_ip_meta_reg = 32'd0;
reg [15:0] src_port_meta_reg = 16'd0;
reg [15:0] dst_port_meta_reg = 16'd0;
reg [15:0] payload_len_meta_reg = 16'd0;

reg [3:0] status_error_reg = 4'd0;
reg status_valid_reg = 1'b0;

reg [8:0] out_ptr_reg = 9'd0;
reg [8:0] out_end_reg = 9'd0;
reg m_valid_reg = 1'b0;
reg [7:0] m_data_reg = 8'd0;
reg m_last_reg = 1'b0;

assign s_ready = (state_reg == ST_IDLE) || (state_reg == ST_RECV);

assign m_data = m_data_reg;
assign m_valid = m_valid_reg;
assign m_last = m_last_reg;
assign m_src_ip = src_ip_meta_reg;
assign m_src_port = src_port_meta_reg;
assign m_dst_port = dst_port_meta_reg;
assign m_payload_len = payload_len_meta_reg;
assign status_valid = status_valid_reg;
assign status_error = status_error_reg;

function automatic [15:0] get_word;
    input integer idx;
    begin
        get_word = {buf_mem[idx], buf_mem[idx+1]};
    end
endfunction

function automatic [15:0] fold16;
    input [31:0] x;
    reg [31:0] t;
    begin
        t = x;
        t = (t[15:0] + t[31:16]);
        t = (t[15:0] + t[31:16]);
        fold16 = t[15:0];
    end
endfunction

integer i;
reg [31:0] ip_sum;
reg [31:0] udp_sum;
reg [15:0] ip_fold;
reg [15:0] udp_fold;
reg [3:0] next_error;
reg [15:0] ip_total_len_v;
reg [15:0] udp_len_v;
reg [15:0] udp_checksum_v;
reg [15:0] udp_payload_len_v;
reg [15:0] src_port_v;
reg [15:0] dst_port_v;
reg [31:0] src_ip_v;
reg [31:0] dst_ip_v;
reg [8:0] frame_len_v;
reg [8:0] udp_bytes_end_v;
reg [7:0] ver_ihl;
reg [7:0] proto_byte;
reg [7:0] frag_hi;
reg [7:0] frag_lo;
reg [12:0] frag_off;

always @(posedge clk) begin
    if (rst) begin
        state_reg <= ST_IDLE;
        recv_count_reg <= 9'd0;
        oversize_reg <= 1'b0;
        frame_len_reg <= 9'd0;
        ip_total_len_reg <= 16'd0;
        udp_len_reg <= 16'd0;
        udp_checksum_reg <= 16'd0;
        dst_ip_reg <= 32'd0;
        src_ip_meta_reg <= 32'd0;
        src_port_meta_reg <= 16'd0;
        dst_port_meta_reg <= 16'd0;
        payload_len_meta_reg <= 16'd0;
        status_error_reg <= 4'd0;
        status_valid_reg <= 1'b0;
        out_ptr_reg <= 9'd0;
        out_end_reg <= 9'd0;
        m_valid_reg <= 1'b0;
        m_data_reg <= 8'd0;
        m_last_reg <= 1'b0;
    end else begin
        status_valid_reg <= 1'b0;

        case (state_reg)
            ST_IDLE: begin
                recv_count_reg <= 9'd0;
                oversize_reg <= 1'b0;
                m_valid_reg <= 1'b0;
                m_last_reg <= 1'b0;
                if (s_valid) begin
                    if (9'd0 < 9'd512)
                        buf_mem[0] <= s_data;
                    recv_count_reg <= 9'd1;
                    if (s_last) begin
                        state_reg <= ST_VALIDATE;
                    end else begin
                        state_reg <= ST_RECV;
                    end
                end
            end

            ST_RECV: begin
                if (s_valid) begin
                    if (recv_count_reg < 9'd512) begin
                        buf_mem[recv_count_reg] <= s_data;
                        recv_count_reg <= recv_count_reg + 9'd1;
                    end else begin
                        oversize_reg <= 1'b1;
                    end
                    if (s_last) begin
                        state_reg <= ST_VALIDATE;
                    end
                end
            end

            ST_VALIDATE: begin
                frame_len_v = recv_count_reg;
                ip_total_len_v = 16'd0;
                udp_len_v = 16'd0;
                udp_checksum_v = 16'd0;
                udp_payload_len_v = 16'd0;
                src_port_v = 16'd0;
                dst_port_v = 16'd0;
                src_ip_v = 32'd0;
                dst_ip_v = 32'd0;
                ip_sum = 32'd0;
                udp_sum = 32'd0;
                ip_fold = 16'd0;
                udp_fold = 16'd0;
                next_error = 4'd0;
                udp_bytes_end_v = 9'd0;
                ver_ihl = 8'd0;
                proto_byte = 8'd0;
                frag_hi = 8'd0;
                frag_lo = 8'd0;
                frag_off = 13'd0;

                if ((frame_len_v < 9'd28) || oversize_reg) begin
                    next_error = 4'd1;
                end else begin
                    ver_ihl = buf_mem[0];
                    proto_byte = buf_mem[9];
                    frag_hi = buf_mem[6];
                    frag_lo = buf_mem[7];
                    frag_off = {frag_hi[4:0], frag_lo};

                    if (ver_ihl[7:4] != 4'd4) next_error = 4'd1;
                    else if (ver_ihl[3:0] != 4'd5) next_error = 4'd1;
                    else if (proto_byte != 8'd17) next_error = 4'd1;
                    else if (frag_hi[5] != 1'b0) next_error = 4'd1;
                    else if (frag_off != 13'd0) next_error = 4'd1;
                end

                if (next_error == 4'd0) begin
                    ip_total_len_v = get_word(2);
                    udp_len_v = get_word(24);
                    udp_checksum_v = get_word(26);
                    src_port_v = get_word(20);
                    dst_port_v = get_word(22);
                    src_ip_v = {buf_mem[12],buf_mem[13],buf_mem[14],buf_mem[15]};
                    dst_ip_v = {buf_mem[16],buf_mem[17],buf_mem[18],buf_mem[19]};

                    if (ip_total_len_v != {7'd0,frame_len_v}) begin
                        next_error = 4'd2;
                    end else if (udp_len_v != (ip_total_len_v - 16'd20)) begin
                        next_error = 4'd2;
                    end else begin
                        udp_payload_len_v = udp_len_v - 16'd8;
                        if (udp_payload_len_v < 16'd1 || udp_payload_len_v > 16'd256) begin
                            next_error = 4'd2;
                        end
                    end
                end

                if (next_error == 4'd0) begin
                    for (i = 0; i < 20; i = i + 2) begin
                        ip_sum = ip_sum + {buf_mem[i],buf_mem[i+1]};
                    end
                    ip_fold = fold16(ip_sum);
                    if (ip_fold != 16'hffff)
                        next_error = 4'd3;
                end

                if (next_error == 4'd0) begin
                    if (udp_checksum_v != 16'd0) begin
                        udp_sum = 32'd0;
                        udp_sum = udp_sum + {buf_mem[12],buf_mem[13]};
                        udp_sum = udp_sum + {buf_mem[14],buf_mem[15]};
                        udp_sum = udp_sum + {buf_mem[16],buf_mem[17]};
                        udp_sum = udp_sum + {buf_mem[18],buf_mem[19]};
                        udp_sum = udp_sum + 16'h0011;
                        udp_sum = udp_sum + udp_len_v;

                        udp_bytes_end_v = 9'd20 + udp_len_v[8:0];
                        for (i = 20; i < 512; i = i + 2) begin
                            if (i < udp_bytes_end_v) begin
                                if ((i + 1) < udp_bytes_end_v)
                                    udp_sum = udp_sum + {buf_mem[i],buf_mem[i+1]};
                                else
                                    udp_sum = udp_sum + {buf_mem[i],8'h00};
                            end
                        end
                        udp_fold = fold16(udp_sum);
                        if (udp_fold != 16'hffff)
                            next_error = 4'd4;
                    end
                end

                if (next_error == 4'd0) begin
                    if (dst_ip_v != 32'h0a000002 || dst_port_v != 16'd9000)
                        next_error = 4'd5;
                end

                frame_len_reg <= frame_len_v;
                ip_total_len_reg <= ip_total_len_v;
                udp_len_reg <= udp_len_v;
                udp_checksum_reg <= udp_checksum_v;
                dst_ip_reg <= dst_ip_v;
                src_ip_meta_reg <= src_ip_v;
                src_port_meta_reg <= src_port_v;
                dst_port_meta_reg <= dst_port_v;
                payload_len_meta_reg <= udp_len_v - 16'd8;
                status_error_reg <= next_error;
                state_reg <= ST_STATUS;
            end

            ST_STATUS: begin
                status_valid_reg <= 1'b1;
                if (status_error_reg == 4'd0) begin
                    out_ptr_reg <= 9'd28;
                    out_end_reg <= 9'd20 + udp_len_reg[8:0];
                    if ((9'd28) < (9'd20 + udp_len_reg[8:0])) begin
                        m_data_reg <= buf_mem[28];
                        m_last_reg <= ((9'd28 + 9'd1) == (9'd20 + udp_len_reg[8:0]));
                        m_valid_reg <= 1'b1;
                        state_reg <= ST_OUTPUT;
                    end else begin
                        m_valid_reg <= 1'b0;
                        m_last_reg <= 1'b0;
                        state_reg <= ST_IDLE;
                    end
                end else begin
                    m_valid_reg <= 1'b0;
                    m_last_reg <= 1'b0;
                    state_reg <= ST_IDLE;
                end
            end

            ST_OUTPUT: begin
                if (m_valid_reg && m_ready) begin
                    if (m_last_reg) begin
                        m_valid_reg <= 1'b0;
                        m_last_reg <= 1'b0;
                        state_reg <= ST_WAITDONE;
                    end else begin
                        out_ptr_reg <= out_ptr_reg + 9'd1;
                        m_data_reg <= buf_mem[out_ptr_reg + 9'd1];
                        m_last_reg <= ((out_ptr_reg + 9'd2) == out_end_reg);
                        m_valid_reg <= 1'b1;
                    end
                end
            end

            ST_WAITDONE: begin
                state_reg <= ST_IDLE;
            end

            default: begin
                state_reg <= ST_IDLE;
            end
        endcase
    end
end

endmodule
