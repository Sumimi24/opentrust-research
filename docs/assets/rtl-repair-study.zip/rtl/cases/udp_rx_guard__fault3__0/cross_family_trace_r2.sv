`timescale 1ns / 1ps
`default_nettype none

module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

reg [7:0] bytes[0:511];

reg [2:0] state_reg;
localparam [2:0]
    ST_IDLE      = 3'd0,
    ST_COLLECT   = 3'd1,
    ST_STATUS    = 3'd2,
    ST_PAYLOAD   = 3'd3,
    ST_DRAINWAIT = 3'd4;

reg [9:0] frame_len_reg;
reg oversize_reg;

reg status_valid_reg;
reg [3:0] status_error_reg;

reg [8:0] ptr_reg;
reg payload_active_reg;

reg [31:0] out_src_ip_reg;
reg [15:0] out_src_port_reg;
reg [15:0] out_dst_port_reg;
reg [15:0] out_payload_len_reg;

assign s_ready = !rst && ((state_reg == ST_IDLE) || (state_reg == ST_COLLECT));
assign m_valid = (state_reg == ST_PAYLOAD) && payload_active_reg;
assign m_data  = bytes[ptr_reg];
assign m_last  = (state_reg == ST_PAYLOAD) && (ptr_reg == frame_len_reg - 10'd1);
assign m_src_ip       = out_src_ip_reg;
assign m_src_port     = out_src_port_reg;
assign m_dst_port     = out_dst_port_reg;
assign m_payload_len  = out_payload_len_reg;
assign status_valid   = status_valid_reg;
assign status_error   = status_error_reg;

function [15:0] get16;
    input integer idx;
    begin
        get16 = {bytes[idx], bytes[idx+1]};
    end
endfunction

function [15:0] fold16;
    input [31:0] sum_in;
    reg [31:0] t;
    begin
        t = sum_in;
        t = (t[15:0] + t[31:16]);
        t = (t[15:0] + t[31:16]);
        fold16 = t[15:0];
    end
endfunction

integer j;
reg [3:0] error_calc;
reg [15:0] ip_total_len_calc;
reg [15:0] udp_len_calc;
reg [15:0] payload_len_calc;
reg [31:0] ip_sum_calc;
reg [31:0] udp_sum_calc;
reg udp_checksum_nonzero_calc;
reg [15:0] udp_checksum_field_calc;
reg [15:0] frag_offset_calc;
reg mf_calc;

always @* begin
    error_calc = 4'd0;
    ip_total_len_calc = 16'd0;
    udp_len_calc = 16'd0;
    payload_len_calc = 16'd0;
    ip_sum_calc = 32'd0;
    udp_sum_calc = 32'd0;
    udp_checksum_nonzero_calc = 1'b0;
    udp_checksum_field_calc = 16'd0;
    frag_offset_calc = 16'd0;
    mf_calc = 1'b0;

    if (frame_len_reg >= 10'd28) begin
        ip_total_len_calc = get16(2);
        udp_len_calc = get16(24);
        payload_len_calc = udp_len_calc - 16'd8;
        frag_offset_calc = {bytes[6][4:0], bytes[7]};
        mf_calc = bytes[6][5];
        udp_checksum_field_calc = get16(26);
        udp_checksum_nonzero_calc = (udp_checksum_field_calc != 16'd0);
    end

    if (frame_len_reg < 10'd28 || oversize_reg || frame_len_reg > 10'd512 ||
        (bytes[0][7:4] != 4'd4) || (bytes[0][3:0] != 4'd5) ||
        (bytes[9] != 8'd17) || mf_calc || (frag_offset_calc != 16'd0)) begin
        error_calc = 4'd1;
    end else if ((ip_total_len_calc != frame_len_reg[15:0]) ||
                 (udp_len_calc != (ip_total_len_calc - 16'd20)) ||
                 (payload_len_calc < 16'd1) || (payload_len_calc > 16'd256)) begin
        error_calc = 4'd2;
    end else begin
        ip_sum_calc = 32'd0;
        for (j = 0; j < 20; j = j + 2) begin
            ip_sum_calc = ip_sum_calc + get16(j);
        end
        if (fold16(ip_sum_calc) != 16'hffff) begin
            error_calc = 4'd3;
        end else begin
            if (udp_checksum_nonzero_calc) begin
                udp_sum_calc = 32'd0;
                udp_sum_calc = udp_sum_calc + get16(12);
                udp_sum_calc = udp_sum_calc + get16(14);
                udp_sum_calc = udp_sum_calc + get16(16);
                udp_sum_calc = udp_sum_calc + get16(18);
                udp_sum_calc = udp_sum_calc + 32'h0011;
                udp_sum_calc = udp_sum_calc + {16'd0, udp_len_calc};

                for (j = 20; j < 512; j = j + 2) begin
                    if (j < (20 + udp_len_calc)) begin
                        udp_sum_calc = udp_sum_calc + {bytes[j], ((j+1) < (20 + udp_len_calc)) ? bytes[j+1] : 8'h00};
                    end
                end

                if (fold16(udp_sum_calc) != 16'hffff) begin
                    error_calc = 4'd4;
                end else if (({bytes[16], bytes[17], bytes[18], bytes[19]} != 32'h0a000002) ||
                             (get16(22) != 16'd9000)) begin
                    error_calc = 4'd5;
                end
            end else if (({bytes[16], bytes[17], bytes[18], bytes[19]} != 32'h0a000002) ||
                         (get16(22) != 16'd9000)) begin
                error_calc = 4'd5;
            end
        end
    end
end

always @(posedge clk) begin
    if (rst) begin
        state_reg <= ST_IDLE;
        frame_len_reg <= 10'd0;
        oversize_reg <= 1'b0;
        status_valid_reg <= 1'b0;
        status_error_reg <= 4'd0;
        ptr_reg <= 9'd20;
        payload_active_reg <= 1'b0;
        out_src_ip_reg <= 32'd0;
        out_src_port_reg <= 16'd0;
        out_dst_port_reg <= 16'd0;
        out_payload_len_reg <= 16'd0;
    end else begin
        status_valid_reg <= 1'b0;

        case (state_reg)
            ST_IDLE: begin
                frame_len_reg <= 10'd0;
                oversize_reg <= 1'b0;
                ptr_reg <= 9'd20;
                payload_active_reg <= 1'b0;
                if (s_valid) begin
                    bytes[0] <= s_data;
                    frame_len_reg <= 10'd1;
                    oversize_reg <= 1'b0;
                    if (s_last) begin
                        state_reg <= ST_STATUS;
                    end else begin
                        state_reg <= ST_COLLECT;
                    end
                end
            end

            ST_COLLECT: begin
                if (s_valid) begin
                    if (frame_len_reg < 10'd512) begin
                        bytes[frame_len_reg] <= s_data;
                    end else begin
                        oversize_reg <= 1'b1;
                    end
                    frame_len_reg <= frame_len_reg + 10'd1;
                    if (s_last) begin
                        state_reg <= ST_STATUS;
                    end
                end
            end

            ST_STATUS: begin
                status_valid_reg <= 1'b1;
                status_error_reg <= error_calc;
                if (error_calc == 4'd0) begin
                    out_src_ip_reg <= {bytes[12], bytes[13], bytes[14], bytes[15]};
                    out_src_port_reg <= get16(20);
                    out_dst_port_reg <= get16(22);
                    out_payload_len_reg <= get16(24) - 16'd8;
                    ptr_reg <= 9'd28;
                    payload_active_reg <= 1'b1;
                    state_reg <= ST_PAYLOAD;
                end else begin
                    frame_len_reg <= 10'd0;
                    oversize_reg <= 1'b0;
                    state_reg <= ST_IDLE;
                end
            end

            ST_PAYLOAD: begin
                if (m_ready) begin
                    if (ptr_reg == frame_len_reg - 10'd1) begin
                        payload_active_reg <= 1'b0;
                        state_reg <= ST_DRAINWAIT;
                    end else begin
                        ptr_reg <= ptr_reg + 9'd1;
                    end
                end
            end

            ST_DRAINWAIT: begin
                frame_len_reg <= 10'd0;
                oversize_reg <= 1'b0;
                state_reg <= ST_IDLE;
            end

            default: begin
                state_reg <= ST_IDLE;
            end
        endcase
    end
end

endmodule

`default_nettype wire
