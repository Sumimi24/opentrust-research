`timescale 1ns / 1ps
`default_nettype none

module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error
);

reg [7:0] frame_mem[0:511];

reg [9:0] in_count_reg;
reg collecting_reg;
reg oversize_reg;
reg holdoff_reg;

reg status_valid_reg;
reg [3:0] status_error_reg;

reg [31:0] meta_src_ip_reg;
reg [15:0] meta_src_port_reg;
reg [15:0] meta_dst_port_reg;
reg [15:0] meta_payload_len_reg;

reg out_valid_reg;
reg [7:0] out_data_reg;
reg out_last_reg;
reg [31:0] out_src_ip_reg;
reg [15:0] out_src_port_reg;
reg [15:0] out_dst_port_reg;
reg [15:0] out_payload_len_reg;
reg [8:0] out_index_reg;
reg [15:0] out_remaining_reg;

wire s_accept;
assign s_accept = s_valid && s_ready;
assign s_ready = !rst && !holdoff_reg;

assign m_data = out_data_reg;
assign m_valid = out_valid_reg;
assign m_last = out_last_reg;
assign m_src_ip = out_src_ip_reg;
assign m_src_port = out_src_port_reg;
assign m_dst_port = out_dst_port_reg;
assign m_payload_len = out_payload_len_reg;
assign status_valid = status_valid_reg;
assign status_error = status_error_reg;

wire [31:0] parser_m_ip_source_ip;
wire [15:0] parser_m_udp_source_port;
wire [15:0] parser_m_udp_dest_port;
wire [15:0] parser_m_udp_length;
wire parser_busy;
wire parser_error_header_early_termination;
wire parser_error_payload_early_termination;

reg parser_hdr_valid_reg;
wire parser_hdr_ready;
reg parser_payload_valid_reg;
wire parser_payload_ready;
reg [7:0] parser_payload_data_reg;
reg parser_payload_last_reg;

udp_ip_rx parser_inst (
    .clk(clk),
    .rst(rst),
    .s_ip_hdr_valid(parser_hdr_valid_reg),
    .s_ip_hdr_ready(parser_hdr_ready),
    .s_eth_dest_mac(48'd0),
    .s_eth_src_mac(48'd0),
    .s_eth_type(16'h0800),
    .s_ip_version(4'd4),
    .s_ip_ihl(4'd5),
    .s_ip_dscp(frame_mem[1][7:2]),
    .s_ip_ecn(frame_mem[1][1:0]),
    .s_ip_length({frame_mem[2], frame_mem[3]}),
    .s_ip_identification({frame_mem[4], frame_mem[5]}),
    .s_ip_flags(frame_mem[6][7:5]),
    .s_ip_fragment_offset({frame_mem[6][4:0], frame_mem[7]}),
    .s_ip_ttl(frame_mem[8]),
    .s_ip_protocol(frame_mem[9]),
    .s_ip_header_checksum({frame_mem[10], frame_mem[11]}),
    .s_ip_source_ip({frame_mem[12], frame_mem[13], frame_mem[14], frame_mem[15]}),
    .s_ip_dest_ip({frame_mem[16], frame_mem[17], frame_mem[18], frame_mem[19]}),
    .s_ip_payload_axis_tdata(parser_payload_data_reg),
    .s_ip_payload_axis_tvalid(parser_payload_valid_reg),
    .s_ip_payload_axis_tready(parser_payload_ready),
    .s_ip_payload_axis_tlast(parser_payload_last_reg),
    .s_ip_payload_axis_tuser(1'b0),
    .m_udp_hdr_valid(),
    .m_udp_hdr_ready(1'b1),
    .m_eth_dest_mac(),
    .m_eth_src_mac(),
    .m_eth_type(),
    .m_ip_version(),
    .m_ip_ihl(),
    .m_ip_dscp(),
    .m_ip_ecn(),
    .m_ip_length(),
    .m_ip_identification(),
    .m_ip_flags(),
    .m_ip_fragment_offset(),
    .m_ip_ttl(),
    .m_ip_protocol(),
    .m_ip_header_checksum(),
    .m_ip_source_ip(parser_m_ip_source_ip),
    .m_ip_dest_ip(),
    .m_udp_source_port(parser_m_udp_source_port),
    .m_udp_dest_port(parser_m_udp_dest_port),
    .m_udp_length(parser_m_udp_length),
    .m_udp_checksum(),
    .m_udp_payload_axis_tdata(),
    .m_udp_payload_axis_tvalid(),
    .m_udp_payload_axis_tready(1'b1),
    .m_udp_payload_axis_tlast(),
    .m_udp_payload_axis_tuser(),
    .busy(parser_busy),
    .error_header_early_termination(parser_error_header_early_termination),
    .error_payload_early_termination(parser_error_payload_early_termination)
);

function [15:0] get16;
    input [8:0] idx;
    begin
        get16 = {frame_mem[idx], frame_mem[idx+1]};
    end
endfunction

function [16:0] add16c;
    input [16:0] a;
    input [15:0] b;
    reg [16:0] t;
    begin
        t = a + {1'b0, b};
        add16c = {1'b0, t[15:0]} + t[16];
    end
endfunction

reg [15:0] ip_total_len_calc;
reg [15:0] udp_len_calc;
reg [15:0] payload_len_calc;
reg [15:0] frag_field_calc;
reg [16:0] ip_sum_calc;
reg [16:0] udp_sum_calc;
reg [31:0] dst_ip_calc;
reg [31:0] src_ip_calc;
reg [15:0] src_port_calc;
reg [15:0] dst_port_calc;
reg [3:0] error_calc;
integer k;

always @* begin
    ip_total_len_calc = 16'd0;
    udp_len_calc = 16'd0;
    payload_len_calc = 16'd0;
    frag_field_calc = 16'd0;
    ip_sum_calc = 17'd0;
    udp_sum_calc = 17'd0;
    dst_ip_calc = 32'd0;
    src_ip_calc = 32'd0;
    src_port_calc = 16'd0;
    dst_port_calc = 16'd0;
    error_calc = 4'd0;

    if (in_count_reg >= 10'd28) begin
        ip_total_len_calc = get16(9'd2);
        udp_len_calc = get16(9'd24);
        payload_len_calc = get16(9'd24) - 16'd8;
        frag_field_calc = {frame_mem[6][5:0], frame_mem[7]};
        src_ip_calc = {frame_mem[12], frame_mem[13], frame_mem[14], frame_mem[15]};
        dst_ip_calc = {frame_mem[16], frame_mem[17], frame_mem[18], frame_mem[19]};
        src_port_calc = get16(9'd20);
        dst_port_calc = get16(9'd22);
    end

    if (in_count_reg < 10'd28 ||
        oversize_reg ||
        frame_mem[0][7:4] != 4'd4 ||
        frame_mem[0][3:0] != 4'd5 ||
        frame_mem[9] != 8'd17 ||
        frame_mem[6][5] ||
        frag_field_calc[12:0] != 13'd0) begin
        error_calc = 4'd1;
    end else if (ip_total_len_calc != {6'd0, in_count_reg} ||
                 udp_len_calc != ip_total_len_calc - 16'd20 ||
                 payload_len_calc == 16'd0 ||
                 payload_len_calc > 16'd256) begin
        error_calc = 4'd2;
    end else begin
        ip_sum_calc = 17'd0;
        for (k = 0; k < 20; k = k + 2) begin
            ip_sum_calc = add16c(ip_sum_calc, {frame_mem[k[8:0]], frame_mem[(k+1)[8:0]]});
        end
        if (ip_sum_calc[15:0] != 16'hffff) begin
            error_calc = 4'd3;
        end else begin
            if (get16(9'd26) != 16'd0) begin
                udp_sum_calc = 17'd0;
                udp_sum_calc = add16c(udp_sum_calc, {frame_mem[12], frame_mem[13]});
                udp_sum_calc = add16c(udp_sum_calc, {frame_mem[14], frame_mem[15]});
                udp_sum_calc = add16c(udp_sum_calc, {frame_mem[16], frame_mem[17]});
                udp_sum_calc = add16c(udp_sum_calc, {frame_mem[18], frame_mem[19]});
                udp_sum_calc = add16c(udp_sum_calc, 16'h0011);
                udp_sum_calc = add16c(udp_sum_calc, udp_len_calc);
                for (k = 20; k < 512; k = k + 2) begin
                    if (k < (20 + udp_len_calc)) begin
                        if ((k + 1) < (20 + udp_len_calc)) begin
                            udp_sum_calc = add16c(udp_sum_calc, {frame_mem[k[8:0]], frame_mem[(k+1)[8:0]]});
                        end else begin
                            udp_sum_calc = add16c(udp_sum_calc, {frame_mem[k[8:0]], 8'h00});
                        end
                    end
                end
                if (udp_sum_calc[15:0] != 16'hffff) begin
                    error_calc = 4'd4;
                end else if (dst_ip_calc != 32'h0a000002 || dst_port_calc != 16'd9000) begin
                    error_calc = 4'd5;
                end
            end else if (dst_ip_calc != 32'h0a000002 || dst_port_calc != 16'd9000) begin
                error_calc = 4'd5;
            end
        end
    end
end

always @(posedge clk) begin
    if (rst) begin
        in_count_reg <= 10'd0;
        collecting_reg <= 1'b0;
        oversize_reg <= 1'b0;
        holdoff_reg <= 1'b0;
        status_valid_reg <= 1'b0;
        status_error_reg <= 4'd0;
        meta_src_ip_reg <= 32'd0;
        meta_src_port_reg <= 16'd0;
        meta_dst_port_reg <= 16'd0;
        meta_payload_len_reg <= 16'd0;
        out_valid_reg <= 1'b0;
        out_data_reg <= 8'd0;
        out_last_reg <= 1'b0;
        out_src_ip_reg <= 32'd0;
        out_src_port_reg <= 16'd0;
        out_dst_port_reg <= 16'd0;
        out_payload_len_reg <= 16'd0;
        out_index_reg <= 9'd0;
        out_remaining_reg <= 16'd0;
        parser_hdr_valid_reg <= 1'b0;
        parser_payload_valid_reg <= 1'b0;
        parser_payload_data_reg <= 8'd0;
        parser_payload_last_reg <= 1'b0;
    end else begin
        status_valid_reg <= 1'b0;

        if (out_valid_reg && m_ready) begin
            if (out_last_reg) begin
                out_valid_reg <= 1'b0;
                out_last_reg <= 1'b0;
                holdoff_reg <= 1'b0;
                out_remaining_reg <= 16'd0;
            end else begin
                out_index_reg <= out_index_reg + 9'd1;
                out_remaining_reg <= out_remaining_reg - 16'd1;
                out_data_reg <= frame_mem[out_index_reg + 9'd1];
                out_last_reg <= (out_remaining_reg == 16'd2);
            end
        end

        if (s_accept) begin
            if (!collecting_reg) begin
                in_count_reg <= 10'd1;
                collecting_reg <= !s_last;
                oversize_reg <= 1'b0;
                frame_mem[0] <= s_data;

                if (s_last) begin
                    status_valid_reg <= 1'b1;
                    status_error_reg <= 4'd1;
                    in_count_reg <= 10'd0;
                    collecting_reg <= 1'b0;
                    oversize_reg <= 1'b0;
                end
            end else begin
                if (in_count_reg < 10'd512) begin
                    frame_mem[in_count_reg] <= s_data;
                end else begin
                    oversize_reg <= 1'b1;
                end

                if (s_last) begin
                    status_valid_reg <= 1'b1;
                    status_error_reg <= error_calc;

                    if (error_calc == 4'd0) begin
                        meta_src_ip_reg <= src_ip_calc;
                        meta_src_port_reg <= src_port_calc;
                        meta_dst_port_reg <= dst_port_calc;
                        meta_payload_len_reg <= payload_len_calc;

                        out_src_ip_reg <= src_ip_calc;
                        out_src_port_reg <= src_port_calc;
                        out_dst_port_reg <= dst_port_calc;
                        out_payload_len_reg <= payload_len_calc;
                        out_index_reg <= 9'd28;
                        out_remaining_reg <= payload_len_calc;
                        out_data_reg <= frame_mem[28];
                        out_last_reg <= (payload_len_calc == 16'd1);
                        out_valid_reg <= 1'b1;
                        holdoff_reg <= 1'b1;
                    end

                    in_count_reg <= 10'd0;
                    collecting_reg <= 1'b0;
                    oversize_reg <= 1'b0;
                end else begin
                    in_count_reg <= in_count_reg + 10'd1;
                end
            end
        end

        parser_hdr_valid_reg <= 1'b0;
        parser_payload_valid_reg <= 1'b0;
        parser_payload_data_reg <= 8'd0;
        parser_payload_last_reg <= 1'b0;

        if (1'b0) begin
            parser_hdr_valid_reg <= parser_hdr_valid_reg;
            parser_payload_valid_reg <= parser_payload_valid_reg;
            parser_payload_data_reg <= parser_payload_data_reg;
            parser_payload_last_reg <= parser_payload_last_reg;
        end
    end
end

endmodule

`default_nettype wire
