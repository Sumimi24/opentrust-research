`timescale 1ns / 1ps
`default_nettype none

module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error
);

reg [7:0] frame_mem[0:511];

reg [9:0] frame_len_reg;
reg collecting_reg;
reg oversize_reg;
reg output_busy_reg;

reg status_valid_reg;
reg [3:0] status_error_reg;

reg [31:0] out_src_ip_reg;
reg [15:0] out_src_port_reg;
reg [15:0] out_dst_port_reg;
reg [15:0] out_payload_len_reg;

reg [8:0] out_ptr_reg;
reg [15:0] out_rem_reg;
reg out_last_pending_reg;

reg hdr_valid_reg;
reg payload_valid_reg;
reg payload_last_reg;
reg [7:0] payload_data_reg;

wire parser_s_hdr_ready;
wire parser_s_payload_ready;

wire [31:0] parser_m_src_ip;
wire [15:0] parser_m_src_port;
wire [15:0] parser_m_dst_port;
wire [15:0] parser_m_udp_length;

wire [7:0] parser_m_tdata;
wire parser_m_tvalid;
wire parser_m_tlast;

reg [9:0] actual_len_calc;
reg [15:0] ip_total_len_calc;
reg [15:0] udp_len_calc;
reg [15:0] payload_len_calc;
reg [15:0] frag_off_calc;
reg [31:0] ip_cksum_sum_calc;
reg [31:0] udp_cksum_sum_calc;
reg [3:0] error_calc;
integer i;

function [15:0] word16;
    input integer idx;
    begin
        word16 = {frame_mem[idx], frame_mem[idx+1]};
    end
endfunction

function [31:0] fold_sum;
    input [31:0] s;
    reg [31:0] t;
    begin
        t = s;
        t = (t[15:0] + t[31:16]);
        t = (t[15:0] + t[31:16]);
        t = (t[15:0] + t[31:16]);
        fold_sum = t;
    end
endfunction

always @* begin
    actual_len_calc = frame_len_reg;
    ip_total_len_calc = 16'd0;
    udp_len_calc = 16'd0;
    payload_len_calc = 16'd0;
    frag_off_calc = 16'd0;
    ip_cksum_sum_calc = 32'd0;
    udp_cksum_sum_calc = 32'd0;
    error_calc = 4'd0;

    if (frame_len_reg >= 10'd28) begin
        ip_total_len_calc = word16(2);
        frag_off_calc = {frame_mem[6][4:0], frame_mem[7]};
        udp_len_calc = word16(24);
        payload_len_calc = udp_len_calc - 16'd8;
    end

    if ((frame_len_reg < 10'd28) ||
        oversize_reg ||
        (frame_mem[0][7:4] != 4'd4) ||
        (frame_mem[0][3:0] != 4'd5) ||
        (frame_mem[9] != 8'd17) ||
        frame_mem[6][5] ||
        (frag_off_calc != 16'd0)) begin
        error_calc = 4'd1;
    end else if ((ip_total_len_calc != {6'd0, actual_len_calc}) ||
                 (udp_len_calc != (ip_total_len_calc - 16'd20)) ||
                 (payload_len_calc < 16'd1) ||
                 (payload_len_calc > 16'd256)) begin
        error_calc = 4'd2;
    end else begin
        ip_cksum_sum_calc = 32'd0;
        for (i = 0; i < 20; i = i + 2) begin
            ip_cksum_sum_calc = ip_cksum_sum_calc + word16(i);
        end
        if (fold_sum(ip_cksum_sum_calc) != 32'h0000ffff) begin
            error_calc = 4'd3;
        end else begin
            if (word16(26) != 16'd0) begin
                udp_cksum_sum_calc = 32'd0;
                udp_cksum_sum_calc = udp_cksum_sum_calc + word16(12);
                udp_cksum_sum_calc = udp_cksum_sum_calc + word16(14);
                udp_cksum_sum_calc = udp_cksum_sum_calc + word16(16);
                udp_cksum_sum_calc = udp_cksum_sum_calc + word16(18);
                udp_cksum_sum_calc = udp_cksum_sum_calc + 16'h0011;
                udp_cksum_sum_calc = udp_cksum_sum_calc + udp_len_calc;
                for (i = 20; i < 512; i = i + 2) begin
                    if (i < (20 + udp_len_calc)) begin
                        if ((i + 1) < (20 + udp_len_calc)) begin
                            udp_cksum_sum_calc = udp_cksum_sum_calc + {frame_mem[i], frame_mem[i+1]};
                        end else begin
                            udp_cksum_sum_calc = udp_cksum_sum_calc + {frame_mem[i], 8'h00};
                        end
                    end
                end
                if (fold_sum(udp_cksum_sum_calc) != 32'h0000ffff) begin
                    error_calc = 4'd4;
                end else if (({frame_mem[16], frame_mem[17], frame_mem[18], frame_mem[19]} != 32'h0a000002) ||
                             (word16(22) != 16'd9000)) begin
                    error_calc = 4'd5;
                end
            end else if (({frame_mem[16], frame_mem[17], frame_mem[18], frame_mem[19]} != 32'h0a000002) ||
                         (word16(22) != 16'd9000)) begin
                error_calc = 4'd5;
            end
        end
    end
end

assign s_ready = !rst && !output_busy_reg;

assign m_data = parser_m_tdata;
assign m_valid = parser_m_tvalid;
assign m_last = parser_m_tlast;
assign m_src_ip = out_src_ip_reg;
assign m_src_port = out_src_port_reg;
assign m_dst_port = out_dst_port_reg;
assign m_payload_len = out_payload_len_reg;
assign status_valid = status_valid_reg;
assign status_error = status_error_reg;

always @(posedge clk) begin
    if (rst) begin
        frame_len_reg <= 10'd0;
        collecting_reg <= 1'b0;
        oversize_reg <= 1'b0;
        output_busy_reg <= 1'b0;
        status_valid_reg <= 1'b0;
        status_error_reg <= 4'd0;
        out_src_ip_reg <= 32'd0;
        out_src_port_reg <= 16'd0;
        out_dst_port_reg <= 16'd0;
        out_payload_len_reg <= 16'd0;
        out_ptr_reg <= 9'd0;
        out_rem_reg <= 16'd0;
        out_last_pending_reg <= 1'b0;
        hdr_valid_reg <= 1'b0;
        payload_valid_reg <= 1'b0;
        payload_last_reg <= 1'b0;
        payload_data_reg <= 8'd0;
    end else begin
        status_valid_reg <= 1'b0;

        if (!output_busy_reg) begin
            if (s_valid) begin
                if (!collecting_reg) begin
                    frame_len_reg <= 10'd1;
                    collecting_reg <= !s_last;
                    oversize_reg <= 1'b0;
                    frame_mem[0] <= s_data;
                    if (s_last) begin
                        status_valid_reg <= 1'b1;
                        status_error_reg <= (
                            (10'd1 < 10'd28) ? 4'd1 : 4'd0
                        );
                        frame_len_reg <= 10'd0;
                        collecting_reg <= 1'b0;
                        oversize_reg <= 1'b0;
                    end
                end else begin
                    if (frame_len_reg < 10'd512) begin
                        frame_mem[frame_len_reg] <= s_data;
                    end else begin
                        oversize_reg <= 1'b1;
                    end

                    if (s_last) begin
                        status_valid_reg <= 1'b1;
                        status_error_reg <= error_calc;

                        if (error_calc == 4'd0) begin
                            output_busy_reg <= 1'b1;
                            hdr_valid_reg <= 1'b1;
                            payload_valid_reg <= 1'b0;
                            payload_last_reg <= 1'b0;
                            out_ptr_reg <= 9'd20;
                            out_rem_reg <= payload_len_calc;
                            out_last_pending_reg <= 1'b0;

                            out_src_ip_reg <= {frame_mem[12], frame_mem[13], frame_mem[14], frame_mem[15]};
                            out_src_port_reg <= word16(20);
                            out_dst_port_reg <= word16(22);
                            out_payload_len_reg <= payload_len_calc;
                        end

                        frame_len_reg <= 10'd0;
                        collecting_reg <= 1'b0;
                        oversize_reg <= 1'b0;
                    end else begin
                        frame_len_reg <= frame_len_reg + 10'd1;
                    end
                end
            end
        end

        if (hdr_valid_reg && parser_s_hdr_ready) begin
            hdr_valid_reg <= 1'b0;
            if (out_rem_reg != 16'd0) begin
                payload_valid_reg <= 1'b1;
                payload_data_reg <= frame_mem[20 + 8];
                payload_last_reg <= (out_rem_reg == 16'd1);
                out_ptr_reg <= 9'd29;
                out_last_pending_reg <= (out_rem_reg == 16'd1);
            end else begin
                output_busy_reg <= 1'b0;
            end
        end else if (payload_valid_reg && parser_s_payload_ready) begin
            if (out_last_pending_reg) begin
                payload_valid_reg <= 1'b0;
                payload_last_reg <= 1'b0;
                output_busy_reg <= 1'b0;
                out_last_pending_reg <= 1'b0;
                out_rem_reg <= 16'd0;
            end else begin
                out_rem_reg <= out_rem_reg - 16'd1;
                payload_data_reg <= frame_mem[out_ptr_reg];
                payload_last_reg <= (out_rem_reg == 16'd2);
                out_ptr_reg <= out_ptr_reg + 9'd1;
                out_last_pending_reg <= (out_rem_reg == 16'd2);
            end
        end
    end
end

udp_ip_rx parser_inst (
    .clk(clk),
    .rst(rst),

    .s_ip_hdr_valid(hdr_valid_reg),
    .s_ip_hdr_ready(parser_s_hdr_ready),
    .s_eth_dest_mac(48'd0),
    .s_eth_src_mac(48'd0),
    .s_eth_type(16'h0800),
    .s_ip_version(4'd4),
    .s_ip_ihl(4'd5),
    .s_ip_dscp(frame_mem[1][7:2]),
    .s_ip_ecn(frame_mem[1][1:0]),
    .s_ip_length(word16(2)),
    .s_ip_identification(word16(4)),
    .s_ip_flags(frame_mem[6][7:5]),
    .s_ip_fragment_offset({frame_mem[6][4:0], frame_mem[7]}),
    .s_ip_ttl(frame_mem[8]),
    .s_ip_protocol(frame_mem[9]),
    .s_ip_header_checksum(word16(10)),
    .s_ip_source_ip({frame_mem[12], frame_mem[13], frame_mem[14], frame_mem[15]}),
    .s_ip_dest_ip({frame_mem[16], frame_mem[17], frame_mem[18], frame_mem[19]}),

    .s_ip_payload_axis_tdata(payload_data_reg),
    .s_ip_payload_axis_tvalid(payload_valid_reg),
    .s_ip_payload_axis_tready(parser_s_payload_ready),
    .s_ip_payload_axis_tlast(payload_last_reg),
    .s_ip_payload_axis_tuser(1'b0),

    .m_udp_hdr_valid(),
    .m_udp_hdr_ready(1'b1),
    .m_eth_dest_mac(),
    .m_eth_src_mac(),
    .m_eth_type(),
    .m_ip_version(),
    .m_ip_ihl(),
    .m_ip_dscp(),
    .m_ip_ecn(),
    .m_ip_length(),
    .m_ip_identification(),
    .m_ip_flags(),
    .m_ip_fragment_offset(),
    .m_ip_ttl(),
    .m_ip_protocol(),
    .m_ip_header_checksum(),
    .m_ip_source_ip(parser_m_src_ip),
    .m_ip_dest_ip(),
    .m_udp_source_port(parser_m_src_port),
    .m_udp_dest_port(parser_m_dst_port),
    .m_udp_length(parser_m_udp_length),
    .m_udp_checksum(),
    .m_udp_payload_axis_tdata(parser_m_tdata),
    .m_udp_payload_axis_tvalid(parser_m_tvalid),
    .m_udp_payload_axis_tready(m_ready),
    .m_udp_payload_axis_tlast(parser_m_tlast),
    .m_udp_payload_axis_tuser(),

    .busy(),
    .error_header_early_termination(),
    .error_payload_early_termination(),
    .error_invalid_header(),
    .error_invalid_checksum()
);

endmodule

`default_nettype wire
