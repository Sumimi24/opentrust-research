`timescale 1ns / 1ps
`default_nettype none

module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

localparam [2:0]
    ST_IDLE   = 3'd0,
    ST_RECV   = 3'd1,
    ST_STATUS = 3'd2,
    ST_PAY    = 3'd3;

reg [2:0] state_reg = ST_IDLE;

reg [7:0] frame_mem[0:511];
reg [9:0] frame_len_reg = 10'd0;
reg [9:0] recv_count_reg = 10'd0;
reg oversize_reg = 1'b0;

reg status_valid_reg = 1'b0;
reg [3:0] status_error_reg = 4'd0;

reg [3:0] error_code_reg = 4'd0;

reg [31:0] src_ip_reg = 32'd0;
reg [15:0] src_port_reg = 16'd0;
reg [15:0] dst_port_reg = 16'd0;
reg [15:0] payload_len_reg = 16'd0;

reg [9:0] pay_ptr_reg = 10'd28;
reg [9:0] last_index_reg = 10'd27;

assign s_ready = !rst && ((state_reg == ST_IDLE) || (state_reg == ST_RECV));

function automatic [15:0] get_word16;
    input [9:0] idx;
    begin
        get_word16 = {frame_mem[idx], frame_mem[idx+10'd1]};
    end
endfunction

function automatic [16:0] fold_once17;
    input [17:0] x;
    reg [16:0] t;
    begin
        t = x[15:0] + x[17:16];
        fold_once17 = t;
    end
endfunction

integer i;
reg [31:0] sum_ip;
reg [31:0] sum_udp;
reg [15:0] ip_total_len;
reg [15:0] udp_len_chk;
reg [15:0] udp_csum;
reg [7:0] ver_ihl;
reg [7:0] protocol_f;
reg [2:0] flags_f;
reg [12:0] frag_off_f;
reg [31:0] dst_ip_chk;
reg [15:0] dst_port_chk;
reg [15:0] src_port_chk;
reg [31:0] src_ip_chk;
reg [15:0] tmp_payload_len;
reg [3:0] next_error;

assign m_data = frame_mem[pay_ptr_reg];
assign m_valid = (state_reg == ST_PAY);
assign m_last = (pay_ptr_reg == last_index_reg);

assign m_src_ip = src_ip_reg;
assign m_src_port = src_port_reg;
assign m_dst_port = dst_port_reg;
assign m_payload_len = payload_len_reg;

assign status_valid = status_valid_reg;
assign status_error = status_error_reg;

always @* begin
    next_error = 4'd0;

    ver_ihl = frame_mem[0];
    protocol_f = frame_mem[9];
    flags_f = frame_mem[6][7:5];
    frag_off_f = {frame_mem[6][4:0], frame_mem[7]};
    ip_total_len = get_word16(10'd2);
    udp_len_chk = get_word16(10'd24);
    udp_csum = get_word16(10'd26);
    src_ip_chk = {frame_mem[12], frame_mem[13], frame_mem[14], frame_mem[15]};
    dst_ip_chk = {frame_mem[16], frame_mem[17], frame_mem[18], frame_mem[19]};
    src_port_chk = get_word16(10'd20);
    dst_port_chk = get_word16(10'd22);
    tmp_payload_len = udp_len_chk - 16'd8;

    if ((frame_len_reg < 10'd28) || oversize_reg || (ver_ihl[7:4] != 4'd4) || (ver_ihl[3:0] != 4'd5) || (protocol_f != 8'd17) || (flags_f[0] == 1'b1) || (frag_off_f != 13'd0)) begin
        next_error = 4'd1;
    end else if ((ip_total_len != frame_len_reg) || (udp_len_chk != (ip_total_len - 16'd20)) || (tmp_payload_len < 16'd1) || (tmp_payload_len > 16'd256)) begin
        next_error = 4'd2;
    end else begin
        sum_ip = 32'd0;
        for (i = 0; i < 20; i = i + 2) begin
            sum_ip = sum_ip + {frame_mem[i], frame_mem[i+1]};
        end
        sum_ip = {15'd0, fold_once17(sum_ip[17:0])} + sum_ip[31:18];
        sum_ip = {15'd0, fold_once17(sum_ip[17:0])} + sum_ip[31:18];
        sum_ip = {15'd0, fold_once17(sum_ip[17:0])};

        if (sum_ip[15:0] != 16'hffff) begin
            next_error = 4'd3;
        end else begin
            sum_udp = 32'd0;
            sum_udp = sum_udp + {frame_mem[12], frame_mem[13]};
            sum_udp = sum_udp + {frame_mem[14], frame_mem[15]};
            sum_udp = sum_udp + {frame_mem[16], frame_mem[17]};
            sum_udp = sum_udp + {frame_mem[18], frame_mem[19]};
            sum_udp = sum_udp + 16'h0011;
            sum_udp = sum_udp + udp_len_chk;

            for (i = 20; i < 512; i = i + 2) begin
                if (i < frame_len_reg) begin
                    if ((i + 1) < frame_len_reg) begin
                        sum_udp = sum_udp + {frame_mem[i], frame_mem[i+1]};
                    end else begin
                        sum_udp = sum_udp + {frame_mem[i], 8'h00};
                    end
                end
            end

            sum_udp = {15'd0, fold_once17(sum_udp[17:0])} + sum_udp[31:18];
            sum_udp = {15'd0, fold_once17(sum_udp[17:0])} + sum_udp[31:18];
            sum_udp = {15'd0, fold_once17(sum_udp[17:0])};

            if ((udp_csum != 16'h0000) && (sum_udp[15:0] != 16'hffff)) begin
                next_error = 4'd4;
            end else if ((dst_ip_chk != 32'h0a000002) || (dst_port_chk != 16'd9000)) begin
                next_error = 4'd5;
            end else begin
                next_error = 4'd0;
            end
        end
    end
end

always @(posedge clk) begin
    if (rst) begin
        state_reg <= ST_IDLE;
        frame_len_reg <= 10'd0;
        recv_count_reg <= 10'd0;
        oversize_reg <= 1'b0;
        status_valid_reg <= 1'b0;
        status_error_reg <= 4'd0;
        error_code_reg <= 4'd0;
        src_ip_reg <= 32'd0;
        src_port_reg <= 16'd0;
        dst_port_reg <= 16'd0;
        payload_len_reg <= 16'd0;
        pay_ptr_reg <= 10'd28;
        last_index_reg <= 10'd27;
    end else begin
        status_valid_reg <= 1'b0;

        case (state_reg)
            ST_IDLE: begin
                frame_len_reg <= 10'd0;
                recv_count_reg <= 10'd0;
                oversize_reg <= 1'b0;
                if (s_valid) begin
                    if (10'd0 < 10'd512) begin
                        frame_mem[0] <= s_data;
                    end
                    recv_count_reg <= 10'd1;
                    if (s_last) begin
                        frame_len_reg <= 10'd1;
                        state_reg <= ST_STATUS;
                    end else begin
                        state_reg <= ST_RECV;
                    end
                end
            end

            ST_RECV: begin
                if (s_valid) begin
                    if (recv_count_reg < 10'd512) begin
                        frame_mem[recv_count_reg] <= s_data;
                    end else begin
                        oversize_reg <= 1'b1;
                    end
                    if (s_last) begin
                        if (recv_count_reg < 10'd512) begin
                            frame_len_reg <= recv_count_reg + 10'd1;
                        end else begin
                            frame_len_reg <= 10'd512;
                        end
                        state_reg <= ST_STATUS;
                    end
                    recv_count_reg <= recv_count_reg + 10'd1;
                end
            end

            ST_STATUS: begin
                error_code_reg <= next_error;
                status_valid_reg <= 1'b1;
                status_error_reg <= next_error;

                if (next_error == 4'd0) begin
                    src_ip_reg <= {frame_mem[12], frame_mem[13], frame_mem[14], frame_mem[15]};
                    src_port_reg <= get_word16(10'd20);
                    dst_port_reg <= get_word16(10'd22);
                    payload_len_reg <= get_word16(10'd24) - 16'd8;
                    pay_ptr_reg <= 10'd28;
                    last_index_reg <= frame_len_reg - 10'd1;
                    state_reg <= ST_PAY;
                end else begin
                    frame_len_reg <= 10'd0;
                    recv_count_reg <= 10'd0;
                    oversize_reg <= 1'b0;
                    state_reg <= ST_IDLE;
                end
            end

            ST_PAY: begin
                if (m_ready) begin
                    if (pay_ptr_reg == last_index_reg) begin
                        frame_len_reg <= 10'd0;
                        recv_count_reg <= 10'd0;
                        oversize_reg <= 1'b0;
                        state_reg <= ST_IDLE;
                    end else begin
                        pay_ptr_reg <= pay_ptr_reg + 10'd1;
                    end
                end
            end

            default: begin
                state_reg <= ST_IDLE;
            end
        endcase
    end
end

endmodule
`default_nettype wire
