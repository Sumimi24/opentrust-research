`timescale 1ns / 1ps
`default_nettype none

module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

localparam [1:0]
    ST_IDLE   = 2'd0,
    ST_RECV   = 2'd1,
    ST_STATUS = 2'd2,
    ST_PAY    = 2'd3;

reg [1:0] state_reg = ST_IDLE;

reg [7:0] frame_mem[0:511];
reg [9:0] frame_len_reg = 10'd0;
reg [9:0] recv_count_reg = 10'd0;
reg oversize_reg = 1'b0;

reg status_valid_reg = 1'b0;
reg [3:0] status_error_reg = 4'd0;

reg [31:0] src_ip_reg = 32'd0;
reg [15:0] src_port_reg = 16'd0;
reg [15:0] dst_port_reg = 16'd0;
reg [15:0] payload_len_reg = 16'd0;

reg [9:0] pay_ptr_reg = 10'd28;
reg [9:0] last_index_reg = 10'd27;

integer i;

assign s_ready = !rst && (state_reg == ST_IDLE || state_reg == ST_RECV);

assign m_data = frame_mem[pay_ptr_reg];
assign m_valid = (state_reg == ST_PAY);
assign m_last = (pay_ptr_reg == last_index_reg);

assign m_src_ip = src_ip_reg;
assign m_src_port = src_port_reg;
assign m_dst_port = dst_port_reg;
assign m_payload_len = payload_len_reg;

assign status_valid = status_valid_reg;
assign status_error = status_error_reg;

always @(posedge clk) begin
    if (rst) begin
        state_reg <= ST_IDLE;
        frame_len_reg <= 10'd0;
        recv_count_reg <= 10'd0;
        oversize_reg <= 1'b0;
        status_valid_reg <= 1'b0;
        status_error_reg <= 4'd0;
        src_ip_reg <= 32'd0;
        src_port_reg <= 16'd0;
        dst_port_reg <= 16'd0;
        payload_len_reg <= 16'd0;
        pay_ptr_reg <= 10'd28;
        last_index_reg <= 10'd27;
    end else begin
        status_valid_reg <= 1'b0;

        case (state_reg)
            ST_IDLE: begin
                recv_count_reg <= 10'd0;
                frame_len_reg <= 10'd0;
                oversize_reg <= 1'b0;
                if (s_valid && s_ready) begin
                    if (!oversize_reg && recv_count_reg < 10'd512) begin
                        frame_mem[recv_count_reg] <= s_data;
                    end else begin
                        oversize_reg <= 1'b1;
                    end
                    recv_count_reg <= recv_count_reg + 10'd1;
                    if (s_last) begin
                        frame_len_reg <= oversize_reg ? 10'd512 : (recv_count_reg + 10'd1);
                        state_reg <= ST_STATUS;
                    end else begin
                        state_reg <= ST_RECV;
                    end
                end
            end

            ST_RECV: begin
                if (s_valid && s_ready) begin
                    if (!oversize_reg && recv_count_reg < 10'd512) begin
                        frame_mem[recv_count_reg] <= s_data;
                    end else begin
                        oversize_reg <= 1'b1;
                    end
                    recv_count_reg <= recv_count_reg + 10'd1;
                    if (s_last) begin
                        frame_len_reg <= oversize_reg ? 10'd512 : (recv_count_reg + 10'd1);
                        state_reg <= ST_STATUS;
                    end
                end
            end

            ST_STATUS: begin
                status_valid_reg <= 1'b1;
                // Compute all classification here (sequential logic for checksums)
                reg [3:0] err;
                err = 4'd0;

                // Check error1 conditions
                if ((frame_len_reg < 10'd28) || oversize_reg || 
                    (frame_mem[0][7:4] != 4'd4) || (frame_mem[0][3:0] != 4'd5) ||
                    (frame_mem[9] != 8'd17) || (frame_mem[6][7] == 1'b1) ||
                    ({frame_mem[6][4:0], frame_mem[7]} != 13'd0))
                    err = 4'd1;
                else begin
                    // error2 checks
                    reg [15:0] ip_total_len;
                    reg [15:0] udp_len;
                    reg [15:0] payload_len_calc;
                    ip_total_len = {frame_mem[2], frame_mem[3]};
                    udp_len = {frame_mem[24], frame_mem[25]};
                    payload_len_calc = udp_len - 16'd8;

                    if ((ip_total_len != frame_len_reg) || 
                        (udp_len != (ip_total_len - 16'd20)) ||
                        (payload_len_calc < 16'd1) || (payload_len_calc > 16'd256))
                        err = 4'd2;
                    else begin
                        // error3: IP header checksum
                        reg [18:0] sum_ip;
                        reg [15:0] ip_csum_result;
                        integer j;
                        sum_ip = 19'd0;
                        for (j = 0; j < 20; j = j + 2) begin
                            sum_ip = sum_ip + {frame_mem[j], frame_mem[j+1]};
                        end
                        // fold to 16 bits
                        while (|sum_ip[18:16])
                            sum_ip = {3'd0, sum_ip[15:0]} + sum_ip[18:16];
                        ip_csum_result = sum_ip[15:0];

                        if (ip_csum_result != 16'hffff)
                            err = 4'd3;
                        else begin
                            // error4: UDP checksum
                            reg [31:0] sum_udp;
                            reg [15:0] udp_csum_field;
                            integer k;
                            sum_udp = 32'd0;
                            // pseudo-header
                            sum_udp = sum_udp + {frame_mem[12], frame_mem[13]};
                            sum_udp = sum_udp + {frame_mem[14], frame_mem[15]};
                            sum_udp = sum_udp + {frame_mem[16], frame_mem[17]};
                            sum_udp = sum_udp + {frame_mem[18], frame_mem[19]};
                            sum_udp = sum_udp + 16'h0011;
                            sum_udp = sum_udp + udp_len;
                            // UDP header + payload
                            for (k = 20; k < 512; k = k + 2) begin
                                if ((k + 1) < frame_len_reg) begin
                                    sum_udp = sum_udp + {frame_mem[k], frame_mem[k+1]};
                                end else if (k < frame_len_reg) begin
                                    sum_udp = sum_udp + {frame_mem[k], 8'h00};
                                end
                            end
                            // fold to 16 bits
                            while (|sum_udp[31:16])
                                sum_udp = {16'd0, sum_udp[15:0]} + sum_udp[31:16];
                            // invert
                            udp_csum_field = {frame_mem[26], frame_mem[27]};

                            if ((udp_csum_field != 16'h0000) && (sum_udp[15:0] != 16'hffff))
                                err = 4'd4;
                            else begin
                                // error5
                                if (({frame_mem[16], frame_mem[17], frame_mem[18], frame_mem[19]} != 32'h0a000002) ||
                                    ({frame_mem[22], frame_mem[23]} != 16'd9000))
                                    err = 4'd5;
                                else
                                    err = 4'd0;
                            end
                        end
                    end
                end

                status_error_reg <= err;

                if (err == 4'd0) begin
                    src_ip_reg <= {frame_mem[12], frame_mem[13], frame_mem[14], frame_mem[15]};
                    src_port_reg <= {frame_mem[20], frame_mem[21]};
                    dst_port_reg <= {frame_mem[22], frame_mem[23]};
                    payload_len_reg <= {frame_mem[24], frame_mem[25]} - 16'd8;
                    pay_ptr_reg <= 10'd28;
                    last_index_reg <= frame_len_reg - 10'd1;
                    state_reg <= ST_PAY;
                end else begin
                    state_reg <= ST_IDLE;
                end
            end

            ST_PAY: begin
                if (m_ready && m_valid) begin
                    if (pay_ptr_reg == last_index_reg) begin
                        state_reg <= ST_IDLE;
                    end else begin
                        pay_ptr_reg <= pay_ptr_reg + 10'd1;
                    end
                end
            end

            default: state_reg <= ST_IDLE;
        endcase
    end
end

endmodule
`default_nettype wire
