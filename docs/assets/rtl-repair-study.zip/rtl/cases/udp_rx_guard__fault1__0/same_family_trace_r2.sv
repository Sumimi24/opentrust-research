`timescale 1ns / 1ps
`default_nettype none

module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

localparam [1:0]
    ST_IDLE   = 2'd0,
    ST_RECV   = 2'd1,
    ST_STATUS = 2'd2,
    ST_OUT    = 2'd3;

reg [1:0] state_reg = ST_IDLE;

reg [7:0] frame_mem[0:511];
reg [9:0] recv_count_reg = 10'd0;
reg [9:0] frame_len_reg = 10'd0;
reg oversize_reg = 1'b0;

reg status_valid_reg = 1'b0;
reg [3:0] status_error_reg = 4'd0;

reg out_valid_reg = 1'b0;
reg [7:0] out_data_reg = 8'd0;
reg out_last_reg = 1'b0;
reg [31:0] out_src_ip_reg = 32'd0;
reg [15:0] out_src_port_reg = 16'd0;
reg [15:0] out_dst_port_reg = 16'd0;
reg [15:0] out_payload_len_reg = 16'd0;
reg [9:0] out_ptr_reg = 10'd0;
reg [9:0] out_last_ptr_reg = 10'd0;

assign s_ready = !rst && ((state_reg == ST_IDLE) || (state_reg == ST_RECV));
assign m_data = out_data_reg;
assign m_valid = out_valid_reg;
assign m_last = out_last_reg;
assign m_src_ip = out_src_ip_reg;
assign m_src_port = out_src_port_reg;
assign m_dst_port = out_dst_port_reg;
assign m_payload_len = out_payload_len_reg;
assign status_valid = status_valid_reg;
assign status_error = status_error_reg;

function automatic [15:0] get_word16;
    input [9:0] idx;
    begin
        get_word16 = {frame_mem[idx], frame_mem[idx+10'd1]};
    end
endfunction

integer i;
reg [31:0] sum_ip;
reg [31:0] sum_udp;
reg [15:0] ip_total_len;
reg [15:0] udp_len_chk;
reg [15:0] udp_csum;
reg [7:0] ver_ihl;
reg [7:0] protocol_f;
reg mf_flag;
reg [12:0] frag_off_f;
reg [31:0] src_ip_chk;
reg [31:0] dst_ip_chk;
reg [15:0] src_port_chk;
reg [15:0] dst_port_chk;
reg [15:0] payload_len_chk;
reg [3:0] next_error;

always @* begin
    ver_ihl = frame_mem[0];
    protocol_f = frame_mem[9];
    mf_flag = frame_mem[6][5];
    frag_off_f = {frame_mem[6][4:0], frame_mem[7]};
    ip_total_len = get_word16(10'd2);
    src_ip_chk = {frame_mem[12], frame_mem[13], frame_mem[14], frame_mem[15]};
    dst_ip_chk = {frame_mem[16], frame_mem[17], frame_mem[18], frame_mem[19]};
    src_port_chk = get_word16(10'd20);
    dst_port_chk = get_word16(10'd22);
    udp_len_chk = get_word16(10'd24);
    udp_csum = get_word16(10'd26);
    payload_len_chk = udp_len_chk - 16'd8;
    next_error = 4'd0;

    if ((frame_len_reg < 10'd28) || oversize_reg || (ver_ihl[7:4] != 4'd4) || (ver_ihl[3:0] != 4'd5) || (protocol_f != 8'd17) || mf_flag || (frag_off_f != 13'd0)) begin
        next_error = 4'd1;
    end else if ((ip_total_len != frame_len_reg) || (udp_len_chk != (ip_total_len - 16'd20)) || (payload_len_chk < 16'd1) || (payload_len_chk > 16'd256)) begin
        next_error = 4'd2;
    end else begin
        sum_ip = 32'd0;
        for (i = 0; i < 20; i = i + 2) begin
            sum_ip = sum_ip + {frame_mem[i], frame_mem[i+1]};
        end
        sum_ip = (sum_ip[15:0] + sum_ip[31:16]);
        sum_ip = (sum_ip[15:0] + sum_ip[31:16]);
        if (sum_ip[15:0] != 16'hffff) begin
            next_error = 4'd3;
        end else begin
            if (udp_csum != 16'h0000) begin
                sum_udp = 32'd0;
                sum_udp = sum_udp + {frame_mem[12], frame_mem[13]};
                sum_udp = sum_udp + {frame_mem[14], frame_mem[15]};
                sum_udp = sum_udp + {frame_mem[16], frame_mem[17]};
                sum_udp = sum_udp + {frame_mem[18], frame_mem[19]};
                sum_udp = sum_udp + 16'h0011;
                sum_udp = sum_udp + udp_len_chk;
                for (i = 20; i < 512; i = i + 2) begin
                    if (i < frame_len_reg) begin
                        if (i + 1 < frame_len_reg) begin
                            sum_udp = sum_udp + {frame_mem[i], frame_mem[i+1]};
                        end else begin
                            sum_udp = sum_udp + {frame_mem[i], 8'h00};
                        end
                    end
                end
                sum_udp = (sum_udp[15:0] + sum_udp[31:16]);
                sum_udp = (sum_udp[15:0] + sum_udp[31:16]);
                sum_udp = (sum_udp[15:0] + sum_udp[31:16]);
                if (sum_udp[15:0] != 16'hffff) begin
                    next_error = 4'd4;
                end else if ((dst_ip_chk != 32'h0a000002) || (dst_port_chk != 16'd9000)) begin
                    next_error = 4'd5;
                end else begin
                    next_error = 4'd0;
                end
            end else begin
                if ((dst_ip_chk != 32'h0a000002) || (dst_port_chk != 16'd9000)) begin
                    next_error = 4'd5;
                end else begin
                    next_error = 4'd0;
                end
            end
        end
    end
end

always @(posedge clk) begin
    if (rst) begin
        state_reg <= ST_IDLE;
        recv_count_reg <= 10'd0;
        frame_len_reg <= 10'd0;
        oversize_reg <= 1'b0;
        status_valid_reg <= 1'b0;
        status_error_reg <= 4'd0;
        out_valid_reg <= 1'b0;
        out_data_reg <= 8'd0;
        out_last_reg <= 1'b0;
        out_src_ip_reg <= 32'd0;
        out_src_port_reg <= 16'd0;
        out_dst_port_reg <= 16'd0;
        out_payload_len_reg <= 16'd0;
        out_ptr_reg <= 10'd0;
        out_last_ptr_reg <= 10'd0;
    end else begin
        status_valid_reg <= 1'b0;

        if (out_valid_reg && m_ready) begin
            if (out_last_reg) begin
                out_valid_reg <= 1'b0;
                out_last_reg <= 1'b0;
            end else begin
                out_ptr_reg <= out_ptr_reg + 10'd1;
                out_data_reg <= frame_mem[out_ptr_reg + 10'd1];
                out_last_reg <= ((out_ptr_reg + 10'd1) == out_last_ptr_reg);
            end
        end

        case (state_reg)
            ST_IDLE: begin
                recv_count_reg <= 10'd0;
                frame_len_reg <= 10'd0;
                oversize_reg <= 1'b0;
                if (s_valid) begin
                    frame_mem[0] <= s_data;
                    recv_count_reg <= 10'd1;
                    if (s_last) begin
                        frame_len_reg <= 10'd1;
                        state_reg <= ST_STATUS;
                    end else begin
                        state_reg <= ST_RECV;
                    end
                end
            end

            ST_RECV: begin
                if (s_valid) begin
                    if (recv_count_reg < 10'd512) begin
                        frame_mem[recv_count_reg] <= s_data;
                    end else begin
                        oversize_reg <= 1'b1;
                    end
                    recv_count_reg <= recv_count_reg + 10'd1;
                    if (s_last) begin
                        if (recv_count_reg < 10'd512) begin
                            frame_len_reg <= recv_count_reg + 10'd1;
                        end else begin
                            frame_len_reg <= 10'd512;
                        end
                        state_reg <= ST_STATUS;
                    end
                end
            end

            ST_STATUS: begin
                status_valid_reg <= 1'b1;
                status_error_reg <= next_error;
                if (next_error == 4'd0) begin
                    out_src_ip_reg <= src_ip_chk;
                    out_src_port_reg <= src_port_chk;
                    out_dst_port_reg <= dst_port_chk;
                    out_payload_len_reg <= payload_len_chk;
                    out_ptr_reg <= 10'd28;
                    out_last_ptr_reg <= frame_len_reg - 10'd1;
                    out_data_reg <= frame_mem[10'd28];
                    out_last_reg <= (10'd28 == (frame_len_reg - 10'd1));
                    out_valid_reg <= 1'b1;
                    state_reg <= ST_OUT;
                end else begin
                    state_reg <= ST_IDLE;
                end
            end

            ST_OUT: begin
                if (out_valid_reg && m_ready && out_last_reg) begin
                    state_reg <= ST_IDLE;
                end
            end

            default: begin
                state_reg <= ST_IDLE;
            end
        endcase
    end
end

endmodule
`default_nettype wire
