module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

localparam ST_IDLE     = 3'd0;
localparam ST_ANALYZE  = 3'd1;
localparam ST_CHECKLEN = 3'd2;
localparam ST_IPCHKSUM = 3'd3;
localparam ST_UDPCHKSUM = 3'd4;
localparam ST_CLASSIFY = 3'd5;
localparam ST_STATUS   = 3'd6;
localparam ST_DRAIN    = 3'd7;

reg [7:0] buf_mem [0:511];
reg [9:0] byte_cnt;
reg [2:0] state;
reg [3:0] err_code;
reg status_valid_r;
reg [3:0] status_error_r;
reg [9:0] out_ptr;
reg [9:0] out_end;
reg [15:0] ip_total_len;
reg [15:0] udp_len;
reg [31:0] src_ip_r;
reg [15:0] src_port_r;
reg [15:0] dst_port_r;
reg [15:0] payload_len_r;
reg oversize;
reg [16:0] ip_chksum;
reg [4:0] ip_chk_idx;
reg [17:0] udp_sum;
reg [9:0] udp_ptr;
reg udp_chk_done;
reg [9:0] chk_timer;
reg [15:0] ip_chksum_folded;
reg [15:0] udp_chksum_folded;

wire [7:0] buf_data_out;
assign buf_data_out = buf_mem[out_ptr];

assign s_ready = (state == ST_IDLE) && !rst;
assign status_valid = status_valid_r;
assign status_error = status_error_r;
assign m_valid = (state == ST_DRAIN);
assign m_data = (state == ST_DRAIN) ? buf_data_out : 8'd0;
assign m_last = (state == ST_DRAIN) && (out_ptr == out_end);
assign m_src_ip = src_ip_r;
assign m_src_port = src_port_r;
assign m_dst_port = dst_port_r;
assign m_payload_len = payload_len_r;

always @(posedge clk) begin
    if (rst) begin
        state <= ST_IDLE;
        byte_cnt <= 10'd0;
        status_valid_r <= 1'b0;
        status_error_r <= 4'd0;
        oversize <= 1'b0;
        out_ptr <= 10'd0;
        out_end <= 10'd0;
        ip_chksum <= 17'd0;
        ip_chk_idx <= 5'd0;
        udp_sum <= 18'd0;
        udp_ptr <= 10'd0;
        udp_chk_done <= 1'b0;
        chk_timer <= 10'd0;
        ip_chksum_folded <= 16'd0;
        udp_chksum_folded <= 16'd0;
    end else begin
        status_valid_r <= 1'b0;
        case (state)
            ST_IDLE: begin
                if (s_valid && s_ready) begin
                    if (byte_cnt < 10'd512)
                        buf_mem[byte_cnt] <= s_data;
                    else
                        oversize <= 1'b1;
                    byte_cnt <= byte_cnt + 10'd1;
                    if (s_last) begin
                        state <= ST_ANALYZE;
                    end
                end
            end

            ST_ANALYZE: begin
                if (oversize || byte_cnt < 10'd28 || byte_cnt > 10'd512) begin
                    err_code <= 4'd1;
                    state <= ST_STATUS;
                end else if (buf_mem[0][7:4] != 4'd4 || buf_mem[0][3:0] != 4'd5 || buf_mem[9] != 8'd17 || buf_mem[6][5] || ({buf_mem[6][4:0], buf_mem[7]} != 13'd0)) begin
                    err_code <= 4'd1;
                    state <= ST_STATUS;
                end else begin
                    ip_total_len <= {buf_mem[2], buf_mem[3]};
                    udp_len <= {buf_mem[24], buf_mem[25]};
                    state <= ST_CHECKLEN;
                end
            end

            ST_CHECKLEN: begin
                if (ip_total_len != byte_cnt || udp_len != (ip_total_len - 16'd20) || udp_len < 16'd9 || udp_len > 16'd264) begin
                    err_code <= 4'd2;
                    state <= ST_STATUS;
                end else begin
                    ip_chksum <= 17'd0;
                    ip_chk_idx <= 5'd0;
                    state <= ST_IPCHKSUM;
                end
            end

            ST_IPCHKSUM: begin
                if (ip_chk_idx < 5'd10) begin
                    ip_chksum <= ip_chksum + {buf_mem[{ip_chk_idx[3:0], 1'b0}], buf_mem[{ip_chk_idx[3:0], 1'b1}]};
                    ip_chk_idx <= ip_chk_idx + 5'd1;
                end else begin
                    ip_chksum_folded <= ip_chksum[15:0] + ip_chksum[16];
                    if ((ip_chksum[15:0] + ip_chksum[16]) != 16'hFFFF) begin
                        err_code <= 4'd3;
                        state <= ST_STATUS;
                    end else begin
                        udp_sum <= {buf_mem[12], buf_mem[13]} + {buf_mem[14], buf_mem[15]} + {buf_mem[16], buf_mem[17]} + {buf_mem[18], buf_mem[19]} + 17'd17 + {1'b0, udp_len} + {buf_mem[20], buf_mem[21]} + {buf_mem[22], buf_mem[23]} + {buf_mem[24], buf_mem[25]};
                        udp_ptr <= 10'd28;
                        udp_chk_done <= 1'b0;
                        state <= ST_UDPCHKSUM;
                    end
                end
            end

            ST_UDPCHKSUM: begin
                if (!udp_chk_done) begin
                    if (udp_ptr < byte_cnt) begin
                        if ((udp_ptr + 10'd1) < byte_cnt) begin
                            udp_sum <= udp_sum + {buf_mem[udp_ptr], buf_mem[udp_ptr + 10'd1]};
                            udp_ptr <= udp_ptr + 10'd2;
                        end else begin
                            udp_sum <= udp_sum + {buf_mem[udp_ptr], 8'd0};
                            udp_ptr <= udp_ptr + 10'd1;
                        end
                    end else begin
                        udp_chk_done <= 1'b1;
                    end
                end else begin
                    udp_chksum_folded <= udp_sum[15:0] + udp_sum[17:16];
                    if (({buf_mem[26], buf_mem[27]}) != 16'd0) begin
                        if (((udp_sum[15:0] + udp_sum[17:16]) != 16'hFFFF) && (({buf_mem[26], buf_mem[27]}) != 16'hFFFF)) begin
                            err_code <= 4'd4;
                            state <= ST_STATUS;
                        end else begin
                            state <= ST_CLASSIFY;
                        end
                    end else begin
                        state <= ST_CLASSIFY;
                    end
                end
            end

            ST_CLASSIFY: begin
                src_ip_r <= {buf_mem[12], buf_mem[13], buf_mem[14], buf_mem[15]};
                src_port_r <= {buf_mem[20], buf_mem[21]};
                dst_port_r <= {buf_mem[22], buf_mem[23]};
                payload_len_r <= udp_len - 16'd8;
                if (({buf_mem[16], buf_mem[17], buf_mem[18], buf_mem[19]}) != 32'h0A000002 || ({buf_mem[22], buf_mem[23]}) != 16'd9000) begin
                    err_code <= 4'd5;
                    state <= ST_STATUS;
                end else begin
                    err_code <= 4'd0;
                    state <= ST_STATUS;
                end
            end

            ST_STATUS: begin
                status_valid_r <= 1'b1;
                status_error_r <= err_code;
                if (err_code == 4'd0) begin
                    out_ptr <= 10'd28;
                    out_end <= byte_cnt - 10'd1;
                    state <= ST_DRAIN;
                end else begin
                    state <= ST_IDLE;
                    byte_cnt <= 10'd0;
                    oversize <= 1'b0;
                end
            end

            ST_DRAIN: begin
                if (m_valid && m_ready) begin
                    if (out_ptr == out_end) begin
                        state <= ST_IDLE;
                        byte_cnt <= 10'd0;
                        oversize <= 1'b0;
                    end else begin
                        out_ptr <= out_ptr + 10'd1;
                    end
                end
            end

            default: begin
                state <= ST_IDLE;
                byte_cnt <= 10'd0;
                oversize <= 1'b0;
            end
        endcase
        if (state != ST_IDLE && state != ST_ANALYZE) begin
            chk_timer <= chk_timer + 10'd1;
        end
    end
end

endmodule
