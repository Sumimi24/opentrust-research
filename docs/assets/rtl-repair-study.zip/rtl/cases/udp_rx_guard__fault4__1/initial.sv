module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
output wire s_ready,
input wire s_valid,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

reg [7:0] buf[0:511];
reg [9:0] byte_cnt;
reg [2:0] state;
reg [3:0] err_code;
reg status_valid_r;
reg [3:0] status_error_r;
reg [9:0] out_ptr;
reg [9:0] out_end;
reg [8:0] csum_acc;
reg [3:0] csum_idx;
reg [16:0] udp_sum;
reg [15:0] ip_total_len;
reg [15:0] udp_len;
reg [31:0] src_ip_r;
reg [15:0] src_port_r;
reg [15:0] dst_port_r;
reg [15:0] payload_len_r;
reg [31:0] dst_ip_r;
reg [9:0] chk_timer;
reg oversize;

assign s_ready = (state == 3'd0) && !rst;
assign status_valid = status_valid_r;
assign status_error = status_error_r;
assign m_valid = (state == 3'd4);
assign m_data = (state == 3'd4) ? buf[out_ptr] : 8'd0;
assign m_last = (state == 3'd4) && (out_ptr == out_end);
assign m_src_ip = src_ip_r;
assign m_src_port = src_port_r;
assign m_dst_port = dst_port_r;
assign m_payload_len = payload_len_r;

always @(posedge clk) begin
    if (rst) begin
        state <= 3'd0;
        byte_cnt <= 10'd0;
        status_valid_r <= 1'b0;
        status_error_r <= 4'd0;
        oversize <= 1'b0;
        out_ptr <= 10'd0;
        out_end <= 10'd0;
        csum_acc <= 9'd0;
        csum_idx <= 4'd0;
        udp_sum <= 17'd0;
        chk_timer <= 10'd0;
    end else begin
        status_valid_r <= 1'b0;
        case (state)
            3'd0: begin
                if (s_valid && s_ready) begin
                    if (byte_cnt < 10'd512)
                        buf[byte_cnt] <= s_data;
                    else
                        oversize <= 1'b1;
                    byte_cnt <= byte_cnt + 10'd1;
                    if (s_last) begin
                        state <= 3'd1;
                    end
                end
            end
            3'd1: begin
                if (oversize || byte_cnt < 10'd28 || byte_cnt > 10'd512) begin
                    err_code <= 4'd1;
                    state <= 3'd6;
                end else if (buf[0][7:4] != 4'd4 || buf[0][3:0] != 4'd5 || buf[9] != 8'd17 || buf[6][5] != 1'b0 || {buf[6][4:0], buf[7]} != 13'd0) begin
                    err_code <= 4'd1;
                    state <= 3'd6;
                end else begin
                    ip_total_len <= {buf[2], buf[3]};
                    udp_len <= {buf[24], buf[25]};
                    state <= 3'd2;
                end
            end
            3'd2: begin
                if (ip_total_len != byte_cnt || udp_len != ip_total_len - 16'd20 || udp_len < 16'd9 || udp_len > 16'd264) begin
                    err_code <= 4'd2;
                    state <= 3'd6;
                end else begin
                    csum_acc <= 9'd0;
                    csum_idx <= 4'd0;
                    state <= 3'd3;
                end
            end
            3'd3: begin
                if (csum_idx < 4'd10) begin
                    csum_acc <= csum_acc + {1'b0, buf[{csum_idx, 1'b0}]} + {1'b0, buf[{csum_idx, 1'b1}]};
                    csum_idx <= csum_idx + 4'd1;
                end else begin
                    if ((csum_acc + (csum_acc >> 8)) != 9'h1FF) begin
                        err_code <= 4'd3;
                        state <= 3'd6;
                    end else begin
                        udp_sum <= {buf[12], buf[13]} + {buf[14], buf[15]} + {buf[16], buf[17]} + {buf[18], buf[19]} + 17'd17 + {4'd0, udp_len} + {buf[20], buf[21]} + {buf[22], buf[23]} + {buf[24], buf[25]} + {buf[26], buf[27]};
                        out_ptr <= 10'd28;
                        state <= 3'd4;
                    end
                end
            end
            3'd4: begin
                if (out_ptr < byte_cnt) begin
                    udp_sum <= udp_sum + {buf[out_ptr], (out_ptr + 10'd1 < byte_cnt) ? buf[out_ptr + 10'd1] : 8'd0};
                    out_ptr <= out_ptr + 10'd2;
                end else begin
                    if ({buf[26], buf[27]} != 16'd0) begin
                        if ((udp_sum[15:0] + udp_sum[16]) != 16'hFFFF) begin
                            err_code <= 4'd4;
                            state <= 3'd6;
                        end else begin
                            state <= 3'd5;
                        end
                    end else begin
                        state <= 3'd5;
                    end
                end
            end
            3'd5: begin
                dst_ip_r <= {buf[16], buf[17], buf[18], buf[19]};
                src_ip_r <= {buf[12], buf[13], buf[14], buf[15]};
                src_port_r <= {buf[20], buf[21]};
                dst_port_r <= {buf[22], buf[23]};
                payload_len_r <= udp_len - 16'd8;
                if ({buf[16], buf[17], buf[18], buf[19]} != 32'h0A000002 || {buf[22], buf[23]} != 16'd9000) begin
                    err_code <= 4'd5;
                    state <= 3'd6;
                end else begin
                    err_code <= 4'd0;
                    state <= 3'd6;
                end
            end
            3'd6: begin
                status_valid_r <= 1'b1;
                status_error_r <= err_code;
                if (err_code == 4'd0) begin
                    out_ptr <= 10'd28;
                    out_end <= byte_cnt - 10'd1;
                    state <= 3'd7;
                end else begin
                    state <= 3'd0;
                    byte_cnt <= 10'd0;
                    oversize <= 1'b0;
                end
            end
            3'd7: begin
                if (m_valid && m_ready && m_last) begin
                    state <= 3'd0;
                    byte_cnt <= 10'd0;
                    oversize <= 1'b0;
                end
            end
            default: begin
                state <= 3'd0;
                byte_cnt <= 10'd0;
                oversize <= 1'b0;
            end
        endcase
    end
end

endmodule
