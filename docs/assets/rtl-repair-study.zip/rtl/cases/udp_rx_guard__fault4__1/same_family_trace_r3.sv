`timescale 1ns/1ps
`default_nettype none

module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output reg s_ready,
input wire s_last,
output reg [7:0] m_data,
output reg m_valid,
input wire m_ready,
output reg m_last,
output reg [31:0] m_src_ip,
output reg [15:0] m_src_port,
output reg [15:0] m_dst_port,
output reg [15:0] m_payload_len,
output reg status_valid,
output reg [3:0] status_error);

reg [7:0] buf [0:511];
reg [9:0] byte_cnt;
reg [2:0] state;
reg [3:0] err_code;
reg [9:0] out_ptr;
reg [9:0] out_end;
reg [8:0] csum_acc;
reg [3:0] csum_idx;
reg [16:0] udp_sum;
reg [15:0] ip_total_len;
reg [15:0] udp_len;
reg [31:0] src_ip_r;
reg [15:0] src_port_r;
reg [15:0] dst_port_r;
reg [15:0] payload_len_r;
reg oversize;
reg [15:0] udp_word;
reg [16:0] udp_s1;
reg [16:0] udp_s2;
reg [15:0] udp_final;
reg [7:0] b0,b1,b2,b3,b4,b5,b6,b7,b8,b9;
reg [7:0] b12,b13,b14,b15,b16,b17,b18,b19;
reg [7:0] b20,b21,b22,b23,b24,b25,b26,b27;
reg [7:0] nxt_data;
reg nxt_last;
reg [9:0] nxt_ptr;

always @(posedge clk) begin
    if (rst) begin
        state <= 3'd0;
        byte_cnt <= 10'd0;
        status_valid <= 1'b0;
        status_error <= 4'd0;
        oversize <= 1'b0;
        s_ready <= 1'b1;
        m_valid <= 1'b0;
        m_last <= 1'b0;
        m_data <= 8'd0;
        m_src_ip <= 32'd0;
        m_src_port <= 16'd0;
        m_dst_port <= 16'd0;
        m_payload_len <= 16'd0;
        out_ptr <= 10'd0;
        out_end <= 10'd0;
        csum_acc <= 9'd0;
        csum_idx <= 4'd0;
        udp_sum <= 17'd0;
    end else begin
        status_valid <= 1'b0;
        case (state)
            3'd0: begin
                s_ready <= 1'b1;
                m_valid <= 1'b0;
                byte_cnt <= 10'd0;
                oversize <= 1'b0;
                if (s_valid && s_ready) begin
                    if (byte_cnt < 10'd512) begin
                        buf[byte_cnt] <= s_data;
                    end else begin
                        oversize <= 1'b1;
                    end
                    byte_cnt <= byte_cnt + 10'd1;
                    if (s_last) begin
                        s_ready <= 1'b0;
                        state <= 3'd1;
                    end
                end
            end
            3'd1: begin
                b0 <= buf[0];
                b6 <= buf[6];
                b7 <= buf[7];
                b9 <= buf[9];
                b2 <= buf[2];
                b3 <= buf[3];
                b24 <= buf[24];
                b25 <= buf[25];
                if (oversize || byte_cnt < 10'd28 || byte_cnt > 10'd512) begin
                    err_code <= 4'd1;
                    state <= 3'd6;
                end else begin
                    state <= 3'd2;
                end
            end
            3'd2: begin
                if (b0[7:4] != 4'd4 || b0[3:0] != 4'd5 || b9 != 8'd17 || b6[5] != 1'b0 || {b6[4:0], b7} != 13'd0) begin
                    err_code <= 4'd1;
                    state <= 3'd6;
                end else begin
                    ip_total_len <= {b2, b3};
                    udp_len <= {b24, b25};
                    state <= 3'd3;
                end
            end
            3'd3: begin
                if (ip_total_len != byte_cnt || udp_len != (ip_total_len - 16'd20) || udp_len < 16'd9 || udp_len > 16'd264) begin
                    err_code <= 4'd2;
                    state <= 3'd6;
                end else begin
                    csum_acc <= 9'd0;
                    csum_idx <= 4'd0;
                    state <= 3'd4;
                end
            end
            3'd4: begin
                if (csum_idx < 4'd10) begin
                    csum_acc <= csum_acc + {1'b0, buf[{csum_idx, 1'b0}]} + {1'b0, buf[{csum_idx, 1'b1}]};
                    csum_idx <= csum_idx + 4'd1;
                end else begin
                    state <= 3'd5;
                end
            end
            3'd5: begin
                b12 <= buf[12]; b13 <= buf[13]; b14 <= buf[14]; b15 <= buf[15];
                b16 <= buf[16]; b17 <= buf[17]; b18 <= buf[18]; b19 <= buf[19];
                b20 <= buf[20]; b21 <= buf[21]; b22 <= buf[22]; b23 <= buf[23];
                b26 <= buf[26]; b27 <= buf[27];
                if ((csum_acc + {1'b0, csum_acc[8]}) != 9'h1FF) begin
                    err_code <= 4'd3;
                    state <= 3'd6;
                end else begin
                    udp_sum <= {buf[12], buf[13]} + {buf[14], buf[15]} + {buf[16], buf[17]} + {buf[18], buf[19]} + 17'd17 + {4'd0, udp_len} + {buf[20], buf[21]} + {buf[22], buf[23]} + {buf[24], buf[25]} + {buf[26], buf[27]};
                    out_ptr <= 10'd28;
                    state <= 3'd7;
                end
            end
            3'd7: begin
                if (out_ptr < byte_cnt) begin
                    if (out_ptr + 10'd1 < byte_cnt) begin
                        udp_word <= {buf[out_ptr], buf[out_ptr + 10'd1]};
                    end else begin
                        udp_word <= {buf[out_ptr], 8'd0};
                    end
                    udp_s1 <= udp_sum + udp_word;
                    udp_s2 <= udp_s1[15:0] + udp_s1[16];
                    udp_sum <= udp_s2[15:0] + udp_s2[16];
                    out_ptr <= out_ptr + 10'd2;
                end else begin
                    udp_final <= udp_sum[15:0] + udp_sum[16];
                    state <= 3'd8;
                end
            end
            3'd8: begin
                src_ip_r <= {b12, b13, b14, b15};
                src_port_r <= {b20, b21};
                dst_port_r <= {b22, b23};
                payload_len_r <= udp_len - 16'd8;
                if ({b26, b27} != 16'd0 && udp_final != 16'hFFFF) begin
                    err_code <= 4'd4;
                    state <= 3'd6;
                end else if ({b16, b17, b18, b19} != 32'h0A000002 || {b22, b23} != 16'd9000) begin
                    err_code <= 4'd5;
                    state <= 3'd6;
                end else begin
                    err_code <= 4'd0;
                    state <= 3'd6;
                end
            end
            3'd6: begin
                status_valid <= 1'b1;
                status_error <= err_code;
                if (err_code == 4'd0) begin
                    out_ptr <= 10'd28;
                    out_end <= byte_cnt - 10'd1;
                    nxt_ptr <= 10'd28;
                    nxt_data <= buf[10'd28];
                    nxt_last <= (10'd28 == (byte_cnt - 10'd1));
                    m_valid <= 1'b1;
                    m_data <= buf[10'd28];
                    m_last <= (10'd28 == (byte_cnt - 10'd1));
                    m_src_ip <= src_ip_r;
                    m_src_port <= src_port_r;
                    m_dst_port <= dst_port_r;
                    m_payload_len <= payload_len_r;
                    state <= 3'd9;
                end else begin
                    state <= 3'd0;
                    s_ready <= 1'b1;
                end
            end
            3'd9: begin
                if (m_valid && m_ready) begin
                    if (m_last) begin
                        m_valid <= 1'b0;
                        state <= 3'd0;
                        s_ready <= 1'b1;
                    end else begin
                        nxt_ptr <= out_ptr + 10'd1;
                        nxt_data <= buf[out_ptr + 10'd1];
                        nxt_last <= ((out_ptr + 10'd1) == out_end);
                        out_ptr <= out_ptr + 10'd1;
                        m_data <= buf[out_ptr + 10'd1];
                        m_last <= ((out_ptr + 10'd1) == out_end);
                    end
                end
            end
            default: begin
                state <= 3'd0;
                s_ready <= 1'b1;
                m_valid <= 1'b0;
            end
        endcase
    end
end

endmodule
