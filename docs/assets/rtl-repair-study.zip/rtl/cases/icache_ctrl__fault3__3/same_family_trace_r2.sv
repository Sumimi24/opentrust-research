module icache_ctrl(
input wire clk_i,
input wire rst_ni,
input wire req_i,
input wire branch_i,
input wire [31:0] addr_i,
input wire ready_i,
output wire valid_o,
output wire [31:0] rdata_o,
output wire [31:0] addr_o,
output wire err_o,
output wire instr_req_o,
input wire instr_gnt_i,
output wire [31:0] instr_addr_o,
input wire [31:0] instr_rdata_i,
input wire instr_err_i,
input wire instr_rvalid_i,
input wire icache_inval_i,
output wire busy_o);

reg [1:0] tag_req;
reg tag_write;
reg [7:0] tag_addr;
reg [21:0] tag_wdata;
wire [21:0] tag_rdata [2];
reg [1:0] data_req;
reg data_write;
reg [7:0] data_addr;
reg [63:0] data_wdata;
wire [63:0] data_rdata [2];

reg [21:0] tag_mem0 [0:255];
reg [21:0] tag_mem1 [0:255];
reg [63:0] data_mem0 [0:255];
reg [63:0] data_mem1 [0:255];

reg [21:0] tag_rdata0_reg;
reg [21:0] tag_rdata1_reg;
reg [63:0] data_rdata0_reg;
reg [63:0] data_rdata1_reg;

always @(posedge clk_i) begin
    if (tag_req[0]) begin
        tag_rdata0_reg <= tag_mem0[tag_addr];
        if (tag_write) tag_mem0[tag_addr] <= tag_wdata;
    end
    if (tag_req[1]) begin
        tag_rdata1_reg <= tag_mem1[tag_addr];
        if (tag_write) tag_mem1[tag_addr] <= tag_wdata;
    end
    if (data_req[0]) begin
        data_rdata0_reg <= data_mem0[data_addr];
        if (data_write) data_mem0[data_addr] <= data_wdata;
    end
    if (data_req[1]) begin
        data_rdata1_reg <= data_mem1[data_addr];
        if (data_write) data_mem1[data_addr] <= data_wdata;
    end
end

assign tag_rdata[0] = tag_rdata0_reg;
assign tag_rdata[1] = tag_rdata1_reg;
assign data_rdata[0] = data_rdata0_reg;
assign data_rdata[1] = data_rdata1_reg;

ibex_icache #(
    .ICacheECC(0),
    .ResetAll(1),
    .BranchCache(0),
    .TweakInfection(0)
) core (
    .clk_i(clk_i),
    .rst_ni(rst_ni),
    .req_i(req_i),
    .branch_i(branch_i),
    .addr_i(addr_i),
    .ready_i(ready_i),
    .valid_o(valid_o),
    .rdata_o(rdata_o),
    .addr_o(addr_o),
    .err_o(err_o),
    .instr_req_o(instr_req_o),
    .instr_gnt_i(instr_gnt_i),
    .instr_addr_o(instr_addr_o),
    .instr_rdata_i(instr_rdata_i),
    .instr_err_i(instr_err_i),
    .instr_rvalid_i(instr_rvalid_i),
    .icache_inval_i(icache_inval_i),
    .busy_o(busy_o),
    .ic_tag_req_o(tag_req),
    .ic_tag_write_o(tag_write),
    .ic_tag_addr_o(tag_addr),
    .ic_tag_wdata_o(tag_wdata),
    .ic_tag_rdata_i(tag_rdata),
    .ic_data_req_o(data_req),
    .ic_data_write_o(data_write),
    .ic_data_addr_o(data_addr),
    .ic_data_wdata_o(data_wdata),
    .ic_data_rdata_i(data_rdata),
    .ic_scr_key_valid_i(1'b1),
    .icache_enable_i(1'b1)
);

endmodule
