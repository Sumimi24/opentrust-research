module icache_ctrl(
input wire clk_i,
input wire rst_ni,
input wire req_i,
input wire branch_i,
input wire [31:0] addr_i,
input wire ready_i,
output wire valid_o,
output wire [31:0] rdata_o,
output wire [31:0] addr_o,
output wire err_o,
output wire instr_req_o,
input wire instr_gnt_i,
output wire [31:0] instr_addr_o,
input wire [31:0] instr_rdata_i,
input wire instr_err_i,
input wire instr_rvalid_i,
input wire icache_inval_i,
output wire busy_o);

localparam integer CACHE_LINES = 8;
localparam integer INDEX_W = 3;
localparam integer TAG_W = 27;
localparam integer FIFO_W = 6;
localparam integer EPOCH_W = 2;

reg [31:0] cache_data [0:CACHE_LINES-1];
reg [TAG_W-1:0] cache_tag [0:CACHE_LINES-1];
reg              cache_valid [0:CACHE_LINES-1];

reg [31:0] out_data_q;
reg [31:0] out_addr_q;
reg        out_err_q;
reg        out_valid_q;

reg [31:0] pc_q;
reg        stream_active_q;
reg        after_error_q;

reg [31:0] req_addr_fifo [0:31];
reg [EPOCH_W-1:0] req_epoch_fifo [0:31];
reg [4:0] req_head_q, req_tail_q;
reg [5:0] req_count_q;

reg [31:0] fill_addr_q;
reg [EPOCH_W-1:0] fill_epoch_q;
reg        fill_valid_q;

reg [EPOCH_W-1:0] epoch_q;
reg               inval_pending_q;

wire consume_w;
wire [INDEX_W-1:0] pc_index_w;
wire [TAG_W-1:0] pc_tag_w;
wire cache_hit_w;

assign consume_w = out_valid_q & ready_i & ~branch_i;

assign pc_index_w = pc_q[4:2];
assign pc_tag_w = pc_q[31:5];
assign cache_hit_w = cache_valid[pc_index_w] && (cache_tag[pc_index_w] == pc_tag_w);

assign valid_o = out_valid_q;
assign rdata_o = out_data_q;
assign addr_o = out_addr_q;
assign err_o = out_err_q;

assign instr_req_o = req_i && stream_active_q && ~after_error_q &&
                     ~out_valid_q &&
                     ~cache_hit_w &&
                     (req_count_q < 6'd32);

assign instr_addr_o = {pc_q[31:2], 2'b00};

assign busy_o = (req_count_q != 0) | fill_valid_q | out_valid_q | inval_pending_q;

integer i;
reg [31:0] old_pc;
reg [INDEX_W-1:0] idx;
always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
        out_data_q <= 32'b0;
        out_addr_q <= 32'b0;
        out_err_q <= 1'b0;
        out_valid_q <= 1'b0;
        pc_q <= 32'b0;
        stream_active_q <= 1'b0;
        after_error_q <= 1'b0;
        req_head_q <= 5'b0;
        req_tail_q <= 5'b0;
        req_count_q <= 6'b0;
        fill_addr_q <= 32'b0;
        fill_epoch_q <= {EPOCH_W{1'b0}};
        fill_valid_q <= 1'b0;
        epoch_q <= {EPOCH_W{1'b0}};
        inval_pending_q <= 1'b0;
        for (i = 0; i < CACHE_LINES; i = i + 1) begin
            cache_data[i] <= 32'b0;
            cache_tag[i] <= {TAG_W{1'b0}};
            cache_valid[i] <= 1'b0;
        end
    end else begin
        if (icache_inval_i) begin
            inval_pending_q <= 1'b1;
        end

        if (inval_pending_q) begin
            for (i = 0; i < CACHE_LINES; i = i + 1) begin
                cache_valid[i] <= 1'b0;
            end
            inval_pending_q <= 1'b0;
        end

        if (branch_i) begin
            out_valid_q <= 1'b0;
            out_err_q <= 1'b0;
            pc_q <= {addr_i[31:2], 2'b00};
            stream_active_q <= 1'b1;
            after_error_q <= 1'b0;
            epoch_q <= epoch_q + {{(EPOCH_W-1){1'b0}},1'b1};
        end else if (consume_w) begin
            out_valid_q <= 1'b0;
            if (!out_err_q) begin
                pc_q <= out_addr_q + 32'd4;
            end
            if (out_err_q) begin
                after_error_q <= 1'b1;
            end
        end

        if (instr_req_o && instr_gnt_i) begin
            req_addr_fifo[req_tail_q] <= {pc_q[31:2], 2'b00};
            req_epoch_fifo[req_tail_q] <= epoch_q;
            req_tail_q <= req_tail_q + 5'd1;
            req_count_q <= req_count_q + 6'd1;
        end

        if (!fill_valid_q && (req_count_q != 0)) begin
            fill_addr_q <= req_addr_fifo[req_head_q];
            fill_epoch_q <= req_epoch_fifo[req_head_q];
            fill_valid_q <= 1'b1;
            req_head_q <= req_head_q + 5'd1;
            req_count_q <= req_count_q - 6'd1;
        end

        if (instr_rvalid_i && fill_valid_q) begin
            if (fill_epoch_q == epoch_q) begin
                idx = fill_addr_q[4:2];
                cache_data[idx] <= instr_rdata_i;
                cache_tag[idx] <= fill_addr_q[31:5];
                cache_valid[idx] <= ~instr_err_i;
                if (!out_valid_q && stream_active_q && !after_error_q && (fill_addr_q == pc_q)) begin
                    out_valid_q <= 1'b1;
                    out_data_q <= instr_rdata_i;
                    out_addr_q <= fill_addr_q;
                    out_err_q <= instr_err_i;
                end
            end
            fill_valid_q <= 1'b0;
        end

        if (!branch_i && !out_valid_q && stream_active_q && !after_error_q) begin
            old_pc = pc_q;
            if (cache_valid[old_pc[4:2]] && (cache_tag[old_pc[4:2]] == old_pc[31:5])) begin
                out_valid_q <= 1'b1;
                out_data_q <= cache_data[old_pc[4:2]];
                out_addr_q <= old_pc;
                out_err_q <= 1'b0;
            end
        end
    end
end

endmodule
