`timescale 1ns / 1ps
`default_nettype none

module dma_write(
input wire clk,
input wire rst,
input wire [15:0] desc_addr,
input wire [15:0] desc_len,
input wire [7:0] desc_tag,
input wire desc_valid,
output wire desc_ready,
input wire [31:0] s_data,
input wire [3:0] s_keep,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [15:0] status_len,
output wire [7:0] status_tag,
output wire [3:0] status_error,
output wire status_valid,
output wire [3:0] m_axi_awid,
output wire [15:0] m_axi_awaddr,
output wire [7:0] m_axi_awlen,
output wire [2:0] m_axi_awsize,
output wire [1:0] m_axi_awburst,
output wire m_axi_awlock,
output wire [3:0] m_axi_awcache,
output wire [2:0] m_axi_awprot,
output wire m_axi_awvalid,
input wire m_axi_awready,
output wire [31:0] m_axi_wdata,
output wire [3:0] m_axi_wstrb,
output wire m_axi_wlast,
output wire m_axi_wvalid,
input wire m_axi_wready,
input wire [3:0] m_axi_bid,
input wire [1:0] m_axi_bresp,
input wire m_axi_bvalid,
output wire m_axi_bready);

localparam S_IDLE  = 3'd0;
localparam S_AW    = 3'd1;
localparam S_W     = 3'd2;
localparam S_WAIT  = 3'd3;
localparam S_DONE  = 3'd4;

reg [2:0] state;
reg [15:0] addr;
reg [15:0] remain;
reg [7:0]  tag;
reg [15:0] total_len;
reg        stream_last;
reg [31:0] wdata;
reg [3:0]  wstrb;
reg [1:0]  error;
reg        aw_sent;
reg        aw_addr_valid;
reg [15:0] aw_addr;
reg [3:0]  aw_len;
reg [3:0]  w_cnt;
reg        w_last;
reg        w_first;
reg        r_accept;
reg        w_accept;

assign desc_ready   = (state == S_IDLE);
assign status_len   = total_len;
assign status_tag   = tag;
assign status_error = error;
assign status_valid = (state == S_DONE);

assign m_axi_awid    = 4'd0;
assign m_axi_awaddr  = aw_addr;
assign m_axi_awlen   = {4'd0, aw_len};
assign m_axi_awsize  = 3'd2;
assign m_axi_awburst = 2'b01;
assign m_axi_awlock  = 1'b0;
assign m_axi_awcache = 4'd3;
assign m_axi_awprot  = 3'd0;
assign m_axi_awvalid = aw_addr_valid;

assign m_axi_wdata   = wdata;
assign m_axi_wstrb   = wstrb;
assign m_axi_wlast   = w_last;
assign m_axi_wvalid  = w_accept;
assign m_axi_bready  = (state == S_WAIT);

assign s_ready       = (state == S_W) && !r_accept;

function [3:0] calc_wstrb;
    input [15:0] base;
    input [3:0]  orig;
    input        is_first;
    begin
        if (!is_first) begin
            calc_wstrb = orig;
        end else begin
            case (base[1:0])
                2'd0: calc_wstrb = orig;
                2'd1: calc_wstrb = {orig[3:1], 1'b0};
                2'd2: calc_wstrb = {orig[3:2], 2'b00};
                2'd3: calc_wstrb = {orig[3],   3'b000};
                default: calc_wstrb = orig;
            endcase
        end
    end
endfunction

always @(posedge clk) begin
    if (rst) begin
        state          <= S_IDLE;
        error          <= 2'b00;
        aw_sent        <= 1'b0;
        aw_addr_valid  <= 1'b0;
        w_accept       <= 1'b0;
        r_accept       <= 1'b0;
    end else begin
        case (state)
            S_IDLE: begin
                error <= 2'b00;
                if (desc_valid && desc_ready) begin
                    addr       <= desc_addr;
                    remain     <= desc_len;
                    tag        <= desc_tag;
                    total_len  <= desc_len;
                    stream_last<= 1'b0;
                    aw_sent    <= 1'b0;
                    state      <= S_AW;
                end
            end

            S_AW: begin
                if (!aw_sent) begin
                    if (!aw_addr_valid) begin
                        aw_addr <= addr;
                        if (remain <= 16'd64) begin
                            aw_len <= remain[5:2] - 4'd1;
                        end else begin
                            if ((addr & 16'hF00) != ((addr + 16'd64 - 16'd1) & 16'hF00)) begin
                                aw_len <= ((16'h1000 - (addr & 16'hFFF)) >> 2) - 4'd1;
                            end else begin
                                aw_len <= 4'd15;
                            end
                        end
                        aw_addr_valid <= 1'b1;
                    end
                    
                    if (aw_addr_valid && m_axi_awready) begin
                        aw_addr_valid <= 1'b0;
                        aw_sent       <= 1'b1;
                        w_cnt         <= 4'd0;
                        w_first       <= 1'b1;
                        r_accept      <= 1'b0;
                        w_accept      <= 1'b0;
                        state         <= S_W;
                    end
                end
            end

            S_W: begin
                if (!r_accept && s_valid && s_ready) begin
                    r_accept <= 1'b1;
                    wdata    <= s_data;
                    wstrb    <= calc_wstrb(aw_addr + {12'd0, w_cnt, 2'b00}, s_keep, w_first);
                    stream_last <= s_last;
                end

                if (r_accept && !w_accept) begin
                    w_accept <= 1'b1;
                end

                if (w_accept && m_axi_wvalid && m_axi_wready) begin
                    w_accept <= 1'b0;
                    r_accept <= 1'b0;
                    if (w_cnt == aw_len) begin
                        addr   <= aw_addr + {12'd0, aw_len, 2'b00} + 16'd4;
                        remain <= remain - {12'd0, aw_len, 2'b00} - 16'd4;
                        if (remain == {12'd0, aw_len, 2'b00} + 16'd4) begin
                            state <= S_WAIT;
                        end else begin
                            aw_sent <= 1'b0;
                            state   <= S_AW;
                        end
                    end else begin
                        w_cnt   <= w_cnt + 4'd1;
                        w_first <= 1'b0;
                    end
                end
            end

            S_WAIT: begin
                if (m_axi_bvalid && m_axi_bready) begin
                    if (m_axi_bresp == 2'b10) error[0] <= 1'b1;
                    if (m_axi_bresp == 2'b11) error[1] <= 1'b1;
                    state <= S_DONE;
                end
            end

            S_DONE: begin
                state <= S_IDLE;
            end

            default: state <= S_IDLE;
        endcase
    end
end

endmodule
