`timescale 1ns / 1ps
`default_nettype none

module dma_write(
input wire clk,
input wire rst,
input wire [15:0] desc_addr,
input wire [15:0] desc_len,
input wire [7:0] desc_tag,
input wire desc_valid,
output wire desc_ready,
input wire [31:0] s_data,
input wire [3:0] s_keep,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [15:0] status_len,
output wire [7:0] status_tag,
output wire [3:0] status_error,
output wire status_valid,
output wire [3:0] m_axi_awid,
output wire [15:0] m_axi_awaddr,
output wire [7:0] m_axi_awlen,
output wire [2:0] m_axi_awsize,
output wire [1:0] m_axi_awburst,
output wire m_axi_awlock,
output wire [3:0] m_axi_awcache,
output wire [2:0] m_axi_awprot,
output wire m_axi_awvalid,
input wire m_axi_awready,
output wire [31:0] m_axi_wdata,
output wire [3:0] m_axi_wstrb,
output wire m_axi_wlast,
output wire m_axi_wvalid,
input wire m_axi_wready,
input wire [3:0] m_axi_bid,
input wire [1:0] m_axi_bresp,
input wire m_axi_bvalid,
output wire m_axi_bready);

reg [2:0] state;
localparam S_IDLE = 3'd0;
localparam S_AW   = 3'd1;
localparam S_W    = 3'd2;
localparam S_B    = 3'd3;
localparam S_DONE = 3'd4;

reg [15:0] r_addr;
reg [15:0] r_rem;
reg [7:0]  r_tag;
reg [15:0] r_len;
reg        r_last_in;
reg [31:0] r_data;
reg [3:0]  r_keep;
reg [1:0]  r_err;

reg [3:0]  b_beats;
reg [3:0]  w_beat;
reg [15:0] b_addr;
reg [15:0] b_rem;
reg        aw_done;
reg        s_accept;
reg        w_active;

wire [15:0] burst_bytes_c = (r_rem > 16'd64) ? 16'd64 : r_rem;
wire [3:0]  total_beats_c = burst_bytes_c[3:0] == 4'd0 ? 4'hF : {burst_bytes_c[3:0] - 4'd1};
wire [15:0] page_off_c    = r_addr & 16'h0FFF;
wire [15:0] max_page_c    = 16'h1000 - page_off_c;
wire        page_lim_c    = ({burst_bytes_c, 2'b00}) > max_page_c;
wire [3:0]  adj_beats_c   = page_lim_c ? ((max_page_c >> 2) - 4'd1) : total_beats_c;
wire [7:0]  awlen_val_c   = {4'd0, adj_beats_c};
wire [15:0] aw_burst_bytes_c = {adj_beats_c + 4'd1, 2'b00};

assign desc_ready       = (state == S_IDLE);
assign status_len       = r_len;
assign status_tag       = r_tag;
assign status_error     = r_err;
assign status_valid     = (state == S_DONE);

assign m_axi_awid       = 4'd0;
assign m_axi_awaddr     = r_addr;
assign m_axi_awlen      = awlen_val_c;
assign m_axi_awsize     = 3'd2;
assign m_axi_awburst    = 2'b01;
assign m_axi_awlock     = 1'b0;
assign m_axi_awcache    = 4'd3;
assign m_axi_awprot     = 3'd0;
assign m_axi_awvalid    = (state == S_AW);

assign m_axi_wdata      = r_data;
assign m_axi_wstrb      = r_keep;
assign m_axi_wlast      = (w_beat == b_beats);
assign m_axi_wvalid     = (state == S_W) && w_active;

assign m_axi_bready     = (state == S_B);
assign s_ready          = (state == S_W) && !w_active;

always @(posedge clk) begin
    if (rst) begin
        state    <= S_IDLE;
        r_err    <= 2'b00;
        w_active <= 1'b0;
    end else begin
        case (state)
            S_IDLE: begin
                r_err <= 2'b00;
                if (desc_valid) begin
                    r_addr    <= desc_addr;
                    r_rem     <= desc_len;
                    r_tag     <= desc_tag;
                    r_len     <= desc_len;
                    r_last_in <= 1'b0;
                    state     <= S_AW;
                end
            end

            S_AW: begin
                if (m_axi_awready) begin
                    b_beats  <= awlen_val_c[3:0];
                    b_addr   <= r_addr;
                    b_rem    <= r_rem;
                    w_beat   <= 4'd0;
                    w_active <= 1'b0;
                    state    <= S_W;
                end
            end

            S_W: begin
                if (!w_active) begin
                    if (s_valid) begin
                        r_data    <= s_data;
                        r_keep    <= s_keep;
                        r_last_in <= s_last;
                        w_active  <= 1'b1;
                    end
                end else begin
                    if (m_axi_wready) begin
                        if (m_axi_wlast) begin
                            w_active <= 1'b0;
                            r_addr   <= b_addr + aw_burst_bytes_c;
                            r_rem    <= b_rem - aw_burst_bytes_c;
                            state    <= S_B;
                        end else begin
                            w_beat   <= w_beat + 4'd1;
                            w_active <= 1'b0;
                        end
                    end
                end
            end

            S_B: begin
                if (m_axi_bvalid) begin
                    if (m_axi_bresp == 2'b10) r_err[0] <= 1'b1;
                    if (m_axi_bresp == 2'b11) r_err[1] <= 1'b1;
                    if (r_rem == 16'd0) begin
                        state <= S_DONE;
                    end else begin
                        state <= S_AW;
                    end
                end
            end

            S_DONE: begin
                state <= S_IDLE;
            end

            default: state <= S_IDLE;
        endcase
    end
end

endmodule
