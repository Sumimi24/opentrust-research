module icache_ctrl(
input wire clk_i,
input wire rst_ni,
input wire req_i,
input wire branch_i,
input wire [31:0] addr_i,
input wire ready_i,
output wire valid_o,
output wire [31:0] rdata_o,
output wire [31:0] addr_o,
output wire err_o,
output wire instr_req_o,
input wire instr_gnt_i,
output wire [31:0] instr_addr_o,
input wire [31:0] instr_rdata_i,
input wire instr_err_i,
input wire instr_rvalid_i,
input wire icache_inval_i,
output wire busy_o);

wire [1:0] ic_tag_req;
wire ic_tag_write;
wire [7:0] ic_tag_addr;
wire [21:0] ic_tag_wdata;
wire [21:0] ic_tag_rdata [0:1];
wire [1:0] ic_data_req;
wire ic_data_write;
wire [7:0] ic_data_addr;
wire [63:0] ic_data_wdata;
wire [63:0] ic_data_rdata [0:1];

reg [21:0] tag_mem0 [0:255];
reg [21:0] tag_mem1 [0:255];
reg [63:0] data_mem0 [0:255];
reg [63:0] data_mem1 [0:255];

always @(posedge clk_i) begin
    if (ic_tag_req[0]) begin
        ic_tag_rdata[0] <= tag_mem0[ic_tag_addr];
        if (ic_tag_write)
            tag_mem0[ic_tag_addr] <= ic_tag_wdata;
    end
    if (ic_tag_req[1]) begin
        ic_tag_rdata[1] <= tag_mem1[ic_tag_addr];
        if (ic_tag_write)
            tag_mem1[ic_tag_addr] <= ic_tag_wdata;
    end
    if (ic_data_req[0]) begin
        ic_data_rdata[0] <= data_mem0[ic_data_addr];
        if (ic_data_write)
            data_mem0[ic_data_addr] <= ic_data_wdata;
    end
    if (ic_data_req[1]) begin
        ic_data_rdata[1] <= data_mem1[ic_data_addr];
        if (ic_data_write)
            data_mem1[ic_data_addr] <= ic_data_wdata;
    end
end

ibex_icache #(
    .ICacheECC(0),
    .BranchCache(0),
    .TweakInfection(0)
) core (
    .clk_i(clk_i),
    .rst_ni(rst_ni),
    .req_i(req_i),
    .branch_i(branch_i),
    .addr_i(addr_i),
    .ready_i(ready_i),
    .valid_o(valid_o),
    .rdata_o(rdata_o),
    .addr_o(addr_o),
    .err_o(err_o),
    .instr_req_o(instr_req_o),
    .instr_gnt_i(instr_gnt_i),
    .instr_addr_o(instr_addr_o),
    .instr_rdata_i(instr_rdata_i),
    .instr_err_i(instr_err_i),
    .instr_rvalid_i(instr_rvalid_i),
    .icache_inval_i(icache_inval_i),
    .busy_o(busy_o),
    .ic_tag_req_o(ic_tag_req),
    .ic_tag_write_o(ic_tag_write),
    .ic_tag_addr_o(ic_tag_addr),
    .ic_tag_wdata_o(ic_tag_wdata),
    .ic_tag_rdata_i(ic_tag_rdata),
    .ic_data_req_o(ic_data_req),
    .ic_data_write_o(ic_data_write),
    .ic_data_addr_o(ic_data_addr),
    .ic_data_wdata_o(ic_data_wdata),
    .ic_data_rdata_i(ic_data_rdata),
    .ic_scr_key_valid_i(1'b1)
);

endmodule
