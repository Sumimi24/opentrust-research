module icache_ctrl(
input wire clk_i,
input wire rst_ni,
input wire req_i,
input wire branch_i,
input wire [31:0] addr_i,
input wire ready_i,
output wire valid_o,
output wire [31:0] rdata_o,
output wire [31:0] addr_o,
output wire err_o,
output wire instr_req_o,
input wire instr_gnt_i,
output wire [31:0] instr_addr_o,
input wire [31:0] instr_rdata_i,
input wire instr_err_i,
input wire instr_rvalid_i,
input wire icache_inval_i,
output wire busy_o
);

localparam int NUM_LINES = 64;
localparam int IDX_W     = 6;
localparam int TAG_W     = 25;
localparam int FIFO_W    = 32;

reg [31:0] cache_data [0:NUM_LINES-1];
reg [TAG_W-1:0] cache_tag [0:NUM_LINES-1];
reg [NUM_LINES-1:0] cache_valid;

reg [31:0] out_data_q;
reg [31:0] out_addr_q;
reg        out_err_q;
reg        out_valid_q;
reg        error_mode_q;

reg [31:0] next_pc_q;
reg [31:0] fetch_addr_q;
reg        have_stream_q;

reg [31:0] req_addr_fifo [0:FIFO_W-1];
reg [5:0]  req_epoch_fifo [0:FIFO_W-1];
reg [5:0]  req_head_q;
reg [5:0]  req_tail_q;
reg [5:0]  outstanding_q;

reg [5:0] epoch_q;
reg       inval_pending_q;

wire out_fire = out_valid_q & ready_i & ~branch_i;

wire [IDX_W-1:0] next_idx  = next_pc_q[7:2];
wire [TAG_W-1:0] next_tag  = next_pc_q[31:8];
wire             hit_next  = cache_valid[next_idx] && (cache_tag[next_idx] == next_tag);
wire [31:0]      hit_rdata = cache_data[next_idx];

wire fifo_full  = (outstanding_q == FIFO_W);
wire fifo_empty = (outstanding_q == 0);

wire [31:0] head_req_addr  = req_addr_fifo[req_head_q[4:0]];
wire [5:0]  head_req_epoch = req_epoch_fifo[req_head_q[4:0]];

wire issue_miss = have_stream_q && req_i && ~out_valid_q && ~error_mode_q && ~hit_next && ~fifo_full;

assign valid_o      = out_valid_q;
assign rdata_o      = out_data_q;
assign addr_o       = out_addr_q;
assign err_o        = out_err_q;
assign instr_req_o  = issue_miss;
assign instr_addr_o = {next_pc_q[31:2], 2'b00};
assign busy_o       = (outstanding_q != 0) | out_valid_q | inval_pending_q;

integer i;
always @(negedge rst_ni or posedge clk_i) begin
    if (!rst_ni) begin
        for (i = 0; i < NUM_LINES; i = i + 1) begin
            cache_data[i]  <= 32'h0;
            cache_tag[i]   <= {TAG_W{1'b0}};
        end
        cache_valid      <= {NUM_LINES{1'b0}};
        out_data_q       <= 32'h0;
        out_addr_q       <= 32'h0;
        out_err_q        <= 1'b0;
        out_valid_q      <= 1'b0;
        error_mode_q     <= 1'b0;
        next_pc_q        <= 32'h0;
        fetch_addr_q     <= 32'h0;
        have_stream_q    <= 1'b0;
        req_head_q       <= 6'h0;
        req_tail_q       <= 6'h0;
        outstanding_q    <= 6'h0;
        epoch_q          <= 6'h0;
        inval_pending_q  <= 1'b0;
    end else begin
        if (icache_inval_i) begin
            cache_valid     <= {NUM_LINES{1'b0}};
            inval_pending_q <= 1'b1;
        end else begin
            inval_pending_q <= 1'b0;
        end

        if (branch_i) begin
            out_valid_q    <= 1'b0;
            out_err_q      <= 1'b0;
            error_mode_q   <= 1'b0;
            next_pc_q      <= {addr_i[31:2], 2'b00};
            fetch_addr_q   <= {addr_i[31:2], 2'b00};
            have_stream_q  <= 1'b1;
            epoch_q        <= epoch_q + 6'd1;
        end else if (out_fire) begin
            out_valid_q <= 1'b0;
            if (out_err_q) begin
                error_mode_q <= 1'b1;
            end else begin
                next_pc_q <= next_pc_q + 32'd4;
            end
        end

        if (instr_req_o && instr_gnt_i) begin
            req_addr_fifo[req_tail_q[4:0]]  <= instr_addr_o;
            req_epoch_fifo[req_tail_q[4:0]] <= epoch_q;
            req_tail_q                      <= req_tail_q + 6'd1;
            outstanding_q                   <= outstanding_q + 6'd1;
            fetch_addr_q                    <= instr_addr_o + 32'd4;
        end

        if (instr_rvalid_i && !fifo_empty) begin
            req_head_q    <= req_head_q + 6'd1;
            outstanding_q <= outstanding_q - 6'd1;

            if (head_req_epoch == epoch_q) begin
                if (!instr_err_i) begin
                    cache_data[head_req_addr[7:2]]  <= instr_rdata_i;
                    cache_tag[head_req_addr[7:2]]   <= head_req_addr[31:8];
                    cache_valid[head_req_addr[7:2]] <= 1'b1;
                end

                if (!out_valid_q && !error_mode_q && have_stream_q &&
                    ({head_req_addr[31:2], 2'b00} == {next_pc_q[31:2], 2'b00})) begin
                    out_valid_q <= 1'b1;
                    out_addr_q  <= next_pc_q;
                    out_err_q   <= instr_err_i;
                    out_data_q  <= instr_rdata_i;
                end
            end
        end

        if (!branch_i && !out_valid_q && !error_mode_q && have_stream_q) begin
            if (hit_next) begin
                out_valid_q <= 1'b1;
                out_addr_q  <= next_pc_q;
                out_err_q   <= 1'b0;
                out_data_q  <= hit_rdata;
            end
        end
    end
end

endmodule
