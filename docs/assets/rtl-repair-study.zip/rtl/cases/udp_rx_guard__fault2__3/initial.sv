module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

reg [7:0] bytes[0:511];
reg [9:0] n;
reg [9:0] ptr;
reg [2:0] state;
reg status_valid_reg;
reg [3:0] status_error_reg;
reg [17:0] ip_sum;
reg [17:0] udp_sum;
reg [15:0] ip_len;
reg [15:0] udp_len;
reg [3:0] error_code;
reg [9:0] j;
reg [31:0] m_src_ip_reg;
reg [15:0] m_src_port_reg;
reg [15:0] m_dst_port_reg;
reg [15:0] m_payload_len_reg;
reg [7:0] m_data_reg;
reg m_valid_reg;
reg m_last_reg;
reg hdr_ready;
reg parse_ready;
reg [15:0] parsed_length;

function automatic [15:0] word16(input [9:0] offset);
    word16 = {bytes[offset], bytes[offset+1]};
endfunction

function automatic [15:0] fold16(input [17:0] value);
    reg [17:0] v;
    begin
        v = (value & 16'hFFFF) + (value >> 16);
        fold16 = (v & 16'hFFFF) + (v >> 16);
    end
endfunction

assign s_ready = !rst && (state == 3'd0);
assign status_valid = status_valid_reg;
assign status_error = status_error_reg;
assign m_src_ip = m_src_ip_reg;
assign m_src_port = m_src_port_reg;
assign m_dst_port = m_dst_port_reg;
assign m_payload_len = m_payload_len_reg;
assign m_data = m_data_reg;
assign m_valid = m_valid_reg;
assign m_last = m_last_reg;

always @(posedge clk) begin
    if (rst) begin
        state <= 3'd0;
        n <= 10'd0;
        ptr <= 10'd0;
        status_valid_reg <= 1'b0;
        status_error_reg <= 4'd0;
        m_valid_reg <= 1'b0;
        m_last_reg <= 1'b0;
        m_data_reg <= 8'd0;
        m_src_ip_reg <= 32'd0;
        m_src_port_reg <= 16'd0;
        m_dst_port_reg <= 16'd0;
        m_payload_len_reg <= 16'd0;
        hdr_ready <= 1'b0;
        parse_ready <= 1'b0;
        parsed_length <= 16'd0;
        ip_sum <= 18'd0;
        udp_sum <= 18'd0;
        ip_len <= 16'd0;
        udp_len <= 16'd0;
        error_code <= 4'd0;
    end else begin
        status_valid_reg <= 1'b0;
        
        case (state)
            3'd0: begin
                m_valid_reg <= 1'b0;
                m_last_reg <= 1'b0;
                hdr_ready <= 1'b0;
                parse_ready <= 1'b0;
                
                if (s_valid && s_ready) begin
                    if (n < 10'd512) begin
                        bytes[n] <= s_data;
                    end
                    n <= n + 10'd1;
                    if (s_last) begin
                        state <= 3'd1;
                    end
                end
            end
            
            3'd1: begin
                ip_len <= word16(10'd2);
                udp_len <= word16(10'd24);
                
                error_code <= 4'd0;
                
                if (n < 10'd28 || n > 10'd512) begin
                    error_code <= 4'd1;
                end else if (bytes[0] != 8'h45) begin
                    error_code <= 4'd1;
                end else if (bytes[9] != 8'd17) begin
                    error_code <= 4'd1;
                end else if ((bytes[6] & 8'h3F) != 8'h00 || bytes[7] != 8'h00) begin
                    error_code <= 4'd1;
                end else begin
                    ip_sum <= 18'd0;
                    for (j = 10'd0; j < 10'd20; j = j + 10'd2) begin
                        ip_sum <= ip_sum + {2'b00, word16(j)};
                    end
                    
                    if (fold16(ip_sum) != 16'hFFFF) begin
                        error_code <= 4'd3;
                    end else begin
                        error_code <= 4'd0;
                    end
                end
                
                if (error_code == 4'd0 && n >= 10'd28 && n <= 10'd512 && bytes[0] == 8'h45 && bytes[9] == 8'd17 && (bytes[6] & 8'h3F) == 8'h00 && bytes[7] == 8'h00) begin
                    if (word16(10'd2) != n[15:0]) begin
                        error_code <= 4'd2;
                    end else if (word16(10'd24) != word16(10'd2) - 16'd20) begin
                        error_code <= 4'd2;
                    end else begin
                        udp_sum <= 18'd0;
                        udp_sum <= udp_sum + {2'b00, word16(10'd12)};
                        udp_sum <= udp_sum + {2'b00, word16(10'd14)};
                        udp_sum <= udp_sum + {2'b00, word16(10'd16)};
                        udp_sum <= udp_sum + {2'b00, word16(10'd18)};
                        udp_sum <= udp_sum + {2'b00, 8'd17};
                        udp_sum <= udp_sum + {2'b00, 8'd0};
                        udp_sum <= udp_sum + {2'b00, word16(10'd24)};
                        
                        for (j = 10'd20; j < n; j = j + 10'd2) begin
                            if (j + 10'd1 < n) begin
                                udp_sum <= udp_sum + {2'b00, {bytes[j], bytes[j+1]}};
                            end else begin
                                udp_sum <= udp_sum + {2'b00, {bytes[j], 8'h00}};
                            end
                        end
                        
                        if (word16(10'd26) != 16'd0 && fold16(udp_sum) != 16'hFFFF) begin
                            error_code <= 4'd4;
                        end else if ({bytes[16], bytes[17], bytes[18], bytes[19]} != 32'h0A000002) begin
                            error_code <= 4'd5;
                        end else if (word16(10'd22) != 16'd9000) begin
                            error_code <= 4'd5;
                        end else if (word16(10'd24) < 16'd9 || word16(10'd24) > 16'd264) begin
                            error_code <= 4'd2;
                        end else begin
                            error_code <= 4'd0;
                        end
                    end
                end
                
                status_valid_reg <= 1'b1;
                status_error_reg <= error_code;
                
                if (error_code == 4'd0) begin
                    m_src_ip_reg <= {bytes[12], bytes[13], bytes[14], bytes[15]};
                    m_src_port_reg <= word16(10'd20);
                    m_dst_port_reg <= word16(10'd22);
                    m_payload_len_reg <= word16(10'd24) - 16'd8;
                    ptr <= 10'd28;
                    parsed_length <= word16(10'd24);
                    state <= 3'd2;
                end else begin
                    state <= 3'd0;
                    n <= 10'd0;
                end
            end
            
            3'd2: begin
                hdr_ready <= 1'b1;
                if (hdr_ready) begin
                    state <= 3'd3;
                end
            end
            
            3'd3: begin
                hdr_ready <= 1'b0;
                parse_ready <= 1'b1;
                
                if (parse_ready) begin
                    if (ptr < n) begin
                        m_data_reg <= bytes[ptr];
                        m_valid_reg <= 1'b1;
                        if (ptr == n - 10'd1) begin
                            m_last_reg <= 1'b1;
                        end else begin
                            m_last_reg <= 1'b0;
                        end
                        
                        if (m_ready) begin
                            ptr <= ptr + 10'd1;
                            if (ptr == n - 10'd1) begin
                                state <= 3'd4;
                            end
                        end
                    end
                end
            end
            
            3'd4: begin
                parse_ready <= 1'b0;
                if (m_ready) begin
                    m_valid_reg <= 1'b0;
                    m_last_reg <= 1'b0;
                    state <= 3'd0;
                    n <= 10'd0;
                    ptr <= 10'd0;
                end
            end
            
            default: begin
                state <= 3'd0;
                n <= 10'd0;
                ptr <= 10'd0;
            end
        endcase
    end
end

endmodule
