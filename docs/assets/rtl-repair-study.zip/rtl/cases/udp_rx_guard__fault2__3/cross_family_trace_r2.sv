`timescale 1ns/1ps
module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error
);

localparam ST_IDLE   = 2'd0;
localparam ST_RECV   = 2'd1;
localparam ST_STATUS = 2'd2;
localparam ST_OUT    = 2'd3;

reg [1:0] state_reg = ST_IDLE;

reg [7:0] frame_mem[0:511];
reg [9:0] frame_len_reg = 10'd0;
reg oversize_reg = 1'b0;

reg [3:0] status_error_reg = 4'd0;
reg status_valid_reg = 1'b0;

reg [31:0] out_src_ip_reg = 32'd0;
reg [15:0] out_src_port_reg = 16'd0;
reg [15:0] out_dst_port_reg = 16'd0;
reg [15:0] out_payload_len_reg = 16'd0;
reg [9:0] out_ptr_reg = 10'd0;
reg [9:0] out_start_reg = 10'd0;
reg [9:0] out_end_reg = 10'd0;
reg out_active_reg = 1'b0;

reg [7:0] m_data_reg = 8'd0;
reg m_valid_reg = 1'b0;
reg m_last_reg = 1'b0;

integer k;
reg [17:0] sum_reg;
reg [15:0] ip_total_len;
reg [15:0] udp_len;
reg [15:0] ip_csum_fold;
reg [15:0] udp_csum_fold;
reg [15:0] payload_len_calc;
reg [3:0] err_next;
reg [31:0] dst_ip_calc;
reg [31:0] src_ip_calc;
reg [15:0] src_port_calc;
reg [15:0] dst_port_calc;
reg [15:0] word_tmp;

function automatic [15:0] fold18;
    input [17:0] x;
    reg [16:0] t;
    begin
        t = x[15:0] + x[17:16];
        t = t[15:0] + t[16];
        fold18 = t[15:0];
    end
endfunction

assign s_ready = (state_reg == ST_IDLE || state_reg == ST_RECV) && !out_active_reg;
assign m_data = m_data_reg;
assign m_valid = m_valid_reg;
assign m_last = m_last_reg;
assign m_src_ip = out_src_ip_reg;
assign m_src_port = out_src_port_reg;
assign m_dst_port = out_dst_port_reg;
assign m_payload_len = out_payload_len_reg;
assign status_valid = status_valid_reg;
assign status_error = status_error_reg;

always @(posedge clk) begin
    if (rst) begin
        state_reg <= ST_IDLE;
        frame_len_reg <= 10'd0;
        oversize_reg <= 1'b0;
        status_valid_reg <= 1'b0;
        status_error_reg <= 4'd0;
        out_src_ip_reg <= 32'd0;
        out_src_port_reg <= 16'd0;
        out_dst_port_reg <= 16'd0;
        out_payload_len_reg <= 16'd0;
        out_ptr_reg <= 10'd0;
        out_start_reg <= 10'd0;
        out_end_reg <= 10'd0;
        out_active_reg <= 1'b0;
        m_data_reg <= 8'd0;
        m_valid_reg <= 1'b0;
        m_last_reg <= 1'b0;
    end else begin
        status_valid_reg <= 1'b0;

        if (m_valid_reg && m_ready) begin
            if (out_ptr_reg == out_end_reg) begin
                m_valid_reg <= 1'b0;
                m_last_reg <= 1'b0;
                out_active_reg <= 1'b0;
                out_ptr_reg <= 10'd0;
                out_start_reg <= 10'd0;
                out_end_reg <= 10'd0;
                state_reg <= ST_IDLE;
                frame_len_reg <= 10'd0;
                oversize_reg <= 1'b0;
            end else begin
                out_ptr_reg <= out_ptr_reg + 10'd1;
                m_data_reg <= frame_mem[out_ptr_reg + 10'd1];
                m_last_reg <= ((out_ptr_reg + 10'd1) == out_end_reg);
            end
        end

        case (state_reg)
            ST_IDLE: begin
                if (!out_active_reg && s_valid) begin
                    frame_len_reg <= 10'd1;
                    oversize_reg <= 1'b0;
                    frame_mem[0] <= s_data;
                    if (s_last) begin
                        state_reg <= ST_STATUS;
                    end else begin
                        state_reg <= ST_RECV;
                    end
                end
            end

            ST_RECV: begin
                if (s_valid) begin
                    if (frame_len_reg < 10'd512) begin
                        frame_mem[frame_len_reg] <= s_data;
                    end else begin
                        oversize_reg <= 1'b1;
                    end
                    frame_len_reg <= frame_len_reg + 10'd1;
                    if (s_last) begin
                        state_reg <= ST_STATUS;
                    end
                end
            end

            ST_STATUS: begin
                err_next = 4'd0;

                ip_total_len = {frame_mem[2], frame_mem[3]};
                udp_len = {frame_mem[24], frame_mem[25]};
                src_ip_calc = {frame_mem[12], frame_mem[13], frame_mem[14], frame_mem[15]};
                dst_ip_calc = {frame_mem[16], frame_mem[17], frame_mem[18], frame_mem[19]};
                src_port_calc = {frame_mem[20], frame_mem[21]};
                dst_port_calc = {frame_mem[22], frame_mem[23]};

                if (frame_len_reg < 10'd28 || oversize_reg || frame_len_reg > 10'd512 ||
                    frame_mem[0][7:4] != 4'd4 ||
                    frame_mem[0][3:0] != 4'd5 ||
                    frame_mem[9] != 8'd17 ||
                    frame_mem[6][5] != 1'b0 ||
                    frame_mem[6][4:0] != 5'd0 ||
                    frame_mem[7] != 8'd0) begin
                    err_next = 4'd1;
                end else begin
                    payload_len_calc = udp_len - 16'd8;
                    if (ip_total_len != frame_len_reg ||
                        udp_len != (ip_total_len - 16'd20) ||
                        payload_len_calc < 16'd1 ||
                        payload_len_calc > 16'd256) begin
                        err_next = 4'd2;
                    end else begin
                        sum_reg = 18'd0;
                        for (k = 0; k < 20; k = k + 2) begin
                            word_tmp = {frame_mem[k], frame_mem[k+1]};
                            sum_reg = sum_reg + word_tmp;
                            sum_reg = {2'b00, fold18(sum_reg)};
                        end
                        ip_csum_fold = fold18(sum_reg);
                        if (ip_csum_fold != 16'hFFFF) begin
                            err_next = 4'd3;
                        end else begin
                            if ({frame_mem[26], frame_mem[27]} != 16'h0000) begin
                                sum_reg = 18'd0;
                                sum_reg = sum_reg + {frame_mem[12], frame_mem[13]};
                                sum_reg = {2'b00, fold18(sum_reg)};
                                sum_reg = sum_reg + {frame_mem[14], frame_mem[15]};
                                sum_reg = {2'b00, fold18(sum_reg)};
                                sum_reg = sum_reg + {frame_mem[16], frame_mem[17]};
                                sum_reg = {2'b00, fold18(sum_reg)};
                                sum_reg = sum_reg + {frame_mem[18], frame_mem[19]};
                                sum_reg = {2'b00, fold18(sum_reg)};
                                sum_reg = sum_reg + 16'h0011;
                                sum_reg = {2'b00, fold18(sum_reg)};
                                sum_reg = sum_reg + udp_len;
                                sum_reg = {2'b00, fold18(sum_reg)};

                                for (k = 20; k < frame_len_reg; k = k + 2) begin
                                    if (k+1 < frame_len_reg) begin
                                        word_tmp = {frame_mem[k], frame_mem[k+1]};
                                    end else begin
                                        word_tmp = {frame_mem[k], 8'h00};
                                    end
                                    sum_reg = sum_reg + word_tmp;
                                    sum_reg = {2'b00, fold18(sum_reg)};
                                end

                                udp_csum_fold = fold18(sum_reg);
                                if (udp_csum_fold != 16'hFFFF) begin
                                    err_next = 4'd4;
                                end else if (dst_ip_calc != 32'h0A000002 || dst_port_calc != 16'd9000) begin
                                    err_next = 4'd5;
                                end
                            end else begin
                                if (dst_ip_calc != 32'h0A000002 || dst_port_calc != 16'd9000) begin
                                    err_next = 4'd5;
                                end
                            end
                        end
                    end
                end

                status_valid_reg <= 1'b1;
                status_error_reg <= err_next;

                if (err_next == 4'd0) begin
                    out_src_ip_reg <= src_ip_calc;
                    out_src_port_reg <= src_port_calc;
                    out_dst_port_reg <= dst_port_calc;
                    out_payload_len_reg <= payload_len_calc;
                    out_start_reg <= 10'd28;
                    out_end_reg <= 10'd27 + payload_len_calc[9:0];
                    out_ptr_reg <= 10'd28;
                    out_active_reg <= 1'b1;
                    m_data_reg <= frame_mem[28];
                    m_valid_reg <= 1'b1;
                    m_last_reg <= (payload_len_calc == 16'd1);
                    state_reg <= ST_OUT;
                end else begin
                    frame_len_reg <= 10'd0;
                    oversize_reg <= 1'b0;
                    state_reg <= ST_IDLE;
                end
            end

            ST_OUT: begin
            end

            default: begin
                state_reg <= ST_IDLE;
            end
        endcase
    end
end

endmodule
