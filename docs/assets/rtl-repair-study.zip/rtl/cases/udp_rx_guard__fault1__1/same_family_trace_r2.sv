`timescale 1ns/1ps
`default_nettype none

module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

reg [7:0] buf [0:511];
reg [9:0] byte_cnt;
reg last_seen;
reg oversize;

reg [2:0] state;
localparam S_IDLE   = 3'd0;
localparam S_RECV   = 3'd1;
localparam S_CHECK  = 3'd2;
localparam S_STATUS = 3'd3;
localparam S_OUT    = 3'd4;

reg [3:0] err_code;
reg status_valid_r;
reg [3:0] status_error_r;

reg [9:0] out_ptr;
reg [8:0] pay_len;

assign s_ready = (state == S_IDLE || state == S_RECV) && !rst;
assign status_valid = status_valid_r;
assign status_error = status_error_r;

assign m_valid = (state == S_OUT) && (pay_len > 0);
assign m_data  = buf[out_ptr[8:0]];
assign m_last  = (out_ptr == {1'b0, 9'd27} + {1'b0, pay_len} - 10'd1);
assign m_src_ip       = {buf[12], buf[13], buf[14], buf[15]};
assign m_src_port     = {buf[20], buf[21]};
assign m_dst_port     = {buf[22], buf[23]};
assign m_payload_len  = {7'b0, pay_len};

integer j;
reg [17:0] ip_sum_acc;
reg [17:0] udp_sum_acc;
reg [17:0] tmp;
reg [15:0] folded_ip;
reg [15:0] folded_udp;
reg [15:0] ip_total_length;
reg [15:0] udp_length;
reg [15:0] udp_cksum;
reg [31:0] dst_ip;
reg [15:0] udp_dst_port;
reg [15:0] frag_off;
reg [7:0] b_even;
reg [7:0] b_odd;

always @(posedge clk) begin
    if (rst) begin
        state <= S_IDLE;
        byte_cnt <= 10'd0;
        last_seen <= 1'b0;
        oversize <= 1'b0;
        status_valid_r <= 1'b0;
        status_error_r <= 4'd0;
        out_ptr <= 10'd0;
        pay_len <= 9'd0;
        err_code <= 4'd0;
    end else begin
        status_valid_r <= 1'b0;

        case (state)
            S_IDLE: begin
                byte_cnt <= 10'd0;
                last_seen <= 1'b0;
                oversize <= 1'b0;
                if (s_valid && s_ready) begin
                    buf[0] <= s_data;
                    byte_cnt <= 10'd1;
                    if (s_last) begin
                        last_seen <= 1'b1;
                        state <= S_CHECK;
                    end else begin
                        state <= S_RECV;
                    end
                end
            end

            S_RECV: begin
                if (s_valid && s_ready) begin
                    if (byte_cnt < 10'd512)
                        buf[byte_cnt[8:0]] <= s_data;
                    else
                        oversize <= 1'b1;
                    byte_cnt <= byte_cnt + 10'd1;
                    if (s_last) begin
                        last_seen <= 1'b1;
                        state <= S_CHECK;
                    end
                end
            end

            S_CHECK: begin
                ip_total_length = {buf[2], buf[3]};
                udp_length      = {buf[24], buf[25]};
                udp_cksum       = {buf[26], buf[27]};
                dst_ip          = {buf[16], buf[17], buf[18], buf[19]};
                udp_dst_port    = {buf[22], buf[23]};
                frag_off        = {buf[6][4:0], buf[7]};

                err_code <= 4'd0;
                if (oversize || byte_cnt > 10'd512) begin
                    err_code <= 4'd1;
                end else if (byte_cnt < 10'd28) begin
                    err_code <= 4'd1;
                end else if (buf[0][7:4] != 4'd4) begin
                    err_code <= 4'd1;
                end else if (buf[0][3:0] != 4'd5) begin
                    err_code <= 4'd1;
                end else if (buf[9] != 8'd17) begin
                    err_code <= 4'd1;
                end else if (buf[6][5]) begin
                    err_code <= 4'd1;
                end else if (frag_off != 13'd0) begin
                    err_code <= 4'd1;
                end else begin
                    err_code <= 4'd0;
                end

                if (err_code == 4'd0 && !oversize && byte_cnt >= 10'd28 && byte_cnt <= 10'd512) begin
                    if (ip_total_length != byte_cnt)
                        err_code <= 4'd2;
                    else if (udp_length != ip_total_length - 16'd20)
                        err_code <= 4'd2;
                    else if (udp_length < 16'd9 || udp_length > 16'd264)
                        err_code <= 4'd2;
                end

                if (err_code == 4'd0) begin
                    ip_sum_acc = 18'd0;
                    for (j = 0; j < 20; j = j + 2) begin
                        ip_sum_acc = ip_sum_acc + {8'd0, buf[j], buf[j+1]};
                    end
                    tmp = ip_sum_acc;
                    tmp = (tmp & 18'hFFFF) + (tmp >> 16);
                    folded_ip = tmp[15:0] + tmp[17:16];
                    if (folded_ip != 16'hFFFF)
                        err_code <= 4'd3;
                end

                if (err_code == 4'd0 && udp_cksum != 16'd0) begin
                    udp_sum_acc = 18'd0;
                    for (j = 12; j < 20; j = j + 2) begin
                        udp_sum_acc = udp_sum_acc + {8'd0, buf[j], buf[j+1]};
                    end
                    udp_sum_acc = udp_sum_acc + 18'd17 + {2'd0, udp_length};
                    for (j = 20; j < 512; j = j + 2) begin
                        if (j < byte_cnt) begin
                            b_even = buf[j];
                            if (j + 1 < byte_cnt)
                                b_odd = buf[j+1];
                            else
                                b_odd = 8'd0;
                            udp_sum_acc = udp_sum_acc + {8'd0, b_even, b_odd};
                        end
                    end
                    tmp = udp_sum_acc;
                    tmp = (tmp & 18'hFFFF) + (tmp >> 16);
                    folded_udp = tmp[15:0] + tmp[17:16];
                    if (folded_udp != 16'hFFFF)
                        err_code <= 4'd4;
                end

                if (err_code == 4'd0) begin
                    if (dst_ip != 32'h0A000002 || udp_dst_port != 16'd9000)
                        err_code <= 4'd5;
                end

                if (err_code == 4'd0) begin
                    pay_len <= udp_length[8:0] - 9'd8;
                end else begin
                    pay_len <= 9'd0;
                end

                state <= S_STATUS;
            end

            S_STATUS: begin
                status_valid_r <= 1'b1;
                status_error_r <= err_code;
                if (err_code == 4'd0) begin
                    out_ptr <= 10'd28;
                    state <= S_OUT;
                end else begin
                    byte_cnt <= 10'd0;
                    last_seen <= 1'b0;
                    oversize <= 1'b0;
                    state <= S_IDLE;
                end
            end

            S_OUT: begin
                if (pay_len == 9'd0) begin
                    byte_cnt <= 10'd0;
                    last_seen <= 1'b0;
                    oversize <= 1'b0;
                    state <= S_IDLE;
                end else if (m_valid && m_ready) begin
                    if (m_last) begin
                        byte_cnt <= 10'd0;
                        last_seen <= 1'b0;
                        oversize <= 1'b0;
                        state <= S_IDLE;
                    end else begin
                        out_ptr <= out_ptr + 10'd1;
                    end
                end
            end

            default: state <= S_IDLE;
        endcase
    end
end

endmodule
