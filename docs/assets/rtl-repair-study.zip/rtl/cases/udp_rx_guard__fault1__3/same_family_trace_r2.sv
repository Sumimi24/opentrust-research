module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

localparam IDLE = 3'd0;
localparam RECV = 3'd1;
localparam CHECK = 3'd2;
localparam OUTPUT = 3'd3;
localparam DRAIN = 3'd4;

reg [2:0] state;
reg [9:0] n;
reg [9:0] ptr;
reg [7:0] bytes[0:511];
reg [3:0] error_code;
reg status_valid_reg;
reg [3:0] status_error_reg;
reg m_valid_reg;
reg m_last_reg;
reg [7:0] m_data_reg;
reg [31:0] m_src_ip_reg;
reg [15:0] m_src_port_reg;
reg [15:0] m_dst_port_reg;
reg [15:0] m_payload_len_reg;
reg [15:0] payload_remaining;
reg [11:0] timeout_cnt;

wire [15:0] ip_total_len = {bytes[2], bytes[3]};
wire [15:0] udp_len = {bytes[24], bytes[25]};
wire [15:0] udp_checksum = {bytes[26], bytes[27]};
wire [31:0] dst_ip = {bytes[16], bytes[17], bytes[18], bytes[19]};
wire [15:0] dst_port = {bytes[22], bytes[23]};
wire [15:0] src_port = {bytes[20], bytes[21]};
wire [31:0] src_ip = {bytes[12], bytes[13], bytes[14], bytes[15]};
wire [15:0] ip_id = {bytes[4], bytes[5]};
wire [15:0] ip_frag = {bytes[6], bytes[7]};
wire [7:0] ip_ttl_proto = bytes[9];
wire [7:0] ip_ihl_ver = bytes[0];

function automatic [15:0] fold16(input [16:0] x);
    fold16 = x[15:0] + {15'd0, x[16]};
endfunction

function automatic [15:0] fold17(input [17:0] x);
    reg [16:0] t;
    t = x[15:0] + x[17:16];
    fold17 = t[15:0] + {15'd0, t[16]};
endfunction

assign s_ready = (state == IDLE) || (state == RECV);
assign status_valid = status_valid_reg;
assign status_error = status_error_reg;
assign m_data = m_data_reg;
assign m_valid = m_valid_reg;
assign m_last = m_last_reg;
assign m_src_ip = m_src_ip_reg;
assign m_src_port = m_src_port_reg;
assign m_dst_port = m_dst_port_reg;
assign m_payload_len = m_payload_len_reg;

integer i;

always @(posedge clk) begin
    if (rst) begin
        state <= IDLE;
        n <= 10'd0;
        ptr <= 10'd0;
        error_code <= 4'd0;
        status_valid_reg <= 1'b0;
        status_error_reg <= 4'd0;
        m_valid_reg <= 1'b0;
        m_last_reg <= 1'b0;
        m_data_reg <= 8'd0;
        m_src_ip_reg <= 32'd0;
        m_src_port_reg <= 16'd0;
        m_dst_port_reg <= 16'd0;
        m_payload_len_reg <= 16'd0;
        payload_remaining <= 16'd0;
        timeout_cnt <= 12'd0;
        for (i = 0; i < 512; i = i + 1) begin
            bytes[i] <= 8'd0;
        end
    end else begin
        status_valid_reg <= 1'b0;
        
        case (state)
            IDLE: begin
                m_valid_reg <= 1'b0;
                m_last_reg <= 1'b0;
                n <= 10'd0;
                error_code <= 4'd0;
                if (s_valid && s_ready) begin
                    bytes[0] <= s_data;
                    n <= 10'd1;
                    if (s_last) begin
                        state <= CHECK;
                    end else begin
                        state <= RECV;
                    end
                end
            end
            
            RECV: begin
                if (s_valid && s_ready) begin
                    if (n < 10'd512) begin
                        bytes[n] <= s_data;
                    end
                    n <= n + 10'd1;
                    if (s_last) begin
                        state <= CHECK;
                    end else if (n == 10'd511) begin
                        state <= DRAIN;
                    end
                end
            end
            
            DRAIN: begin
                if (s_valid && s_ready) begin
                    n <= n + 10'd1;
                    if (s_last) begin
                        error_code <= 4'd1;
                        status_error_reg <= 4'd1;
                        status_valid_reg <= 1'b1;
                        state <= IDLE;
                    end
                end
            end
            
            CHECK: begin
                error_code <= 4'd0;
                
                if (n < 10'd28) begin
                    error_code <= 4'd1;
                end else if (n > 10'd512) begin
                    error_code <= 4'd1;
                end else if (ip_ihl_ver != 8'h45) begin
                    error_code <= 4'd1;
                end else if (ip_ttl_proto != 8'd17) begin
                    error_code <= 4'd1;
                end else if ((ip_frag[15:13] != 3'b000) || (ip_frag[12:0] != 13'd0)) begin
                    error_code <= 4'd1;
                end else if (ip_total_len != n[15:0]) begin
                    error_code <= 4'd2;
                end else if (udp_len != ip_total_len - 16'd20) begin
                    error_code <= 4'd2;
                end else if (udp_len < 16'd9 || udp_len > 16'd264) begin
                    error_code <= 4'd2;
                end else begin
                    reg [16:0] ip_sum;
                    ip_sum = 17'd0;
                    for (i = 0; i < 20; i = i + 2) begin
                        ip_sum = ip_sum + {1'b0, bytes[i], bytes[i+1]};
                    end
                    ip_sum = fold16(ip_sum);
                    if (ip_sum != 16'hFFFF) begin
                        error_code <= 4'd3;
                    end else begin
                        reg [17:0] udp_sum;
                        udp_sum = 18'd0;
                        udp_sum = udp_sum + {2'b00, src_ip[31:16]} + {2'b00, src_ip[15:0]};
                        udp_sum = udp_sum + {2'b00, dst_ip[31:16]} + {2'b00, dst_ip[15:0]};
                        udp_sum = udp_sum + {2'b00, 8'd17, 8'd0};
                        udp_sum = udp_sum + {2'b00, udp_len};
                        for (i = 20; i < n; i = i + 2) begin
                            if (i + 1 < n) begin
                                udp_sum = udp_sum + {2'b00, bytes[i], bytes[i+1]};
                            end else begin
                                udp_sum = udp_sum + {2'b00, bytes[i], 8'h00};
                            end
                        end
                        udp_sum = fold17(udp_sum);
                        if (udp_checksum != 16'd0 && udp_sum != 18'h0FFFF) begin
                            error_code <= 4'd4;
                        end else if (dst_ip != 32'h0A000002) begin
                            error_code <= 4'd5;
                        end else if (dst_port != 16'd9000) begin
                            error_code <= 4'd5;
                        end
                    end
                end
                
                status_error_reg <= error_code;
                status_valid_reg <= 1'b1;
                timeout_cnt <= 12'd0;
                
                if (error_code == 4'd0) begin
                    m_src_ip_reg <= src_ip;
                    m_src_port_reg <= src_port;
                    m_dst_port_reg <= dst_port;
                    m_payload_len_reg <= udp_len - 16'd8;
                    payload_remaining <= udp_len - 16'd8;
                    ptr <= 10'd28;
                    m_data_reg <= bytes[28];
                    m_valid_reg <= 1'b1;
                    m_last_reg <= (udp_len == 16'd9);
                    state <= OUTPUT;
                end else begin
                    state <= IDLE;
                end
            end
            
            OUTPUT: begin
                timeout_cnt <= timeout_cnt + 12'd1;
                if (m_ready) begin
                    payload_remaining <= payload_remaining - 16'd1;
                    ptr <= ptr + 10'd1;
                    if (payload_remaining == 16'd1) begin
                        m_valid_reg <= 1'b0;
                        m_last_reg <= 1'b0;
                        state <= IDLE;
                    end else begin
                        m_data_reg <= bytes[ptr + 10'd1];
                        m_last_reg <= (payload_remaining == 16'd2);
                    end
                end
            end
            
            default: state <= IDLE;
        endcase
    end
end

endmodule
