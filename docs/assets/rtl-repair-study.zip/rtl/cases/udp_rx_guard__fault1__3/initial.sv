module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

reg [7:0] bytes[0:511];
reg [9:0] n;
reg [9:0] ptr;
reg [2:0] state;
reg status_valid_reg;
reg [3:0] status_error_reg;
reg [16:0] ip_sum;
reg [17:0] udp_sum;
reg [15:0] ip_len;
reg [15:0] udp_len;
reg [3:0] error_code;
reg [9:0] j;
reg m_valid_reg;
reg m_last_reg;
reg [7:0] m_data_reg;
reg [31:0] m_src_ip_reg;
reg [15:0] m_src_port_reg;
reg [15:0] m_dst_port_reg;
reg [15:0] m_payload_len_reg;
reg [9:0] payload_cnt;
reg [11:0] status_timer;
reg [15:0] udp_checksum_reg;

function automatic [15:0] word16(input [9:0] offset);
    word16 = {bytes[offset], bytes[offset+1]};
endfunction

function automatic [16:0] fold17(input [17:0] value);
    reg [16:0] v;
    begin
        v = value[15:0] + value[17:16];
        fold17 = v[15:0] + v[16];
    end
endfunction

function automatic [15:0] fold16(input [16:0] value);
    fold16 = value[15:0] + value[16];
endfunction

localparam IDLE = 3'd0;
localparam CHECK = 3'd1;
localparam OUTPUT_HDR = 3'd2;
localparam OUTPUT_DATA = 3'd3;
localparam WAIT_LAST = 3'd4;
localparam DRAIN_OVERSIZE = 3'd5;

wire [15:0] ip_total_len = word16(2);
wire [15:0] udp_total_len = word16(24);
wire [15:0] udp_checksum = word16(26);
wire [31:0] dst_ip = {bytes[16], bytes[17], bytes[18], bytes[19]};
wire [15:0] dst_port = word16(22);

assign s_ready = !rst && (state == IDLE || state == DRAIN_OVERSIZE);
assign status_valid = status_valid_reg;
assign status_error = status_error_reg;
assign m_data = m_data_reg;
assign m_valid = m_valid_reg;
assign m_last = m_last_reg;
assign m_src_ip = m_src_ip_reg;
assign m_src_port = m_src_port_reg;
assign m_dst_port = m_dst_port_reg;
assign m_payload_len = m_payload_len_reg;

always @(posedge clk) begin
    if (rst) begin
        state <= IDLE;
        n <= 10'd0;
        ptr <= 10'd20;
        status_valid_reg <= 1'b0;
        status_error_reg <= 4'd0;
        m_valid_reg <= 1'b0;
        m_last_reg <= 1'b0;
        m_data_reg <= 8'd0;
        m_src_ip_reg <= 32'd0;
        m_src_port_reg <= 16'd0;
        m_dst_port_reg <= 16'd0;
        m_payload_len_reg <= 16'd0;
        payload_cnt <= 10'd0;
        status_timer <= 12'd0;
        ip_sum <= 17'd0;
        udp_sum <= 18'd0;
        error_code <= 4'd0;
        udp_checksum_reg <= 16'd0;
    end else begin
        status_valid_reg <= 1'b0;
        
        case (state)
            IDLE: begin
                m_valid_reg <= 1'b0;
                m_last_reg <= 1'b0;
                if (s_valid && s_ready) begin
                    if (n < 10'd512) begin
                        bytes[n] <= s_data;
                    end
                    n <= n + 10'd1;
                    if (s_last) begin
                        if (n >= 10'd511) begin
                            state <= CHECK;
                        end else begin
                            state <= CHECK;
                        end
                    end else if (n == 10'd511) begin
                        state <= DRAIN_OVERSIZE;
                    end
                end
            end
            
            DRAIN_OVERSIZE: begin
                if (s_valid && s_ready) begin
                    n <= n + 10'd1;
                    if (s_last) begin
                        error_code <= 4'd1;
                        status_error_reg <= 4'd1;
                        status_valid_reg <= 1'b1;
                        n <= 10'd0;
                        state <= IDLE;
                    end
                end
            end
            
            CHECK: begin
                ip_len <= ip_total_len;
                udp_len <= udp_total_len;
                udp_checksum_reg <= udp_checksum;
                
                error_code <= 4'd0;
                
                if (n < 10'd28 || n > 10'd512 || bytes[0] != 8'h45 || bytes[9] != 8'd17 || 
                    (bytes[6] & 8'h3F) != 8'h00 || bytes[7] != 8'h00) begin
                    error_code <= 4'd1;
                end else if (ip_total_len != n[15:0] || udp_total_len != ip_total_len - 16'd20) begin
                    error_code <= 4'd2;
                end else begin
                    if (udp_total_len < 16'd9 || udp_total_len > 16'd264) begin
                        error_code <= 4'd2;
                    end
                end
                
                if (error_code == 4'd0) begin
                    ip_sum <= 17'd0;
                    for (j = 10'd0; j < 10'd20; j = j + 10'd2) begin
                        ip_sum <= ip_sum + {1'b0, word16(j)};
                    end
                end
                
                state <= 3'd6;
            end
            
            3'd6: begin
                if (error_code == 4'd0) begin
                    if (fold16(ip_sum) != 16'hFFFF) begin
                        error_code <= 4'd3;
                    end else begin
                        udp_sum <= 18'd0;
                        udp_sum[17:0] <= {2'b00, bytes[12], bytes[13]} + {2'b00, bytes[14], bytes[15]} +
                                         {2'b00, bytes[16], bytes[17]} + {2'b00, bytes[18], bytes[19]} +
                                         {10'd0, 8'd17, 8'd0} + {2'b00, udp_len};
                    end
                end
                state <= 3'd7;
            end
            
            3'd7: begin
                if (error_code == 4'd0) begin
                    for (j = 10'd20; j < n; j = j + 10'd2) begin
                        if (j + 10'd1 < n) begin
                            udp_sum <= udp_sum + {2'b00, bytes[j], bytes[j+1]};
                        end else begin
                            udp_sum <= udp_sum + {2'b00, bytes[j], 8'h00};
                        end
                    end
                end
                state <= 3'd5;
            end
            
            3'd5: begin
                if (error_code == 4'd0) begin
                    if (udp_checksum_reg != 16'd0 && fold17(udp_sum) != 16'hFFFF) begin
                        error_code <= 4'd4;
                    end else if (dst_ip != 32'h0A000002 || dst_port != 16'd9000) begin
                        error_code <= 4'd5;
                    end
                end
                
                status_error_reg <= error_code;
                status_valid_reg <= 1'b1;
                status_timer <= 12'd0;
                
                if (error_code == 4'd0) begin
                    m_src_ip_reg <= {bytes[12], bytes[13], bytes[14], bytes[15]};
                    m_src_port_reg <= word16(20);
                    m_dst_port_reg <= dst_port;
                    m_payload_len_reg <= udp_len - 16'd8;
                    ptr <= 10'd28;
                    payload_cnt <= 10'd0;
                    state <= OUTPUT_HDR;
                end else begin
                    n <= 10'd0;
                    state <= IDLE;
                end
            end
            
            OUTPUT_HDR: begin
                status_timer <= status_timer + 12'd1;
                m_valid_reg <= 1'b1;
                m_data_reg <= bytes[ptr];
                m_last_reg <= (payload_cnt == m_payload_len_reg - 16'd1);
                
                if (m_ready) begin
                    ptr <= ptr + 10'd1;
                    payload_cnt <= payload_cnt + 10'd1;
                    if (payload_cnt == m_payload_len_reg - 16'd1) begin
                        m_valid_reg <= 1'b0;
                        n <= 10'd0;
                        state <= IDLE;
                    end
                end
            end
            
            default: state <= IDLE;
        endcase
        
        if (status_timer == 12'd1023) begin
            status_timer <= 12'd0;
        end
    end
end

endmodule
