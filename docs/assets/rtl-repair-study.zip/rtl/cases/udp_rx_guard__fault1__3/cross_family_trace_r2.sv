`timescale 1ns/1ps
module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error
);

localparam [1:0]
    ST_IDLE   = 2'd0,
    ST_RECV   = 2'd1,
    ST_DRAIN  = 2'd2,
    ST_OUTPUT = 2'd3;

reg [1:0] state_reg;

reg [7:0] frame_mem [0:511];

reg [9:0] recv_count_reg;
reg oversize_reg;

reg out_valid_reg;
reg [7:0] out_data_reg;
reg out_last_reg;
reg [31:0] out_src_ip_reg;
reg [15:0] out_src_port_reg;
reg [15:0] out_dst_port_reg;
reg [15:0] out_payload_len_reg;
reg [9:0] out_index_reg;

reg status_valid_reg;
reg [3:0] status_error_reg;

assign s_ready = (state_reg == ST_IDLE) || (state_reg == ST_RECV) || (state_reg == ST_DRAIN);

assign m_data = out_data_reg;
assign m_valid = out_valid_reg;
assign m_last = out_last_reg;
assign m_src_ip = out_src_ip_reg;
assign m_src_port = out_src_port_reg;
assign m_dst_port = out_dst_port_reg;
assign m_payload_len = out_payload_len_reg;

assign status_valid = status_valid_reg;
assign status_error = status_error_reg;

integer i;
integer sum_int;
integer word_int;
integer udp_bytes_int;
integer payload_len_int;
integer actual_len_int;
integer ip_total_len_int;
integer udp_len_int;
integer ihl_words_int;
integer frag_field_int;
integer udp_sum_int;
integer idx_int;
integer temp_int;

reg [3:0] calc_error;
reg [31:0] calc_src_ip;
reg [31:0] calc_dst_ip;
reg [15:0] calc_src_port;
reg [15:0] calc_dst_port;
reg [15:0] calc_payload_len;

always @(posedge clk) begin
    if (rst) begin
        state_reg <= ST_IDLE;
        recv_count_reg <= 10'd0;
        oversize_reg <= 1'b0;

        out_valid_reg <= 1'b0;
        out_data_reg <= 8'd0;
        out_last_reg <= 1'b0;
        out_src_ip_reg <= 32'd0;
        out_src_port_reg <= 16'd0;
        out_dst_port_reg <= 16'd0;
        out_payload_len_reg <= 16'd0;
        out_index_reg <= 10'd0;

        status_valid_reg <= 1'b0;
        status_error_reg <= 4'd0;
    end else begin
        status_valid_reg <= 1'b0;

        case (state_reg)
            ST_IDLE: begin
                out_valid_reg <= 1'b0;
                out_last_reg <= 1'b0;
                out_index_reg <= 10'd0;
                recv_count_reg <= 10'd0;
                oversize_reg <= 1'b0;

                if (s_valid) begin
                    if (10'd0 < 10'd512) begin
                        frame_mem[0] <= s_data;
                    end
                    recv_count_reg <= 10'd1;
                    if (s_last) begin
                        actual_len_int = 1;

                        calc_error = 4'd0;
                        calc_src_ip = 32'd0;
                        calc_dst_ip = 32'd0;
                        calc_src_port = 16'd0;
                        calc_dst_port = 16'd0;
                        calc_payload_len = 16'd0;

                        if (actual_len_int < 28 || actual_len_int > 512) begin
                            calc_error = 4'd1;
                        end

                        if (calc_error == 4'd0) begin
                            if (frame_mem[0][7:4] != 4'd4) begin
                                calc_error = 4'd1;
                            end
                            if (frame_mem[0][3:0] != 4'd5) begin
                                calc_error = 4'd1;
                            end
                            if (frame_mem[9] != 8'd17) begin
                                calc_error = 4'd1;
                            end
                            frag_field_int = {frame_mem[6], frame_mem[7]};
                            if ((frag_field_int & 16'h2000) != 0) begin
                                calc_error = 4'd1;
                            end
                            if ((frag_field_int & 16'h1FFF) != 0) begin
                                calc_error = 4'd1;
                            end
                        end

                        if (calc_error == 4'd0) begin
                            ip_total_len_int = {frame_mem[2], frame_mem[3]};
                            udp_len_int = {frame_mem[24], frame_mem[25]};
                            if (ip_total_len_int != actual_len_int) begin
                                calc_error = 4'd2;
                            end
                            if (udp_len_int != (ip_total_len_int - 20)) begin
                                calc_error = 4'd2;
                            end
                            payload_len_int = udp_len_int - 8;
                            if (payload_len_int < 1 || payload_len_int > 256) begin
                                calc_error = 4'd2;
                            end
                        end

                        if (calc_error == 4'd0) begin
                            sum_int = 0;
                            for (i = 0; i < 20; i = i + 2) begin
                                word_int = {frame_mem[i], frame_mem[i+1]};
                                sum_int = sum_int + word_int;
                                while (sum_int > 16'hFFFF) begin
                                    sum_int = (sum_int & 16'hFFFF) + (sum_int >> 16);
                                end
                            end
                            while (sum_int > 16'hFFFF) begin
                                sum_int = (sum_int & 16'hFFFF) + (sum_int >> 16);
                            end
                            if ((sum_int & 16'hFFFF) != 16'hFFFF) begin
                                calc_error = 4'd3;
                            end
                        end

                        if (calc_error == 4'd0) begin
                            calc_src_ip = {frame_mem[12], frame_mem[13], frame_mem[14], frame_mem[15]};
                            calc_dst_ip = {frame_mem[16], frame_mem[17], frame_mem[18], frame_mem[19]};
                            calc_src_port = {frame_mem[20], frame_mem[21]};
                            calc_dst_port = {frame_mem[22], frame_mem[23]};
                            calc_payload_len = udp_len_int - 8;

                            if ({frame_mem[26], frame_mem[27]} != 16'd0) begin
                                udp_sum_int = 0;
                                udp_sum_int = udp_sum_int + {frame_mem[12], frame_mem[13]};
                                udp_sum_int = udp_sum_int + {frame_mem[14], frame_mem[15]};
                                udp_sum_int = udp_sum_int + {frame_mem[16], frame_mem[17]};
                                udp_sum_int = udp_sum_int + {frame_mem[18], frame_mem[19]};
                                udp_sum_int = udp_sum_int + 16'h0011;
                                udp_sum_int = udp_sum_int + {frame_mem[24], frame_mem[25]};
                                while (udp_sum_int > 16'hFFFF) begin
                                    udp_sum_int = (udp_sum_int & 16'hFFFF) + (udp_sum_int >> 16);
                                end

                                udp_bytes_int = udp_len_int;
                                idx_int = 20;
                                while (udp_bytes_int > 1) begin
                                    udp_sum_int = udp_sum_int + {frame_mem[idx_int], frame_mem[idx_int+1]};
                                    while (udp_sum_int > 16'hFFFF) begin
                                        udp_sum_int = (udp_sum_int & 16'hFFFF) + (udp_sum_int >> 16);
                                    end
                                    idx_int = idx_int + 2;
                                    udp_bytes_int = udp_bytes_int - 2;
                                end
                                if (udp_bytes_int == 1) begin
                                    udp_sum_int = udp_sum_int + {frame_mem[idx_int], 8'h00};
                                    while (udp_sum_int > 16'hFFFF) begin
                                        udp_sum_int = (udp_sum_int & 16'hFFFF) + (udp_sum_int >> 16);
                                    end
                                end
                                while (udp_sum_int > 16'hFFFF) begin
                                    udp_sum_int = (udp_sum_int & 16'hFFFF) + (udp_sum_int >> 16);
                                end
                                if ((udp_sum_int & 16'hFFFF) != 16'hFFFF) begin
                                    calc_error = 4'd4;
                                end
                            end
                        end

                        if (calc_error == 4'd0) begin
                            if (calc_dst_ip != 32'h0a000002 || calc_dst_port != 16'd9000) begin
                                calc_error = 4'd5;
                            end
                        end

                        status_valid_reg <= 1'b1;
                        status_error_reg <= calc_error;

                        if (calc_error == 4'd0) begin
                            out_src_ip_reg <= calc_src_ip;
                            out_src_port_reg <= calc_src_port;
                            out_dst_port_reg <= calc_dst_port;
                            out_payload_len_reg <= calc_payload_len;
                            out_index_reg <= 10'd0;
                            out_valid_reg <= 1'b1;
                            out_data_reg <= frame_mem[28];
                            out_last_reg <= (calc_payload_len == 16'd1);
                            state_reg <= ST_OUTPUT;
                        end else begin
                            state_reg <= ST_IDLE;
                        end
                    end else begin
                        state_reg <= ST_RECV;
                    end
                end
            end

            ST_RECV: begin
                if (s_valid) begin
                    if (recv_count_reg < 10'd512) begin
                        frame_mem[recv_count_reg] <= s_data;
                        recv_count_reg <= recv_count_reg + 10'd1;

                        if (s_last) begin
                            actual_len_int = recv_count_reg + 1;

                            calc_error = 4'd0;
                            calc_src_ip = 32'd0;
                            calc_dst_ip = 32'd0;
                            calc_src_port = 16'd0;
                            calc_dst_port = 16'd0;
                            calc_payload_len = 16'd0;

                            if (actual_len_int < 28 || actual_len_int > 512) begin
                                calc_error = 4'd1;
                            end

                            if (calc_error == 4'd0) begin
                                if ({frame_mem[0][7:4], frame_mem[0][3:0]} !== {4'd4,4'd5}) begin
                                    if (frame_mem[0][7:4] != 4'd4) begin
                                        calc_error = 4'd1;
                                    end
                                    if (frame_mem[0][3:0] != 4'd5) begin
                                        calc_error = 4'd1;
                                    end
                                end else begin
                                    if (frame_mem[9] != 8'd17) begin
                                        calc_error = 4'd1;
                                    end
                                    frag_field_int = {frame_mem[6], frame_mem[7]};
                                    if ((frag_field_int & 16'h2000) != 0) begin
                                        calc_error = 4'd1;
                                    end
                                    if ((frag_field_int & 16'h1FFF) != 0) begin
                                        calc_error = 4'd1;
                                    end
                                end
                                if (frame_mem[0][7:4] != 4'd4) begin
                                    calc_error = 4'd1;
                                end
                                if (frame_mem[0][3:0] != 4'd5) begin
                                    calc_error = 4'd1;
                                end
                                if (frame_mem[9] != 8'd17) begin
                                    calc_error = 4'd1;
                                end
                                frag_field_int = {frame_mem[6], frame_mem[7]};
                                if ((frag_field_int & 16'h2000) != 0) begin
                                    calc_error = 4'd1;
                                end
                                if ((frag_field_int & 16'h1FFF) != 0) begin
                                    calc_error = 4'd1;
                                end
                            end

                            if (calc_error == 4'd0) begin
                                ip_total_len_int = {frame_mem[2], frame_mem[3]};
                                udp_len_int = {frame_mem[24], frame_mem[25]};
                                if (ip_total_len_int != actual_len_int) begin
                                    calc_error = 4'd2;
                                end
                                if (udp_len_int != (ip_total_len_int - 20)) begin
                                    calc_error = 4'd2;
                                end
                                payload_len_int = udp_len_int - 8;
                                if (payload_len_int < 1 || payload_len_int > 256) begin
                                    calc_error = 4'd2;
                                end
                            end

                            if (calc_error == 4'd0) begin
                                sum_int = 0;
                                for (i = 0; i < 20; i = i + 2) begin
                                    word_int = {frame_mem[i], frame_mem[i+1]};
                                    sum_int = sum_int + word_int;
                                    while (sum_int > 16'hFFFF) begin
                                        sum_int = (sum_int & 16'hFFFF) + (sum_int >> 16);
                                    end
                                end
                                while (sum_int > 16'hFFFF) begin
                                    sum_int = (sum_int & 16'hFFFF) + (sum_int >> 16);
                                end
                                if ((sum_int & 16'hFFFF) != 16'hFFFF) begin
                                    calc_error = 4'd3;
                                end
                            end

                            if (calc_error == 4'd0) begin
                                calc_src_ip = {frame_mem[12], frame_mem[13], frame_mem[14], frame_mem[15]};
                                calc_dst_ip = {frame_mem[16], frame_mem[17], frame_mem[18], frame_mem[19]};
                                calc_src_port = {frame_mem[20], frame_mem[21]};
                                calc_dst_port = {frame_mem[22], frame_mem[23]};
                                calc_payload_len = udp_len_int - 8;

                                if ({frame_mem[26], frame_mem[27]} != 16'd0) begin
                                    udp_sum_int = 0;
                                    udp_sum_int = udp_sum_int + {frame_mem[12], frame_mem[13]};
                                    udp_sum_int = udp_sum_int + {frame_mem[14], frame_mem[15]};
                                    udp_sum_int = udp_sum_int + {frame_mem[16], frame_mem[17]};
                                    udp_sum_int = udp_sum_int + {frame_mem[18], frame_mem[19]};
                                    udp_sum_int = udp_sum_int + 16'h0011;
                                    udp_sum_int = udp_sum_int + {frame_mem[24], frame_mem[25]};
                                    while (udp_sum_int > 16'hFFFF) begin
                                        udp_sum_int = (udp_sum_int & 16'hFFFF) + (udp_sum_int >> 16);
                                    end

                                    udp_bytes_int = udp_len_int;
                                    idx_int = 20;
                                    while (udp_bytes_int > 1) begin
                                        udp_sum_int = udp_sum_int + {frame_mem[idx_int], frame_mem[idx_int+1]};
                                        while (udp_sum_int > 16'hFFFF) begin
                                            udp_sum_int = (udp_sum_int & 16'hFFFF) + (udp_sum_int >> 16);
                                        end
                                        idx_int = idx_int + 2;
                                        udp_bytes_int = udp_bytes_int - 2;
                                    end
                                    if (udp_bytes_int == 1) begin
                                        udp_sum_int = udp_sum_int + {frame_mem[idx_int], 8'h00};
                                        while (udp_sum_int > 16'hFFFF) begin
                                            udp_sum_int = (udp_sum_int & 16'hFFFF) + (udp_sum_int >> 16);
                                        end
                                    end
                                    while (udp_sum_int > 16'hFFFF) begin
                                        udp_sum_int = (udp_sum_int & 16'hFFFF) + (udp_sum_int >> 16);
                                    end
                                    if ((udp_sum_int & 16'hFFFF) != 16'hFFFF) begin
                                        calc_error = 4'd4;
                                    end
                                end
                            end

                            if (calc_error == 4'd0) begin
                                if (calc_dst_ip != 32'h0a000002 || calc_dst_port != 16'd9000) begin
                                    calc_error = 4'd5;
                                end
                            end

                            status_valid_reg <= 1'b1;
                            status_error_reg <= calc_error;

                            if (calc_error == 4'd0) begin
                                out_src_ip_reg <= calc_src_ip;
                                out_src_port_reg <= calc_src_port;
                                out_dst_port_reg <= calc_dst_port;
                                out_payload_len_reg <= calc_payload_len;
                                out_index_reg <= 10'd0;
                                out_valid_reg <= 1'b1;
                                out_data_reg <= frame_mem[28];
                                out_last_reg <= (calc_payload_len == 16'd1);
                                state_reg <= ST_OUTPUT;
                            end else begin
                                state_reg <= ST_IDLE;
                            end
                        end
                    end else begin
                        oversize_reg <= 1'b1;
                        if (s_last) begin
                            status_valid_reg <= 1'b1;
                            status_error_reg <= 4'd1;
                            state_reg <= ST_IDLE;
                        end else begin
                            state_reg <= ST_DRAIN;
                        end
                    end
                end
            end

            ST_DRAIN: begin
                if (s_valid && s_last) begin
                    status_valid_reg <= 1'b1;
                    status_error_reg <= 4'd1;
                    state_reg <= ST_IDLE;
                end
            end

            ST_OUTPUT: begin
                if (out_valid_reg && m_ready) begin
                    if (out_index_reg + 10'd1 >= out_payload_len_reg[9:0]) begin
                        out_valid_reg <= 1'b0;
                        out_last_reg <= 1'b0;
                        state_reg <= ST_IDLE;
                    end else begin
                        out_index_reg <= out_index_reg + 10'd1;
                        out_data_reg <= frame_mem[10'd28 + out_index_reg + 10'd1];
                        out_last_reg <= ((out_index_reg + 10'd2) >= out_payload_len_reg[9:0]);
                    end
                end
            end

            default: begin
                state_reg <= ST_IDLE;
            end
        endcase
    end
end

endmodule
