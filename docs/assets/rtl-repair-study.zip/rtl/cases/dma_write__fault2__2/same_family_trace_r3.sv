module dma_write(
    input wire clk,
    input wire rst,
    input wire [15:0] desc_addr,
    input wire [15:0] desc_len,
    input wire [7:0] desc_tag,
    input wire desc_valid,
    output wire desc_ready,
    input wire [31:0] s_data,
    input wire [3:0] s_keep,
    input wire s_valid,
    output wire s_ready,
    input wire s_last,
    output wire [15:0] status_len,
    output wire [7:0] status_tag,
    output wire [3:0] status_error,
    output wire status_valid,
    output wire [3:0] m_axi_awid,
    output wire [15:0] m_axi_awaddr,
    output wire [7:0] m_axi_awlen,
    output wire [2:0] m_axi_awsize,
    output wire [1:0] m_axi_awburst,
    output wire m_axi_awlock,
    output wire [3:0] m_axi_awcache,
    output wire [2:0] m_axi_awprot,
    output wire m_axi_awvalid,
    input wire m_axi_awready,
    output wire [31:0] m_axi_wdata,
    output wire [3:0] m_axi_wstrb,
    output wire m_axi_wlast,
    output wire m_axi_wvalid,
    input wire m_axi_wready,
    input wire [3:0] m_axi_bid,
    input wire [1:0] m_axi_bresp,
    input wire m_axi_bvalid,
    output wire m_axi_bready
);

    localparam IDLE = 2'd0;
    localparam SEND_BURSTS = 2'd1;
    localparam WAIT_RESP = 2'd2;

    reg [1:0] state, next_state;
    reg [15:0] bytes_remaining, next_bytes_remaining;
    reg [15:0] current_addr, next_current_addr;
    reg [7:0] stored_tag, next_stored_tag;
    reg [15:0] stored_len, next_stored_len;
    reg saw_decerr, saw_slverr, next_saw_decerr, next_saw_slverr;

    wire desc_fire = desc_valid && desc_ready;
    wire stream_fire = s_valid && s_ready;
    wire aw_fire = m_axi_awvalid && m_axi_awready;
    wire w_fire = m_axi_wvalid && m_axi_wready;
    wire b_fire = m_axi_bvalid && m_axi_bready;

    reg [8:0] beat_count_in_burst, next_beat_count_in_burst;
    reg [7:0] awlen_reg, next_awlen_reg;
    reg [15:0] burst_byte_count_total, next_burst_byte_count_total;
    reg [15:0] bytes_sent_in_burst, next_bytes_sent_in_burst;
    reg [1:0] b_resp_count, next_b_resp_count;
    reg status_pending, next_status_pending;
    reg buf_valid, next_buf_valid;
    reg [31:0] wdata_buf, next_wdata_buf;
    reg [3:0] wstrb_buf, next_wstrb_buf;

    function [7:0] calc_awlen;
        input [15:0] rem_bytes;
        input [15:0] addr;
        reg [15:0] bytes_to_boundary;
        reg [15:0] bytes_in_burst;
        begin
            bytes_to_boundary = 16'd4096 - {addr[15:12], 12'd0};
            if (rem_bytes < bytes_to_boundary)
                bytes_in_burst = rem_bytes;
            else
                bytes_in_burst = bytes_to_boundary;
            if (bytes_in_burst > 16'd64)
                bytes_in_burst = 16'd64;
            calc_awlen = (bytes_in_burst + 16'd3) >> 2;
            if (calc_awlen == 0)
                calc_awlen = 8'd0;
            else
                calc_awlen = calc_awlen - 1;
        end
    endfunction

    always @* begin
        next_state = state;
        next_bytes_remaining = bytes_remaining;
        next_current_addr = current_addr;
        next_stored_tag = stored_tag;
        next_stored_len = stored_len;
        next_saw_decerr = saw_decerr;
        next_saw_slverr = saw_slverr;
        next_beat_count_in_burst = beat_count_in_burst;
        next_awlen_reg = awlen_reg;
        next_burst_byte_count_total = burst_byte_count_total;
        next_bytes_sent_in_burst = bytes_sent_in_burst;
        next_b_resp_count = b_resp_count;
        next_status_pending = status_pending;
        next_buf_valid = buf_valid;
        next_wdata_buf = wdata_buf;
        next_wstrb_buf = wstrb_buf;

        case (state)
            IDLE: begin
                if (desc_fire) begin
                    next_state = SEND_BURSTS;
                    next_bytes_remaining = desc_len;
                    next_current_addr = desc_addr;
                    next_stored_tag = desc_tag;
                    next_stored_len = desc_len;
                    next_saw_decerr = 1'b0;
                    next_saw_slverr = 1'b0;
                    next_beat_count_in_burst = 9'd0;
                    next_awlen_reg = calc_awlen(desc_len, desc_addr);
                    next_burst_byte_count_total = (calc_awlen(desc_len, desc_addr) + 1) << 2;
                    next_bytes_sent_in_burst = 16'd0;
                    next_b_resp_count = 2'd0;
                    next_status_pending = 1'b0;
                    next_buf_valid = 1'b0;
                end
            end
            SEND_BURSTS: begin
                if (aw_fire) begin
                    next_b_resp_count = b_resp_count + 2'd1;
                    next_beat_count_in_burst = 9'd0;
                    next_bytes_sent_in_burst = 16'd0;
                end
                if (w_fire) begin
                    next_beat_count_in_burst = beat_count_in_burst + 9'd1;
                    next_bytes_sent_in_burst = bytes_sent_in_burst + 16'd4;
                end
                if (stream_fire && !buf_valid && bytes_remaining > 16'd0) begin
                    next_wdata_buf = s_data;
                    next_wstrb_buf = s_keep;
                    next_buf_valid = 1'b1;
                    next_bytes_remaining = bytes_remaining - {12'd0, s_keep[0]} - {12'd0, s_keep[1]} - {12'd0, s_keep[2]} - {12'd0, s_keep[3]};
                end
                if (w_fire && buf_valid) begin
                    next_buf_valid = 1'b0;
                end
                if (state == SEND_BURSTS && next_state == SEND_BURSTS && bytes_remaining == 16'd0 && !buf_valid && !(s_valid && bytes_remaining > 16'd0) && next_b_resp_count == b_resp_count) begin
                    if (b_resp_count == 2'd0 || (aw_fire && b_resp_count == 2'd0 && !(state == SEND_BURSTS && next_state == SEND_BURSTS && bytes_remaining == 16'd0)))
                        next_state = IDLE;
                    else
                        next_state = WAIT_RESP;
                    next_status_pending = 1'b1;
                end
                if (aw_fire && (bytes_remaining <= burst_byte_count_total || (bytes_remaining == 16'd0 && !aw_fire))) begin
                    if (b_resp_count == 2'd0)
                        next_state = IDLE;
                    else
                        next_state = WAIT_RESP;
                    next_status_pending = 1'b1;
                end else if (aw_fire && bytes_remaining > burst_byte_count_total) begin
                    next_bytes_remaining = bytes_remaining - burst_byte_count_total + 16'd0;
                    next_current_addr = current_addr + burst_byte_count_total;
                    next_awlen_reg = calc_awlen(bytes_remaining - burst_byte_count_total, current_addr + burst_byte_count_total);
                    next_burst_byte_count_total = (calc_awlen(bytes_remaining - burst_byte_count_total, current_addr + burst_byte_count_total) + 1) << 2;
                end
            end
            WAIT_RESP: begin
                if (b_fire) begin
                    if (m_axi_bresp == 2'b11)
                        next_saw_decerr = 1'b1;
                    else if (m_axi_bresp == 2'b10)
                        next_saw_slverr = 1'b1;
                    next_b_resp_count = b_resp_count - 2'd1;
                    if (b_resp_count == 2'd1) begin
                        next_state = IDLE;
                        next_status_pending = 1'b0;
                    end
                end
            end
        endcase
    end

    always @(posedge clk) begin
        if (rst) begin
            state <= IDLE;
            bytes_remaining <= 16'd0;
            current_addr <= 16'd0;
            stored_tag <= 8'd0;
            stored_len <= 16'd0;
            saw_decerr <= 1'b0;
            saw_slverr <= 1'b0;
            beat_count_in_burst <= 9'd0;
            awlen_reg <= 8'd0;
            burst_byte_count_total <= 16'd0;
            bytes_sent_in_burst <= 16'd0;
            b_resp_count <= 2'd0;
            status_pending <= 1'b0;
            buf_valid <= 1'b0;
            wdata_buf <= 32'd0;
            wstrb_buf <= 4'd0;
        end else begin
            state <= next_state;
            bytes_remaining <= next_bytes_remaining;
            current_addr <= next_current_addr;
            stored_tag <= next_stored_tag;
            stored_len <= next_stored_len;
            saw_decerr <= next_saw_decerr;
            saw_slverr <= next_saw_slverr;
            beat_count_in_burst <= next_beat_count_in_burst;
            awlen_reg <= next_awlen_reg;
            burst_byte_count_total <= next_burst_byte_count_total;
            bytes_sent_in_burst <= next_bytes_sent_in_burst;
            b_resp_count <= next_b_resp_count;
            status_pending <= next_status_pending;
            buf_valid <= next_buf_valid;
            wdata_buf <= next_wdata_buf;
            wstrb_buf <= next_wstrb_buf;
        end
    end

    assign desc_ready = (state == IDLE) && !rst;

    assign m_axi_awid = 4'd0;
    assign m_axi_awaddr = current_addr;
    assign m_axi_awlen = awlen_reg;
    assign m_axi_awsize = 3'd2;
    assign m_axi_awburst = 2'd1;
    assign m_axi_awlock = 1'b0;
    assign m_axi_awcache = 4'd3;
    assign m_axi_awprot = 3'd0;
    assign m_axi_awvalid = (state == SEND_BURSTS) && (beat_count_in_burst == 9'd0) && !(state == SEND_BURSTS && next_state == WAIT_RESP) && bytes_remaining > 16'd0;

    wire [3:0] wstrb_masked;
    wire [1:0] addr_offset = current_addr[1:0];
    wire [3:0] first_mask = (beat_count_in_burst == 9'd0) ?
                             ((addr_offset == 2'd1) ? 4'b1110 :
                              (addr_offset == 2'd2) ? 4'b1100 :
                              (addr_offset == 2'd3) ? 4'b1000 : 4'b1111) : 4'b1111;
    assign wstrb_masked = (buf_valid ? wstrb_buf : s_keep) & first_mask;

    wire last_beat = (state == SEND_BURSTS) && 
                     ((beat_count_in_burst == awlen_reg) || 
                      (bytes_remaining <= 16'd4 && !buf_valid && s_valid && stream_fire));

    assign m_axi_wdata = buf_valid ? wdata_buf : s_data;
    assign m_axi_wstrb = wstrb_masked;
    assign m_axi_wlast = last_beat && (buf_valid || (s_valid && !buf_valid));
    assign m_axi_wvalid = (state == SEND_BURSTS) && (buf_valid || s_valid) && (beat_count_in_burst <= awlen_reg);

    assign s_ready = (state == SEND_BURSTS) && !buf_valid && bytes_remaining > 16'd0 && 
                     !(m_axi_wvalid && m_axi_wready && !(state == SEND_BURSTS && next_state == WAIT_RESP));

    assign m_axi_bready = (state == WAIT_RESP) || (state == SEND_BURSTS && next_state == WAIT_RESP) || status_pending;

    assign status_valid = status_pending && (state == WAIT_RESP || state == SEND_BURSTS);
    assign status_len = stored_len;
    assign status_tag = stored_tag;
    assign status_error = saw_decerr ? 4'd7 : (saw_slverr ? 4'd6 : 4'd0);

endmodule
