module dma_write(
    input wire clk,
    input wire rst,
    input wire [15:0] desc_addr,
    input wire [15:0] desc_len,
    input wire [7:0] desc_tag,
    input wire desc_valid,
    output wire desc_ready,
    input wire [31:0] s_data,
    input wire [3:0] s_keep,
    input wire s_valid,
    output wire s_ready,
    input wire s_last,
    output wire [15:0] status_len,
    output wire [7:0] status_tag,
    output wire [3:0] status_error,
    output wire status_valid,
    output wire [3:0] m_axi_awid,
    output wire [15:0] m_axi_awaddr,
    output wire [7:0] m_axi_awlen,
    output wire [2:0] m_axi_awsize,
    output wire [1:0] m_axi_awburst,
    output wire m_axi_awlock,
    output wire [3:0] m_axi_awcache,
    output wire [2:0] m_axi_awprot,
    output wire m_axi_awvalid,
    input wire m_axi_awready,
    output wire [31:0] m_axi_wdata,
    output wire [3:0] m_axi_wstrb,
    output wire m_axi_wlast,
    output wire m_axi_wvalid,
    input wire m_axi_wready,
    input wire [3:0] m_axi_bid,
    input wire [1:0] m_axi_bresp,
    input wire m_axi_bvalid,
    output wire m_axi_bready
);

    localparam IDLE = 2'd0;
    localparam SEND_BURSTS = 2'd1;
    localparam WAIT_RESP = 2'd2;

    reg [1:0] state;
    reg [15:0] bytes_remaining;
    reg [15:0] current_addr;
    reg [7:0] stored_tag;
    reg [15:0] stored_len;
    reg saw_decerr;
    reg saw_slverr;

    reg [7:0] awlen_out;
    reg [7:0] beats_remaining_in_burst;
    reg [15:0] next_addr_after_burst;

    reg [31:0] wdata_buf;
    reg [3:0] wstrb_buf;
    reg wdata_valid;

    reg [15:0] aw_outstanding;
    reg [15:0] b_received;

    wire desc_fire = desc_valid && desc_ready;
    wire stream_fire = s_valid && s_ready;
    wire aw_fire = m_axi_awvalid && m_axi_awready;
    wire w_fire = m_axi_wvalid && m_axi_wready;
    wire b_fire = m_axi_bvalid && m_axi_bready;

    wire [15:0] addr_align = {current_addr[15:2], 2'b00};
    wire [15:0] next_4k = {current_addr[15:12] + 4'd1, 12'd0};
    wire [15:0] bytes_to_4k = next_4k - current_addr;
    wire [15:0] max_bytes_in_burst = (bytes_remaining < bytes_to_4k) ? bytes_remaining : bytes_to_4k;
    wire [15:0] max_beats = (max_bytes_in_burst + 16'd3) >> 2;
    wire [15:0] actual_beats = (max_beats > 16'd16) ? 16'd16 : max_beats;
    wire [15:0] burst_bytes = actual_beats << 2;

    wire [1:0] first_offset = current_addr[1:0];
    wire [3:0] first_beat_mask = (first_offset == 2'd0) ? 4'b1111 :
                                 (first_offset == 2'd1) ? 4'b1110 :
                                 (first_offset == 2'd2) ? 4'b1100 : 4'b1000;

    wire wlast_calc = (beats_remaining_in_burst == 8'd1);

    wire can_send_aw = (state == SEND_BURSTS) && (bytes_remaining > 0) && (aw_outstanding == b_received);
    wire can_send_w = (state == SEND_BURSTS) && wdata_valid;
    wire last_burst_of_desc = (bytes_remaining <= burst_bytes) && (bytes_remaining > 0);

    always @(posedge clk) begin
        if (rst) begin
            state <= IDLE;
            bytes_remaining <= 16'd0;
            current_addr <= 16'd0;
            stored_tag <= 8'd0;
            stored_len <= 16'd0;
            saw_decerr <= 1'b0;
            saw_slverr <= 1'b0;
            awlen_out <= 8'd0;
            beats_remaining_in_burst <= 8'd0;
            next_addr_after_burst <= 16'd0;
            wdata_buf <= 32'd0;
            wstrb_buf <= 4'd0;
            wdata_valid <= 1'b0;
            aw_outstanding <= 16'd0;
            b_received <= 16'd0;
        end else begin
            if (desc_fire) begin
                state <= SEND_BURSTS;
                bytes_remaining <= desc_len;
                current_addr <= desc_addr;
                stored_tag <= desc_tag;
                stored_len <= desc_len;
                saw_decerr <= 1'b0;
                saw_slverr <= 1'b0;
                aw_outstanding <= 16'd0;
                b_received <= 16'd0;
                wdata_valid <= 1'b0;
            end

            if (state == SEND_BURSTS) begin
                if (aw_fire) begin
                    awlen_out <= actual_beats[7:0] - 8'd1;
                    beats_remaining_in_burst <= actual_beats[7:0];
                    next_addr_after_burst <= current_addr + burst_bytes;
                    aw_outstanding <= aw_outstanding + 16'd1;
                end

                if (w_fire) begin
                    if (beats_remaining_in_burst > 8'd1) begin
                        beats_remaining_in_burst <= beats_remaining_in_burst - 8'd1;
                    end else begin
                        beats_remaining_in_burst <= 8'd0;
                        if (bytes_remaining > burst_bytes) begin
                            bytes_remaining <= bytes_remaining - burst_bytes;
                            current_addr <= next_addr_after_burst;
                        end else begin
                            bytes_remaining <= 16'd0;
                        end
                    end
                    wdata_valid <= 1'b0;
                end

                if (stream_fire && !wdata_valid) begin
                    wdata_buf <= s_data;
                    wstrb_buf <= s_keep;
                    wdata_valid <= 1'b1;
                end

                if (bytes_remaining == 16'd0 && beats_remaining_in_burst == 8'd0 && !wdata_valid && aw_outstanding == b_received) begin
                    state <= WAIT_RESP;
                end
            end

            if (state == WAIT_RESP) begin
                if (b_fire) begin
                    if (m_axi_bresp == 2'b11)
                        saw_decerr <= 1'b1;
                    else if (m_axi_bresp == 2'b10)
                        saw_slverr <= 1'b1;
                    b_received <= b_received + 16'd1;
                    if (b_received + 16'd1 == aw_outstanding) begin
                        state <= IDLE;
                    end
                end
            end
        end
    end

    assign desc_ready = (state == IDLE);

    assign m_axi_awid = 4'd0;
    assign m_axi_awaddr = current_addr;
    assign m_axi_awlen = actual_beats[7:0] - 8'd1;
    assign m_axi_awsize = 3'd2;
    assign m_axi_awburst = 2'b01;
    assign m_axi_awlock = 1'b0;
    assign m_axi_awcache = 4'b0011;
    assign m_axi_awprot = 3'd0;
    assign m_axi_awvalid = can_send_aw;

    assign m_axi_wdata = wdata_buf;
    assign m_axi_wstrb = (beats_remaining_in_burst == awlen_out + 8'd1) ? (wstrb_buf & first_beat_mask) : wstrb_buf;
    assign m_axi_wlast = wlast_calc;
    assign m_axi_wvalid = can_send_w;

    assign s_ready = (state == SEND_BURSTS) && !wdata_valid;

    assign m_axi_bready = (state == WAIT_RESP) || (state == SEND_BURSTS && bytes_remaining == 16'd0 && beats_remaining_in_burst == 8'd0 && !wdata_valid);

    reg status_valid_reg;
    always @(posedge clk) begin
        if (rst)
            status_valid_reg <= 1'b0;
        else
            status_valid_reg <= (state == WAIT_RESP) && b_fire && (b_received + 16'd1 == aw_outstanding);
    end

    assign status_valid = status_valid_reg;
    assign status_len = stored_len;
    assign status_tag = stored_tag;
    assign status_error = saw_decerr ? 4'd7 : (saw_slverr ? 4'd6 : 4'd0);

endmodule
