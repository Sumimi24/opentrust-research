`timescale 1ns/1ps
module dma_write(
    input wire clk,
    input wire rst,
    input wire [15:0] desc_addr,
    input wire [15:0] desc_len,
    input wire [7:0] desc_tag,
    input wire desc_valid,
    output wire desc_ready,
    input wire [31:0] s_data,
    input wire [3:0] s_keep,
    input wire s_valid,
    output wire s_ready,
    input wire s_last,
    output wire [15:0] status_len,
    output wire [7:0] status_tag,
    output wire [3:0] status_error,
    output wire status_valid,
    output wire [3:0] m_axi_awid,
    output wire [15:0] m_axi_awaddr,
    output wire [7:0] m_axi_awlen,
    output wire [2:0] m_axi_awsize,
    output wire [1:0] m_axi_awburst,
    output wire m_axi_awlock,
    output wire [3:0] m_axi_awcache,
    output wire [2:0] m_axi_awprot,
    output wire m_axi_awvalid,
    input wire m_axi_awready,
    output wire [31:0] m_axi_wdata,
    output wire [3:0] m_axi_wstrb,
    output wire m_axi_wlast,
    output wire m_axi_wvalid,
    input wire m_axi_wready,
    input wire [3:0] m_axi_bid,
    input wire [1:0] m_axi_bresp,
    input wire m_axi_bvalid,
    output wire m_axi_bready
);

reg active_reg = 1'b0;

reg [15:0] desc_addr_reg = 16'd0;
reg [15:0] desc_len_reg = 16'd0;
reg [7:0] desc_tag_reg = 8'd0;

reg [15:0] bytes_in_count_reg = 16'd0;
reg [15:0] bytes_written_reg = 16'd0;

reg [31:0] data_fifo_0_reg = 32'd0;
reg [31:0] data_fifo_1_reg = 32'd0;
reg [3:0] keep_fifo_0_reg = 4'd0;
reg [3:0] keep_fifo_1_reg = 4'd0;
reg last_fifo_0_reg = 1'b0;
reg last_fifo_1_reg = 1'b0;
reg [1:0] fifo_count_reg = 2'd0;

reg awvalid_reg = 1'b0;
reg [15:0] awaddr_reg = 16'd0;
reg [7:0] awlen_reg = 8'd0;

reg burst_active_reg = 1'b0;
reg [7:0] burst_beats_total_reg = 8'd0;
reg [7:0] burst_beats_sent_reg = 8'd0;
reg [15:0] burst_addr_reg = 16'd0;
reg [15:0] burst_desc_offset_reg = 16'd0;

reg [15:0] next_aw_addr_reg = 16'd0;
reg [15:0] next_desc_offset_reg = 16'd0;

reg [15:0] bursts_issued_reg = 16'd0;
reg [15:0] b_count_reg = 16'd0;

reg [3:0] error_reg = 4'd0;

reg status_valid_reg = 1'b0;
reg [15:0] status_len_reg = 16'd0;
reg [7:0] status_tag_reg = 8'd0;
reg [3:0] status_error_reg = 4'd0;

wire desc_accept;
wire s_accept;
wire aw_accept;
wire w_accept;
wire b_accept;

wire [15:0] bytes_remaining_total;
wire [15:0] bytes_available_for_issue;
wire [15:0] bytes_to_4k;
wire [15:0] burst_bytes_limit;
wire [15:0] burst_bytes_calc;
wire [7:0] burst_beats_calc;

wire can_start_burst;

wire [31:0] fifo_head_data;
wire [3:0] fifo_head_keep;
wire fifo_head_last;

wire [15:0] beat_addr;
wire [15:0] beat_desc_offset;
wire [15:0] bytes_left_from_beat;
wire [3:0] range_mask;
wire [3:0] wstrb_calc;
wire wlast_calc;

assign desc_accept = desc_valid && desc_ready;
assign s_accept = s_valid && s_ready;
assign aw_accept = awvalid_reg && m_axi_awready;
assign w_accept = m_axi_wvalid && m_axi_wready;
assign b_accept = m_axi_bvalid && m_axi_bready;

assign bytes_remaining_total = desc_len_reg - bytes_written_reg;
assign bytes_available_for_issue = bytes_in_count_reg - bytes_written_reg;

assign bytes_to_4k = 16'h1000 - {4'd0, next_aw_addr_reg[11:0]};
assign burst_bytes_limit = bytes_available_for_issue < bytes_to_4k ? bytes_available_for_issue : bytes_to_4k;
assign burst_bytes_calc = burst_bytes_limit > 16'd64 ? 16'd64 : burst_bytes_limit;
assign burst_beats_calc = burst_bytes_calc[15:2] + (|burst_bytes_calc[1:0]);

assign can_start_burst = active_reg &&
    !awvalid_reg &&
    !burst_active_reg &&
    (bytes_written_reg < desc_len_reg) &&
    (bytes_available_for_issue != 16'd0) &&
    (burst_beats_calc != 8'd0);

assign fifo_head_data = data_fifo_0_reg;
assign fifo_head_keep = keep_fifo_0_reg;
assign fifo_head_last = last_fifo_0_reg;

assign beat_addr = burst_addr_reg + {8'd0, burst_beats_sent_reg, 2'b00};
assign beat_desc_offset = burst_desc_offset_reg + {8'd0, burst_beats_sent_reg, 2'b00};
assign bytes_left_from_beat = desc_len_reg - beat_desc_offset;

assign range_mask =
    (bytes_left_from_beat == 16'd0) ? 4'b0000 :
    (bytes_left_from_beat == 16'd1) ? 4'b0001 :
    (bytes_left_from_beat == 16'd2) ? 4'b0011 :
    (bytes_left_from_beat == 16'd3) ? 4'b0111 :
    4'b1111;

assign wstrb_calc = fifo_head_keep &
    ((burst_beats_sent_reg == 8'd0) ?
        (4'b1111 << burst_addr_reg[1:0]) :
        4'b1111) &
    range_mask;

assign wlast_calc = burst_active_reg && (burst_beats_sent_reg + 8'd1 == burst_beats_total_reg);

assign desc_ready = !active_reg;

assign s_ready = active_reg && (fifo_count_reg != 2'd2) && (bytes_in_count_reg < desc_len_reg);

assign status_len = status_len_reg;
assign status_tag = status_tag_reg;
assign status_error = status_error_reg;
assign status_valid = status_valid_reg;

assign m_axi_awid = 4'd0;
assign m_axi_awaddr = awaddr_reg;
assign m_axi_awlen = awlen_reg;
assign m_axi_awsize = 3'd2;
assign m_axi_awburst = 2'b01;
assign m_axi_awlock = 1'b0;
assign m_axi_awcache = 4'b0011;
assign m_axi_awprot = 3'd0;
assign m_axi_awvalid = awvalid_reg;

assign m_axi_wdata = fifo_head_data;
assign m_axi_wstrb = wstrb_calc;
assign m_axi_wlast = wlast_calc;
assign m_axi_wvalid = burst_active_reg && (fifo_count_reg != 2'd0);

assign m_axi_bready = active_reg;

always @(posedge clk) begin
    if (rst) begin
        active_reg <= 1'b0;
        desc_addr_reg <= 16'd0;
        desc_len_reg <= 16'd0;
        desc_tag_reg <= 8'd0;
        bytes_in_count_reg <= 16'd0;
        bytes_written_reg <= 16'd0;
        data_fifo_0_reg <= 32'd0;
        data_fifo_1_reg <= 32'd0;
        keep_fifo_0_reg <= 4'd0;
        keep_fifo_1_reg <= 4'd0;
        last_fifo_0_reg <= 1'b0;
        last_fifo_1_reg <= 1'b0;
        fifo_count_reg <= 2'd0;
        awvalid_reg <= 1'b0;
        awaddr_reg <= 16'd0;
        awlen_reg <= 8'd0;
        burst_active_reg <= 1'b0;
        burst_beats_total_reg <= 8'd0;
        burst_beats_sent_reg <= 8'd0;
        burst_addr_reg <= 16'd0;
        burst_desc_offset_reg <= 16'd0;
        next_aw_addr_reg <= 16'd0;
        next_desc_offset_reg <= 16'd0;
        bursts_issued_reg <= 16'd0;
        b_count_reg <= 16'd0;
        error_reg <= 4'd0;
        status_valid_reg <= 1'b0;
        status_len_reg <= 16'd0;
        status_tag_reg <= 8'd0;
        status_error_reg <= 4'd0;
    end else begin
        status_valid_reg <= 1'b0;

        if (desc_accept) begin
            active_reg <= 1'b0 ? 1'b0 : 1'b1;
            desc_addr_reg <= desc_addr;
            desc_len_reg <= desc_len;
            desc_tag_reg <= desc_tag;
            bytes_in_count_reg <= 16'd0;
            bytes_written_reg <= 16'd0;
            data_fifo_0_reg <= 32'd0;
            data_fifo_1_reg <= 32'd0;
            keep_fifo_0_reg <= 4'd0;
            keep_fifo_1_reg <= 4'd0;
            last_fifo_0_reg <= 1'b0;
            last_fifo_1_reg <= 1'b0;
            fifo_count_reg <= 2'd0;
            awvalid_reg <= 1'b0;
            awaddr_reg <= 16'd0;
            awlen_reg <= 8'd0;
            burst_active_reg <= 1'b0;
            burst_beats_total_reg <= 8'd0;
            burst_beats_sent_reg <= 8'd0;
            burst_addr_reg <= 16'd0;
            burst_desc_offset_reg <= 16'd0;
            next_aw_addr_reg <= desc_addr;
            next_desc_offset_reg <= 16'd0;
            bursts_issued_reg <= 16'd0;
            b_count_reg <= 16'd0;
            error_reg <= 4'd0;
            status_len_reg <= desc_len;
            status_tag_reg <= desc_tag;
            status_error_reg <= 4'd0;
            active_reg <= 1'b1;
        end

        if (s_accept) begin
            case (fifo_count_reg)
                2'd0: begin
                    data_fifo_0_reg <= s_data;
                    keep_fifo_0_reg <= s_keep;
                    last_fifo_0_reg <= s_last;
                    fifo_count_reg <= 2'd1;
                end
                2'd1: begin
                    data_fifo_1_reg <= s_data;
                    keep_fifo_1_reg <= s_keep;
                    last_fifo_1_reg <= s_last;
                    fifo_count_reg <= 2'd2;
                end
                default: begin
                    fifo_count_reg <= fifo_count_reg;
                end
            endcase
            bytes_in_count_reg <= bytes_in_count_reg + 16'd4;
        end

        if (can_start_burst) begin
            awvalid_reg <= 1'b1;
            awaddr_reg <= next_aw_addr_reg;
            awlen_reg <= burst_beats_calc - 8'd1;
            burst_addr_reg <= next_aw_addr_reg;
            burst_desc_offset_reg <= next_desc_offset_reg;
            burst_beats_total_reg <= burst_beats_calc;
            burst_beats_sent_reg <= 8'd0;
            next_aw_addr_reg <= next_aw_addr_reg + {8'd0, burst_beats_calc, 2'b00};
            next_desc_offset_reg <= next_desc_offset_reg + {8'd0, burst_beats_calc, 2'b00};
            bursts_issued_reg <= bursts_issued_reg + 16'd1;
        end

        if (aw_accept) begin
            awvalid_reg <= 1'b0;
            burst_active_reg <= 1'b1;
        end

        if (w_accept) begin
            bytes_written_reg <= bytes_written_reg + 16'd4;

            if (fifo_count_reg == 2'd2) begin
                data_fifo_0_reg <= data_fifo_1_reg;
                keep_fifo_0_reg <= keep_fifo_1_reg;
                last_fifo_0_reg <= last_fifo_1_reg;
            end
            if (fifo_count_reg != 2'd0) begin
                fifo_count_reg <= fifo_count_reg - 2'd1;
            end

            if (wlast_calc) begin
                burst_active_reg <= 1'b0;
                burst_beats_sent_reg <= 8'd0;
            end else begin
                burst_beats_sent_reg <= burst_beats_sent_reg + 8'd1;
            end
        end

        if (b_accept) begin
            b_count_reg <= b_count_reg + 16'd1;
            if (m_axi_bresp == 2'b10 && error_reg != 4'd7) begin
                error_reg <= 4'd6;
            end
            if (m_axi_bresp == 2'b11) begin
                error_reg <= 4'd7;
            end
        end

        if (active_reg &&
            (bytes_written_reg >= desc_len_reg) &&
            (b_count_reg == bursts_issued_reg) &&
            !awvalid_reg &&
            !burst_active_reg) begin
            active_reg <= 1'b0;
            status_valid_reg <= 1'b1;
            status_len_reg <= desc_len_reg;
            status_tag_reg <= desc_tag_reg;
            status_error_reg <= error_reg;
        end
    end
end

endmodule
