module dma_write(
    input wire clk,
    input wire rst,
    input wire [15:0] desc_addr,
    input wire [15:0] desc_len,
    input wire [7:0] desc_tag,
    input wire desc_valid,
    output wire desc_ready,
    input wire [31:0] s_data,
    input wire [3:0] s_keep,
    input wire s_valid,
    output wire s_ready,
    input wire s_last,
    output wire [15:0] status_len,
    output wire [7:0] status_tag,
    output wire [3:0] status_error,
    output wire status_valid,
    output wire [3:0] m_axi_awid,
    output wire [15:0] m_axi_awaddr,
    output wire [7:0] m_axi_awlen,
    output wire [2:0] m_axi_awsize,
    output wire [1:0] m_axi_awburst,
    output wire m_axi_awlock,
    output wire [3:0] m_axi_awcache,
    output wire [2:0] m_axi_awprot,
    output wire m_axi_awvalid,
    input wire m_axi_awready,
    output wire [31:0] m_axi_wdata,
    output wire [3:0] m_axi_wstrb,
    output wire m_axi_wlast,
    output wire m_axi_wvalid,
    input wire m_axi_wready,
    input wire [3:0] m_axi_bid,
    input wire [1:0] m_axi_bresp,
    input wire m_axi_bvalid,
    output wire m_axi_bready
);

    localparam IDLE = 2'd0;
    localparam SEND_BURSTS = 2'd1;
    localparam WAIT_RESP = 2'd2;

    reg [1:0] state, next_state;
    reg [15:0] bytes_remaining, next_bytes_remaining;
    reg [15:0] current_addr, next_current_addr;
    reg [7:0] stored_tag, next_stored_tag;
    reg [15:0] stored_len, next_stored_len;
    reg saw_decerr, saw_slverr, next_saw_decerr, next_saw_slverr;

    wire desc_fire = desc_valid && desc_ready;
    wire stream_fire = s_valid && s_ready;
    wire aw_fire = m_axi_awvalid && m_axi_awready;
    wire w_fire = m_axi_wvalid && m_axi_wready;
    wire b_fire = m_axi_bvalid && m_axi_bready;

    reg [8:0] beat_count_in_burst, next_beat_count_in_burst;
    reg [3:0] awlen_out, next_awlen_out;
    wire [15:0] awaddr_out, next_awaddr_out_comb;
    wire [7:0] next_awlen_comb;

    function [7:0] calc_awlen;
        input [15:0] rem_bytes;
        input [15:0] addr;
        reg [15:0] max_beats;
        reg [15:0] bytes_to_boundary;
        reg [15:0] bytes_in_burst;
        begin
            bytes_to_boundary = 16'd4096 - {addr[15:12], 12'd0};
            if (rem_bytes < bytes_to_boundary)
                bytes_in_burst = rem_bytes;
            else
                bytes_in_burst = bytes_to_boundary;
            max_beats = (bytes_in_burst + 16'd3) >> 2;
            if (max_beats > 16'd16)
                max_beats = 16'd16;
            calc_awlen = max_beats - 1;
        end
    endfunction

    wire [15:0] burst_bytes_raw, burst_bytes_aligned;
    wire [15:0] addr_offset_lo;

    assign next_awlen_comb = calc_awlen(next_bytes_remaining, next_current_addr);
    assign awaddr_out = current_addr;
    assign next_awaddr_out_comb = current_addr + {12'd0, next_awlen_out} * 16'd4 + 16'd4;

    reg [31:0] wdata_in_buf, next_wdata_in_buf;
    reg [3:0] wstrb_in_buf, next_wstrb_in_buf;
    reg has_data_in_buf, next_has_data_in_buf;

    always @* begin
        next_state = state;
        next_bytes_remaining = bytes_remaining;
        next_current_addr = current_addr;
        next_stored_tag = stored_tag;
        next_stored_len = stored_len;
        next_saw_decerr = saw_decerr;
        next_saw_slverr = saw_slverr;
        next_beat_count_in_burst = beat_count_in_burst;
        next_awlen_out = awlen_out;
        next_wdata_in_buf = wdata_in_buf;
        next_wstrb_in_buf = wstrb_in_buf;
        next_has_data_in_buf = has_data_in_buf;

        case (state)
            IDLE: begin
                if (desc_fire) begin
                    next_state = SEND_BURSTS;
                    next_bytes_remaining = desc_len;
                    next_current_addr = desc_addr;
                    next_stored_tag = desc_tag;
                    next_stored_len = desc_len;
                    next_saw_decerr = 1'b0;
                    next_saw_slverr = 1'b0;
                    next_awlen_out = calc_awlen(desc_len, desc_addr);
                    next_beat_count_in_burst = 9'd0;
                    next_has_data_in_buf = 1'b0;
                end
            end
            SEND_BURSTS: begin
                if (aw_fire && (next_beat_count_in_burst == 9'd0 || w_fire)) begin
                    next_beat_count_in_burst = (next_beat_count_in_burst == {1'b0, next_awlen_out}) ? 9'd0 : next_beat_count_in_burst + 9'd1;
                    if (aw_fire) begin
                        next_awlen_out = next_awlen_comb;
                        next_bytes_remaining = (next_bytes_remaining > 16'd4) ? next_bytes_remaining - 16'd4 : 16'd0;
                        next_current_addr = next_current_addr + 16'd4;
                        if (next_beat_count_in_burst == {1'b0, next_awlen_out}) begin
                            if (next_bytes_remaining == 16'd0) begin
                                next_state = WAIT_RESP;
                                next_current_addr = next_awaddr_out_comb;
                            end else begin
                                next_awlen_out = next_awlen_comb;
                                next_current_addr = next_awaddr_out_comb;
                            end
                        end
                    end
                end
                if (stream_fire && !has_data_in_buf && !(aw_fire && w_fire && next_beat_count_in_burst == {1'b0, next_awlen_out})) begin
                    next_wdata_in_buf = s_data;
                    next_wstrb_in_buf = s_keep;
                    next_has_data_in_buf = (s_keep != 4'b0000);
                end
                if (w_fire && has_data_in_buf) begin
                    next_has_data_in_buf = 1'b0;
                end
            end
            WAIT_RESP: begin
                if (b_fire) begin
                    if (m_axi_bresp == 2'b11)
                        next_saw_decerr = 1'b1;
                    else if (m_axi_bresp == 2'b10)
                        next_saw_slverr = 1'b1;
                    if (next_bytes_remaining == 16'd0 && next_beat_count_in_burst == {1'b0, next_awlen_out})
                        next_state = IDLE;
                end
                if (next_state == IDLE)
                    next_has_data_in_buf = 1'b0;
            end
        endcase
    end

    always @(posedge clk) begin
        if (rst) begin
            state <= IDLE;
            bytes_remaining <= 16'd0;
            current_addr <= 16'd0;
            stored_tag <= 8'd0;
            stored_len <= 16'd0;
            saw_decerr <= 1'b0;
            saw_slverr <= 1'b0;
            beat_count_in_burst <= 9'd0;
            awlen_out <= 8'd0;
            wdata_in_buf <= 32'd0;
            wstrb_in_buf <= 4'b0000;
            has_data_in_buf <= 1'b0;
        end else begin
            state <= next_state;
            bytes_remaining <= next_bytes_remaining;
            current_addr <= next_current_addr;
            stored_tag <= next_stored_tag;
            stored_len <= next_stored_len;
            saw_decerr <= next_saw_decerr;
            saw_slverr <= next_saw_slverr;
            beat_count_in_burst <= next_beat_count_in_burst;
            awlen_out <= next_awlen_out;
            wdata_in_buf <= next_wdata_in_buf;
            wstrb_in_buf <= next_wstrb_in_buf;
            has_data_in_buf <= next_has_data_in_buf;
        end
    end

    assign desc_ready = (state == IDLE) && !rst;

    assign m_axi_awid = 4'd0;
    assign m_axi_awaddr = awaddr_out;
    assign m_axi_awlen = awlen_out;
    assign m_axi_awsize = 3'd2;
    assign m_axi_awburst = 2'd1;
    assign m_axi_awlock = 1'b0;
    assign m_axi_awcache = 4'd3;
    assign m_axi_awprot = 3'd0;
    assign m_axi_awvalid = (state == SEND_BURSTS) && (next_state != WAIT_RESP) && (next_bytes_remaining != 16'd0 || next_beat_count_in_burst != {1'b0, next_awlen_out});

    assign m_axi_wdata = has_data_in_buf ? wdata_in_buf : s_data;
    wire [3:0] wstrb_raw = has_data_in_buf ? wstrb_in_buf : (s_valid ? s_keep : 4'b0000);
    wire [1:0] addr_offset = current_addr[1:0];
    wire [3:0] first_beat_mask;
    assign first_beat_mask = (beat_count_in_burst == 9'd0) ? ((addr_offset == 2'd1) ? 4'b1110 :
                                                              (addr_offset == 2'd2) ? 4'b1100 :
                                                              (addr_offset == 2'd3) ? 4'b1000 : 4'b1111) : 4'b1111;
    assign m_axi_wstrb = wstrb_raw & first_beat_mask;
    assign m_axi_wlast = (state == SEND_BURSTS) && (next_beat_count_in_burst == {1'b0, awlen_out}) && (next_bytes_remaining == 16'd0 || next_beat_count_in_burst != 9'd0) && (has_data_in_buf || s_valid);
    assign m_axi_wvalid = (state == SEND_BURSTS) && (has_data_in_buf || (s_valid && (next_beat_count_in_burst != {1'b0, awlen_out} || next_bytes_remaining != 16'd0)));

    assign s_ready = (state == SEND_BURSTS) && !has_data_in_buf && !(m_axi_wvalid && m_axi_wready && next_has_data_in_buf);

    assign m_axi_bready = (state == WAIT_RESP) || (state == SEND_BURSTS && next_state == WAIT_RESP);

    reg status_valid_reg;
    always @(posedge clk) begin
        if (rst)
            status_valid_reg <= 1'b0;
        else
            status_valid_reg <= (state == WAIT_RESP && next_state == IDLE);
    end

    assign status_valid = status_valid_reg;
    assign status_len = stored_len;
    assign status_tag = stored_tag;
    assign status_error = saw_decerr ? 4'd7 : (saw_slverr ? 4'd6 : 4'd0);

endmodule
