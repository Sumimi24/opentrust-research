module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

reg [7:0] bytes[0:511];

localparam ST_RECV   = 3'd0;
localparam ST_STATUS = 3'd1;
localparam ST_HDR    = 3'd2;
localparam ST_PAY    = 3'd3;
localparam ST_WAIT   = 3'd4;

reg [2:0] state_reg;
reg [9:0] n_reg;
reg oversize_reg;
reg [9:0] ptr_reg;

reg status_valid_reg;
reg [3:0] status_error_reg;

reg [3:0] error_code_reg;
reg [15:0] ip_len_reg;
reg [15:0] udp_len_reg;
reg [15:0] payload_len_reg;

reg [31:0] src_ip_reg;
reg [15:0] src_port_reg;
reg [15:0] dst_port_reg;

function [15:0] get16;
    input integer idx;
    begin
        get16 = {bytes[idx], bytes[idx+1]};
    end
endfunction

function [15:0] fold32;
    input [31:0] sum;
    reg [31:0] t;
    begin
        t = sum[15:0] + sum[31:16];
        t = t[15:0] + t[31:16];
        t = t[15:0] + t[31:16];
        fold32 = t[15:0];
    end
endfunction

reg [31:0] ip_sum_calc;
reg [31:0] udp_sum_calc;
reg [3:0] error_code_calc;
reg [15:0] ip_len_calc;
reg [15:0] udp_len_calc;
reg [15:0] payload_len_calc;
reg [31:0] src_ip_calc;
reg [15:0] src_port_calc;
reg [15:0] dst_port_calc;
reg [31:0] dest_ip_calc;

integer j;
reg [15:0] w;

always @* begin
    ip_len_calc = {bytes[2], bytes[3]};
    udp_len_calc = {bytes[24], bytes[25]};
    payload_len_calc = udp_len_calc - 16'd8;
    src_ip_calc = {bytes[12], bytes[13], bytes[14], bytes[15]};
    src_port_calc = {bytes[20], bytes[21]};
    dst_port_calc = {bytes[22], bytes[23]};
    dest_ip_calc = {bytes[16], bytes[17], bytes[18], bytes[19]};

    error_code_calc = 4'd0;

    if (n_reg < 10'd28 || oversize_reg || bytes[0][7:4] != 4'd4 || bytes[0][3:0] != 4'd5 || bytes[9] != 8'd17 || bytes[6][5] || ({bytes[6][4:0], bytes[7]} != 13'd0))
        error_code_calc = 4'd1;
    else if (ip_len_calc != n_reg[15:0] || udp_len_calc != (ip_len_calc - 16'd20) || payload_len_calc < 16'd1 || payload_len_calc > 16'd256)
        error_code_calc = 4'd2;
    else begin
        ip_sum_calc = 32'd0;
        for (j = 0; j < 20; j = j + 2)
            ip_sum_calc = ip_sum_calc + get16(j);
        if (fold32(ip_sum_calc) != 16'hffff)
            error_code_calc = 4'd3;
        else begin
            udp_sum_calc = 32'd0;
            udp_sum_calc = udp_sum_calc + get16(12);
            udp_sum_calc = udp_sum_calc + get16(14);
            udp_sum_calc = udp_sum_calc + get16(16);
            udp_sum_calc = udp_sum_calc + get16(18);
            udp_sum_calc = udp_sum_calc + 32'd17;
            udp_sum_calc = udp_sum_calc + udp_len_calc;

            for (j = 20; j < (20 + udp_len_calc); j = j + 2) begin
                if (j + 1 < (20 + udp_len_calc))
                    w = {bytes[j], bytes[j+1]};
                else
                    w = {bytes[j], 8'h00};
                udp_sum_calc = udp_sum_calc + w;
            end

            if ({bytes[26], bytes[27]} != 16'd0 && fold32(udp_sum_calc) != 16'hffff)
                error_code_calc = 4'd4;
            else if (dest_ip_calc != 32'h0a000002 || dst_port_calc != 16'd9000)
                error_code_calc = 4'd5;
        end
    end
end

wire parser_hdr_ready;
wire parser_pay_ready;
wire [7:0] parser_m_data;
wire parser_m_valid;
wire parser_m_last;

assign s_ready = (state_reg == ST_RECV);

assign status_valid = status_valid_reg;
assign status_error = status_error_reg;

assign m_data = parser_m_data;
assign m_valid = parser_m_valid;
assign m_last = parser_m_last;
assign m_src_ip = src_ip_reg;
assign m_src_port = src_port_reg;
assign m_dst_port = dst_port_reg;
assign m_payload_len = payload_len_reg;

always @(posedge clk) begin
    if (rst) begin
        state_reg <= ST_RECV;
        n_reg <= 10'd0;
        oversize_reg <= 1'b0;
        ptr_reg <= 10'd20;
        status_valid_reg <= 1'b0;
        status_error_reg <= 4'd0;
        error_code_reg <= 4'd0;
        ip_len_reg <= 16'd0;
        udp_len_reg <= 16'd0;
        payload_len_reg <= 16'd0;
        src_ip_reg <= 32'd0;
        src_port_reg <= 16'd0;
        dst_port_reg <= 16'd0;
    end else begin
        status_valid_reg <= 1'b0;

        case (state_reg)
            ST_RECV: begin
                if (s_valid) begin
                    if (n_reg < 10'd512)
                        bytes[n_reg] <= s_data;
                    else
                        oversize_reg <= 1'b1;

                    n_reg <= n_reg + 10'd1;

                    if (s_last) begin
                        error_code_reg <= error_code_calc;
                        ip_len_reg <= ip_len_calc;
                        udp_len_reg <= udp_len_calc;
                        payload_len_reg <= payload_len_calc;
                        src_ip_reg <= src_ip_calc;
                        src_port_reg <= src_port_calc;
                        dst_port_reg <= dst_port_calc;
                        state_reg <= ST_STATUS;
                    end
                end
            end

            ST_STATUS: begin
                status_valid_reg <= 1'b1;
                status_error_reg <= error_code_reg;
                if (error_code_reg == 4'd0) begin
                    ptr_reg <= 10'd20;
                    state_reg <= ST_HDR;
                end else begin
                    state_reg <= ST_RECV;
                    n_reg <= 10'd0;
                    oversize_reg <= 1'b0;
                    ptr_reg <= 10'd20;
                end
            end

            ST_HDR: begin
                if (parser_hdr_ready) begin
                    ptr_reg <= 10'd20;
                    state_reg <= ST_PAY;
                end
            end

            ST_PAY: begin
                if (parser_pay_ready) begin
                    if (ptr_reg == (n_reg - 10'd1))
                        state_reg <= ST_WAIT;
                    ptr_reg <= ptr_reg + 10'd1;
                end
            end

            ST_WAIT: begin
                if (parser_m_valid && m_ready && parser_m_last) begin
                    state_reg <= ST_RECV;
                    n_reg <= 10'd0;
                    oversize_reg <= 1'b0;
                    ptr_reg <= 10'd20;
                end
            end

            default: begin
                state_reg <= ST_RECV;
                n_reg <= 10'd0;
                oversize_reg <= 1'b0;
                ptr_reg <= 10'd20;
            end
        endcase
    end
end

udp_ip_rx parser(
    .clk(clk),
    .rst(rst),

    .s_ip_hdr_valid(state_reg == ST_HDR),
    .s_ip_hdr_ready(parser_hdr_ready),

    .s_eth_dest_mac(48'd0),
    .s_eth_src_mac(48'd0),
    .s_eth_type(16'h0800),

    .s_ip_version(4'd4),
    .s_ip_ihl(4'd5),
    .s_ip_dscp(bytes[1][7:2]),
    .s_ip_ecn(bytes[1][1:0]),
    .s_ip_length(ip_len_reg),
    .s_ip_identification({bytes[4], bytes[5]}),
    .s_ip_flags(bytes[6][7:5]),
    .s_ip_fragment_offset({bytes[6][4:0], bytes[7]}),
    .s_ip_ttl(bytes[8]),
    .s_ip_protocol(8'd17),
    .s_ip_header_checksum({bytes[10], bytes[11]}),
    .s_ip_source_ip(src_ip_reg),
    .s_ip_dest_ip(dest_ip_calc),

    .s_ip_payload_axis_tdata(bytes[ptr_reg]),
    .s_ip_payload_axis_tvalid(state_reg == ST_PAY),
    .s_ip_payload_axis_tready(parser_pay_ready),
    .s_ip_payload_axis_tlast(ptr_reg == (n_reg - 10'd1)),
    .s_ip_payload_axis_tuser(1'b0),

    .m_udp_hdr_ready(1'b1),

    .m_udp_payload_axis_tdata(parser_m_data),
    .m_udp_payload_axis_tvalid(parser_m_valid),
    .m_udp_payload_axis_tready(m_ready),
    .m_udp_payload_axis_tlast(parser_m_last),
    .m_udp_payload_axis_tuser()
);

endmodule
