`timescale 1ns/1ps
module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error
);

reg [7:0] buf_mem[0:511];

reg [9:0] rx_count_reg;
reg in_frame_reg;
reg oversize_reg;
reg busy_out_reg;

reg status_valid_reg;
reg [3:0] status_error_reg;

reg m_valid_reg;
reg [7:0] m_data_reg;
reg m_last_reg;
reg [31:0] m_src_ip_reg;
reg [15:0] m_src_port_reg;
reg [15:0] m_dst_port_reg;
reg [15:0] m_payload_len_reg;

reg [15:0] out_index_reg;

reg [3:0] calc_error;
reg [15:0] calc_frame_len;
reg [15:0] calc_ip_total_len;
reg [15:0] calc_udp_len;
reg [15:0] calc_payload_len;
reg [31:0] calc_src_ip;
reg [31:0] calc_dst_ip;
reg [15:0] calc_src_port;
reg [15:0] calc_dst_port;
reg [15:0] calc_udp_checksum;
reg [31:0] sum32;
reg [31:0] folded;
reg [15:0] word16;
integer i;

function [31:0] fold16;
    input [31:0] x;
    reg [31:0] t;
    begin
        t = x;
        t = (t[15:0] + t[31:16]);
        t = (t[15:0] + t[31:16]);
        t = (t[15:0] + t[31:16]);
        fold16 = t;
    end
endfunction

always @* begin
    calc_frame_len = rx_count_reg + 16'd1;

    calc_ip_total_len = {buf_mem[2], buf_mem[3]};
    calc_udp_len = {buf_mem[24], buf_mem[25]};
    calc_payload_len = calc_udp_len - 16'd8;
    calc_src_ip = {buf_mem[12], buf_mem[13], buf_mem[14], buf_mem[15]};
    calc_dst_ip = {buf_mem[16], buf_mem[17], buf_mem[18], buf_mem[19]};
    calc_src_port = {buf_mem[20], buf_mem[21]};
    calc_dst_port = {buf_mem[22], buf_mem[23]};
    calc_udp_checksum = {buf_mem[26], buf_mem[27]};

    calc_error = 4'd0;

    if (calc_frame_len < 16'd28 ||
        oversize_reg ||
        buf_mem[0][7:4] != 4'd4 ||
        buf_mem[0][3:0] != 4'd5 ||
        buf_mem[9] != 8'd17 ||
        buf_mem[6][5] != 1'b0 ||
        {buf_mem[6][4:0], buf_mem[7]} != 13'd0) begin
        calc_error = 4'd1;
    end else if (calc_ip_total_len != calc_frame_len ||
                 calc_udp_len != (calc_ip_total_len - 16'd20) ||
                 calc_payload_len < 16'd1 ||
                 calc_payload_len > 16'd256) begin
        calc_error = 4'd2;
    end else begin
        sum32 = 32'd0;
        for (i = 0; i < 20; i = i + 2) begin
            sum32 = sum32 + {buf_mem[i], buf_mem[i+1]};
        end
        folded = fold16(sum32);
        if (folded[15:0] != 16'hffff) begin
            calc_error = 4'd3;
        end else begin
            if (calc_udp_checksum != 16'd0) begin
                sum32 = 32'd0;
                sum32 = sum32 + {buf_mem[12], buf_mem[13]};
                sum32 = sum32 + {buf_mem[14], buf_mem[15]};
                sum32 = sum32 + {buf_mem[16], buf_mem[17]};
                sum32 = sum32 + {buf_mem[18], buf_mem[19]};
                sum32 = sum32 + 32'h0011;
                sum32 = sum32 + calc_udp_len;

                for (i = 20; i < 512; i = i + 2) begin
                    if (i < (20 + calc_udp_len)) begin
                        if ((i + 1) < (20 + calc_udp_len)) begin
                            word16 = {buf_mem[i], buf_mem[i+1]};
                        end else begin
                            word16 = {buf_mem[i], 8'h00};
                        end
                        sum32 = sum32 + word16;
                    end
                end

                folded = fold16(sum32);
                if (folded[15:0] != 16'hffff) begin
                    calc_error = 4'd4;
                end else if (calc_dst_ip != 32'h0a000002 || calc_dst_port != 16'd9000) begin
                    calc_error = 4'd5;
                end
            end else if (calc_dst_ip != 32'h0a000002 || calc_dst_port != 16'd9000) begin
                calc_error = 4'd5;
            end
        end
    end
end

assign s_ready = !busy_out_reg;
assign m_data = m_data_reg;
assign m_valid = m_valid_reg;
assign m_last = m_last_reg;
assign m_src_ip = m_src_ip_reg;
assign m_src_port = m_src_port_reg;
assign m_dst_port = m_dst_port_reg;
assign m_payload_len = m_payload_len_reg;
assign status_valid = status_valid_reg;
assign status_error = status_error_reg;

always @(posedge clk) begin
    if (rst) begin
        rx_count_reg <= 10'd0;
        in_frame_reg <= 1'b0;
        oversize_reg <= 1'b0;
        busy_out_reg <= 1'b0;

        status_valid_reg <= 1'b0;
        status_error_reg <= 4'd0;

        m_valid_reg <= 1'b0;
        m_data_reg <= 8'd0;
        m_last_reg <= 1'b0;
        m_src_ip_reg <= 32'd0;
        m_src_port_reg <= 16'd0;
        m_dst_port_reg <= 16'd0;
        m_payload_len_reg <= 16'd0;
        out_index_reg <= 16'd0;
    end else begin
        status_valid_reg <= 1'b0;

        if (m_valid_reg && m_ready) begin
            if (m_last_reg) begin
                m_valid_reg <= 1'b0;
                m_last_reg <= 1'b0;
                busy_out_reg <= 1'b0;
                rx_count_reg <= 10'd0;
                in_frame_reg <= 1'b0;
                oversize_reg <= 1'b0;
            end else begin
                out_index_reg <= out_index_reg + 16'd1;
                m_data_reg <= buf_mem[28 + out_index_reg + 16'd1];
                m_last_reg <= ((out_index_reg + 16'd1) == (m_payload_len_reg - 16'd1));
            end
        end

        if (s_valid && s_ready) begin
            if (!in_frame_reg) begin
                rx_count_reg <= 10'd0;
                oversize_reg <= 1'b0;
                in_frame_reg <= 1'b1;
            end

            if (rx_count_reg < 10'd512) begin
                buf_mem[rx_count_reg] <= s_data;
            end else begin
                oversize_reg <= 1'b1;
            end

            if (rx_count_reg == 10'd511) begin
                oversize_reg <= 1'b1;
            end

            if (s_last) begin
                status_valid_reg <= 1'b1;
                status_error_reg <= calc_error;

                if (calc_error == 4'd0) begin
                    busy_out_reg <= 1'b1;
                    m_src_ip_reg <= calc_src_ip;
                    m_src_port_reg <= calc_src_port;
                    m_dst_port_reg <= calc_dst_port;
                    m_payload_len_reg <= calc_payload_len;
                    out_index_reg <= 16'd0;
                    m_data_reg <= buf_mem[28];
                    m_last_reg <= (calc_payload_len == 16'd1);
                    m_valid_reg <= 1'b1;
                end else begin
                    busy_out_reg <= 1'b0;
                    m_valid_reg <= 1'b0;
                    m_last_reg <= 1'b0;
                    rx_count_reg <= 10'd0;
                    in_frame_reg <= 1'b0;
                    oversize_reg <= 1'b0;
                end
            end else begin
                if (rx_count_reg < 10'd512) begin
                    rx_count_reg <= rx_count_reg + 10'd1;
                end
            end
        end
    end
end

endmodule
