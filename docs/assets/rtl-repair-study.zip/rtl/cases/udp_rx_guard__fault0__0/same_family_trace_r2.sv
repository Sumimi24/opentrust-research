module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error
);

reg [7:0] frame_mem[0:511];

reg [9:0] frame_len_reg;
reg oversize_reg;
reg holdoff_reg;

reg status_valid_reg;
reg [3:0] status_error_reg;

reg out_valid_reg;
reg [7:0] out_data_reg;
reg out_last_reg;
reg [31:0] out_src_ip_reg;
reg [15:0] out_src_port_reg;
reg [15:0] out_dst_port_reg;
reg [15:0] out_payload_len_reg;
reg [8:0] out_ptr_reg;

reg [31:0] src_ip_reg;
reg [15:0] src_port_reg;
reg [15:0] dst_port_reg;
reg [15:0] payload_len_reg;

reg [3:0] error_code_calc;
reg [15:0] ip_total_length_calc;
reg [15:0] udp_length_calc;
reg [15:0] udp_checksum_calc;
reg [15:0] payload_length_calc;
reg [31:0] src_ip_calc;
reg [31:0] dst_ip_calc;
reg [15:0] src_port_calc;
reg [15:0] dst_port_calc;
reg [31:0] ip_sum_calc;
reg [31:0] udp_sum_calc;
reg [31:0] tmp_sum;
reg [15:0] word16;
integer i;

function [31:0] fold_sum32;
    input [31:0] x;
    reg [31:0] t;
    begin
        t = x;
        t = (t[15:0] + t[31:16]);
        t = (t[15:0] + t[31:16]);
        t = (t[15:0] + t[31:16]);
        fold_sum32 = t;
    end
endfunction

always @* begin
    ip_total_length_calc = {frame_mem[2], frame_mem[3]};
    src_ip_calc = {frame_mem[12], frame_mem[13], frame_mem[14], frame_mem[15]};
    dst_ip_calc = {frame_mem[16], frame_mem[17], frame_mem[18], frame_mem[19]};
    src_port_calc = {frame_mem[20], frame_mem[21]};
    dst_port_calc = {frame_mem[22], frame_mem[23]};
    udp_length_calc = {frame_mem[24], frame_mem[25]};
    udp_checksum_calc = {frame_mem[26], frame_mem[27]};
    payload_length_calc = udp_length_calc - 16'd8;

    error_code_calc = 4'd0;

    if (frame_len_reg < 10'd28 ||
        oversize_reg ||
        frame_mem[0][7:4] != 4'd4 ||
        frame_mem[0][3:0] != 4'd5 ||
        frame_mem[9] != 8'd17 ||
        frame_mem[6][5] != 1'b0 ||
        {frame_mem[6][4:0], frame_mem[7]} != 13'd0) begin
        error_code_calc = 4'd1;
    end else if (ip_total_length_calc != frame_len_reg ||
                 udp_length_calc != (ip_total_length_calc - 16'd20) ||
                 payload_length_calc < 16'd1 ||
                 payload_length_calc > 16'd256) begin
        error_code_calc = 4'd2;
    end else begin
        ip_sum_calc = 32'd0;
        for (i = 0; i < 20; i = i + 2) begin
            ip_sum_calc = ip_sum_calc + {frame_mem[i], frame_mem[i+1]};
        end
        if (fold_sum32(ip_sum_calc) != 32'h0000ffff) begin
            error_code_calc = 4'd3;
        end else begin
            if (udp_checksum_calc != 16'd0) begin
                udp_sum_calc = 32'd0;
                udp_sum_calc = udp_sum_calc + {frame_mem[12], frame_mem[13]};
                udp_sum_calc = udp_sum_calc + {frame_mem[14], frame_mem[15]};
                udp_sum_calc = udp_sum_calc + {frame_mem[16], frame_mem[17]};
                udp_sum_calc = udp_sum_calc + {frame_mem[18], frame_mem[19]};
                udp_sum_calc = udp_sum_calc + 32'h0011;
                udp_sum_calc = udp_sum_calc + udp_length_calc;

                for (i = 20; i < 532; i = i + 2) begin
                    if (i < (20 + udp_length_calc)) begin
                        if ((i + 1) < (20 + udp_length_calc))
                            word16 = {frame_mem[i], frame_mem[i+1]};
                        else
                            word16 = {frame_mem[i], 8'h00};
                        udp_sum_calc = udp_sum_calc + word16;
                    end
                end

                if (fold_sum32(udp_sum_calc) != 32'h0000ffff)
                    error_code_calc = 4'd4;
                else if (dst_ip_calc != 32'h0a000002 || dst_port_calc != 16'd9000)
                    error_code_calc = 4'd5;
            end else begin
                if (dst_ip_calc != 32'h0a000002 || dst_port_calc != 16'd9000)
                    error_code_calc = 4'd5;
            end
        end
    end
end

assign s_ready = !holdoff_reg;
assign m_data = out_data_reg;
assign m_valid = out_valid_reg;
assign m_last = out_last_reg;
assign m_src_ip = out_src_ip_reg;
assign m_src_port = out_src_port_reg;
assign m_dst_port = out_dst_port_reg;
assign m_payload_len = out_payload_len_reg;
assign status_valid = status_valid_reg;
assign status_error = status_error_reg;

always @(posedge clk) begin
    if (rst) begin
        frame_len_reg <= 10'd0;
        oversize_reg <= 1'b0;
        holdoff_reg <= 1'b0;
        status_valid_reg <= 1'b0;
        status_error_reg <= 4'd0;
        out_valid_reg <= 1'b0;
        out_data_reg <= 8'd0;
        out_last_reg <= 1'b0;
        out_src_ip_reg <= 32'd0;
        out_src_port_reg <= 16'd0;
        out_dst_port_reg <= 16'd0;
        out_payload_len_reg <= 16'd0;
        out_ptr_reg <= 9'd0;
        src_ip_reg <= 32'd0;
        src_port_reg <= 16'd0;
        dst_port_reg <= 16'd0;
        payload_len_reg <= 16'd0;
    end else begin
        status_valid_reg <= 1'b0;

        if (out_valid_reg) begin
            if (m_ready) begin
                if (out_last_reg) begin
                    out_valid_reg <= 1'b0;
                    out_last_reg <= 1'b0;
                    holdoff_reg <= 1'b0;
                end else begin
                    out_ptr_reg <= out_ptr_reg + 9'd1;
                    out_data_reg <= frame_mem[28 + out_ptr_reg + 9'd1];
                    out_last_reg <= ((out_ptr_reg + 9'd1) == (payload_len_reg - 16'd1));
                end
            end
        end

        if (s_valid && s_ready) begin
            if (frame_len_reg < 10'd512)
                frame_mem[frame_len_reg] <= s_data;
            else
                oversize_reg <= 1'b1;

            if (frame_len_reg == 10'd511)
                oversize_reg <= 1'b1;

            if (frame_len_reg < 10'd512)
                frame_len_reg <= frame_len_reg + 10'd1;

            if (s_last) begin
                status_valid_reg <= 1'b1;
                status_error_reg <= error_code_calc;
                src_ip_reg <= src_ip_calc;
                src_port_reg <= src_port_calc;
                dst_port_reg <= dst_port_calc;
                payload_len_reg <= payload_length_calc;

                if (error_code_calc == 4'd0) begin
                    holdoff_reg <= 1'b1;
                    out_src_ip_reg <= src_ip_calc;
                    out_src_port_reg <= src_port_calc;
                    out_dst_port_reg <= dst_port_calc;
                    out_payload_len_reg <= payload_length_calc;
                    out_ptr_reg <= 9'd0;
                    out_data_reg <= frame_mem[28];
                    out_last_reg <= (payload_length_calc == 16'd1);
                    out_valid_reg <= 1'b1;
                end else begin
                    holdoff_reg <= 1'b0;
                    out_valid_reg <= 1'b0;
                    out_last_reg <= 1'b0;
                end

                if (!(error_code_calc == 4'd0))
                    frame_len_reg <= 10'd0;
                else
                    frame_len_reg <= frame_len_reg + 10'd1;

                if (!(error_code_calc == 4'd0))
                    oversize_reg <= 1'b0;
            end
        end

        if (!holdoff_reg && !out_valid_reg && !(s_valid && s_ready && s_last)) begin
            if (!s_valid || !s_ready) begin
                if (frame_len_reg != 10'd0 && !holdoff_reg) begin
                end
            end
        end

        if (!holdoff_reg && !out_valid_reg && frame_len_reg != 10'd0 && !(s_valid && s_ready)) begin
        end

        if (!holdoff_reg && !out_valid_reg && status_valid_reg && status_error_reg != 4'd0) begin
            frame_len_reg <= 10'd0;
            oversize_reg <= 1'b0;
        end

        if (!holdoff_reg && !out_valid_reg && !status_valid_reg && frame_len_reg != 10'd0) begin
        end

        if (!holdoff_reg && !out_valid_reg && frame_len_reg != 10'd0 && status_valid_reg == 1'b0) begin
        end

        if (!holdoff_reg && !out_valid_reg && frame_len_reg != 10'd0 && !(s_valid && s_ready && !s_last)) begin
        end

        if (!holdoff_reg && !out_valid_reg && frame_len_reg != 10'd0 && !(s_valid && s_ready && s_last)) begin
        end

        if (!holdoff_reg && !out_valid_reg && frame_len_reg != 10'd0 && status_valid_reg && status_error_reg == 4'd0) begin
        end

        if (!holdoff_reg && !out_valid_reg && frame_len_reg != 10'd0 && !holdoff_reg && !out_valid_reg && status_valid_reg == 1'b0) begin
        end

        if (!holdoff_reg && !out_valid_reg && frame_len_reg != 10'd0) begin
            if (!(s_valid && s_ready)) begin
            end
        end

        if (!holdoff_reg && !out_valid_reg && frame_len_reg != 10'd0 && status_valid_reg && status_error_reg != 4'd0) begin
            frame_len_reg <= 10'd0;
            oversize_reg <= 1'b0;
        end

        if (!holdoff_reg && !out_valid_reg && frame_len_reg != 10'd0 && !status_valid_reg && !(s_valid && s_ready && s_last)) begin
        end

        if (!holdoff_reg && !out_valid_reg && status_valid_reg && status_error_reg == 4'd0) begin
        end

        if (!holdoff_reg && !out_valid_reg && !status_valid_reg && frame_len_reg == 10'd0) begin
        end

        if (!holdoff_reg && !out_valid_reg && status_valid_reg && status_error_reg != 4'd0) begin
            frame_len_reg <= 10'd0;
            oversize_reg <= 1'b0;
        end

        if (!holdoff_reg && !out_valid_reg && status_valid_reg && status_error_reg == 4'd0) begin
        end

        if (!out_valid_reg && !holdoff_reg && frame_len_reg != 10'd0 && !(s_valid && s_ready)) begin
        end

        if (!out_valid_reg && !holdoff_reg && frame_len_reg != 10'd0 && status_valid_reg && status_error_reg != 4'd0) begin
            frame_len_reg <= 10'd0;
            oversize_reg <= 1'b0;
        end

        if (!holdoff_reg && !out_valid_reg && frame_len_reg != 10'd0 && status_valid_reg && status_error_reg != 4'd0) begin
            frame_len_reg <= 10'd0;
            oversize_reg <= 1'b0;
        end

        if (!holdoff_reg && !out_valid_reg && frame_len_reg != 10'd0 && !(s_valid && s_ready && !s_last) && !status_valid_reg) begin
        end

        if (!holdoff_reg && !out_valid_reg && frame_len_reg != 10'd0 && !(s_valid && s_ready && s_last) && !status_valid_reg) begin
        end

        if (!holdoff_reg && !out_valid_reg && frame_len_reg != 10'd0 && status_valid_reg && status_error_reg != 4'd0) begin
            frame_len_reg <= 10'd0;
            oversize_reg <= 1'b0;
        end

        if (!holdoff_reg && !out_valid_reg && frame_len_reg != 10'd0 && !status_valid_reg) begin
        end

        if (!holdoff_reg && !out_valid_reg && frame_len_reg != 10'd0 && status_valid_reg == 1'b0) begin
        end

        if (!holdoff_reg && !out_valid_reg && frame_len_reg != 10'd0 && status_valid_reg && status_error_reg != 4'd0) begin
            frame_len_reg <= 10'd0;
            oversize_reg <= 1'b0;
        end
    end
end

endmodule
