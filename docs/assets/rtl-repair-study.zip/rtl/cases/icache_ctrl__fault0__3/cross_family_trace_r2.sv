module icache_ctrl(
input wire clk_i,
input wire rst_ni,
input wire req_i,
input wire branch_i,
input wire [31:0] addr_i,
input wire ready_i,
output wire valid_o,
output wire [31:0] rdata_o,
output wire [31:0] addr_o,
output wire err_o,
output wire instr_req_o,
input wire instr_gnt_i,
output wire [31:0] instr_addr_o,
input wire [31:0] instr_rdata_i,
input wire instr_err_i,
input wire instr_rvalid_i,
input wire icache_inval_i,
output wire busy_o);

localparam integer REGION_WORDS = 8;
localparam integer CACHE_LINES  = 16;
localparam integer FIFO_DEPTH   = 32;
localparam integer FIFO_W       = 5;
localparam integer REGION_IDX_W = 3;
localparam integer CACHE_IDX_W  = 4;

reg [31:0] base_pc_q;
reg        stream_valid_q;
reg        poison_q;

reg        out_valid_q;
reg [31:0] out_data_q;
reg [31:0] out_addr_q;
reg        out_err_q;

reg        inval_pending_q;

reg [31:0] req_addr_mem [0:FIFO_DEPTH-1];
reg [31:0] rsp_addr_q;
reg [31:0] rsp_data_q;
reg        rsp_err_q;
reg        rsp_valid_q;

reg [FIFO_W-1:0] fifo_wr_q;
reg [FIFO_W-1:0] fifo_rd_q;
reg [FIFO_W:0]   fifo_count_q;

reg [31:0] cache_data_q [0:CACHE_LINES-1];
reg [27:0] cache_tag_q  [0:CACHE_LINES-1];
reg        cache_valid_q[0:CACHE_LINES-1];

reg [27:0] region_tag_q;
reg [31:0] region_data_q [0:REGION_WORDS-1];
reg [REGION_WORDS-1:0] region_valid_q;
reg        region_active_q;

wire out_fire = out_valid_q & ready_i & ~branch_i;

wire [31:0] branch_addr_aligned = {addr_i[31:2], 2'b00};

wire [31:0] next_seq_addr = out_fire ? (out_addr_q + 32'd4) : out_addr_q;

wire [CACHE_IDX_W-1:0] lookup_idx =
    next_seq_addr[2 +: CACHE_IDX_W];
wire [27:0] lookup_tag =
    next_seq_addr[31:4];
wire cache_hit =
    cache_valid_q[lookup_idx] && (cache_tag_q[lookup_idx] == lookup_tag);

wire region_hit =
    region_active_q &&
    (region_tag_q == next_seq_addr[31:5]) &&
    region_valid_q[next_seq_addr[4:2]];

wire can_fill_output =
    stream_valid_q &&
    ~poison_q &&
    ~out_valid_q &&
    (region_hit || cache_hit || rsp_valid_q);

wire [31:0] fill_data =
    region_hit ? region_data_q[next_seq_addr[4:2]] :
    cache_hit  ? cache_data_q[lookup_idx] :
                 rsp_data_q;

wire [31:0] fill_addr =
    region_hit ? next_seq_addr :
    cache_hit  ? next_seq_addr :
                 rsp_addr_q;

wire fill_err =
    region_hit ? 1'b0 :
    cache_hit  ? 1'b0 :
                 rsp_err_q;

wire [31:0] prefetch_addr =
    out_valid_q ? (out_addr_q + 32'd4) :
    stream_valid_q ? base_pc_q :
    32'h0000_0000;

wire [CACHE_IDX_W-1:0] prefetch_idx =
    prefetch_addr[2 +: CACHE_IDX_W];
wire [27:0] prefetch_tag =
    prefetch_addr[31:4];
wire prefetch_cache_hit =
    cache_valid_q[prefetch_idx] && (cache_tag_q[prefetch_idx] == prefetch_tag);
wire prefetch_region_hit =
    region_active_q &&
    (region_tag_q == prefetch_addr[31:5]) &&
    region_valid_q[prefetch_addr[4:2]];

wire can_request =
    req_i &&
    stream_valid_q &&
    ~poison_q &&
    (fifo_count_q < FIFO_DEPTH) &&
    ~rsp_valid_q &&
    ~out_valid_q &&
    ~prefetch_cache_hit &&
    ~prefetch_region_hit &&
    ~inval_pending_q;

assign valid_o = out_valid_q;
assign rdata_o = out_data_q;
assign addr_o  = out_addr_q;
assign err_o   = out_err_q;

assign instr_req_o  = can_request;
assign instr_addr_o = {prefetch_addr[31:2], 2'b00};

assign busy_o = (fifo_count_q != 0) | rsp_valid_q | out_valid_q | inval_pending_q;

integer i;
always @(negedge rst_ni or posedge clk_i) begin
    if (!rst_ni) begin
        base_pc_q       <= 32'h0000_0000;
        stream_valid_q  <= 1'b0;
        poison_q        <= 1'b0;
        out_valid_q     <= 1'b0;
        out_data_q      <= 32'h0000_0000;
        out_addr_q      <= 32'h0000_0000;
        out_err_q       <= 1'b0;
        inval_pending_q <= 1'b0;
        rsp_addr_q      <= 32'h0000_0000;
        rsp_data_q      <= 32'h0000_0000;
        rsp_err_q       <= 1'b0;
        rsp_valid_q     <= 1'b0;
        fifo_wr_q       <= {FIFO_W{1'b0}};
        fifo_rd_q       <= {FIFO_W{1'b0}};
        fifo_count_q    <= {(FIFO_W+1){1'b0}};
        region_tag_q    <= 28'h0;
        region_valid_q  <= {REGION_WORDS{1'b0}};
        region_active_q <= 1'b0;
        for (i = 0; i < CACHE_LINES; i = i + 1) begin
            cache_data_q[i]  <= 32'h0000_0000;
            cache_tag_q[i]   <= 28'h0;
            cache_valid_q[i] <= 1'b0;
        end
        for (i = 0; i < REGION_WORDS; i = i + 1) begin
            region_data_q[i] <= 32'h0000_0000;
        end
    end else begin
        if (icache_inval_i) begin
            inval_pending_q <= 1'b1;
        end

        if (branch_i) begin
            base_pc_q      <= branch_addr_aligned;
            stream_valid_q <= 1'b1;
            poison_q       <= 1'b0;
            out_valid_q    <= 1'b0;
            out_err_q      <= 1'b0;
            rsp_valid_q    <= 1'b0;
            fifo_rd_q      <= fifo_wr_q;
            fifo_count_q   <= {FIFO_W+1{1'b0}};
            if (region_active_q && (region_tag_q != branch_addr_aligned[31:5])) begin
                region_active_q <= region_active_q;
            end
        end else begin
            if (out_fire) begin
                if (out_err_q) begin
                    poison_q    <= 1'b1;
                    out_valid_q <= 1'b0;
                end else begin
                    out_valid_q <= 1'b0;
                    base_pc_q   <= out_addr_q + 32'd4;
                end
            end

            if (instr_req_o && instr_gnt_i) begin
                req_addr_mem[fifo_wr_q] <= instr_addr_o;
                fifo_wr_q <= fifo_wr_q + {{(FIFO_W-1){1'b0}},1'b1};
                fifo_count_q <= fifo_count_q + {{FIFO_W{1'b0}},1'b1};
            end

            if (instr_rvalid_i && (fifo_count_q != 0)) begin
                rsp_addr_q   <= req_addr_mem[fifo_rd_q];
                rsp_data_q   <= instr_rdata_i;
                rsp_err_q    <= instr_err_i;
                rsp_valid_q  <= 1'b1;
                fifo_rd_q    <= fifo_rd_q + {{(FIFO_W-1){1'b0}},1'b1};
                fifo_count_q <= fifo_count_q - {{FIFO_W{1'b0}},1'b1};

                cache_data_q[req_addr_mem[fifo_rd_q][2 +: CACHE_IDX_W]]  <= instr_rdata_i;
                cache_tag_q [req_addr_mem[fifo_rd_q][2 +: CACHE_IDX_W]]  <= req_addr_mem[fifo_rd_q][31:4];
                cache_valid_q[req_addr_mem[fifo_rd_q][2 +: CACHE_IDX_W]] <= ~instr_err_i & ~inval_pending_q;

                if (~instr_err_i) begin
                    if (!region_active_q || (region_tag_q != req_addr_mem[fifo_rd_q][31:5])) begin
                        region_tag_q    <= req_addr_mem[fifo_rd_q][31:5];
                        region_valid_q  <= (8'b0000_0001 << req_addr_mem[fifo_rd_q][4:2]);
                        region_data_q[req_addr_mem[fifo_rd_q][4:2]] <= instr_rdata_i;
                        region_active_q <= 1'b1;
                    end else begin
                        region_valid_q[req_addr_mem[fifo_rd_q][4:2]] <= 1'b1;
                        region_data_q[req_addr_mem[fifo_rd_q][4:2]] <= instr_rdata_i;
                    end
                end
            end

            if (can_fill_output) begin
                out_valid_q <= 1'b1;
                out_data_q  <= fill_data;
                out_addr_q  <= fill_addr;
                out_err_q   <= fill_err;
                if (rsp_valid_q && ~region_hit && ~cache_hit) begin
                    rsp_valid_q <= 1'b0;
                end
            end

            if (inval_pending_q && (fifo_count_q == 0) && ~rsp_valid_q && ~out_valid_q) begin
                inval_pending_q <= 1'b0;
                region_valid_q  <= {REGION_WORDS{1'b0}};
                region_active_q <= 1'b0;
                for (i = 0; i < CACHE_LINES; i = i + 1) begin
                    cache_valid_q[i] <= 1'b0;
                end
            end
        end
    end
end

endmodule
