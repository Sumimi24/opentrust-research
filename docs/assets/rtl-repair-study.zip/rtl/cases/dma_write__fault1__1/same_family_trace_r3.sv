`timescale 1ns / 1ps
`default_nettype none

module dma_write(
input wire clk,
input wire rst,
input wire [15:0] desc_addr,
input wire [15:0] desc_len,
input wire [7:0] desc_tag,
input wire desc_valid,
output wire desc_ready,
input wire [31:0] s_data,
input wire [3:0] s_keep,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [15:0] status_len,
output wire [7:0] status_tag,
output wire [3:0] status_error,
output wire status_valid,
output wire [3:0] m_axi_awid,
output wire [15:0] m_axi_awaddr,
output wire [7:0] m_axi_awlen,
output wire [2:0] m_axi_awsize,
output wire [1:0] m_axi_awburst,
output wire m_axi_awlock,
output wire [3:0] m_axi_awcache,
output wire [2:0] m_axi_awprot,
output wire m_axi_awvalid,
input wire m_axi_awready,
output wire [31:0] m_axi_wdata,
output wire [3:0] m_axi_wstrb,
output wire m_axi_wlast,
output wire m_axi_wvalid,
input wire m_axi_wready,
input wire [3:0] m_axi_bid,
input wire [1:0] m_axi_bresp,
input wire m_axi_bvalid,
output wire m_axi_bready);

reg [2:0] state;
localparam S_IDLE = 3'd0, S_RUN = 3'd1, S_WAIT_B = 3'd2, S_DONE = 3'd3;

reg [15:0] r_desc_addr;
reg [15:0] r_desc_len;
reg [7:0]  r_desc_tag;
reg [15:0] r_bytes_left;
reg [3:0]  r_err;
reg        r_status_valid;

reg aw_sent;
reg [7:0] burst_beats_reg;
reg [15:0] beat_count;
reg last_burst;
reg b_pending;

wire [15:0] w_total_beats = (r_desc_len + 16'd3) >> 2;
wire [15:0] w_offset      = r_desc_len - r_bytes_left;
wire [15:0] w_beat_idx    = w_offset >> 2;
wire [15:0] w_remaining   = w_total_beats - w_beat_idx;

wire [15:0] w_page_rem    = 16'd1024 - (r_desc_addr[15:2] & 16'h03FF);
wire [15:0] w_max_burst   = (w_remaining < 16'd16) ? w_remaining : 16'd16;
wire [15:0] w_burst_beats_calc = (w_max_burst < w_page_rem) ? w_max_burst : w_page_rem;
wire [7:0]  w_awlen_calc  = w_burst_beats_calc[7:0] - 8'd1;
wire [15:0] w_awaddr_calc = r_desc_addr + {w_beat_idx[13:0], 2'b00};
wire        w_all_done_calc = (w_beat_idx + w_burst_beats_calc >= w_total_beats);

wire [1:0]  w_lane_off    = r_desc_addr[1:0];
wire [3:0]  w_first_mask  = 4'hF << w_lane_off;
wire [1:0]  w_end_off     = (r_desc_addr[1:0] + r_desc_len[1:0]) & 2'd3;
wire [3:0]  w_last_mask   = (w_end_off == 2'd0) ? 4'hF : ((4'd1 << w_end_off) - 4'd1);

wire        w_is_first    = (w_beat_idx == 16'd0);
wire        w_is_last     = last_burst && (beat_count == burst_beats_reg - 8'd1);

wire aw_handshake = m_axi_awvalid && m_axi_awready;
wire w_handshake  = m_axi_wvalid && m_axi_wready;

assign desc_ready       = (state == S_IDLE);
assign status_len       = r_desc_len;
assign status_tag       = r_desc_tag;
assign status_error     = r_err;
assign status_valid     = r_status_valid;

assign m_axi_awid       = 4'd0;
assign m_axi_awaddr     = w_awaddr_calc;
assign m_axi_awlen      = w_awlen_calc;
assign m_axi_awsize     = 3'd2;
assign m_axi_awburst    = 2'b01;
assign m_axi_awlock     = 1'b0;
assign m_axi_awcache    = 4'd3;
assign m_axi_awprot     = 3'd0;
assign m_axi_awvalid    = (state == S_RUN) && !aw_sent;

assign m_axi_wdata      = s_data;
assign m_axi_wstrb      = (w_is_first && last_burst) ? (s_keep & w_first_mask & w_last_mask)
                        : w_is_first                   ? (s_keep & w_first_mask)
                        : last_burst && (beat_count == burst_beats_reg - 8'd1) ? (s_keep & w_last_mask)
                        : s_keep;
assign m_axi_wlast      = w_is_last;
assign m_axi_wvalid     = (state == S_RUN) && aw_sent && s_valid;

assign s_ready          = (state == S_RUN) && aw_sent && m_axi_wready;

assign m_axi_bready     = (state == S_RUN || state == S_WAIT_B || state == S_DONE);

always @(posedge clk) begin
    if (rst) begin
        state          <= S_IDLE;
        r_desc_addr    <= 16'd0;
        r_desc_len     <= 16'd0;
        r_desc_tag     <= 8'd0;
        r_bytes_left   <= 16'd0;
        r_err          <= 4'd0;
        r_status_valid <= 1'b0;
        aw_sent        <= 1'b0;
        burst_beats_reg<= 8'd0;
        beat_count     <= 16'd0;
        last_burst     <= 1'b0;
        b_pending      <= 1'b0;
    end else begin
        r_status_valid <= 1'b0;
        case (state)
            S_IDLE: begin
                aw_sent    <= 1'b0;
                beat_count <= 16'd0;
                b_pending  <= 1'b0;
                if (desc_valid && desc_ready) begin
                    r_desc_addr  <= desc_addr;
                    r_desc_len   <= desc_len;
                    r_desc_tag   <= desc_tag;
                    r_bytes_left <= desc_len;
                    r_err        <= 4'd0;
                    state        <= S_RUN;
                end
            end
            S_RUN: begin
                if (m_axi_bvalid && m_axi_bready) begin
                    if (m_axi_bresp == 2'b11)
                        r_err <= 4'd7;
                    else if (m_axi_bresp == 2'b10 && r_err != 4'd7)
                        r_err <= 4'd6;
                    b_pending <= 1'b0;
                end
                if (!aw_sent) begin
                    if (aw_handshake) begin
                        aw_sent         <= 1'b1;
                        burst_beats_reg <= w_burst_beats_calc[7:0];
                        last_burst      <= w_all_done_calc;
                        beat_count      <= 16'd0;
                        b_pending       <= 1'b1;
                    end
                end else begin
                    if (w_handshake) begin
                        if (beat_count == burst_beats_reg - 8'd1) begin
                            if (last_burst) begin
                                if (b_pending && !(m_axi_bvalid && m_axi_bready))
                                    state <= S_WAIT_B;
                                else
                                    state <= S_DONE;
                            end else begin
                                aw_sent      <= 1'b0;
                                r_bytes_left <= r_bytes_left - {burst_beats_reg[5:0], 2'b00};
                                beat_count   <= 16'd0;
                            end
                        end else begin
                            beat_count <= beat_count + 16'd1;
                        end
                    end
                end
            end
            S_WAIT_B: begin
                if (m_axi_bvalid && m_axi_bready) begin
                    if (m_axi_bresp == 2'b11)
                        r_err <= 4'd7;
                    else if (m_axi_bresp == 2'b10 && r_err != 4'd7)
                        r_err <= 4'd6;
                    b_pending <= 1'b0;
                    state     <= S_DONE;
                end
            end
            S_DONE: begin
                r_status_valid <= 1'b1;
                state          <= S_IDLE;
            end
            default: state <= S_IDLE;
        endcase
    end
end

endmodule
