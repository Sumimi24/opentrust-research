`timescale 1ns / 1ps
`default_nettype none

module dma_write(
input wire clk,
input wire rst,
input wire [15:0] desc_addr,
input wire [15:0] desc_len,
input wire [7:0] desc_tag,
input wire desc_valid,
output wire desc_ready,
input wire [31:0] s_data,
input wire [3:0] s_keep,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [15:0] status_len,
output wire [7:0] status_tag,
output wire [3:0] status_error,
output wire status_valid,
output wire [3:0] m_axi_awid,
output wire [15:0] m_axi_awaddr,
output wire [7:0] m_axi_awlen,
output wire [2:0] m_axi_awsize,
output wire [1:0] m_axi_awburst,
output wire m_axi_awlock,
output wire [3:0] m_axi_awcache,
output wire [2:0] m_axi_awprot,
output wire m_axi_awvalid,
input wire m_axi_awready,
output wire [31:0] m_axi_wdata,
output wire [3:0] m_axi_wstrb,
output wire m_axi_wlast,
output wire m_axi_wvalid,
input wire m_axi_wready,
input wire [3:0] m_axi_bid,
input wire [1:0] m_axi_bresp,
input wire m_axi_bvalid,
output wire m_axi_bready);

// FSM states
localparam S_IDLE  = 3'd0;
localparam S_DATA  = 3'd1;  // Accepting stream data, issuing AW when possible
localparam S_WONLY = 3'd2;  // AW done, finishing W beats
localparam S_BWAIT = 3'd3;  // All data sent, waiting for B responses

reg [2:0] state, next_state;

// Descriptor registers
reg [15:0] r_desc_addr;
reg [15:0] r_desc_len;
reg [7:0]  r_desc_tag;
reg [15:0] r_bytes_remaining;  // bytes still to transfer
reg [15:0] r_bytes_sent;       // bytes sent on W channel

// Burst control
reg [15:0] r_burst_addr;       // aligned address for current burst
reg [7:0]  r_burst_beats;      // beats in current burst
reg [7:0]  r_beat_idx;         // current beat in burst (0-based)
reg        r_aw_done;          // AW handshake completed for this burst

// W channel registers
reg [31:0] r_wdata;
reg [3:0]  r_wstrb;
reg        r_wvalid;
reg        r_wlast;

// AW channel
reg        r_awvalid;

// Completion tracking
reg [7:0]  r_aw_sent_count;    // AWs issued, waiting for B
reg        r_status_valid;
reg [3:0]  r_error;

// Stream holding
reg [31:0] r_hold_data;
reg [3:0]  r_hold_keep;
reg        r_hold_last;
reg        r_hold_valid;

// Combinational
wire [15:0] w_total_beats = (r_desc_len + 16'd3) >> 2;
wire [15:0] w_beats_sent = r_bytes_sent >> 2;
wire [15:0] w_beats_remaining = w_total_beats - w_beats_sent;

wire [15:0] w_current_addr = r_desc_addr + r_bytes_sent;
wire [15:0] w_awaddr_aligned = {w_current_addr[15:2], 2'b00};
wire [1:0]  w_addr_offset = w_current_addr[1:0];

// Page boundary: 4096 bytes = 1024 words
wire [15:0] w_page_words = 16'd1024;
wire [15:0] w_words_in_page = w_page_words - (w_awaddr_aligned[15:2] & 16'h03FF);
wire [15:0] w_max_burst_beats = (w_beats_remaining < 16'd16) ? w_beats_remaining : 16'd16;
wire [15:0] w_burst_beats = (w_max_burst_beats < w_words_in_page) ? w_max_burst_beats : w_words_in_page;

wire        w_is_first_beat = (r_bytes_sent == 0);
wire        w_is_last_beat_of_desc = (r_bytes_sent + 16'd4 >= r_desc_len);
wire [1:0]  w_end_offset = (r_desc_addr[1:0] + r_desc_len[1:0]) & 2'd3;
wire [3:0]  w_last_mask = (w_end_offset == 2'd0) ? 4'hF : ((4'd1 << w_end_offset) - 4'd1);
wire [3:0]  w_first_mask = 4'hF << r_desc_addr[1:0];

// Have data ready from stream or hold register
wire        w_data_avail = r_hold_valid || (s_valid && (state == S_DATA || state == S_WONLY));
wire [31:0] w_data_val = r_hold_valid ? r_hold_data : s_data;
wire [3:0]  w_keep_val = r_hold_valid ? r_hold_keep : s_keep;
wire        w_last_val = r_hold_valid ? r_hold_last : s_last;

// Strobe computation
wire [3:0] w_strb_first = w_keep_val & w_first_mask;
wire [3:0] w_strb_last  = w_keep_val & w_last_mask;
wire [3:0] w_strb_mid   = w_keep_val;
wire [3:0] w_strb_calc = w_is_first_beat ? (w_is_last_beat_of_desc ? w_strb_first & w_last_mask : w_strb_first) :
                          (w_is_last_beat_of_desc ? w_strb_last : w_strb_mid);

// Outputs
assign desc_ready = (state == S_IDLE);
assign s_ready = (state == S_DATA || state == S_WONLY) && !r_hold_valid && r_wvalid && m_axi_wready;
assign status_len = r_desc_len;
assign status_tag = r_desc_tag;
assign status_error = r_error;
assign status_valid = r_status_valid;

assign m_axi_awid = 4'd0;
assign m_axi_awaddr = r_burst_addr;
assign m_axi_awlen = r_burst_beats - 8'd1;
assign m_axi_awsize = 3'd2;
assign m_axi_awburst = 2'b01;
assign m_axi_awlock = 1'b0;
assign m_axi_awcache = 4'd3;
assign m_axi_awprot = 3'd0;
assign m_axi_awvalid = r_awvalid;

assign m_axi_wdata = r_wdata;
assign m_axi_wstrb = r_wstrb;
assign m_axi_wlast = r_wlast;
assign m_axi_wvalid = r_wvalid;

assign m_axi_bready = 1'b1;

// Next state
always @(*) begin
    next_state = state;
    case (state)
        S_IDLE: begin
            if (desc_valid && desc_ready)
                next_state = S_DATA;
        end
        S_DATA: begin
            // Need to get first data, then can issue AW
            if (r_hold_valid || s_valid) begin
                // Have data, try to issue AW and W together or sequentially
                if (r_awvalid && m_axi_awready && r_wvalid && m_axi_wready) begin
                    // Both handshaked
                    if (r_burst_beats == 8'd1)
                        next_state = S_BWAIT;
                    else
                        next_state = S_WONLY;
                end else if (r_awvalid && m_axi_awready) begin
                    // AW done, still need W
                    next_state = S_WONLY;
                end else if (r_wvalid && m_axi_wready) begin
                    // W done, still need AW
                    // Stay in DATA, but AW should be pending
                end
            end
        end
        S_WONLY: begin
            // Finishing W beats
            if (r_wvalid && m_axi_wready && r_wlast) begin
                if (r_bytes_sent + 16'd4 >= r_desc_len)
                    next_state = S_BWAIT;
                else
                    next_state = S_DATA;
            end
        end
        S_BWAIT: begin
            if (r_aw_sent_count == 0)
                next_state = S_IDLE;
        end
    endcase
end

always @(posedge clk) begin
    if (rst) begin
        state <= S_IDLE;
        r_desc_addr <= 16'd0;
        r_desc_len <= 16'd0;
        r_desc_tag <= 8'd0;
        r_bytes_remaining <= 16'd0;
        r_bytes_sent <= 16'd0;
        r_burst_addr <= 16'd0;
        r_burst_beats <= 8'd0;
        r_beat_idx <= 8'd0;
        r_aw_done <= 1'b0;
        r_wdata <= 32'd0;
        r_wstrb <= 4'd0;
        r_wvalid <= 1'b0;
        r_wlast <= 1'b0;
        r_awvalid <= 1'b0;
        r_aw_sent_count <= 8'd0;
        r_status_valid <= 1'b0;
        r_error <= 4'd0;
        r_hold_valid <= 1'b0;
        r_hold_data <= 32'd0;
        r_hold_keep <= 4'd0;
        r_hold_last <= 1'b0;
    end else begin
        r_status_valid <= 1'b0;
        
        // B response handling
        if (m_axi_bvalid && m_axi_bready) begin
            if (m_axi_bresp == 2'b11)
                r_error <= 4'd7;
            else if (m_axi_bresp == 2'b10 && r_error != 4'd7)
                r_error <= 4'd6;
            if (r_aw_sent_count > 0)
                r_aw_sent_count <= r_aw_sent_count - 8'd1;
        end
        
        // Hold register management
        if (r_hold_valid) begin
            // Hold is consumed when W handshake happens
            if (r_wvalid && m_axi_wready) begin
                r_hold_valid <= 1'b0;
            end
        end else if ((state == S_DATA || state == S_WONLY) && s_valid && !r_wvalid) begin
            // Load from stream when we need data and W is idle
            r_hold_data <= s_data;
            r_hold_keep <= s_keep;
            r_hold_last <= s_last;
            r_hold_valid <= 1'b1;
        end
        
        case (state)
            S_IDLE: begin
                r_awvalid <= 1'b0;
                r_wvalid <= 1'b0;
                if (desc_valid && desc_ready) begin
                    r_desc_addr <= desc_addr;
                    r_desc_len <= desc_len;
                    r_desc_tag <= desc_tag;
                    r_bytes_sent <= 16'd0;
                    r_error <= 4'd0;
                    r_aw_sent_count <= 8'd0;
                    r_hold_valid <= 1'b0;
                end
            end
            
            S_DATA: begin
                // Plan burst when entering or when needed
                if (!r_awvalid && r_beat_idx == 0 && !r_wvalid) begin
                    r_burst_addr <= w_awaddr_aligned;
                    r_burst_beats <= w_burst_beats[7:0];
                    r_beat_idx <= 8'd0;
                    r_awvalid <= 1'b1;
                end
                
                // Load W data when available
                if (!r_wvalid && !r_hold_valid && s_valid) begin
                    // Direct from stream
                    r_wdata <= s_data;
                    r_wstrb <= w_strb_calc;
                    r_wlast <= (r_burst_beats == 8'd1);
                    r_wvalid <= 1'b1;
                    r_hold_valid <= 1'b0; // consumed directly
                end else if (!r_wvalid && r_hold_valid) begin
                    // From hold
                    r_wdata <= r_hold_data;
                    r_wstrb <= w_strb_calc;
                    r_wlast <= (r_burst_beats == 8'd1);
                    r_wvalid <= 1'b1;
                end
                
                // AW handshake
                if (r_awvalid && m_axi_awready) begin
                    r_awvalid <= 1'b0;
                    r_aw_sent_count <= r_aw_sent_count + 8'd1;
                end
                
                // W handshake
                if (r_wvalid && m_axi_wready) begin
                    r_bytes_sent <= r_bytes_sent + 16'd4;
                    r_wvalid <= 1'b0;
                    r_beat_idx <= r_beat_idx + 8'd1;
                    if (r_wlast) begin
                        r_beat_idx <= 8'd0;
                    end
                end
            end
            
            S_WONLY: begin
                // Continue with remaining beats of burst
                if (r_wvalid && m_axi_wready) begin
                    r_bytes_sent <= r_bytes_sent + 16'd4;
                    r_wvalid <= 1'b0;
                    r_beat_idx <= r_beat_idx + 8'd1;
                    if (r_wlast) begin
                        r_beat_idx <= 8'd0;
                    end
                end
                
                // Load next beat data
                if (!r_wvalid) begin
                    if (!r_hold_valid && s_valid) begin
                        r_wdata <= s_data;
                        r_wstrb <= w_strb_calc;
                        r_wlast <= (r_beat_idx == r_burst_beats - 8'd2); // next beat is last
                        r_wvalid <= 1'b1;
                    end else if (r_hold_valid) begin
                        r_wdata <= r_hold_data;
                        r_wstrb <= w_strb_calc;
                        r_wlast <= (r_beat_idx == r_burst_beats - 8'd2);
                        r_wvalid <= 1'b1;
                        r_hold_valid <= 1'b0;
                    end
                end
            end
            
            S_BWAIT: begin
                r_awvalid <= 1'b0;
                r_wvalid <= 1'b0;
                if (r_aw_sent_count == 0) begin
                    r_status_valid <= 1'b1;
                end
            end
        endcase
        
        state <= next_state;
    end
end

endmodule
