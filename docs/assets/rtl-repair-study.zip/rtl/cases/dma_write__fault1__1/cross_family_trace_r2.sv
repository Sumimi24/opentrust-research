`timescale 1ns / 1ps
`default_nettype none

module dma_write(
input wire clk,
input wire rst,
input wire [15:0] desc_addr,
input wire [15:0] desc_len,
input wire [7:0] desc_tag,
input wire desc_valid,
output wire desc_ready,
input wire [31:0] s_data,
input wire [3:0] s_keep,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [15:0] status_len,
output wire [7:0] status_tag,
output wire [3:0] status_error,
output wire status_valid,
output wire [3:0] m_axi_awid,
output wire [15:0] m_axi_awaddr,
output wire [7:0] m_axi_awlen,
output wire [2:0] m_axi_awsize,
output wire [1:0] m_axi_awburst,
output wire m_axi_awlock,
output wire [3:0] m_axi_awcache,
output wire [2:0] m_axi_awprot,
output wire m_axi_awvalid,
input wire m_axi_awready,
output wire [31:0] m_axi_wdata,
output wire [3:0] m_axi_wstrb,
output wire m_axi_wlast,
output wire m_axi_wvalid,
input wire m_axi_wready,
input wire [3:0] m_axi_bid,
input wire [1:0] m_axi_bresp,
input wire m_axi_bvalid,
output wire m_axi_bready);

// FSM states
localparam S_IDLE  = 3'd0;
localparam S_RUN   = 3'd1;
localparam S_AW    = 3'd2;  // AW handshake in progress, W beat pending
localparam S_WWAIT = 3'd3;  // W processing, AW already done for this burst
localparam S_DONE  = 3'd4;

reg [2:0] state, next_state;

// Registered descriptor info
reg [15:0] r_desc_addr;
reg [15:0] r_desc_len;
reg [7:0]  r_desc_tag;
reg [15:0] r_bytes_left;   // bytes remaining to transfer in this burst
reg [15:0] r_bytes_done;   // total bytes output so far across all bursts
reg [3:0]  r_err;
reg        r_status_valid;

// Burst planning registers, updated at burst boundaries
reg [15:0] r_burst_bytes;  // bytes in current burst
reg [7:0]  r_burst_beats;  // beats in current burst
reg [15:0] r_burst_addr;   // aligned AW address for current burst
reg [7:0]  r_beat_idx;     // 0-based beat index within current burst

// Beat-level transaction state
reg        r_w_valid;
reg        r_w_last;
reg [31:0] r_w_data;
reg [3:0]  r_w_strb;
reg        r_aw_valid;

// Combinational derived signals
wire [15:0] w_total_beats = (r_desc_len + 16'd3) >> 2;
wire [15:0] w_current_offset = r_bytes_done;
wire [15:0] w_beat_idx_next;

wire [15:0] w_remaining_beats = w_total_beats - (w_current_offset >> 2);
wire [15:0] w_page_rem   = 16'd1024 - ((r_burst_addr[15:2] + r_burst_beats) & 16'h03FF);
wire [15:0] w_max_burst  = (w_remaining_beats < 16'd16) ? w_remaining_beats : 16'd16;
wire [15:0] w_burst_beats_comb = (w_max_burst < w_page_rem) ? w_max_burst : w_page_rem;
wire [15:0] w_burst_bytes_comb = w_burst_beats_comb << 2;
wire [15:0] w_awaddr_comb = r_desc_addr + w_current_offset;
wire [15:0] w_awaddr_aligned = {w_awaddr_comb[15:2], 2'b00};

wire [1:0]  w_lane_off   = r_desc_addr[1:0];
wire [3:0]  w_first_mask = 4'hF << w_lane_off;
wire [1:0]  w_end_off    = (r_desc_addr[1:0] + r_desc_len[1:0]) & 2'd3;
wire [3:0]  w_last_mask  = (w_end_off == 2'd0) ? 4'hF : ((4'd1 << w_end_off) - 4'd1);

wire        w_burst_is_first = (r_bytes_done == 0);
wire        w_beat_is_first_in_burst = (r_beat_idx == 0);
wire        w_beat_is_last_in_burst  = (r_beat_idx == (r_burst_beats - 8'd1));
wire        w_beat_is_first_overall  = w_burst_is_first && w_beat_is_first_in_burst;
wire        w_beat_is_last_overall   = (r_bytes_done + (r_burst_beats << 2) >= r_desc_len);
wire        w_burst_done = (r_beat_idx == r_burst_beats);

// AXI slave response tracking
reg [7:0]  r_aw_sent_count;   // AWs issued but no B received yet
reg        r_all_aw_sent;     // All bursts' AW have been sent

// Pipeline beat valid to avoid glitching after AW handshake
// W channel is registered for stability
assign m_axi_awid    = 4'd0;
assign m_axi_awaddr  = r_burst_addr;
assign m_axi_awlen   = r_burst_beats - 8'd1;
assign m_axi_awsize  = 3'd2;
assign m_axi_awburst = 2'b01;
assign m_axi_awlock  = 1'b0;
assign m_axi_awcache = 4'd3;
assign m_axi_awprot  = 3'd0;
assign m_axi_awvalid = r_aw_valid;

assign m_axi_wdata  = r_w_data;
assign m_axi_wstrb  = r_w_strb;
assign m_axi_wlast  = r_w_last;
assign m_axi_wvalid = r_w_valid;

assign s_ready      = r_w_valid && m_axi_wready; // we consume stream data when W handshake happens
assign m_axi_bready = 1'b1; // always accept B responses

assign desc_ready   = (state == S_IDLE);
assign status_len   = r_desc_len;
assign status_tag   = r_desc_tag;
assign status_error = r_err;
assign status_valid = r_status_valid;

// Next state logic
always @* begin
    next_state = state;
    case (state)
        S_IDLE: begin
            if (desc_valid && desc_ready)
                next_state = S_AW;
        end
        S_AW: begin
            if (r_aw_valid && m_axi_awready)
                next_state = S_WWAIT;
        end
        S_WWAIT: begin
            // When burst completes (last beat transferred on W)
            if (r_w_valid && m_axi_wready && r_w_last) begin
                if (r_bytes_done + (r_burst_beats << 2) >= r_desc_len)
                    next_state = S_DONE;
                else
                    next_state = S_AW; // next burst
            end
        end
        S_DONE: begin
            // Wait until all B responses received
            if (r_aw_sent_count == 0)
                next_state = S_IDLE;
        end
        default: next_state = S_IDLE;
    endcase
end

always @(posedge clk) begin
    if (rst) begin
        state <= S_IDLE;
        r_desc_addr    <= 16'd0;
        r_desc_len     <= 16'd0;
        r_desc_tag     <= 8'd0;
        r_bytes_done   <= 16'd0;
        r_bytes_left   <= 16'd0;
        r_err          <= 4'd0;
        r_status_valid <= 1'b0;
        r_aw_valid     <= 1'b0;
        r_w_valid      <= 1'b0;
        r_w_last       <= 1'b0;
        r_w_data       <= 32'd0;
        r_w_strb       <= 4'd0;
        r_burst_addr   <= 16'd0;
        r_burst_beats  <= 8'd0;
        r_burst_bytes  <= 16'd0;
        r_beat_idx     <= 8'd0;
        r_aw_sent_count <= 8'd0;
        r_all_aw_sent  <= 1'b0;
    end else begin
        r_status_valid <= 1'b0;
        
        // Default: maintain or clear registrations based on flow
        case (state)
            S_IDLE: begin
                if (desc_valid && desc_ready) begin
                    r_desc_addr  <= desc_addr;
                    r_desc_len   <= desc_len;
                    r_desc_tag   <= desc_tag;
                    r_bytes_done <= 16'd0;
                    r_err        <= 4'd0;
                    r_aw_sent_count <= 8'd0;
                    r_all_aw_sent  <= 1'b0;
                end
            end
            S_AW: begin
                // Plan burst
                r_burst_addr   <= w_awaddr_aligned;
                r_burst_beats  <= w_burst_beats_comb[7:0];
                r_burst_bytes  <= w_burst_bytes_comb;
                r_beat_idx     <= 8'd0;
                r_aw_valid     <= 1'b1;
                // W not yet valid, will become valid when we have first beat data
                r_w_valid <= 1'b0;
            end
            S_WWAIT: begin
                // Keep AW deasserted
                r_aw_valid <= 1'b0;
                
                // Transfer beats on W and consume stream accordingly
                if (r_w_valid && m_axi_wready) begin
                    // Beat transferred
                    if (r_beat_idx == r_burst_beats - 8'd1) begin
                        // Last beat of burst
                        r_w_valid <= 1'b0;
                        // Update byte count
                        r_bytes_done <= r_bytes_done + (r_burst_beats << 2);
                    end else begin
                        r_beat_idx <= r_beat_idx + 8'd1;
                        // Will need new data, handled below
                    end
                end
                
                if (r_w_valid && m_axi_wready && r_w_last) begin
                    // Burst completed, will transition out
                end
            end
            S_DONE: begin
                // Just waiting for B responses, no new operations
                r_w_valid <= 1'b0;
                r_aw_valid <= 1'b0;
                if (r_aw_sent_count == 0) begin
                    r_status_valid <= 1'b1;
                end
            end
        endcase
        
        // AW sent tracking
        if (r_aw_valid && m_axi_awready) begin
            r_aw_sent_count <= r_aw_sent_count + 8'd1;
        end
        
        // B response tracking
        if (m_axi_bvalid && m_axi_bready) begin
            if (m_axi_bresp == 2'b11)
                r_err <= 4'd7;
            else if (m_axi_bresp == 2'b10 && r_err != 4'd7)
                r_err <= 4'd6;
            if (r_aw_sent_count > 0)
                r_aw_sent_count <= r_aw_sent_count - 8'd1;
        end
        
        // Stream ingestion: load next beat data when W is ready to accept
        if (r_w_valid && m_axi_wready) begin
            // Current beat accepted, we can load next if stream available
            if (s_valid && s_ready) begin
                r_w_data <= s_data;
                // Compute strobes
                if (w_beat_is_first_overall) begin
                    if (w_beat_is_last_overall)
                        r_w_strb <= s_keep & w_first_mask & w_last_mask;
                    else
                        r_w_strb <= s_keep & w_first_mask;
                end else if (w_beat_is_last_overall) begin
                    r_w_strb <= s_keep & w_last_mask;
                end else begin
                    r_w_strb <= s_keep;
                end
                r_w_last <= w_beat_is_last_overall;
                r_w_valid <= 1'b1;
            end else begin
                // No stream data, wait
                r_w_valid <= 1'b0;
            end
        end else if (!r_w_valid && (state == S_WWAIT)) begin
            // Need new beat data, stream must produce
            if (s_valid) begin
                r_w_data <= s_data;
                if (w_beat_is_first_overall) begin
                    if (w_beat_is_last_overall)
                        r_w_strb <= s_keep & w_first_mask & w_last_mask;
                    else
                        r_w_strb <= s_keep & w_first_mask;
                end else if (w_beat_is_last_overall) begin
                    r_w_strb <= s_keep & w_last_mask;
                end else begin
                    r_w_strb <= s_keep;
                end
                r_w_last <= w_beat_is_last_overall;
                r_w_valid <= 1'b1;
            end
        end
        
        // First beat load after AW handshake (transition S_AW -> S_WWAIT)
        if (state == S_AW && r_aw_valid && m_axi_awready) begin
            // Move to WWAIT and attempt to load first beat immediately
            if (s_valid) begin
                r_w_data <= s_data;
                if (w_beat_is_first_overall) begin
                    if (w_beat_is_last_overall)
                        r_w_strb <= s_keep & w_first_mask & w_last_mask;
                    else
                        r_w_strb <= s_keep & w_first_mask;
                end else if (w_beat_is_last_overall) begin
                    r_w_strb <= s_keep & w_last_mask;
                end else begin
                    r_w_strb <= s_keep;
                end
                r_w_last <= w_beat_is_last_overall;
                r_w_valid <= 1'b1;
            end else begin
                r_w_valid <= 1'b0;
            end
        end
        
        state <= next_state;
    end
end

endmodule
