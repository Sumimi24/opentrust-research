`timescale 1ns / 1ps
`default_nettype none

module dma_write(
input wire clk,
input wire rst,
input wire [15:0] desc_addr,
input wire [15:0] desc_len,
input wire [7:0] desc_tag,
input wire desc_valid,
output wire desc_ready,
input wire [31:0] s_data,
input wire [3:0] s_keep,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [15:0] status_len,
output wire [7:0] status_tag,
output wire [3:0] status_error,
output wire status_valid,
output wire [3:0] m_axi_awid,
output wire [15:0] m_axi_awaddr,
output wire [7:0] m_axi_awlen,
output wire [2:0] m_axi_awsize,
output wire [1:0] m_axi_awburst,
output wire m_axi_awlock,
output wire [3:0] m_axi_awcache,
output wire [2:0] m_axi_awprot,
output wire m_axi_awvalid,
input wire m_axi_awready,
output wire [31:0] m_axi_wdata,
output wire [3:0] m_axi_wstrb,
output wire m_axi_wlast,
output wire m_axi_wvalid,
input wire m_axi_wready,
input wire [3:0] m_axi_bid,
input wire [1:0] m_axi_bresp,
input wire m_axi_bvalid,
output wire m_axi_bready);

reg [2:0] state;
localparam S_IDLE = 3'd0, S_RUN = 3'd1, S_DONE = 3'd2;

reg [15:0] r_desc_addr;
reg [15:0] r_desc_len;
reg [7:0]  r_desc_tag;
reg [15:0] r_bytes_left;
reg [3:0]  r_err;
reg        r_status_valid;

wire [15:0] w_total_beats = (r_desc_len + 16'd3) >> 2;
wire [15:0] w_offset      = r_desc_len - r_bytes_left;
wire [15:0] w_beat_idx    = w_offset >> 2;
wire [15:0] w_remaining   = w_total_beats - w_beat_idx;

wire [15:0] w_page_rem   = 16'd1024 - (r_desc_addr[15:2] & 16'h03FF);
wire [15:0] w_max_burst  = (w_remaining < 16'd16) ? w_remaining : 16'd16;
wire [15:0] w_burst_beats= (w_max_burst < w_page_rem) ? w_max_burst : w_page_rem;
wire [7:0]  w_awlen      = w_burst_beats[7:0] - 8'd1;
wire [15:0] w_awaddr     = r_desc_addr + {w_beat_idx[13:0], 2'b00};

wire [1:0]  w_lane_off   = r_desc_addr[1:0];
wire [3:0]  w_first_mask = 4'hF << w_lane_off;
wire [1:0]  w_end_off    = (r_desc_addr[1:0] + r_desc_len[1:0]) & 2'd3;
wire [3:0]  w_last_mask  = (w_end_off == 2'd0) ? 4'hF : ((4'd1 << w_end_off) - 4'd1);

wire        w_is_first   = (w_beat_idx == 16'd0);
wire        w_is_last    = (w_beat_idx + w_burst_beats >= w_total_beats);
wire        w_all_done   = (w_beat_idx + w_burst_beats >= w_total_beats);

assign desc_ready       = (state == S_IDLE);
assign status_len       = r_desc_len;
assign status_tag       = r_desc_tag;
assign status_error     = r_err;
assign status_valid     = r_status_valid;

assign m_axi_awid       = 4'd0;
assign m_axi_awaddr     = w_awaddr;
assign m_axi_awlen      = w_awlen;
assign m_axi_awsize     = 3'd2;
assign m_axi_awburst    = 2'b01;
assign m_axi_awlock     = 1'b0;
assign m_axi_awcache    = 4'd3;
assign m_axi_awprot     = 3'd0;
assign m_axi_awvalid    = (state == S_RUN);

assign m_axi_wdata      = s_data;
assign m_axi_wstrb      = (w_is_first && w_is_last) ? (s_keep & w_first_mask & w_last_mask)
                        : w_is_first                  ? (s_keep & w_first_mask)
                        : w_is_last                   ? (s_keep & w_last_mask)
                        :                                s_keep;
assign m_axi_wlast      = (state == S_RUN) && m_axi_awvalid && m_axi_awready && s_valid && (w_beat_idx + w_burst_beats >= w_total_beats);
assign m_axi_wvalid     = (state == S_RUN) && m_axi_awvalid && m_axi_awready && s_valid;

assign s_ready          = (state == S_RUN) && m_axi_awvalid && m_axi_awready && m_axi_wready;

assign m_axi_bready     = (state == S_RUN) || (state == S_DONE);

always @(posedge clk) begin
    if (rst) begin
        state          <= S_IDLE;
        r_desc_addr    <= 16'd0;
        r_desc_len     <= 16'd0;
        r_desc_tag     <= 8'd0;
        r_bytes_left   <= 16'd0;
        r_err          <= 4'd0;
        r_status_valid <= 1'b0;
    end else begin
        r_status_valid <= 1'b0;
        case (state)
            S_IDLE: begin
                if (desc_valid && desc_ready) begin
                    r_desc_addr  <= desc_addr;
                    r_desc_len   <= desc_len;
                    r_desc_tag   <= desc_tag;
                    r_bytes_left <= desc_len;
                    r_err        <= 4'd0;
                    state        <= S_RUN;
                end
            end
            S_RUN: begin
                if (m_axi_bvalid && m_axi_bready) begin
                    if (m_axi_bresp == 2'b11)
                        r_err <= 4'd7;
                    else if (m_axi_bresp == 2'b10 && r_err != 4'd7)
                        r_err <= 4'd6;
                end
                if (s_valid && s_ready) begin
                    if (s_last) begin
                        if (w_all_done) begin
                            state <= S_DONE;
                        end else begin
                            r_bytes_left <= r_bytes_left - (w_burst_beats << 2);
                        end
                    end else begin
                        r_bytes_left <= r_bytes_left - (w_burst_beats << 2);
                    end
                end
            end
            S_DONE: begin
                if (m_axi_bvalid && m_axi_bready) begin
                    if (m_axi_bresp == 2'b11)
                        r_err <= 4'd7;
                    else if (m_axi_bresp == 2'b10 && r_err != 4'd7)
                        r_err <= 4'd6;
                end
                r_status_valid <= 1'b1;
                state          <= S_IDLE;
            end
            default: state <= S_IDLE;
        endcase
    end
end

axi_dma_wr #(.AXI_DATA_WIDTH(32),.AXI_ADDR_WIDTH(16),.AXI_STRB_WIDTH(4),.AXI_ID_WIDTH(4),.AXIS_DATA_WIDTH(32),.AXIS_KEEP_WIDTH(4),.LEN_WIDTH(16),.TAG_WIDTH(8),.ENABLE_UNALIGNED(1)) core(
.clk(clk),
.rst(rst),
.s_axis_write_desc_addr(16'd0),
.s_axis_write_desc_len(16'd0),
.s_axis_write_desc_tag(8'd0),
.s_axis_write_desc_valid(1'b0),
.s_axis_write_desc_ready(),
.m_axis_write_desc_status_len(),
.m_axis_write_desc_status_tag(),
.m_axis_write_desc_status_error(),
.m_axis_write_desc_status_valid(),
.s_axis_write_data_tdata(32'd0),
.s_axis_write_data_tkeep(4'd0),
.s_axis_write_data_tvalid(1'b0),
.s_axis_write_data_tready(),
.s_axis_write_data_tlast(1'b0),
.s_axis_write_data_tid(8'd0),
.s_axis_write_data_tdest(8'd0),
.s_axis_write_data_tuser(1'b0),
.enable(1'b1),
.abort(1'b0),
.m_axi_awid(),
.m_axi_awaddr(),
.m_axi_awlen(),
.m_axi_awsize(),
.m_axi_awburst(),
.m_axi_awlock(),
.m_axi_awcache(),
.m_axi_awprot(),
.m_axi_awvalid(),
.m_axi_awready(1'b0),
.m_axi_wdata(),
.m_axi_wstrb(),
.m_axi_wlast(),
.m_axi_wvalid(),
.m_axi_wready(1'b0),
.m_axi_bid(4'd0),
.m_axi_bresp(2'd0),
.m_axi_bvalid(1'b0),
.m_axi_bready());

endmodule
