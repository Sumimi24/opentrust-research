module dma_write(
    input wire clk,
    input wire rst,
    input wire [15:0] desc_addr,
    input wire [15:0] desc_len,
    input wire [7:0] desc_tag,
    input wire desc_valid,
    output wire desc_ready,
    input wire [31:0] s_data,
    input wire [3:0] s_keep,
    input wire s_valid,
    output wire s_ready,
    input wire s_last,
    output wire [15:0] status_len,
    output wire [7:0] status_tag,
    output wire [3:0] status_error,
    output wire status_valid,
    output wire [3:0] m_axi_awid,
    output wire [15:0] m_axi_awaddr,
    output wire [7:0] m_axi_awlen,
    output wire [2:0] m_axi_awsize,
    output wire [1:0] m_axi_awburst,
    output wire m_axi_awlock,
    output wire [3:0] m_axi_awcache,
    output wire [2:0] m_axi_awprot,
    output wire m_axi_awvalid,
    input wire m_axi_awready,
    output wire [31:0] m_axi_wdata,
    output wire [3:0] m_axi_wstrb,
    output wire m_axi_wlast,
    output wire m_axi_wvalid,
    input wire m_axi_wready,
    input wire [3:0] m_axi_bid,
    input wire [1:0] m_axi_bresp,
    input wire m_axi_bvalid,
    output wire m_axi_bready
);

    assign m_axi_awprot = 3'b000;
    assign m_axi_awsize = 3'b010;
    assign m_axi_awburst = 2'b01;
    assign m_axi_awlock = 1'b0;
    assign m_axi_awcache = 4'b0011;
    assign m_axi_awid = 4'b0000;

    // ─── Mask low address bits for the core to prevent boundary-crossing burst misalignment ───
    wire [15:0] core_awaddr;
    assign core_awaddr = {desc_addr[15:2], 2'b00};

    // ─── Compute per-beat lane masks from the low address offset ───
    wire [1:0] addr_offset;
    assign addr_offset = desc_addr[1:0];

    // 4'b1111 is the full-word mask; we shift it right by offset to mask low lanes on beat 0.
    wire [3:0] first_beat_mask;
    assign first_beat_mask = (4'b1111 >> addr_offset);

    // The core's wstrb gets gated with first_beat_mask on the first beat, else full.
    wire core_wstrb_raw [3:0];
    wire core_wstrb_valid;
    // We will intercept wstrb downstream after instantiation.

    // ─── Keep core instance ───
    wire core_desc_ready;
    wire core_status_valid;
    wire [3:0] core_error;

    assign desc_ready = core_desc_ready && !active && !rst;

    wire accepting_desc = desc_valid && desc_ready;
    wire b_handshake = m_axi_bvalid && m_axi_bready;

    // Our local beat counter to know if this is the first beat of the entire transfer.
    // The core does burst management, but we need to apply the first_beat_mask only on the
    // very first W beat of the whole DMA, not at every burst start.
    reg first_beat;
    reg active;
    reg seen_slverr, seen_decerr;

    // Edge for beat handshake: wvalid && wready
    wire w_handshake = m_axi_wvalid && m_axi_wready;

    always @(posedge clk) begin
        if (rst) begin
            active <= 1'b0;
            seen_slverr <= 1'b0;
            seen_decerr <= 1'b0;
            first_beat <= 1'b0;
        end else begin
            if (core_status_valid)
                active <= 1'b0;
            if (accepting_desc) begin
                active <= 1'b1;
                seen_slverr <= 1'b0;
                seen_decerr <= 1'b0;
                first_beat <= 1'b1;   // the next W beat will be the first
            end
            if (w_handshake)
                first_beat <= 1'b0;   // only the very first handshake gets mask
            if (b_handshake) begin
                if (m_axi_bresp == 2'b10)
                    seen_slverr <= 1'b1;
                if (m_axi_bresp == 2'b11)
                    seen_decerr <= 1'b1;
            end
        end
    end

    assign status_valid = core_status_valid;
    assign status_error = seen_decerr ? 4'd7 : (seen_slverr ? 4'd6 : core_error);

    // Mask wstrb: override on first beat only
    wire [3:0] core_wstrb;
    assign core_wstrb = first_beat ? (m_axi_wstrb & first_beat_mask) : m_axi_wstrb;

    wire core_desc_valid = desc_valid && !active && !rst;

    axi_dma_wr #(
        .AXI_DATA_WIDTH(32),
        .AXI_ADDR_WIDTH(16),
        .AXI_STRB_WIDTH(4),
        .AXI_ID_WIDTH(4),
        .AXIS_DATA_WIDTH(32),
        .AXIS_KEEP_WIDTH(4),
        .LEN_WIDTH(16),
        .TAG_WIDTH(8),
        .ENABLE_UNALIGNED(1)
    ) core (
        .clk(clk),
        .rst(rst),
        .s_axis_write_desc_addr(core_awaddr),
        .s_axis_write_desc_len(desc_len),
        .s_axis_write_desc_tag(desc_tag),
        .s_axis_write_desc_valid(core_desc_valid),
        .s_axis_write_desc_ready(core_desc_ready),
        .m_axis_write_desc_status_len(status_len),
        .m_axis_write_desc_status_tag(status_tag),
        .m_axis_write_desc_status_error(core_error),
        .m_axis_write_desc_status_valid(core_status_valid),
        .s_axis_write_data_tdata(s_data),
        .s_axis_write_data_tkeep(s_keep),
        .s_axis_write_data_tvalid(s_valid),
        .s_axis_write_data_tready(s_ready),
        .s_axis_write_data_tlast(s_last),
        .s_axis_write_data_tid(8'b0),
        .s_axis_write_data_tdest(8'b0),
        .s_axis_write_data_tuser(1'b0),
        .enable(1'b1),
        .abort(1'b0),
        .m_axi_awid(m_axi_awid),
        .m_axi_awaddr(m_axi_awaddr),
        .m_axi_awlen(m_axi_awlen),
        .m_axi_awsize(m_axi_awsize),
        .m_axi_awburst(m_axi_awburst),
        .m_axi_awlock(m_axi_awlock),
        .m_axi_awcache(m_axi_awcache),
        .m_axi_awprot(),
        .m_axi_awvalid(m_axi_awvalid),
        .m_axi_awready(m_axi_awready),
        .m_axi_wdata(m_axi_wdata),
        .m_axi_wstrb(core_wstrb),
        .m_axi_wlast(m_axi_wlast),
        .m_axi_wvalid(m_axi_wvalid),
        .m_axi_wready(m_axi_wready),
        .m_axi_bid(m_axi_bid),
        .m_axi_bresp(m_axi_bresp),
        .m_axi_bvalid(m_axi_bvalid),
        .m_axi_bready(m_axi_bready)
    );

endmodule
