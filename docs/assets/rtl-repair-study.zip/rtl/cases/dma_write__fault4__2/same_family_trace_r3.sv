module dma_write(
    input wire clk,
    input wire rst,
    input wire [15:0] desc_addr,
    input wire [15:0] desc_len,
    input wire [7:0] desc_tag,
    input wire desc_valid,
    output wire desc_ready,
    input wire [31:0] s_data,
    input wire [3:0] s_keep,
    input wire s_valid,
    output wire s_ready,
    input wire s_last,
    output wire [15:0] status_len,
    output wire [7:0] status_tag,
    output wire [3:0] status_error,
    output wire status_valid,
    output wire [3:0] m_axi_awid,
    output wire [15:0] m_axi_awaddr,
    output wire [7:0] m_axi_awlen,
    output wire [2:0] m_axi_awsize,
    output wire [1:0] m_axi_awburst,
    output wire m_axi_awlock,
    output wire [3:0] m_axi_awcache,
    output wire [2:0] m_axi_awprot,
    output wire m_axi_awvalid,
    input wire m_axi_awready,
    output wire [31:0] m_axi_wdata,
    output wire [3:0] m_axi_wstrb,
    output wire m_axi_wlast,
    output wire m_axi_wvalid,
    input wire m_axi_wready,
    input wire [3:0] m_axi_bid,
    input wire [1:0] m_axi_bresp,
    input wire m_axi_bvalid,
    output wire m_axi_bready
);

    assign m_axi_awprot = 3'b000;
    assign m_axi_awsize = 3'b010;
    assign m_axi_awburst = 2'b01;
    assign m_axi_awlock = 1'b0;
    assign m_axi_awcache = 4'b0011;
    assign m_axi_awid = 4'b0000;

    // ─── Pass the original desc_addr to the core; we will fix the WSTRB misalignment
    //       inside the module logic.
    wire [15:0] core_awaddr;
    assign core_awaddr = desc_addr;

    reg active, seen_slverr, seen_decerr;
    wire core_status_valid;
    wire [3:0] core_error;

    wire w_handshake = m_axi_wvalid && m_axi_wready;
    wire b_handshake = m_axi_bvalid && m_axi_bready;

    // ─── Compute the lanes that lie beyond the descriptor extent on the last W beat ───
    // Total bytes written = desc_len.
    // On the last beat, if desc_len is not a multiple of 4, the high lanes are invalid.
    wire [1:0] remainder;
    assign remainder = desc_len[1:0];
    wire [3:0] last_beat_mask;
    assign last_beat_mask = (remainder == 2'd0) ? 4'b1111 :
                            (remainder == 2'd1) ? 4'b0001 :
                            (remainder == 2'd2) ? 4'b0011 : 4'b0111;

    // ─── First-beat unaligned masking ───
    wire [1:0] addr_offset;
    assign addr_offset = desc_addr[1:0];
    wire [3:0] first_beat_mask;
    assign first_beat_mask = {1'b1, 1'b1, 1'b1, 1'b1} >> addr_offset;

    // Identify the very first W handshake of the entire DMA transfer.
    reg first_beat;
    always @(posedge clk) begin
        if (rst)
            first_beat <= 1'b0;
        else begin
            if (desc_valid && desc_ready)
                first_beat <= 1'b1;
            if (w_handshake)
                first_beat <= 1'b0;
        end
    end

    // The core drives m_axi_wstrb; we need to gate it for boundary conditions.
    wire [3:0] core_wstrb;
    wire core_wlast;

    // Determine if the current w_handshake is the last burst beat (core asserts wlast)
    wire is_last_beat = core_wlast;

    wire [3:0] mask;
    // Apply first_beat_mask on first beat, last_beat_mask on last beat, intersection if both (single beat).
    assign mask = first_beat ? first_beat_mask & (is_last_beat ? last_beat_mask : 4'b1111) :
                   is_last_beat ? last_beat_mask : 4'b1111;

    assign m_axi_wstrb = core_wstrb & mask;

    wire core_desc_ready;
    wire core_desc_ready_gated;
    assign core_desc_ready_gated = core_desc_ready && !active && !rst;
    assign desc_ready = core_desc_ready_gated;

    always @(posedge clk) begin
        if (rst) begin
            active <= 1'b0;
            seen_slverr <= 1'b0;
            seen_decerr <= 1'b0;
        end else begin
            if (core_status_valid)
                active <= 1'b0;
            if (desc_valid && desc_ready)
                active <= 1'b1;
            if (b_handshake) begin
                if (m_axi_bresp == 2'b10)
                    seen_slverr <= 1'b1;
                if (m_axi_bresp == 2'b11)
                    seen_decerr <= 1'b1;
            end
            if (desc_valid && desc_ready) begin
                seen_slverr <= 1'b0;
                seen_decerr <= 1'b0;
            end
        end
    end

    assign status_valid = core_status_valid;
    assign status_error = seen_decerr ? 4'd7 : (seen_slverr ? 4'd6 : core_error);

    wire core_desc_valid = desc_valid && !active && !rst;

    axi_dma_wr #(
        .AXI_DATA_WIDTH(32),
        .AXI_ADDR_WIDTH(16),
        .AXI_STRB_WIDTH(4),
        .AXI_ID_WIDTH(4),
        .AXIS_DATA_WIDTH(32),
        .AXIS_KEEP_WIDTH(4),
        .LEN_WIDTH(16),
        .TAG_WIDTH(8),
        .ENABLE_UNALIGNED(1)
    ) core (
        .clk(clk),
        .rst(rst),
        .s_axis_write_desc_addr(core_awaddr),
        .s_axis_write_desc_len(desc_len),
        .s_axis_write_desc_tag(desc_tag),
        .s_axis_write_desc_valid(core_desc_valid),
        .s_axis_write_desc_ready(core_desc_ready),
        .m_axis_write_desc_status_len(status_len),
        .m_axis_write_desc_status_tag(status_tag),
        .m_axis_write_desc_status_error(core_error),
        .m_axis_write_desc_status_valid(core_status_valid),
        .s_axis_write_data_tdata(s_data),
        .s_axis_write_data_tkeep(s_keep),
        .s_axis_write_data_tvalid(s_valid),
        .s_axis_write_data_tready(s_ready),
        .s_axis_write_data_tlast(s_last),
        .s_axis_write_data_tid(8'b0),
        .s_axis_write_data_tdest(8'b0),
        .s_axis_write_data_tuser(1'b0),
        .enable(1'b1),
        .abort(1'b0),
        .m_axi_awid(m_axi_awid),
        .m_axi_awaddr(m_axi_awaddr),
        .m_axi_awlen(m_axi_awlen),
        .m_axi_awsize(m_axi_awsize),
        .m_axi_awburst(m_axi_awburst),
        .m_axi_awlock(m_axi_awlock),
        .m_axi_awcache(m_axi_awcache),
        .m_axi_awprot(),
        .m_axi_awvalid(m_axi_awvalid),
        .m_axi_awready(m_axi_awready),
        .m_axi_wdata(m_axi_wdata),
        .m_axi_wstrb(core_wstrb),
        .m_axi_wlast(core_wlast),
        .m_axi_wvalid(m_axi_wvalid),
        .m_axi_wready(m_axi_wready),
        .m_axi_bid(m_axi_bid),
        .m_axi_bresp(m_axi_bresp),
        .m_axi_bvalid(m_axi_bvalid),
        .m_axi_bready(m_axi_bready)
    );

endmodule
