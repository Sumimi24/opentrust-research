module icache_ctrl(
input wire clk_i,
input wire rst_ni,
input wire req_i,
input wire branch_i,
input wire [31:0] addr_i,
input wire ready_i,
output wire valid_o,
output wire [31:0] rdata_o,
output wire [31:0] addr_o,
output wire err_o,
output wire instr_req_o,
input wire instr_gnt_i,
output wire [31:0] instr_addr_o,
input wire [31:0] instr_rdata_i,
input wire instr_err_i,
input wire instr_rvalid_i,
input wire icache_inval_i,
output wire busy_o
);

localparam int ICacheNumWays = 2;
localparam int ICacheIndexWidth = 8;
localparam int ICacheNumLines = 256;
localparam int ICacheTagWidth = 22;

wire [ICacheNumWays-1:0]            tag_req;
wire [ICacheNumWays-1:0]            data_req;
wire                                tag_write;
wire                                data_write;
wire [ICacheIndexWidth-1:0]         tag_addr;
wire [ICacheIndexWidth-1:0]         data_addr;
wire [ICacheTagWidth-1:0]           tag_wdata;
wire [31:0]                         data_wdata;

wire [ICacheTagWidth-1:0]           tag_rdata [0:ICacheNumWays-1];
wire [31:0]                         data_rdata [0:ICacheNumWays-1];

reg [ICacheTagWidth-1:0]            tag_mem [0:ICacheNumWays-1][0:ICacheNumLines-1];
reg [31:0]                          data_mem [0:ICacheNumWays-1][0:ICacheNumLines-1];

genvar g;
generate
  for (g = 0; g < ICacheNumWays; g++) begin : gen_banks
    always @(posedge clk_i) begin
      if (tag_req[g]) begin
        if (tag_write) tag_mem[g][tag_addr] <= tag_wdata;
        tag_rdata[g] <= tag_mem[g][tag_addr];
      end
      if (data_req[g]) begin
        if (data_write) data_mem[g][data_addr] <= data_wdata;
        data_rdata[g] <= data_mem[g][data_addr];
      end
    end
  end
endgenerate

ibex_icache #(
  .ICacheECC       (0),
  .ResetAll        (1),
  .BranchCache     (0),
  .TweakInfection  (0)
) core (
  .clk_i             (clk_i),
  .rst_ni            (rst_ni),
  .req_i             (req_i),
  .branch_i          (branch_i),
  .addr_i            (addr_i),
  .ready_i           (ready_i),
  .valid_o           (valid_o),
  .rdata_o           (rdata_o),
  .addr_o            (addr_o),
  .err_o             (err_o),
  .instr_req_o       (instr_req_o),
  .instr_gnt_i       (instr_gnt_i),
  .instr_addr_o      (instr_addr_o),
  .instr_rdata_i     (instr_rdata_i),
  .instr_err_i       (instr_err_i),
  .instr_rvalid_i    (instr_rvalid_i),
  .icache_inval_i    (icache_inval_i),
  .busy_o            (busy_o),
  .ic_tag_req_o      (tag_req),
  .ic_tag_write_o    (tag_write),
  .ic_tag_addr_o     (tag_addr),
  .ic_tag_wdata_o    (tag_wdata),
  .ic_tag_rdata_i    (tag_rdata),
  .ic_data_req_o     (data_req),
  .ic_data_write_o   (data_write),
  .ic_data_addr_o    (data_addr),
  .ic_data_wdata_o   (data_wdata),
  .ic_data_rdata_i   (data_rdata),
  .ic_scr_key_valid_i(1'b1),
  .icache_enable_i   (1'b1)
);

endmodule
