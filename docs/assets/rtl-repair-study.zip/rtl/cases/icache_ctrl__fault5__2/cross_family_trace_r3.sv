module icache_ctrl(
input wire clk_i,
input wire rst_ni,
input wire req_i,
input wire branch_i,
input wire [31:0] addr_i,
input wire ready_i,
output wire valid_o,
output wire [31:0] rdata_o,
output wire [31:0] addr_o,
output wire err_o,
output wire instr_req_o,
input wire instr_gnt_i,
output wire [31:0] instr_addr_o,
input wire [31:0] instr_rdata_i,
input wire instr_err_i,
input wire instr_rvalid_i,
input wire icache_inval_i,
output wire busy_o
);

localparam integer LINE_WORDS = 8;
localparam integer NUM_LINES  = 4;
localparam integer INDEX_W    = 2;
localparam integer OFFSET_W   = 3;
localparam integer TAG_W      = 32 - 2 - INDEX_W - OFFSET_W;

reg                  cache_valid [0:NUM_LINES-1];
reg [TAG_W-1:0]      cache_tag   [0:NUM_LINES-1];
reg [31:0]           cache_data  [0:NUM_LINES-1][0:LINE_WORDS-1];

reg                  out_valid_q;
reg [31:0]           out_data_q;
reg [31:0]           out_addr_q;
reg                  out_err_q;
reg                  poisoned_q;

reg [31:0]           pc_q;

reg [31:0]           req_addr_q [0:31];
reg [5:0]            req_gen_q  [0:31];
reg [5:0]            gen_q;
reg [5:0]            rsp_gen_q;

reg [31:0]           pend_addr_q [0:31];
reg                  pend_err_q  [0:31];
reg [31:0]           pend_data_q [0:31];
reg [5:0]            pend_gen_q  [0:31];
reg [31:0]           pend_pc_q   [0:31];
reg                  pend_valid_q[0:31];

reg [5:0] req_head_q, req_tail_q, req_count_q;
reg [5:0] pend_count_q;

reg [31:0] fill_base_q [0:NUM_LINES-1];
reg [7:0]  fill_mask_q [0:NUM_LINES-1];
reg [TAG_W-1:0] fill_tag_q [0:NUM_LINES-1];
reg        fill_valid_q[0:NUM_LINES-1];

reg [31:0] next_issue_addr_q;
reg [31:0] branch_base_q;

reg inval_pending_q;

integer i;
integer j;

wire out_fire = out_valid_q & ready_i;

wire [INDEX_W-1:0] pc_index_w  = pc_q[2+OFFSET_W +: INDEX_W];
wire [OFFSET_W-1:0] pc_off_w   = pc_q[2 +: OFFSET_W];
wire [TAG_W-1:0] pc_tag_w      = pc_q[2+OFFSET_W+INDEX_W +: TAG_W];
wire pc_hit_w = cache_valid[pc_index_w] && (cache_tag[pc_index_w] == pc_tag_w);

wire [31:0] aligned_branch_addr_w = {addr_i[31:2], 2'b00};

reg can_issue_r;
reg [31:0] issue_addr_r;
reg [INDEX_W-1:0] issue_index_r;
reg [31:0] line_base_r;
reg outstanding_same_line_r;
reg pending_same_addr_r;
reg cache_hit_issue_r;

always @* begin
  can_issue_r = 1'b0;
  issue_addr_r = next_issue_addr_q;
  issue_index_r = next_issue_addr_q[2+OFFSET_W +: INDEX_W];
  line_base_r = {next_issue_addr_q[31:(2+OFFSET_W)], {(2+OFFSET_W){1'b0}}};
  outstanding_same_line_r = 1'b0;
  pending_same_addr_r = 1'b0;
  cache_hit_issue_r = cache_valid[issue_index_r] &&
                      (cache_tag[issue_index_r] == next_issue_addr_q[2+OFFSET_W+INDEX_W +: TAG_W]);

  if (req_i && !inval_pending_q && (req_count_q != 6'd32) && !poisoned_q) begin
    if (!cache_hit_issue_r) begin
      for (i = 0; i < 32; i = i + 1) begin
        if (i < req_count_q) begin
          if ((req_addr_q[(req_head_q + i) & 6'h1f] & 32'hffffffe0) == line_base_r)
            outstanding_same_line_r = 1'b1;
          if (req_addr_q[(req_head_q + i) & 6'h1f] == issue_addr_r)
            pending_same_addr_r = 1'b1;
        end
      end
      for (i = 0; i < 32; i = i + 1) begin
        if (pend_valid_q[i]) begin
          if (pend_addr_q[i] == issue_addr_r)
            pending_same_addr_r = 1'b1;
        end
      end
      if (!outstanding_same_line_r && !pending_same_addr_r)
        can_issue_r = 1'b1;
    end
  end
end

assign instr_req_o = can_issue_r;
assign instr_addr_o = {issue_addr_r[31:2], 2'b00};

assign valid_o = out_valid_q;
assign rdata_o = out_data_q;
assign addr_o  = out_addr_q;
assign err_o   = out_err_q;

wire busy_internal_w = (req_count_q != 0) || (pend_count_q != 0) || out_valid_q || inval_pending_q;
assign busy_o = busy_internal_w;

always @(posedge clk_i or negedge rst_ni) begin
  if (!rst_ni) begin
    out_valid_q <= 1'b0;
    out_data_q <= 32'h0;
    out_addr_q <= 32'h0;
    out_err_q <= 1'b0;
    poisoned_q <= 1'b0;
    pc_q <= 32'h0;
    next_issue_addr_q <= 32'h0;
    branch_base_q <= 32'h0;
    gen_q <= 6'h1;
    rsp_gen_q <= 6'h0;
    req_head_q <= 6'h0;
    req_tail_q <= 6'h0;
    req_count_q <= 6'h0;
    pend_count_q <= 6'h0;
    inval_pending_q <= 1'b0;
    for (i = 0; i < NUM_LINES; i = i + 1) begin
      cache_valid[i] <= 1'b0;
      cache_tag[i] <= {TAG_W{1'b0}};
      fill_base_q[i] <= 32'h0;
      fill_mask_q[i] <= 8'h00;
      fill_tag_q[i] <= {TAG_W{1'b0}};
      fill_valid_q[i] <= 1'b0;
      for (j = 0; j < LINE_WORDS; j = j + 1) begin
        cache_data[i][j] <= 32'h0;
      end
    end
    for (i = 0; i < 32; i = i + 1) begin
      req_addr_q[i] <= 32'h0;
      req_gen_q[i] <= 6'h0;
      pend_addr_q[i] <= 32'h0;
      pend_err_q[i] <= 1'b0;
      pend_data_q[i] <= 32'h0;
      pend_gen_q[i] <= 6'h0;
      pend_pc_q[i] <= 32'h0;
      pend_valid_q[i] <= 1'b0;
    end
  end else begin
    if (icache_inval_i) begin
      inval_pending_q <= 1'b1;
      for (i = 0; i < NUM_LINES; i = i + 1) begin
        cache_valid[i] <= 1'b0;
        fill_valid_q[i] <= 1'b0;
        fill_mask_q[i] <= 8'h00;
      end
    end

    if (branch_i) begin
      out_valid_q <= 1'b0;
      out_err_q <= 1'b0;
      poisoned_q <= 1'b0;
      pc_q <= aligned_branch_addr_w;
      next_issue_addr_q <= aligned_branch_addr_w;
      branch_base_q <= aligned_branch_addr_w;
      gen_q <= gen_q + 6'h1;
    end else if (out_fire) begin
      out_valid_q <= 1'b0;
      out_err_q <= 1'b0;
      if (!out_err_q) begin
        pc_q <= out_addr_q + 32'd4;
      end
      if (out_err_q) begin
        poisoned_q <= 1'b1;
      end
    end

    if (instr_req_o && instr_gnt_i) begin
      req_addr_q[req_tail_q] <= instr_addr_o;
      req_gen_q[req_tail_q] <= gen_q;
      req_tail_q <= (req_tail_q + 6'd1) & 6'h1f;
      req_count_q <= req_count_q + 6'd1;
      next_issue_addr_q <= instr_addr_o + 32'd4;
    end

    if (instr_rvalid_i && (req_count_q != 0)) begin
      rsp_gen_q <= req_gen_q[req_head_q];
      if (req_gen_q[req_head_q] == gen_q) begin
        for (i = 0; i < 32; i = i + 1) begin
          if (!pend_valid_q[i]) begin
            pend_valid_q[i] <= 1'b1;
            pend_addr_q[i] <= req_addr_q[req_head_q];
            pend_err_q[i] <= instr_err_i;
            pend_data_q[i] <= instr_rdata_i;
            pend_gen_q[i] <= req_gen_q[req_head_q];
            pend_pc_q[i] <= req_addr_q[req_head_q];
            pend_count_q <= pend_count_q + 6'd1;

            if (!instr_err_i) begin
              j = req_addr_q[req_head_q][2+OFFSET_W +: INDEX_W];
              if (!fill_valid_q[j] || (fill_base_q[j] != (req_addr_q[req_head_q] & 32'hffffffe0))) begin
                fill_valid_q[j] <= 1'b1;
                fill_base_q[j] <= req_addr_q[req_head_q] & 32'hffffffe0;
                fill_tag_q[j] <= req_addr_q[req_head_q][2+OFFSET_W+INDEX_W +: TAG_W];
                fill_mask_q[j] <= 8'h00;
              end
              cache_data[j][req_addr_q[req_head_q][2 +: OFFSET_W]] <= instr_rdata_i;
              fill_mask_q[j][req_addr_q[req_head_q][2 +: OFFSET_W]] <= 1'b1;
              if ((fill_mask_q[j] | (8'h1 << req_addr_q[req_head_q][2 +: OFFSET_W])) == 8'hff) begin
                cache_valid[j] <= 1'b1;
                cache_tag[j] <= req_addr_q[req_head_q][2+OFFSET_W+INDEX_W +: TAG_W];
              end
            end
            i = 32;
          end
        end
      end
      req_head_q <= (req_head_q + 6'd1) & 6'h1f;
      req_count_q <= req_count_q - 6'd1;
      if ((req_count_q - 6'd1) == 0)
        inval_pending_q <= 1'b0;
    end else if ((req_count_q == 0) && !out_valid_q) begin
      inval_pending_q <= 1'b0;
    end

    if (!branch_i && !out_valid_q && !poisoned_q) begin
      if (pc_hit_w) begin
        out_valid_q <= 1'b1;
        out_data_q <= cache_data[pc_index_w][pc_off_w];
        out_addr_q <= pc_q;
        out_err_q <= 1'b0;
      end else begin
        for (i = 0; i < 32; i = i + 1) begin
          if (pend_valid_q[i] && (pend_gen_q[i] == gen_q) && (pend_addr_q[i] == pc_q)) begin
            out_valid_q <= 1'b1;
            out_data_q <= pend_data_q[i];
            out_addr_q <= pend_addr_q[i];
            out_err_q <= pend_err_q[i];
            pend_valid_q[i] <= 1'b0;
            pend_count_q <= pend_count_q - 6'd1;
            i = 32;
          end
        end
      end
    end
  end
end

endmodule
