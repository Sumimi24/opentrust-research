`timescale 1ns/1ps
`default_nettype none

module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output reg s_ready,
input wire s_last,
output reg [7:0] m_data,
output reg m_valid,
input wire m_ready,
output reg m_last,
output reg [31:0] m_src_ip,
output reg [15:0] m_src_port,
output reg [15:0] m_dst_port,
output reg [15:0] m_payload_len,
output reg status_valid,
output reg [3:0] status_error);

reg [7:0] buf0, buf1, buf2, buf3, buf4, buf5, buf6, buf7, buf8, buf9;
reg [7:0] buf10, buf11, buf12, buf13, buf14, buf15, buf16, buf17, buf18, buf19;
reg [7:0] buf20, buf21, buf22, buf23, buf24, buf25, buf26, buf27;
reg [8:0] ip_sum;
reg [16:0] udp_sum_acc;
reg [9:0] byte_cnt;
reg [9:0] out_ptr;
reg [9:0] out_end;
reg [3:0] err_code;
reg [3:0] chk_step;
reg [2:0] state;

localparam S_IDLE = 3'd0;
localparam S_RECV = 3'd1;
localparam S_DRAIN = 3'd2;
localparam S_CHK_IP = 3'd3;
localparam S_CHK_UDP = 3'd4;
localparam S_STATUS = 3'd5;
localparam S_OUT = 3'd6;

function [7:0] get_buf;
    input [9:0] idx;
    begin
        case (idx)
            10'd0: get_buf = buf0;
            10'd1: get_buf = buf1;
            10'd2: get_buf = buf2;
            10'd3: get_buf = buf3;
            10'd4: get_buf = buf4;
            10'd5: get_buf = buf5;
            10'd6: get_buf = buf6;
            10'd7: get_buf = buf7;
            10'd8: get_buf = buf8;
            10'd9: get_buf = buf9;
            10'd10: get_buf = buf10;
            10'd11: get_buf = buf11;
            10'd12: get_buf = buf12;
            10'd13: get_buf = buf13;
            10'd14: get_buf = buf14;
            10'd15: get_buf = buf15;
            10'd16: get_buf = buf16;
            10'd17: get_buf = buf17;
            10'd18: get_buf = buf18;
            10'd19: get_buf = buf19;
            10'd20: get_buf = buf20;
            10'd21: get_buf = buf21;
            10'd22: get_buf = buf22;
            10'd23: get_buf = buf23;
            10'd24: get_buf = buf24;
            10'd25: get_buf = buf25;
            10'd26: get_buf = buf26;
            10'd27: get_buf = buf27;
            default: get_buf = 8'd0;
        endcase
    end
endfunction

always @(posedge clk) begin
    if (rst) begin
        state <= S_IDLE;
        byte_cnt <= 10'd0;
        status_valid <= 1'b0;
        status_error <= 4'd0;
        m_valid <= 1'b0;
        s_ready <= 1'b1;
    end else begin
        status_valid <= 1'b0;
        case (state)
            S_IDLE: begin
                s_ready <= 1'b1;
                m_valid <= 1'b0;
                byte_cnt <= 10'd0;
                if (s_valid) begin
                    case (byte_cnt)
                        10'd0: buf0 <= s_data;
                        10'd1: buf1 <= s_data;
                        10'd2: buf2 <= s_data;
                        10'd3: buf3 <= s_data;
                        10'd4: buf4 <= s_data;
                        10'd5: buf5 <= s_data;
                        10'd6: buf6 <= s_data;
                        10'd7: buf7 <= s_data;
                        10'd8: buf8 <= s_data;
                        10'd9: buf9 <= s_data;
                        10'd10: buf10 <= s_data;
                        10'd11: buf11 <= s_data;
                        10'd12: buf12 <= s_data;
                        10'd13: buf13 <= s_data;
                        10'd14: buf14 <= s_data;
                        10'd15: buf15 <= s_data;
                        10'd16: buf16 <= s_data;
                        10'd17: buf17 <= s_data;
                        10'd18: buf18 <= s_data;
                        10'd19: buf19 <= s_data;
                        10'd20: buf20 <= s_data;
                        10'd21: buf21 <= s_data;
                        10'd22: buf22 <= s_data;
                        10'd23: buf23 <= s_data;
                        10'd24: buf24 <= s_data;
                        10'd25: buf25 <= s_data;
                        10'd26: buf26 <= s_data;
                        10'd27: buf27 <= s_data;
                        default: ;
                    endcase
                    byte_cnt <= 10'd1;
                    if (s_last) begin
                        state <= S_CHK_IP;
                        ip_sum <= 9'd0;
                        chk_step <= 4'd0;
                        s_ready <= 1'b0;
                    end else begin
                        state <= S_RECV;
                    end
                end
            end
            S_RECV: begin
                s_ready <= 1'b1;
                if (s_valid) begin
                    if (byte_cnt < 10'd28) begin
                        case (byte_cnt)
                            10'd0: buf0 <= s_data;
                            10'd1: buf1 <= s_data;
                            10'd2: buf2 <= s_data;
                            10'd3: buf3 <= s_data;
                            10'd4: buf4 <= s_data;
                            10'd5: buf5 <= s_data;
                            10'd6: buf6 <= s_data;
                            10'd7: buf7 <= s_data;
                            10'd8: buf8 <= s_data;
                            10'd9: buf9 <= s_data;
                            10'd10: buf10 <= s_data;
                            10'd11: buf11 <= s_data;
                            10'd12: buf12 <= s_data;
                            10'd13: buf13 <= s_data;
                            10'd14: buf14 <= s_data;
                            10'd15: buf15 <= s_data;
                            10'd16: buf16 <= s_data;
                            10'd17: buf17 <= s_data;
                            10'd18: buf18 <= s_data;
                            10'd19: buf19 <= s_data;
                            10'd20: buf20 <= s_data;
                            10'd21: buf21 <= s_data;
                            10'd22: buf22 <= s_data;
                            10'd23: buf23 <= s_data;
                            10'd24: buf24 <= s_data;
                            10'd25: buf25 <= s_data;
                            10'd26: buf26 <= s_data;
                            10'd27: buf27 <= s_data;
                            default: ;
                        endcase
                    end
                    byte_cnt <= byte_cnt + 10'd1;
                    if (s_last) begin
                        state <= S_CHK_IP;
                        ip_sum <= 9'd0;
                        chk_step <= 4'd0;
                        s_ready <= 1'b0;
                    end
                end
            end
            S_DRAIN: begin
                s_ready <= 1'b1;
                if (s_valid && s_last) begin
                    state <= S_CHK_IP;
                    ip_sum <= 9'd0;
                    chk_step <= 4'd0;
                    s_ready <= 1'b0;
                end
            end
            S_CHK_IP: begin
                s_ready <= 1'b0;
                if (chk_step < 4'd10) begin
                    ip_sum <= ip_sum + {get_buf(chk_step * 2), get_buf(chk_step * 2 + 1)};
                    chk_step <= chk_step + 4'd1;
                end else begin
                    state <= S_CHK_UDP;
                    udp_sum_acc <= 17'd0;
                    chk_step <= 4'd0;
                end
            end
            S_CHK_UDP: begin
                s_ready <= 1'b0;
                if (chk_step < 4'd6) begin
                    udp_sum_acc <= udp_sum_acc + {8'd0, get_buf(12 + chk_step * 2), get_buf(12 + chk_step * 2 + 1)}
                                                + {8'd0, get_buf(20 + chk_step * 2), get_buf(20 + chk_step * 2 + 1)};
                    chk_step <= chk_step + 4'd1;
                end else if (chk_step == 4'd6) begin
                    udp_sum_acc <= udp_sum_acc + 17'd17 + {9'd0, get_buf(24), get_buf(25)};
                    chk_step <= 4'd7;
                end else if (chk_step == 4'd7) begin
                    if (byte_cnt > 10'd28) begin
                        udp_sum_acc <= udp_sum_acc + {9'd0, get_buf(28), (byte_cnt > 10'd29 ? get_buf(29) : 8'd0)};
                        chk_step <= 4'd8;
                    end else begin
                        state <= S_STATUS;
                    end
                end else begin
                    state <= S_STATUS;
                end
            end
            S_STATUS: begin
                s_ready <= 1'b0;
                status_valid <= 1'b1;
                status_error <= err_code;
                if (err_code == 4'd0) begin
                    state <= S_OUT;
                    out_ptr <= 10'd28;
                    out_end <= byte_cnt - 10'd1;
                    m_src_ip <= {buf12, buf13, buf14, buf15};
                    m_src_port <= {buf20, buf21};
                    m_dst_port <= {buf22, buf23};
                    m_payload_len <= {buf24, buf25} - 16'd8;
                    m_valid <= 1'b1;
                    m_data <= get_buf(10'd28);
                    m_last <= (byte_cnt == 10'd29);
                end else begin
                    state <= S_IDLE;
                    byte_cnt <= 10'd0;
                    m_valid <= 1'b0;
                end
            end
            S_OUT: begin
                s_ready <= 1'b0;
                if (m_valid && m_ready) begin
                    if (m_last) begin
                        state <= S_IDLE;
                        byte_cnt <= 10'd0;
                        m_valid <= 1'b0;
                    end else begin
                        out_ptr <= out_ptr + 10'd1;
                        m_data <= get_buf(out_ptr + 10'd1);
                        m_last <= ((out_ptr + 10'd1) == out_end);
                    end
                end
            end
            default: begin
                state <= S_IDLE;
                s_ready <= 1'b0;
                m_valid <= 1'b0;
            end
        endcase
    end
end

wire [8:0] ip_folded;
assign ip_folded = ip_sum[8] ? (ip_sum[7:0] + 9'd1) : ip_sum;

wire [15:0] udp_s;
assign udp_s = udp_sum_acc[15:0] + {15'd0, udp_sum_acc[16]};
wire [15:0] udp_folded;
assign udp_folded = udp_s[15:0] + {15'd0, udp_s[16]};

wire [15:0] ip_total_len;
assign ip_total_len = {buf2, buf3};
wire [15:0] udp_len;
assign udp_len = {buf24, buf25};
wire [15:0] payload_len_calc;
assign payload_len_calc = udp_len - 16'd8;
wire [15:0] udp_chk_val;
assign udp_chk_val = {buf26, buf27};

always @(*) begin
    err_code = 4'd0;
    if (state == S_CHK_IP || state == S_CHK_UDP || state == S_STATUS) begin
        if (byte_cnt < 10'd28 || byte_cnt > 10'd512 ||
            buf0[7:4] != 4'd4 || buf0[3:0] != 4'd5 ||
            buf9 != 8'd17 || buf6[5] != 1'b0 ||
            {buf6[4:0], buf7} != 13'd0) begin
            err_code = 4'd1;
        end else if (ip_total_len != byte_cnt ||
                     udp_len != (ip_total_len - 16'd20) ||
                     payload_len_calc < 16'd1 ||
                     payload_len_calc > 16'd256) begin
            err_code = 4'd2;
        end else if (state == S_CHK_UDP || state == S_STATUS) begin
            if (ip_folded != 9'h0ff) begin
                err_code = 4'd3;
            end else if (udp_chk_val != 16'd0 && udp_folded != 16'hffff) begin
                err_code = 4'd4;
            end else if ({buf16, buf17, buf18, buf19} != 32'h0a000002 ||
                         {buf22, buf23} != 16'd9000) begin
                err_code = 4'd5;
            end
        end
    end
end

endmodule
