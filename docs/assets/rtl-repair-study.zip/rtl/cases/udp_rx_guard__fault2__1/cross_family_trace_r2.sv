`timescale 1ns/1ps
`default_nettype none

module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

reg [7:0] buf [0:511];
reg [9:0] byte_cnt;
reg [2:0] state;
reg [3:0] err_code;
reg status_valid_r;
reg [3:0] status_error_r;
reg [9:0] out_ptr;
reg [9:0] out_end;
reg [31:0] r_src_ip;
reg [15:0] r_src_port;
reg [15:0] r_dst_port;
reg [15:0] r_payload_len;
reg [16:0] ip_sum;
reg [16:0] udp_sum;
reg [9:0] chk_idx;
reg drain_oversize;

localparam S_IDLE = 3'd0;
localparam S_RECV = 3'd1;
localparam S_DRAIN = 3'd2;
localparam S_CHK_IP = 3'd3;
localparam S_CHK_UDP = 3'd4;
localparam S_STATUS = 3'd5;
localparam S_OUT = 3'd6;

assign s_ready = (state == S_IDLE) || (state == S_RECV) || (state == S_DRAIN);
assign status_valid = status_valid_r;
assign status_error = status_error_r;
assign m_valid = (state == S_OUT);
assign m_data = buf[out_ptr];
assign m_last = (state == S_OUT) && (out_ptr == out_end);
assign m_src_ip = r_src_ip;
assign m_src_port = r_src_port;
assign m_dst_port = r_dst_port;
assign m_payload_len = r_payload_len;

always @(posedge clk) begin
    if (rst) begin
        state <= S_IDLE;
        byte_cnt <= 10'd0;
        status_valid_r <= 1'b0;
        status_error_r <= 4'd0;
        drain_oversize <= 1'b0;
        err_code <= 4'd0;
    end else begin
        if (status_valid_r)
            status_valid_r <= 1'b0;
        case (state)
            S_IDLE: begin
                if (s_valid && s_ready) begin
                    if (byte_cnt < 512) buf[byte_cnt] <= s_data;
                    byte_cnt <= byte_cnt + 1'd1;
                    if (byte_cnt >= 512) drain_oversize <= 1'b1;
                    if (s_last) begin
                        state <= S_CHK_IP;
                        ip_sum <= 17'd0;
                        chk_idx <= 10'd0;
                    end else begin
                        state <= (byte_cnt >= 512) ? S_DRAIN : S_RECV;
                    end
                end
            end
            S_RECV: begin
                if (s_valid && s_ready) begin
                    if (byte_cnt < 512) buf[byte_cnt] <= s_data;
                    byte_cnt <= byte_cnt + 1'd1;
                    if (byte_cnt >= 511) drain_oversize <= 1'b1;
                    if (s_last) begin
                        state <= S_CHK_IP;
                        ip_sum <= 17'd0;
                        chk_idx <= 10'd0;
                    end else if (byte_cnt >= 511) begin
                        state <= S_DRAIN;
                    end
                end
            end
            S_DRAIN: begin
                if (s_valid && s_ready) begin
                    byte_cnt <= byte_cnt + 1'd1;
                    if (s_last) begin
                        state <= S_CHK_IP;
                        ip_sum <= 17'd0;
                        chk_idx <= 10'd0;
                    end
                end
            end
            S_CHK_IP: begin
                if (chk_idx < 10'd10) begin
                    ip_sum <= ip_sum + {buf[chk_idx*2], buf[chk_idx*2 + 1]};
                    chk_idx <= chk_idx + 1'd1;
                end else begin
                    state <= S_CHK_UDP;
                    udp_sum <= 17'd0;
                    chk_idx <= 10'd0;
                end
            end
            S_CHK_UDP: begin
                if (chk_idx < 10'd10) begin
                    udp_sum <= udp_sum + {buf[chk_idx*2 + 12], buf[chk_idx*2 + 13]};
                    chk_idx <= chk_idx + 1'd1;
                end else if (chk_idx == 10'd10) begin
                    udp_sum <= udp_sum + {buf[26], buf[27]};
                    chk_idx <= chk_idx + 1'd1;
                end else if (chk_idx == 10'd11) begin
                    udp_sum <= udp_sum + {buf[28], buf[29]};
                    chk_idx <= chk_idx + 1'd1;
                end else begin
                    state <= S_STATUS;
                end
            end
            S_STATUS: begin
                status_valid_r <= 1'b1;
                status_error_r <= err_code;
                if (err_code == 4'd0) begin
                    out_ptr <= 10'd28;
                    out_end <= byte_cnt - 1'd1;
                    r_src_ip <= {buf[12], buf[13], buf[14], buf[15]};
                    r_src_port <= {buf[20], buf[21]};
                    r_dst_port <= {buf[22], buf[23]};
                    r_payload_len <= {buf[24], buf[25]} - 16'd8;
                    state <= S_OUT;
                end else begin
                    state <= S_IDLE;
                    byte_cnt <= 10'd0;
                    drain_oversize <= 1'b0;
                end
            end
            S_OUT: begin
                if (m_valid && m_ready) begin
                    if (out_ptr == out_end) begin
                        state <= S_IDLE;
                        byte_cnt <= 10'd0;
                        drain_oversize <= 1'b0;
                    end else begin
                        out_ptr <= out_ptr + 1'd1;
                    end
                end
            end
            default: state <= S_IDLE;
        endcase
    end
end

always @(*) begin
    reg [16:0] folded_ip;
    reg [16:0] folded_udp;
    reg [15:0] tmp_udp_sum;
    reg [10:0] tmp_udp_chk_idx;
    reg [7:0] tmp_udp_data;
    reg [15:0] ip_total_len;
    reg [15:0] udp_len;
    reg [7:0] ihl_;
    reg [6:0] flags;
    reg [12:0] frag_off;
    reg [7:0] proto;
    reg [15:0] dst_port;
    reg [31:0] dst_ip;

    err_code = 4'd0;
    
    if (state == S_CHK_IP || state == S_CHK_UDP || state == S_STATUS) begin
        ihl_ = buf[0][3:0];
        proto = buf[9];
        flags = buf[6][7:5];
        frag_off = {buf[6][4:0], buf[7]};
        ip_total_len = {buf[2], buf[3]};
        udp_len = {buf[24], buf[25]};
        dst_ip = {buf[16], buf[17], buf[18], buf[19]};
        dst_port = {buf[22], buf[23]};

        if (byte_cnt < 28 || drain_oversize ||
            buf[0][7:4] != 4'd4 || ihl_ != 4'd5 ||
            proto != 8'd17 || flags[1] != 1'b0 || frag_off != 13'd0)
            err_code = 4'd1;
        else if (ip_total_len != byte_cnt ||
                 udp_len != (ip_total_len - 16'd20) ||
                 (udp_len - 16'd8) < 1 || (udp_len - 16'd8) > 256)
            err_code = 4'd2;
        else begin
            folded_ip = ip_sum[15:0] + ip_sum[16];
            folded_ip = folded_ip[15:0] + folded_ip[16];
            if (folded_ip[15:0] != 16'hffff)
                err_code = 4'd3;
            else begin
                // compute UDP checksum in combinatorial logic
                tmp_udp_sum = 16'd0;
                // pseudo header
                tmp_udp_sum = tmp_udp_sum + dst_ip[31:16] + dst_ip[15:0];
                tmp_udp_sum = tmp_udp_sum + buf[12] + (buf[13] << 8) + buf[14] + (buf[15] << 8);
                tmp_udp_sum = tmp_udp_sum + 17 + udp_len;
                // UDP header
                tmp_udp_sum = tmp_udp_sum + {buf[20], buf[21]} + {buf[22], buf[23]} + udp_len + {buf[26], buf[27]};
                // payload
                tmp_udp_chk_idx = 11'd28;
                while (tmp_udp_chk_idx < byte_cnt) begin
                    if (tmp_udp_chk_idx + 1 < byte_cnt)
                        tmp_udp_sum = tmp_udp_sum + {buf[tmp_udp_chk_idx], buf[tmp_udp_chk_idx + 1]};
                    else
                        tmp_udp_sum = tmp_udp_sum + {buf[tmp_udp_chk_idx], 8'd0};
                    tmp_udp_chk_idx = tmp_udp_chk_idx + 2;
                end
                // fold
                folded_udp = {1'b0, tmp_udp_sum[15:0]} + {tmp_udp_sum[16], 15'd0};
                folded_udp = folded_udp[15:0] + folded_udp[16];
                if ({buf[26], buf[27]} != 16'd0 && folded_udp[15:0] != 16'hffff)
                    err_code = 4'd4;
                else if (dst_ip != 32'h0a000002 || dst_port != 16'd9000)
                    err_code = 4'd5;
            end
        end
    end
end

endmodule
