`timescale 1ns/1ps
`default_nettype none

module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output reg s_ready,
input wire s_last,
output reg [7:0] m_data,
output reg m_valid,
input wire m_ready,
output reg m_last,
output reg [31:0] m_src_ip,
output reg [15:0] m_src_port,
output reg [15:0] m_dst_port,
output reg [15:0] m_payload_len,
output reg status_valid,
output reg [3:0] status_error);

reg [7:0] buf [0:511];
reg [9:0] byte_cnt;
reg [9:0] out_ptr;
reg [9:0] out_end;
reg [3:0] err_code;
reg [2:0] state;
reg [16:0] ip_sum_acc;
reg [16:0] udp_sum_acc;
reg [3:0] chk_idx;
reg [9:0] udp_pay_idx;
reg [9:0] udp_pay_end;

localparam S_IDLE = 3'd0;
localparam S_RECV = 3'd1;
localparam S_DRAIN = 3'd2;
localparam S_CHK_IP = 3'd3;
localparam S_CHK_UDP = 3'd4;
localparam S_STATUS = 3'd5;
localparam S_OUT = 3'd6;

always @(posedge clk) begin
    if (rst) begin
        state <= S_IDLE;
        byte_cnt <= 10'd0;
        status_valid <= 1'b0;
        status_error <= 4'd0;
        m_valid <= 1'b0;
        s_ready <= 1'b1;
    end else begin
        status_valid <= 1'b0;
        case (state)
            S_IDLE: begin
                s_ready <= 1'b1;
                m_valid <= 1'b0;
                byte_cnt <= 10'd0;
                if (s_valid) begin
                    if (s_ready) begin
                        buf[0] <= s_data;
                        byte_cnt <= 10'd1;
                        if (s_last) begin
                            state <= S_CHK_IP;
                            ip_sum_acc <= 17'd0;
                            chk_idx <= 4'd0;
                            s_ready <= 1'b0;
                        end else begin
                            state <= S_RECV;
                        end
                    end
                end
            end
            S_RECV: begin
                s_ready <= (byte_cnt < 10'd512) ? 1'b1 : 1'b0;
                if (s_valid && s_ready) begin
                    if (byte_cnt < 10'd512) begin
                        buf[byte_cnt] <= s_data;
                    end
                    byte_cnt <= byte_cnt + 10'd1;
                    if (s_last) begin
                        state <= S_CHK_IP;
                        ip_sum_acc <= 17'd0;
                        chk_idx <= 4'd0;
                        s_ready <= 1'b0;
                    end
                end
            end
            S_DRAIN: begin
                s_ready <= 1'b1;
                if (s_valid && s_last) begin
                    state <= S_CHK_IP;
                    ip_sum_acc <= 17'd0;
                    chk_idx <= 4'd0;
                    s_ready <= 1'b0;
                end
            end
            S_CHK_IP: begin
                s_ready <= 1'b0;
                if (chk_idx < 4'd10) begin
                    ip_sum_acc <= ip_sum_acc + {buf[{2'd0, chk_idx, 1'b0}], buf[{2'd0, chk_idx, 1'b1}]};
                    chk_idx <= chk_idx + 4'd1;
                end else begin
                    state <= S_CHK_UDP;
                    udp_sum_acc <= 17'd0;
                    chk_idx <= 4'd0;
                    udp_pay_idx <= 10'd28;
                    udp_pay_end <= (byte_cnt > 10'd28) ? (byte_cnt - 10'd1) : 10'd28;
                end
            end
            S_CHK_UDP: begin
                s_ready <= 1'b0;
                if (chk_idx == 4'd0) begin
                    udp_sum_acc <= udp_sum_acc + {1'b0, buf[12], buf[13]} + {1'b0, buf[20], buf[21]};
                    chk_idx <= 4'd1;
                end else if (chk_idx == 4'd1) begin
                    udp_sum_acc <= udp_sum_acc + {1'b0, buf[14], buf[15]} + {1'b0, buf[22], buf[23]};
                    chk_idx <= 4'd2;
                end else if (chk_idx == 4'd2) begin
                    udp_sum_acc <= udp_sum_acc + {1'b0, buf[16], buf[17]} + {1'b0, buf[24], buf[25]};
                    chk_idx <= 4'd3;
                end else if (chk_idx == 4'd3) begin
                    udp_sum_acc <= udp_sum_acc + {1'b0, buf[18], buf[19]} + 17'd17 + {9'd0, buf[24], buf[25]};
                    chk_idx <= 4'd4;
                end else if (chk_idx == 4'd4) begin
                    if (udp_pay_idx <= udp_pay_end) begin
                        udp_sum_acc <= udp_sum_acc + {9'd0, buf[udp_pay_idx], (udp_pay_idx < udp_pay_end ? buf[udp_pay_idx+10'd1] : 8'd0)};
                        udp_pay_idx <= udp_pay_idx + 10'd2;
                    end else begin
                        state <= S_STATUS;
                    end
                end
            end
            S_STATUS: begin
                s_ready <= 1'b0;
                status_valid <= 1'b1;
                status_error <= err_code;
                if (err_code == 4'd0) begin
                    state <= S_OUT;
                    out_ptr <= 10'd28;
                    out_end <= byte_cnt - 10'd1;
                    m_src_ip <= {buf[12], buf[13], buf[14], buf[15]};
                    m_src_port <= {buf[20], buf[21]};
                    m_dst_port <= {buf[22], buf[23]};
                    m_payload_len <= {buf[24], buf[25]} - 16'd8;
                    m_valid <= 1'b1;
                    m_data <= buf[10'd28];
                    m_last <= (byte_cnt == 10'd29);
                end else begin
                    state <= S_IDLE;
                    byte_cnt <= 10'd0;
                    m_valid <= 1'b0;
                end
            end
            S_OUT: begin
                s_ready <= 1'b0;
                if (m_valid && m_ready) begin
                    if (m_last) begin
                        state <= S_IDLE;
                        byte_cnt <= 10'd0;
                        m_valid <= 1'b0;
                    end else begin
                        out_ptr <= out_ptr + 10'd1;
                        m_data <= buf[out_ptr + 10'd1];
                        m_last <= ((out_ptr + 10'd1) == out_end);
                    end
                end
            end
            default: begin
                state <= S_IDLE;
                s_ready <= 1'b0;
                m_valid <= 1'b0;
            end
        endcase
    end
end

wire [15:0] ip_folded_raw;
assign ip_folded_raw = ip_sum_acc[15:0] + {15'd0, ip_sum_acc[16]};
wire [15:0] ip_folded;
assign ip_folded = ip_folded_raw[15:0] + {15'd0, ip_folded_raw[16]};

wire [15:0] udp_s1;
assign udp_s1 = udp_sum_acc[15:0] + {15'd0, udp_sum_acc[16]};
wire [15:0] udp_folded;
assign udp_folded = udp_s1[15:0] + {15'd0, udp_s1[16]};

wire [15:0] ip_total_len;
assign ip_total_len = {buf[2], buf[3]};
wire [15:0] udp_len;
assign udp_len = {buf[24], buf[25]};
wire [15:0] payload_len_calc;
assign payload_len_calc = udp_len - 16'd8;
wire [15:0] udp_chk_val;
assign udp_chk_val = {buf[26], buf[27]};

always @(*) begin
    err_code = 4'd0;
    if (state == S_CHK_IP || state == S_CHK_UDP || state == S_STATUS) begin
        if (byte_cnt < 10'd28 || byte_cnt > 10'd512 ||
            buf[0][7:4] != 4'd4 || buf[0][3:0] != 4'd5 ||
            buf[9] != 8'd17 || buf[6][5] != 1'b0 ||
            {buf[6][4:0], buf[7]} != 13'd0) begin
            err_code = 4'd1;
        end else if (ip_total_len != byte_cnt ||
                     udp_len != (ip_total_len - 16'd20) ||
                     payload_len_calc < 16'd1 ||
                     payload_len_calc > 16'd256) begin
            err_code = 4'd2;
        end else if (state == S_CHK_UDP || state == S_STATUS) begin
            if (ip_folded != 16'hffff) begin
                err_code = 4'd3;
            end else if (udp_chk_val != 16'd0 && udp_folded != 16'hffff) begin
                err_code = 4'd4;
            end else if ({buf[16], buf[17], buf[18], buf[19]} != 32'h0a000002 ||
                         {buf[22], buf[23]} != 16'd9000) begin
                err_code = 4'd5;
            end
        end
    end
end

endmodule
