`timescale 1ns/1ps
`default_nettype none

module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
output wire s_ready,
input wire s_valid,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

reg [7:0] buf [0:511];
reg [9:0] byte_cnt;
reg [2:0] state;
reg [3:0] err_code;
reg status_valid_r;
reg [3:0] status_error_r;
reg [9:0] out_ptr;
reg [9:0] out_end;
reg [31:0] r_src_ip;
reg [15:0] r_src_port;
reg [15:0] r_dst_port;
reg [15:0] r_payload_len;
reg [8:0] ip_sum;
reg [8:0] udp_sum;
reg [4:0] chk_idx;
reg drain_oversize;

localparam S_IDLE = 3'd0;
localparam S_RECV = 3'd1;
localparam S_DRAIN = 3'd2;
localparam S_CHK_IP = 3'd3;
localparam S_CHK_UDP = 3'd4;
localparam S_STATUS = 3'd5;
localparam S_OUT = 3'd6;

assign s_ready = (state == S_IDLE) || (state == S_RECV) || (state == S_DRAIN);
assign status_valid = status_valid_r;
assign status_error = status_error_r;
assign m_valid = (state == S_OUT);
assign m_data = (state == S_OUT) ? buf[out_ptr] : 8'd0;
assign m_last = (state == S_OUT) ? (out_ptr == out_end) : 1'b0;
assign m_src_ip = r_src_ip;
assign m_src_port = r_src_port;
assign m_dst_port = r_dst_port;
assign m_payload_len = r_payload_len;

always @(posedge clk) begin
    if (rst) begin
        state <= S_IDLE;
        byte_cnt <= 10'd0;
        status_valid_r <= 1'b0;
        status_error_r <= 4'd0;
        drain_oversize <= 1'b0;
    end else begin
        status_valid_r <= 1'b0;
        case (state)
            S_IDLE: begin
                if (s_valid && s_ready) begin
                    if (byte_cnt < 512) buf[byte_cnt] <= s_data;
                    byte_cnt <= byte_cnt + 10'd1;
                    if (s_last) begin
                        state <= S_CHK_IP;
                        ip_sum <= 9'd0;
                        chk_idx <= 5'd0;
                    end else begin
                        state <= S_RECV;
                    end
                end
            end
            S_RECV: begin
                if (s_valid && s_ready) begin
                    if (byte_cnt < 512) buf[byte_cnt] <= s_data;
                    byte_cnt <= byte_cnt + 10'd1;
                    if (s_last) begin
                        state <= S_CHK_IP;
                        ip_sum <= 9'd0;
                        chk_idx <= 5'd0;
                    end
                end
            end
            S_DRAIN: begin
                if (s_valid && s_ready) begin
                    if (s_last) begin
                        state <= S_CHK_IP;
                        ip_sum <= 9'd0;
                        chk_idx <= 5'd0;
                    end
                end
            end
            S_CHK_IP: begin
                if (chk_idx < 5'd10) begin
                    ip_sum <= ip_sum + {buf[{chk_idx, 1'b0}], buf[{chk_idx, 1'b1}]};
                    chk_idx <= chk_idx + 5'd1;
                end else begin
                    state <= S_CHK_UDP;
                    udp_sum <= 9'd0;
                    chk_idx <= 5'd0;
                end
            end
            S_CHK_UDP: begin
                if (chk_idx < 5'd10) begin
                    udp_sum <= udp_sum + {buf[12 + {chk_idx, 1'b0}], buf[12 + {chk_idx, 1'b1}]} +
                               {buf[20 + {chk_idx, 1'b0}], buf[20 + {chk_idx, 1'b1}]};
                    chk_idx <= chk_idx + 5'd1;
                end else if (chk_idx < 5'd11) begin
                    udp_sum <= udp_sum + 17 + {buf[24], buf[25]};
                    chk_idx <= chk_idx + 5'd1;
                end else begin
                    if (chk_idx < 5'd12 + (byte_cnt[9:1])) begin
                        udp_sum <= udp_sum + {buf[{chk_idx - 5'd12, 1'b0}],
                                              (({chk_idx - 5'd12, 1'b1} < byte_cnt) ? buf[{chk_idx - 5'd12, 1'b1}] : 8'd0)};
                        chk_idx <= chk_idx + 5'd1;
                    end else begin
                        state <= S_STATUS;
                    end
                end
            end
            S_STATUS: begin
                status_valid_r <= 1'b1;
                status_error_r <= err_code;
                if (err_code == 4'd0) begin
                    state <= S_OUT;
                    out_ptr <= 10'd28;
                    out_end <= byte_cnt - 10'd1;
                    r_src_ip <= {buf[12], buf[13], buf[14], buf[15]};
                    r_src_port <= {buf[20], buf[21]};
                    r_dst_port <= {buf[22], buf[23]};
                    r_payload_len <= {buf[24], buf[25]} - 16'd8;
                end else begin
                    state <= S_IDLE;
                    byte_cnt <= 10'd0;
                end
            end
            S_OUT: begin
                if (m_valid && m_ready) begin
                    if (m_last) begin
                        state <= S_IDLE;
                        byte_cnt <= 10'd0;
                    end else begin
                        out_ptr <= out_ptr + 10'd1;
                    end
                end
            end
            default: state <= S_IDLE;
        endcase
    end
end

always @(*) begin
    err_code = 4'd0;
    if (state == S_CHK_IP || state == S_CHK_UDP || state == S_STATUS) begin
        if (byte_cnt < 10'd28 || byte_cnt > 10'd512 ||
            buf[0][7:4] != 4'd4 || buf[0][3:0] != 4'd5 ||
            buf[9] != 8'd17 || buf[6][5] != 1'b0 ||
            {buf[6][4:0], buf[7]} != 13'd0) begin
            err_code = 4'd1;
        end else if ({buf[2], buf[3]} != byte_cnt ||
                     {buf[24], buf[25]} != ({buf[2], buf[3]} - 16'd20) ||
                     ({buf[24], buf[25]} - 16'd8) < 16'd1 ||
                     ({buf[24], buf[25]} - 16'd8) > 16'd256) begin
            err_code = 4'd2;
        end else begin
            if (state == S_CHK_UDP || state == S_STATUS) begin
                if (ip_sum != 9'h1ff) begin
                    err_code = 4'd3;
                end else begin
                    if ({buf[26], buf[27]} != 16'd0) begin
                        if (udp_sum != 9'h1ff) begin
                            err_code = 4'd4;
                        end else begin
                            if ({buf[16], buf[17], buf[18], buf[19]} != 32'h0a000002 ||
                                {buf[22], buf[23]} != 16'd9000) begin
                                err_code = 4'd5;
                            end
                        end
                    end else begin
                        if ({buf[16], buf[17], buf[18], buf[19]} != 32'h0a000002 ||
                            {buf[22], buf[23]} != 16'd9000) begin
                            err_code = 4'd5;
                        end
                    end
                end
            end
        end
    end
end

endmodule
