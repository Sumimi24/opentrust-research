module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

localparam IDLE = 3'd0;
localparam LOAD = 3'd1;
localparam STATUS = 3'd2;
localparam HDR = 3'd3;
localparam PAYLOAD = 3'd4;
localparam DRAIN = 3'd5;

reg [7:0] bytes [0:511];
reg [10:0] n; // up to 512
reg [2:0] state;
reg status_valid_reg;
reg [3:0] status_error_reg;
reg [31:0] m_src_ip_reg;
reg [15:0] m_src_port_reg;
reg [15:0] m_dst_port_reg;
reg [15:0] m_payload_len_reg;
reg hdr_sent;
reg [9:0] out_ptr;
reg m_valid_reg;
reg m_last_reg;
reg [7:0] m_data_reg;

wire [31:0] ip_src_ip;
wire [15:0] udp_src_port, udp_dst_port, udp_length;
wire [7:0] udp_payload_tdata;
wire udp_payload_tvalid, udp_payload_tlast;
wire udp_payload_tready;

assign s_ready = (state == IDLE) && !rst;
assign m_data = m_data_reg;
assign m_valid = (state == PAYLOAD) && m_valid_reg;
assign m_last = (state == PAYLOAD) && m_last_reg;
assign m_src_ip = m_src_ip_reg;
assign m_src_port = m_src_port_reg;
assign m_dst_port = m_dst_port_reg;
assign m_payload_len = m_payload_len_reg;
assign status_valid = status_valid_reg;
assign status_error = status_valid_reg ? status_error_reg : 4'd0;

function [15:0] word16 (input integer offset);
begin
  if (offset+1 < n)
    word16 = {bytes[offset], bytes[offset+1]};
  else if (offset < n)
    word16 = {bytes[offset], 8'd0};
  else
    word16 = 16'd0;
end
endfunction

function [15:0] fold (input [31:0] value);
  reg [16:0] tmp;
begin
  tmp = {1'b0, value[15:0]} + {1'b0, value[31:16]};
  fold = tmp[15:0] + {15'd0, tmp[16]};
end
endfunction

integer i;
reg [31:0] ip_checksum;
reg [31:0] udp_checksum;
reg [15:0] ip_total_len, udp_total_len, payload_len;
reg [3:0] error_code;

always @* begin
  error_code = 4'd0;
  ip_total_len = word16(2);
  udp_total_len = word16(24);
  payload_len = udp_total_len - 16'd8;
  // error1: insufficient length, oversized, version!=4, IHL!=5, protocol!=17, MF=1 or fragment offset!=0
  if (n < 28 || n > 512 || bytes[0][7:4] != 4'd4 || bytes[0][3:0] != 4'd5 || bytes[9] != 8'd17 || bytes[6][5] == 1'b1 || {bytes[6][4:0], bytes[7]} != 13'd0)
    error_code = 4'd1;
  // error2: length mismatches, payload length not in 1..256
  else if (ip_total_len != n[15:0] || udp_total_len != ip_total_len - 16'd20 || payload_len < 16'd1 || payload_len > 16'd256)
    error_code = 4'd2;
  else begin
    // error3: IP header checksum
    ip_checksum = 32'd0;
    for (i = 0; i < 20; i = i + 2)
      ip_checksum = ip_checksum + {16'd0, word16(i)};
    ip_checksum = {16'd0, fold(ip_checksum[31:0])};
    if (ip_checksum != 32'h0000FFFF)
      error_code = 4'd3;
    else begin
      // error4: UDP checksum (nonzero check)
      if (word16(26) != 16'd0) begin
        udp_checksum = 32'd0;
        // pseudoheader
        for (i = 12; i < 20; i = i + 2)
          udp_checksum = udp_checksum + {16'd0, word16(i)};
        udp_checksum = udp_checksum + 32'd17;
        udp_checksum = udp_checksum + {16'd0, udp_total_len};
        // UDP header + payload
        for (i = 20; i < n; i = i + 2) begin
          if (i + 1 < n)
            udp_checksum = udp_checksum + {16'd0, word16(i)};
          else
            udp_checksum = udp_checksum + {8'd0, bytes[i], 8'd0};
        end
        udp_checksum = {16'd0, fold(udp_checksum[31:0])};
        if (udp_checksum != 32'h0000FFFF)
          error_code = 4'd4;
      end
      // error5: destination IP or port mismatch
      if (error_code == 4'd0) begin
        if (ip_src_ip_ip != 32'h0a000002 || word16(22) != 16'd9000)
          error_code = 4'd5;
      end
    end
  end
end

wire ip_src_ip_ip = {bytes[12], bytes[13], bytes[14], bytes[15]};

integer j;

always @(posedge clk) begin
  if (rst) begin
    state <= IDLE;
    n <= 11'd0;
    status_valid_reg <= 1'b0;
    status_error_reg <= 4'd0;
    hdr_sent <= 1'b0;
    out_ptr <= 10'd0;
    m_valid_reg <= 1'b0;
    m_last_reg <= 1'b0;
    m_data_reg <= 8'd0;
    m_src_ip_reg <= 32'd0;
    m_src_port_reg <= 16'd0;
    m_dst_port_reg <= 16'd0;
    m_payload_len_reg <= 16'd0;
  end else begin
    status_valid_reg <= 1'b0;
    case (state)
      IDLE: begin
        if (s_valid && s_ready) begin
          if (n < 512)
            bytes[n] <= s_data;
          n <= n + 11'd1;
          if (s_last)
            state <= STATUS;
        end
      end
      STATUS: begin
        status_valid_reg <= 1'b1;
        status_error_reg <= error_code;
        if (error_code == 4'd0) begin
          state <= HDR;
          hdr_sent <= 1'b0;
          out_ptr <= 10'd20;
          m_src_ip_reg <= {bytes[12], bytes[13], bytes[14], bytes[15]};
          m_src_port_reg <= word16(20);
          m_dst_port_reg <= word16(22);
          m_payload_len_reg <= payload_len;
        end else begin
          state <= IDLE;
          n <= 11'd0;
        end
      end
      HDR: begin
        if (!hdr_sent) begin
          hdr_sent <= 1'b1;
          state <= PAYLOAD;
        end
      end
      PAYLOAD: begin
        if (m_valid_reg && m_ready) begin
          if (m_last_reg) begin
            m_valid_reg <= 1'b0;
            state <= IDLE;
            n <= 11'd0;
          end else begin
            if (out_ptr < n) begin
              m_data_reg <= bytes[out_ptr];
              m_valid_reg <= 1'b1;
              m_last_reg <= (out_ptr == (n - 11'd1));
              out_ptr <= out_ptr + 10'd1;
            end
          end
        end else if (!m_valid_reg && out_ptr < n) begin
          m_data_reg <= bytes[out_ptr];
          m_valid_reg <= 1'b1;
          m_last_reg <= (out_ptr == (n - 11'd1));
          out_ptr <= out_ptr + 10'd1;
        end
      end
      default: state <= IDLE;
    endcase
  end
end

endmodule
