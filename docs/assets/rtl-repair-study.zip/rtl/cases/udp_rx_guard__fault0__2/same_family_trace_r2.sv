module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

localparam IDLE = 3'd0;
localparam LOAD = 3'd1;
localparam STATUS = 3'd2;
localparam HDR = 3'd3;
localparam PAYLOAD = 3'd4;

reg [7:0] bytes [0:511];
reg [10:0] n;
reg [2:0] state;
reg status_valid_reg;
reg [3:0] status_error_reg;
reg [31:0] m_src_ip_reg;
reg [15:0] m_src_port_reg;
reg [15:0] m_dst_port_reg;
reg [15:0] m_payload_len_reg;
reg [9:0] out_ptr;
reg m_valid_reg;
reg m_last_reg;
reg [7:0] m_data_reg;
reg [15:0] payload_len_calc;

assign s_ready = (state == IDLE);
assign m_data = m_data_reg;
assign m_valid = m_valid_reg;
assign m_last = m_last_reg;
assign m_src_ip = m_src_ip_reg;
assign m_src_port = m_src_port_reg;
assign m_dst_port = m_dst_port_reg;
assign m_payload_len = m_payload_len_reg;
assign status_valid = status_valid_reg;
assign status_error = status_error_reg;

function [15:0] word16;
  input integer offset;
  reg [15:0] val;
begin
  val = 16'd0;
  if (offset < 512) val[15:8] = bytes[offset];
  if (offset+1 < 512) val[7:0] = bytes[offset+1];
  word16 = val;
end
endfunction

function [15:0] fold;
  input [31:0] value;
  reg [16:0] tmp;
begin
  tmp = {1'b0, value[15:0]} + {1'b0, value[31:16]};
  fold = tmp[15:0] + {15'd0, tmp[16]};
end
endfunction

integer i;
reg [3:0] error_code;
reg [31:0] chk_sum;
wire [15:0] ip_total_len, udp_total_len;
wire [15:0] payload_len;

assign ip_total_len = word16(2);
assign udp_total_len = word16(24);
assign payload_len = udp_total_len - 16'd8;

wire ip_ver_ihl = bytes[0];
wire ip_flags_frag_hi = bytes[6];
wire ip_frag_lo = bytes[7];
wire ip_proto = bytes[9];
wire [31:0] ip_src = {bytes[12], bytes[13], bytes[14], bytes[15]};
wire [15:0] ip_dst_port = word16(22);
wire [15:0] udp_chksum = word16(26);

always @(posedge clk or posedge rst) begin
  if (rst) begin
    state <= IDLE;
    n <= 11'd0;
    status_valid_reg <= 1'b0;
    status_error_reg <= 4'd0;
    for (i = 0; i < 512; i = i + 1) bytes[i] <= 8'd0;
    out_ptr <= 10'd0;
    m_valid_reg <= 1'b0;
    m_last_reg <= 1'b0;
    m_data_reg <= 8'd0;
    m_src_ip_reg <= 32'd0;
    m_src_port_reg <= 16'd0;
    m_dst_port_reg <= 16'd0;
    m_payload_len_reg <= 16'd0;
    payload_len_calc <= 16'd0;
  end else begin
    if (status_valid_reg)
      status_valid_reg <= 1'b0;
    case (state)
      IDLE: begin
        if (s_valid && s_ready) begin
          if (n < 512)
            bytes[n] <= s_data;
          n <= n + 11'd1;
          if (s_last)
            state <= STATUS;
        end
      end
      STATUS: begin
        error_code = 4'd0;
        if (n < 28 || n > 512 || ip_ver_ihl[7:4] != 4'd4 || ip_ver_ihl[3:0] != 4'd5 || ip_proto != 8'd17 || ip_flags_frag_hi[5] == 1'b1 || {ip_flags_frag_hi[4:0], ip_frag_lo} != 13'd0)
          error_code = 4'd1;
        else if (ip_total_len != n[15:0] || udp_total_len != ip_total_len - 16'd20 || payload_len < 16'd1 || payload_len > 16'd256)
          error_code = 4'd2;
        else begin
          chk_sum = 32'd0;
          for (i = 0; i < 10; i = i + 1)
            chk_sum = chk_sum + {16'd0, word16(i*2)};
          if (fold(chk_sum) != 16'hFFFF)
            error_code = 4'd3;
          else begin
            if (udp_chksum != 16'd0) begin
              chk_sum = 32'd0;
              for (i = 6; i < 10; i = i + 1)
                chk_sum = chk_sum + {16'd0, word16(i*2)};
              chk_sum = chk_sum + 32'd17 + {16'd0, udp_total_len};
              for (i = 10; i < (n/2); i = i + 1)
                chk_sum = chk_sum + {16'd0, word16(i*2)};
              if (n[0] == 1'b1)
                chk_sum = chk_sum + {bytes[n-1], 8'd0};
              if (fold(chk_sum) != 16'hFFFF)
                error_code = 4'd4;
            end
            if (error_code == 4'd0) begin
              if (ip_src != 32'h0a000002 || ip_dst_port != 16'd9000)
                error_code = 4'd5;
            end
          end
        end
        status_valid_reg <= 1'b1;
        status_error_reg <= error_code;
        if (error_code == 4'd0) begin
          m_src_ip_reg <= ip_src;
          m_src_port_reg <= word16(20);
          m_dst_port_reg <= ip_dst_port;
          payload_len_calc <= payload_len;
          m_payload_len_reg <= payload_len;
          out_ptr <= 10'd20;
          m_valid_reg <= 1'b0;
          m_last_reg <= 1'b0;
          state <= HDR;
        end else begin
          n <= 11'd0;
          state <= IDLE;
        end
      end
      HDR: begin
        state <= PAYLOAD;
      end
      PAYLOAD: begin
        if (m_ready && m_valid_reg) begin
          m_valid_reg <= 1'b0;
          if (m_last_reg) begin
            state <= IDLE;
            n <= 11'd0;
          end
        end
        if (!m_valid_reg && out_ptr < n) begin
          m_data_reg <= bytes[out_ptr];
          m_valid_reg <= 1'b1;
          m_last_reg <= (out_ptr == (n - 11'd1));
          out_ptr <= out_ptr + 10'd1;
        end
      end
      default: state <= IDLE;
    endcase
  end
end

endmodule
