`timescale 1ns/1ps
module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error
);

localparam ST_IDLE   = 2'd0;
localparam ST_RECV   = 2'd1;
localparam ST_STATUS = 2'd2;
localparam ST_OUT    = 2'd3;

reg [1:0] state_reg;

reg [7:0] frame_mem [0:511];
reg [9:0] recv_count_reg;
reg oversize_reg;

reg [7:0] m_data_reg;
reg m_valid_reg;
reg m_last_reg;
reg [31:0] m_src_ip_reg;
reg [15:0] m_src_port_reg;
reg [15:0] m_dst_port_reg;
reg [15:0] m_payload_len_reg;
reg status_valid_reg;
reg [3:0] status_error_reg;

reg [9:0] out_index_reg;
reg [9:0] out_end_reg;

assign s_ready = (state_reg == ST_IDLE) || (state_reg == ST_RECV);

assign m_data = m_data_reg;
assign m_valid = m_valid_reg;
assign m_last = m_last_reg;
assign m_src_ip = m_src_ip_reg;
assign m_src_port = m_src_port_reg;
assign m_dst_port = m_dst_port_reg;
assign m_payload_len = m_payload_len_reg;
assign status_valid = status_valid_reg;
assign status_error = status_error_reg;

function [15:0] fold_sum16;
    input [31:0] x;
    reg [31:0] t;
    begin
        t = x;
        t = (t[15:0] + t[31:16]);
        t = (t[15:0] + t[31:16]);
        fold_sum16 = t[15:0];
    end
endfunction

integer i;
reg [3:0] calc_error;
reg [15:0] ip_total_len;
reg [15:0] udp_len;
reg [15:0] payload_len;
reg [31:0] sum_acc;
reg [15:0] folded_sum;
reg [9:0] actual_len;

always @(*) begin
    calc_error = 4'd0;
    actual_len = recv_count_reg;
    ip_total_len = {frame_mem[2], frame_mem[3]};
    udp_len = {frame_mem[24], frame_mem[25]};
    payload_len = udp_len - 16'd8;

    if (actual_len < 10'd28) begin
        calc_error = 4'd1;
    end else if (oversize_reg) begin
        calc_error = 4'd1;
    end else if (frame_mem[0][7:4] != 4'd4) begin
        calc_error = 4'd1;
    end else if (frame_mem[0][3:0] != 4'd5) begin
        calc_error = 4'd1;
    end else if (frame_mem[9] != 8'd17) begin
        calc_error = 4'd1;
    end else if (frame_mem[6][5] != 1'b0) begin
        calc_error = 4'd1;
    end else if ({frame_mem[6][4:0], frame_mem[7]} != 13'd0) begin
        calc_error = 4'd1;
    end else if (ip_total_len != actual_len) begin
        calc_error = 4'd2;
    end else if (udp_len != (ip_total_len - 16'd20)) begin
        calc_error = 4'd2;
    end else if ((payload_len < 16'd1) || (payload_len > 16'd256)) begin
        calc_error = 4'd2;
    end else begin
        sum_acc = 32'd0;
        for (i = 0; i < 20; i = i + 2) begin
            sum_acc = sum_acc + {frame_mem[i], frame_mem[i+1]};
        end
        folded_sum = fold_sum16(sum_acc);
        if (folded_sum != 16'hFFFF) begin
            calc_error = 4'd3;
        end else begin
            if ({frame_mem[26], frame_mem[27]} != 16'd0) begin
                sum_acc = 32'd0;
                sum_acc = sum_acc + {frame_mem[12], frame_mem[13]};
                sum_acc = sum_acc + {frame_mem[14], frame_mem[15]};
                sum_acc = sum_acc + {frame_mem[16], frame_mem[17]};
                sum_acc = sum_acc + {frame_mem[18], frame_mem[19]};
                sum_acc = sum_acc + 16'h0011;
                sum_acc = sum_acc + udp_len;
                for (i = 20; i < actual_len; i = i + 2) begin
                    if (i + 1 < actual_len) begin
                        sum_acc = sum_acc + {frame_mem[i], frame_mem[i+1]};
                    end else begin
                        sum_acc = sum_acc + {frame_mem[i], 8'h00};
                    end
                end
                folded_sum = fold_sum16(sum_acc);
                if (folded_sum != 16'hFFFF) begin
                    calc_error = 4'd4;
                end else if ({frame_mem[16], frame_mem[17], frame_mem[18], frame_mem[19]} != 32'h0A000002) begin
                    calc_error = 4'd5;
                end else if ({frame_mem[22], frame_mem[23]} != 16'd9000) begin
                    calc_error = 4'd5;
                end
            end else begin
                if ({frame_mem[16], frame_mem[17], frame_mem[18], frame_mem[19]} != 32'h0A000002) begin
                    calc_error = 4'd5;
                end else if ({frame_mem[22], frame_mem[23]} != 16'd9000) begin
                    calc_error = 4'd5;
                end
            end
        end
    end
end

always @(posedge clk) begin
    if (rst) begin
        state_reg <= ST_IDLE;
        recv_count_reg <= 10'd0;
        oversize_reg <= 1'b0;
        m_data_reg <= 8'd0;
        m_valid_reg <= 1'b0;
        m_last_reg <= 1'b0;
        m_src_ip_reg <= 32'd0;
        m_src_port_reg <= 16'd0;
        m_dst_port_reg <= 16'd0;
        m_payload_len_reg <= 16'd0;
        status_valid_reg <= 1'b0;
        status_error_reg <= 4'd0;
        out_index_reg <= 10'd0;
        out_end_reg <= 10'd0;
    end else begin
        status_valid_reg <= 1'b0;

        case (state_reg)
            ST_IDLE: begin
                recv_count_reg <= 10'd0;
                oversize_reg <= 1'b0;
                m_valid_reg <= 1'b0;
                m_last_reg <= 1'b0;
                if (s_valid) begin
                    if (10'd0 < 10'd512) begin
                        frame_mem[0] <= s_data;
                    end
                    recv_count_reg <= 10'd1;
                    if (s_last) begin
                        state_reg <= ST_STATUS;
                    end else begin
                        state_reg <= ST_RECV;
                    end
                end
            end

            ST_RECV: begin
                m_valid_reg <= 1'b0;
                m_last_reg <= 1'b0;
                if (s_valid) begin
                    if (recv_count_reg < 10'd512) begin
                        frame_mem[recv_count_reg] <= s_data;
                        recv_count_reg <= recv_count_reg + 10'd1;
                    end else begin
                        oversize_reg <= 1'b1;
                    end
                    if (s_last) begin
                        state_reg <= ST_STATUS;
                    end
                end
            end

            ST_STATUS: begin
                status_valid_reg <= 1'b1;
                status_error_reg <= calc_error;
                if (calc_error == 4'd0) begin
                    m_src_ip_reg <= {frame_mem[12], frame_mem[13], frame_mem[14], frame_mem[15]};
                    m_src_port_reg <= {frame_mem[20], frame_mem[21]};
                    m_dst_port_reg <= {frame_mem[22], frame_mem[23]};
                    m_payload_len_reg <= ({frame_mem[24], frame_mem[25]} - 16'd8);
                    out_index_reg <= 10'd28;
                    out_end_reg <= recv_count_reg;
                    m_data_reg <= frame_mem[28];
                    m_valid_reg <= 1'b1;
                    m_last_reg <= (10'd28 == (recv_count_reg - 10'd1));
                    state_reg <= ST_OUT;
                end else begin
                    m_valid_reg <= 1'b0;
                    m_last_reg <= 1'b0;
                    recv_count_reg <= 10'd0;
                    oversize_reg <= 1'b0;
                    state_reg <= ST_IDLE;
                end
            end

            ST_OUT: begin
                if (m_valid_reg && !m_ready) begin
                    m_valid_reg <= m_valid_reg;
                    m_last_reg <= m_last_reg;
                    m_data_reg <= m_data_reg;
                end else if (m_valid_reg && m_ready) begin
                    if (out_index_reg + 10'd1 < out_end_reg) begin
                        out_index_reg <= out_index_reg + 10'd1;
                        m_data_reg <= frame_mem[out_index_reg + 10'd1];
                        m_valid_reg <= 1'b1;
                        m_last_reg <= ((out_index_reg + 10'd1) == (out_end_reg - 10'd1));
                    end else begin
                        m_valid_reg <= 1'b0;
                        m_last_reg <= 1'b0;
                        recv_count_reg <= 10'd0;
                        oversize_reg <= 1'b0;
                        state_reg <= ST_IDLE;
                    end
                end
            end

            default: begin
                state_reg <= ST_IDLE;
            end
        endcase
    end
end

endmodule
