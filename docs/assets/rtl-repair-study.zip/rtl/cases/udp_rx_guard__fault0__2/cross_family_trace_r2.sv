module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

localparam IDLE = 3'd0;
localparam LOAD = 3'd1;
localparam STATUS = 3'd2;
localparam PAYLOAD = 3'd3;

reg [7:0] bytes [0:511];
reg [10:0] n;
reg [2:0] state;
reg status_valid_reg;
reg [3:0] status_error_reg;
reg [31:0] m_src_ip_reg;
reg [15:0] m_src_port_reg;
reg [15:0] m_dst_port_reg;
reg [15:0] m_payload_len_reg;
reg [9:0] out_ptr;
reg m_valid_reg;
reg m_last_reg;
reg [7:0] m_data_reg;
reg frame_complete;
reg [9:0] payload_bytes;

wire [15:0] ip_total_len;
wire [15:0] udp_len;
wire [15:0] payload_len_calc;
assign ip_total_len = {bytes[2], bytes[3]};
assign udp_len = {bytes[24], bytes[25]};
assign payload_len_calc = udp_len - 16'd8;

assign s_ready = (state == IDLE) && !frame_complete && !rst;
assign m_data = m_data_reg;
assign m_valid = (state == PAYLOAD) && m_valid_reg;
assign m_last = (state == PAYLOAD) && m_last_reg;
assign m_src_ip = m_src_ip_reg;
assign m_src_port = m_src_port_reg;
assign m_dst_port = m_dst_port_reg;
assign m_payload_len = m_payload_len_reg;
assign status_valid = status_valid_reg;
assign status_error = status_error_reg;

function [15:0] fold16(input [31:0] val);
  reg [16:0] sum;
  begin
    sum = {1'b0, val[15:0]} + {1'b0, val[31:16]};
    fold16 = sum[15:0] + {15'd0, sum[16]};
  end
endfunction

integer i;
reg [31:0] checksum_acc;
reg [15:0] checksum_folded;
reg [3:0] err_code;

always @(*) begin
  err_code = 4'd0;
  if (n < 28)
    err_code = 4'd1;
  else if (n > 512)
    err_code = 4'd1;
  else if (bytes[0][7:4] != 4'd4)
    err_code = 4'd1;
  else if (bytes[0][3:0] != 4'd5)
    err_code = 4'd1;
  else if (bytes[9] != 8'd17)
    err_code = 4'd1;
  else if (bytes[6][5] != 1'b0)
    err_code = 4'd1;
  else if ({bytes[6][4:0], bytes[7]} != 13'd0)
    err_code = 4'd1;
  else if (ip_total_len != n[15:0])
    err_code = 4'd2;
  else if (udp_len != ip_total_len - 16'd20)
    err_code = 4'd2;
  else if (payload_len_calc < 16'd1 || payload_len_calc > 16'd256)
    err_code = 4'd2;
  else begin
    checksum_acc = 32'd0;
    for (i = 0; i < 20; i = i + 2)
      checksum_acc = checksum_acc + {bytes[i], bytes[i+1]};
    checksum_folded = fold16(checksum_acc);
    if (checksum_folded != 16'hFFFF)
      err_code = 4'd3;
    else begin
      if ({bytes[26], bytes[27]} != 16'd0) begin
        checksum_acc = 32'd0;
        for (i = 12; i < 20; i = i + 2)
          checksum_acc = checksum_acc + {bytes[i], bytes[i+1]};
        checksum_acc = checksum_acc + 8'd17;
        checksum_acc = checksum_acc + udp_len;
        for (i = 20; i < n; i = i + 2) begin
          if (i + 1 < n)
            checksum_acc = checksum_acc + {bytes[i], bytes[i+1]};
          else
            checksum_acc = checksum_acc + {bytes[i], 8'd0};
        end
        checksum_folded = fold16(checksum_acc);
        if (checksum_folded != 16'hFFFF)
          err_code = 4'd4;
      end
      if (err_code == 4'd0) begin
        if ({bytes[16], bytes[17], bytes[18], bytes[19]} != 32'h0a000002)
          err_code = 4'd5;
        else if ({bytes[22], bytes[23]} != 16'd9000)
          err_code = 4'd5;
      end
    end
  end
end

always @(posedge clk) begin
  if (rst) begin
    state <= IDLE;
    n <= 11'd0;
    status_valid_reg <= 1'b0;
    status_error_reg <= 4'd0;
    m_src_ip_reg <= 32'd0;
    m_src_port_reg <= 16'd0;
    m_dst_port_reg <= 16'd0;
    m_payload_len_reg <= 16'd0;
    out_ptr <= 10'd0;
    m_valid_reg <= 1'b0;
    m_last_reg <= 1'b0;
    m_data_reg <= 8'd0;
    frame_complete <= 1'b0;
    payload_bytes <= 10'd0;
  end else begin
    status_valid_reg <= 1'b0;
    case (state)
      IDLE: begin
        m_valid_reg <= 1'b0;
        m_last_reg <= 1'b0;
        if (s_valid && s_ready) begin
          if (n < 512)
            bytes[n] <= s_data;
          n <= n + 11'd1;
          if (s_last) begin
            frame_complete <= 1'b1;
            state <= STATUS;
          end
        end
      end
      STATUS: begin
        status_valid_reg <= 1'b1;
        status_error_reg <= err_code;
        if (err_code == 4'd0) begin
          m_src_ip_reg <= {bytes[12], bytes[13], bytes[14], bytes[15]};
          m_src_port_reg <= {bytes[20], bytes[21]};
          m_dst_port_reg <= {bytes[22], bytes[23]};
          m_payload_len_reg <= payload_len_calc;
          payload_bytes <= n[9:0] - 10'd28;
          out_ptr <= 10'd28;
          state <= PAYLOAD;
        end else begin
          n <= 11'd0;
          frame_complete <= 1'b0;
          state <= IDLE;
        end
      end
      PAYLOAD: begin
        if (!m_valid_reg || m_ready) begin
          if (out_ptr < n) begin
            m_data_reg <= bytes[out_ptr];
            m_valid_reg <= 1'b1;
            m_last_reg <= (out_ptr == n[9:0] - 10'd1);
            out_ptr <= out_ptr + 10'd1;
          end else begin
            m_valid_reg <= 1'b0;
            m_last_reg <= 1'b0;
            n <= 11'd0;
            frame_complete <= 1'b0;
            state <= IDLE;
          end
        end
      end
      default: state <= IDLE;
    endcase
  end
end

endmodule
