module icache_ctrl(
input wire clk_i,
input wire rst_ni,
input wire req_i,
input wire branch_i,
input wire [31:0] addr_i,
input wire ready_i,
output wire valid_o,
output wire [31:0] rdata_o,
output wire [31:0] addr_o,
output wire err_o,
output wire instr_req_o,
input wire instr_gnt_i,
output wire [31:0] instr_addr_o,
input wire [31:0] instr_rdata_i,
input wire instr_err_i,
input wire instr_rvalid_i,
input wire icache_inval_i,
output wire busy_o);

reg ready_q;
reg [31:0] addr_q;
reg valid_q;
reg [31:0] rdata_q;
reg [31:0] addr_out_q;
reg err_q;

wire core_valid;
wire [31:0] core_rdata;
wire [31:0] core_addr;
wire core_err;
wire core_req;
wire core_gnt;
wire [31:0] core_addr_out;
wire core_rvalid;
wire [31:0] core_rdata_in;
wire core_err_in;
wire core_busy;

wire branch_internal;
wire [31:0] addr_internal;

reg [1:0] tag_req;
reg tag_write;
reg [7:0] tag_addr;
reg [21:0] tag_wdata;
wire [21:0] tag_rdata [0:1];
reg [21:0] tag_rdata_reg [0:1];

reg [1:0] data_req;
reg data_write;
reg [7:0] data_addr;
reg [63:0] data_wdata;
wire [63:0] data_rdata [0:1];
reg [63:0] data_rdata_reg [0:1];

reg [21:0] tag_mem0 [0:255];
reg [21:0] tag_mem1 [0:255];
reg [63:0] data_mem0 [0:255];
reg [63:0] data_mem1 [0:255];

reg pending_valid;
reg [31:0] pending_rdata;
reg [31:0] pending_addr;
reg pending_err;

reg core_ready_int;

assign branch_internal = branch_i;
assign addr_internal = addr_i;

always @(posedge clk_i or negedge rst_ni) begin
  if (!rst_ni) begin
    ready_q <= 1'b0;
    addr_q <= 32'h0;
    valid_q <= 1'b0;
    rdata_q <= 32'h0;
    addr_out_q <= 32'h0;
    err_q <= 1'b0;
    pending_valid <= 1'b0;
    pending_rdata <= 32'h0;
    pending_addr <= 32'h0;
    pending_err <= 1'b0;
    core_ready_int <= 1'b1;
    tag_rdata_reg[0] <= 22'h0;
    tag_rdata_reg[1] <= 22'h0;
    data_rdata_reg[0] <= 64'h0;
    data_rdata_reg[1] <= 64'h0;
  end else begin
    tag_rdata_reg[0] <= tag_rdata[0];
    tag_rdata_reg[1] <= tag_rdata[1];
    data_rdata_reg[0] <= data_rdata[0];
    data_rdata_reg[1] <= data_rdata[1];

    if (branch_i) begin
      ready_q <= ready_i;
      addr_q <= addr_i;
      valid_q <= 1'b0;
      rdata_q <= 32'h0;
      addr_out_q <= 32'h0;
      err_q <= 1'b0;
      pending_valid <= 1'b0;
      pending_rdata <= 32'h0;
      pending_addr <= 32'h0;
      pending_err <= 1'b0;
      core_ready_int <= 1'b1;
    end else begin
      ready_q <= ready_i;
      addr_q <= addr_i;

      if (core_valid && !ready_i) begin
        if (!pending_valid) begin
          pending_valid <= 1'b1;
          pending_rdata <= core_rdata;
          pending_addr <= core_addr;
          pending_err <= core_err;
        end
        core_ready_int <= 1'b0;
      end else if (ready_i) begin
        if (pending_valid) begin
          valid_q <= 1'b1;
          rdata_q <= pending_rdata;
          addr_out_q <= pending_addr;
          err_q <= pending_err;
          pending_valid <= 1'b0;
          if (core_valid) begin
            pending_valid <= 1'b1;
            pending_rdata <= core_rdata;
            pending_addr <= core_addr;
            pending_err <= core_err;
            core_ready_int <= 1'b0;
          end else begin
            valid_q <= 1'b0;
            core_ready_int <= 1'b1;
          end
        end else if (core_valid) begin
          valid_q <= 1'b1;
          rdata_q <= core_rdata;
          addr_out_q <= core_addr;
          err_q <= core_err;
          core_ready_int <= 1'b1;
        end else begin
          valid_q <= 1'b0;
          core_ready_int <= 1'b1;
        end
      end else begin
        if (valid_q && !ready_i) begin
          // hold values
        end else begin
          valid_q <= pending_valid;
          rdata_q <= pending_rdata;
          addr_out_q <= pending_addr;
          err_q <= pending_err;
        end
      end
    end
  end
end

assign valid_o = valid_q;
assign rdata_o = rdata_q;
assign addr_o = addr_out_q;
assign err_o = err_q;

assign core_gnt = instr_gnt_i;
assign core_rdata_in = instr_rdata_i;
assign core_err_in = instr_err_i;
assign core_rvalid = instr_rvalid_i;

ibex_icache #(
  .ICacheECC(0),
  .ResetAll(1),
  .BranchCache(0),
  .TweakInfection(0)
) core (
  .clk_i(clk_i),
  .rst_ni(rst_ni),
  .req_i(req_i),
  .branch_i(branch_internal),
  .addr_i(addr_internal),
  .ready_i(core_ready_int),
  .valid_o(core_valid),
  .rdata_o(core_rdata),
  .addr_o(core_addr),
  .err_o(core_err),
  .instr_req_o(core_req),
  .instr_gnt_i(core_gnt),
  .instr_addr_o(core_addr_out),
  .instr_rdata_i(core_rdata_in),
  .instr_err_i(core_err_in),
  .instr_rvalid_i(core_rvalid),
  .icache_inval_i(icache_inval_i),
  .busy_o(core_busy),
  .ic_tag_req_o(tag_req),
  .ic_tag_write_o(tag_write),
  .ic_tag_addr_o(tag_addr),
  .ic_tag_wdata_o(tag_wdata),
  .ic_tag_rdata_i({tag_rdata_reg[1], tag_rdata_reg[0]}),
  .ic_data_req_o(data_req),
  .ic_data_write_o(data_write),
  .ic_data_addr_o(data_addr),
  .ic_data_wdata_o(data_wdata),
  .ic_data_rdata_i({data_rdata_reg[1], data_rdata_reg[0]}),
  .ic_scr_key_valid_i(1'b1),
  .icache_enable_i(1'b1)
);

assign instr_req_o = core_req;
assign instr_addr_o = core_addr_out;
assign busy_o = core_busy;

assign tag_rdata[0] = tag_mem0[tag_addr];
assign tag_rdata[1] = tag_mem1[tag_addr];
assign data_rdata[0] = data_mem0[data_addr];
assign data_rdata[1] = data_mem1[data_addr];

always @(posedge clk_i) begin
  if (tag_req[0] && tag_write) tag_mem0[tag_addr] <= tag_wdata;
  if (tag_req[1] && tag_write) tag_mem1[tag_addr] <= tag_wdata;
  if (data_req[0] && data_write) data_mem0[data_addr] <= data_wdata;
  if (data_req[1] && data_write) data_mem1[data_addr] <= data_wdata;
end

endmodule
