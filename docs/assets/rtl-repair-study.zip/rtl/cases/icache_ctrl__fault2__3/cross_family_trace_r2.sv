module icache_ctrl(
input wire clk_i,
input wire rst_ni,
input wire req_i,
input wire branch_i,
input wire [31:0] addr_i,
input wire ready_i,
output wire valid_o,
output wire [31:0] rdata_o,
output wire [31:0] addr_o,
output wire err_o,
output wire instr_req_o,
input wire instr_gnt_i,
output wire [31:0] instr_addr_o,
input wire [31:0] instr_rdata_i,
input wire instr_err_i,
input wire instr_rvalid_i,
input wire icache_inval_i,
output wire busy_o
);

reg out_valid_q;
reg [31:0] out_rdata_q;
reg [31:0] out_addr_q;
reg out_err_q;

wire core_valid;
wire [31:0] core_rdata;
wire [31:0] core_addr;
wire core_err;
wire core_busy;
wire core_instr_req;
wire [31:0] core_instr_addr;

wire [1:0] ic_tag_req;
wire ic_tag_write;
wire [7:0] ic_tag_addr;
wire [21:0] ic_tag_wdata;
wire [43:0] ic_tag_rdata;

wire [1:0] ic_data_req;
wire ic_data_write;
wire [7:0] ic_data_addr;
wire [63:0] ic_data_wdata;
wire [127:0] ic_data_rdata;

reg [21:0] tag_mem0 [0:255];
reg [21:0] tag_mem1 [0:255];
reg [63:0] data_mem0 [0:255];
reg [63:0] data_mem1 [0:255];

reg [21:0] tag_rdata0_q;
reg [21:0] tag_rdata1_q;
reg [63:0] data_rdata0_q;
reg [63:0] data_rdata1_q;

reg hold_core_q;
wire core_ready_i;

assign core_ready_i = ready_i & ~hold_core_q;

always @(posedge clk_i or negedge rst_ni) begin
  if (!rst_ni) begin
    out_valid_q <= 1'b0;
    out_rdata_q <= 32'h0;
    out_addr_q <= 32'h0;
    out_err_q <= 1'b0;
    hold_core_q <= 1'b0;
    tag_rdata0_q <= 22'h0;
    tag_rdata1_q <= 22'h0;
    data_rdata0_q <= 64'h0;
    data_rdata1_q <= 64'h0;
  end else begin
    tag_rdata0_q <= tag_mem0[ic_tag_addr];
    tag_rdata1_q <= tag_mem1[ic_tag_addr];
    data_rdata0_q <= data_mem0[ic_data_addr];
    data_rdata1_q <= data_mem1[ic_data_addr];

    if (ic_tag_req[0] && ic_tag_write) tag_mem0[ic_tag_addr] <= ic_tag_wdata;
    if (ic_tag_req[1] && ic_tag_write) tag_mem1[ic_tag_addr] <= ic_tag_wdata;
    if (ic_data_req[0] && ic_data_write) data_mem0[ic_data_addr] <= ic_data_wdata;
    if (ic_data_req[1] && ic_data_write) data_mem1[ic_data_addr] <= ic_data_wdata;

    if (branch_i) begin
      out_valid_q <= 1'b0;
      out_rdata_q <= 32'h0;
      out_addr_q <= 32'h0;
      out_err_q <= 1'b0;
      hold_core_q <= 1'b0;
    end else begin
      if (hold_core_q) begin
        if (ready_i) begin
          hold_core_q <= 1'b0;
          out_valid_q <= core_valid;
          out_rdata_q <= core_rdata;
          out_addr_q <= core_addr;
          out_err_q <= core_err;
        end
      end else begin
        out_valid_q <= core_valid;
        out_rdata_q <= core_rdata;
        out_addr_q <= core_addr;
        out_err_q <= core_err;
        if (core_valid && !ready_i) begin
          hold_core_q <= 1'b1;
        end
      end
    end
  end
end

assign valid_o = out_valid_q;
assign rdata_o = out_rdata_q;
assign addr_o = out_addr_q;
assign err_o = out_err_q;

assign instr_req_o = core_instr_req;
assign instr_addr_o = core_instr_addr;
assign busy_o = core_busy;

assign ic_tag_rdata = {tag_rdata1_q, tag_rdata0_q};
assign ic_data_rdata = {data_rdata1_q, data_rdata0_q};

ibex_icache #(
  .ICacheECC(0),
  .BranchCache(0),
  .ResetAll(1'b0),
  .TweakInfection(0)
) u_ibex_icache (
  .clk_i(clk_i),
  .rst_ni(rst_ni),
  .req_i(req_i),
  .branch_i(branch_i),
  .addr_i(addr_i),
  .ready_i(core_ready_i),
  .valid_o(core_valid),
  .rdata_o(core_rdata),
  .addr_o(core_addr),
  .err_o(core_err),
  .instr_req_o(core_instr_req),
  .instr_gnt_i(instr_gnt_i),
  .instr_addr_o(core_instr_addr),
  .instr_rdata_i(instr_rdata_i),
  .instr_err_i(instr_err_i),
  .instr_rvalid_i(instr_rvalid_i),
  .ic_tag_req_o(ic_tag_req),
  .ic_tag_write_o(ic_tag_write),
  .ic_tag_addr_o(ic_tag_addr),
  .ic_tag_wdata_o(ic_tag_wdata),
  .ic_tag_rdata_i(ic_tag_rdata),
  .ic_data_req_o(ic_data_req),
  .ic_data_write_o(ic_data_write),
  .ic_data_addr_o(ic_data_addr),
  .ic_data_wdata_o(ic_data_wdata),
  .ic_data_rdata_i(ic_data_rdata),
  .ic_scr_key_valid_i(1'b1),
  .icache_enable_i(1'b1),
  .icache_inval_i(icache_inval_i),
  .busy_o(core_busy)
);

endmodule
