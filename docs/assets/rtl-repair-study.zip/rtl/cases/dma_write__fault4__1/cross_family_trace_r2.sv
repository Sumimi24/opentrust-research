`timescale 1ns / 1ps
`default_nettype none

module dma_write(
input wire clk,
input wire rst,
input wire [15:0] desc_addr,
input wire [15:0] desc_len,
input wire [7:0] desc_tag,
input wire desc_valid,
output wire desc_ready,
input wire [31:0] s_data,
input wire [3:0] s_keep,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [15:0] status_len,
output wire [7:0] status_tag,
output wire [3:0] status_error,
output wire status_valid,
output wire [3:0] m_axi_awid,
output wire [15:0] m_axi_awaddr,
output wire [7:0] m_axi_awlen,
output wire [2:0] m_axi_awsize,
output wire [1:0] m_axi_awburst,
output wire m_axi_awlock,
output wire [3:0] m_axi_awcache,
output wire [2:0] m_axi_awprot,
output wire m_axi_awvalid,
input wire m_axi_awready,
output wire [31:0] m_axi_wdata,
output wire [3:0] m_axi_wstrb,
output wire m_axi_wlast,
output wire m_axi_wvalid,
input wire m_axi_wready,
input wire [3:0] m_axi_bid,
input wire [1:0] m_axi_bresp,
input wire m_axi_bvalid,
output wire m_axi_bready);

localparam S_IDLE = 3'd0;
localparam S_RUN  = 3'd1;
localparam S_WAIT = 3'd2;
localparam S_DONE = 3'd3;

reg [2:0] state;
reg [15:0] d_addr;
reg [15:0] d_len;
reg [7:0]  d_tag;
reg [15:0] bytes_left;
reg [15:0] b_total;
reg [15:0] b_done;
reg [3:0]  err_acc;
reg        aw_sent;
reg [7:0]  aw_len_reg;
reg [15:0] aw_addr_reg;
reg        stream_done;

assign desc_ready = (state == S_IDLE);

assign status_len   = d_len;
assign status_tag   = d_tag;
assign status_error = err_acc;
assign status_valid = (state == S_DONE);

assign m_axi_awid    = 4'd0;
assign m_axi_awaddr  = aw_addr_reg;
assign m_axi_awlen   = aw_len_reg;
assign m_axi_awsize  = 3'd2;
assign m_axi_awburst = 2'b01;
assign m_axi_awlock  = 1'b0;
assign m_axi_awcache = 4'd3;
assign m_axi_awprot  = 3'd0;
assign m_axi_awvalid = (state == S_RUN) && !aw_sent && !stream_done && (bytes_left > 0);

reg [31:0] w_data_reg;
reg [3:0]  w_strb_reg;
reg        w_last_reg;

assign m_axi_wdata  = w_data_reg;
assign m_axi_wstrb  = w_strb_reg;
assign m_axi_wlast  = w_last_reg;
assign m_axi_wvalid = (state == S_RUN) && s_valid && !stream_done;
assign s_ready      = (state == S_RUN) && m_axi_wready && !stream_done;

assign m_axi_bready = (state == S_RUN || state == S_WAIT) && (b_done < b_total);

always @(posedge clk) begin
    if (rst) begin
        state       <= S_IDLE;
        bytes_left  <= 16'd0;
        b_total     <= 16'd0;
        b_done      <= 16'd0;
        err_acc     <= 4'd0;
        aw_sent     <= 1'b0;
        stream_done <= 1'b0;
    end else begin
        case (state)
            S_IDLE: begin
                aw_sent     <= 1'b0;
                stream_done <= 1'b0;
                b_total     <= 16'd0;
                b_done      <= 16'd0;
                err_acc     <= 4'd0;
                if (desc_valid) begin
                    d_addr     <= desc_addr;
                    d_len      <= desc_len;
                    d_tag      <= desc_tag;
                    bytes_left <= desc_len;
                    state      <= S_RUN;
                end
            end

            S_RUN: begin
                if (m_axi_awvalid && m_axi_awready) begin
                    aw_sent <= 1'b1;
                end

                if (m_axi_wvalid && m_axi_wready) begin
                    if (s_last) begin
                        stream_done <= 1'b1;
                    end
                end

                if (m_axi_bvalid && m_axi_bready) begin
                    b_done <= b_done + 16'd1;
                    if (m_axi_bresp == 2'b11)
                        err_acc <= 4'd7;
                    else if (m_axi_bresp == 2'b10 && err_acc != 4'd7)
                        err_acc <= 4'd6;
                end

                if (stream_done && aw_sent && (b_done + (m_axi_bvalid && m_axi_bready ? 16'd1 : 16'd0)) >= b_total) begin
                    state <= S_DONE;
                end else if (stream_done && aw_sent) begin
                    state <= S_WAIT;
                end
            end

            S_WAIT: begin
                if (m_axi_bvalid && m_axi_bready) begin
                    b_done <= b_done + 16'd1;
                    if (m_axi_bresp == 2'b11)
                        err_acc <= 4'd7;
                    else if (m_axi_bresp == 2'b10 && err_acc != 4'd7)
                        err_acc <= 4'd6;
                    if ((b_done + 16'd1) >= b_total)
                        state <= S_DONE;
                end
            end

            S_DONE: begin
                state <= S_IDLE;
            end

            default: state <= S_IDLE;
        endcase
    end
end

reg [31:0] wd;
reg [3:0]  ws;
reg        wl;

always @(*) begin
    wd = s_data;
    ws = s_keep;
    wl = 1'b0;

    if (state == S_RUN && !stream_done && s_valid) begin
        wl = s_last;
    end
end

always @(posedge clk) begin
    if (!rst) begin
        if (state == S_RUN && m_axi_wvalid && m_axi_wready) begin
            w_data_reg <= wd;
            w_strb_reg <= ws;
            w_last_reg <= wl;
        end
        if (m_axi_wvalid && m_axi_wready) begin
            if (state == S_RUN) begin
                b_total <= b_total + 16'd1;
            end
        end
    end
end

reg [15:0] c_start;
reg [15:0] c_rem;
reg [15:0] max_page;
reg [15:0] max_16;
reg [15:0] max_bytes;
reg [15:0] eff_bytes;
reg [7:0]  beats;

always @(*) begin
    c_start   = {d_addr[15:2], 2'b00};
    c_rem     = bytes_left;
    max_page  = 16'd4096 - {d_addr[11:2], 2'b00};
    max_16    = 16'd64 - {d_addr[5:2], 2'b00};
    max_bytes = (max_page < max_16) ? max_page : max_16;
    eff_bytes = (max_bytes < c_rem) ? max_bytes : c_rem;
    beats     = eff_bytes[15:2] + |eff_bytes[1:0];
    if (beats == 8'd0) beats = 8'd1;
    aw_len_reg  = beats - 8'd1;
    aw_addr_reg = {d_addr[15:2], 2'b00};
end

endmodule
