`timescale 1ns/1ps
module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error
);

localparam ST_RECV   = 2'd0;
localparam ST_PARSE  = 2'd1;
localparam ST_OUTPUT = 2'd2;

reg [1:0] state_reg;

reg [7:0] frame_mem [0:511];
reg [9:0] frame_len_reg;
reg oversize_reg;

reg [9:0] parse_payload_idx_reg;
reg [9:0] out_payload_idx_reg;

reg [31:0] src_ip_reg;
reg [15:0] src_port_reg;
reg [15:0] dst_port_reg;
reg [15:0] payload_len_reg;

reg accepted_reg;

reg [7:0] m_data_reg;
reg m_valid_reg;
reg m_last_reg;

reg status_valid_reg;
reg [3:0] status_error_reg;

integer i;
reg [15:0] ip_total_length;
reg [15:0] udp_length;
reg [15:0] udp_checksum_field;
reg [15:0] ip_word;
reg [15:0] udp_word;
reg [19:0] sum20;
reg [31:0] dst_ip_tmp;
reg [9:0] actual_len10;
reg [9:0] payload_len10;
reg [3:0] err_next;
reg [15:0] folded16;

function [15:0] fold16;
    input [19:0] x;
    reg [19:0] t;
    begin
        t = x;
        t = {4'd0, t[15:0]} + t[19:16];
        t = {4'd0, t[15:0]} + t[19:16];
        fold16 = t[15:0];
    end
endfunction

assign s_ready = (!rst) && (state_reg == ST_RECV) && (!accepted_reg || ((m_valid_reg == 1'b0) && (out_payload_idx_reg == payload_len_reg[9:0])));
assign m_data = m_data_reg;
assign m_valid = m_valid_reg;
assign m_last = m_last_reg;
assign m_src_ip = src_ip_reg;
assign m_src_port = src_port_reg;
assign m_dst_port = dst_port_reg;
assign m_payload_len = payload_len_reg;
assign status_valid = status_valid_reg;
assign status_error = status_error_reg;

always @(posedge clk) begin
    if (rst) begin
        state_reg <= ST_RECV;
        frame_len_reg <= 10'd0;
        oversize_reg <= 1'b0;
        parse_payload_idx_reg <= 10'd0;
        out_payload_idx_reg <= 10'd0;
        src_ip_reg <= 32'd0;
        src_port_reg <= 16'd0;
        dst_port_reg <= 16'd0;
        payload_len_reg <= 16'd0;
        accepted_reg <= 1'b0;
        m_data_reg <= 8'd0;
        m_valid_reg <= 1'b0;
        m_last_reg <= 1'b0;
        status_valid_reg <= 1'b0;
        status_error_reg <= 4'd0;
    end else begin
        status_valid_reg <= 1'b0;

        if (state_reg == ST_OUTPUT) begin
            if (m_valid_reg && m_ready) begin
                if (m_last_reg) begin
                    m_valid_reg <= 1'b0;
                    m_last_reg <= 1'b0;
                    accepted_reg <= 1'b0;
                    out_payload_idx_reg <= payload_len_reg[9:0];
                    state_reg <= ST_RECV;
                    frame_len_reg <= 10'd0;
                    oversize_reg <= 1'b0;
                end else begin
                    out_payload_idx_reg <= out_payload_idx_reg + 10'd1;
                    m_data_reg <= frame_mem[10'd28 + out_payload_idx_reg + 10'd1];
                    m_last_reg <= ((out_payload_idx_reg + 10'd1) == (payload_len_reg[9:0] - 10'd1));
                    m_valid_reg <= 1'b1;
                end
            end
        end else if (state_reg == ST_RECV) begin
            if (s_valid && s_ready) begin
                if (frame_len_reg < 10'd512) begin
                    frame_mem[frame_len_reg] <= s_data;
                end
                if (!oversize_reg) begin
                    if (frame_len_reg == 10'd511) begin
                        oversize_reg <= 1'b1;
                    end
                end
                frame_len_reg <= frame_len_reg + 10'd1;

                if (s_last) begin
                    state_reg <= ST_PARSE;
                end
            end
        end else begin
            actual_len10 = frame_len_reg;

            err_next = 4'd0;

            if (oversize_reg || (actual_len10 < 10'd28)) begin
                err_next = 4'd1;
            end else begin
                if (frame_mem[0][7:4] != 4'd4) begin
                    err_next = 4'd1;
                end else if (frame_mem[0][3:0] != 4'd5) begin
                    err_next = 4'd1;
                end else if (frame_mem[9] != 8'd17) begin
                    err_next = 4'd1;
                end else if (frame_mem[6][5] != 1'b0) begin
                    err_next = 4'd1;
                end else if ({frame_mem[6][4:0], frame_mem[7]} != 13'd0) begin
                    err_next = 4'd1;
                end
            end

            ip_total_length = {frame_mem[2], frame_mem[3]};
            udp_length = {frame_mem[24], frame_mem[25]};
            payload_len10 = udp_length - 16'd8;
            dst_ip_tmp = {frame_mem[16], frame_mem[17], frame_mem[18], frame_mem[19]};

            if (err_next == 4'd0) begin
                if (ip_total_length != actual_len10[15:0]) begin
                    err_next = 4'd2;
                end else if (udp_length != (ip_total_length - 16'd20)) begin
                    err_next = 4'd2;
                end else if (udp_length < 16'd9) begin
                    err_next = 4'd2;
                end else if (payload_len10 > 10'd256) begin
                    err_next = 4'd2;
                end
            end

            if (err_next == 4'd0) begin
                sum20 = 20'd0;
                for (i = 0; i < 20; i = i + 2) begin
                    ip_word = {frame_mem[i], frame_mem[i+1]};
                    sum20 = sum20 + ip_word;
                end
                folded16 = fold16(sum20);
                if (folded16 != 16'hFFFF) begin
                    err_next = 4'd3;
                end
            end

            udp_checksum_field = {frame_mem[26], frame_mem[27]};
            if (err_next == 4'd0) begin
                if (udp_checksum_field != 16'd0) begin
                    sum20 = 20'd0;
                    sum20 = sum20 + {frame_mem[12], frame_mem[13]};
                    sum20 = sum20 + {frame_mem[14], frame_mem[15]};
                    sum20 = sum20 + {frame_mem[16], frame_mem[17]};
                    sum20 = sum20 + {frame_mem[18], frame_mem[19]};
                    sum20 = sum20 + 16'h0011;
                    sum20 = sum20 + udp_length;

                    for (i = 20; i < 512; i = i + 2) begin
                        if (i < actual_len10) begin
                            if ((i + 1) < actual_len10) begin
                                udp_word = {frame_mem[i], frame_mem[i+1]};
                            end else begin
                                udp_word = {frame_mem[i], 8'h00};
                            end
                            sum20 = sum20 + udp_word;
                        end
                    end

                    folded16 = fold16(sum20);
                    if (folded16 != 16'hFFFF) begin
                        err_next = 4'd4;
                    end
                end
            end

            if (err_next == 4'd0) begin
                if (dst_ip_tmp != 32'h0A000002) begin
                    err_next = 4'd5;
                end else if ({frame_mem[22], frame_mem[23]} != 16'd9000) begin
                    err_next = 4'd5;
                end
            end

            status_valid_reg <= 1'b1;
            status_error_reg <= err_next;

            if (err_next == 4'd0) begin
                src_ip_reg <= {frame_mem[12], frame_mem[13], frame_mem[14], frame_mem[15]};
                src_port_reg <= {frame_mem[20], frame_mem[21]};
                dst_port_reg <= {frame_mem[22], frame_mem[23]};
                payload_len_reg <= payload_len10[15:0];
                accepted_reg <= 1'b1;
                out_payload_idx_reg <= 10'd0;

                if (payload_len10 != 10'd0) begin
                    m_data_reg <= frame_mem[10'd28];
                    m_valid_reg <= 1'b1;
                    m_last_reg <= (payload_len10 == 10'd1);
                    state_reg <= ST_OUTPUT;
                end else begin
                    m_valid_reg <= 1'b0;
                    m_last_reg <= 1'b0;
                    accepted_reg <= 1'b0;
                    state_reg <= ST_RECV;
                    frame_len_reg <= 10'd0;
                    oversize_reg <= 1'b0;
                end
            end else begin
                frame_len_reg <= 10'd0;
                oversize_reg <= 1'b0;
                state_reg <= ST_RECV;
                m_valid_reg <= 1'b0;
                m_last_reg <= 1'b0;
            end
        end
    end
end

endmodule
