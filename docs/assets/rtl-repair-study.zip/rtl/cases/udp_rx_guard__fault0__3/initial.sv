module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

reg [7:0] bytes[0:511];
reg [9:0] n;
reg [9:0] ptr;
reg [2:0] state;
reg status_valid_reg;
reg [3:0] status_error_reg;
reg [17:0] ip_sum;
reg [17:0] udp_sum;
reg [15:0] ip_len;
reg [15:0] udp_len;
reg [3:0] error_code;
reg [9:0] j;
reg [15:0] word_val;
reg [17:0] fold_val;
reg [31:0] m_src_ip_reg;
reg [15:0] m_src_port_reg;
reg [15:0] m_dst_port_reg;
reg [15:0] m_payload_len_reg;
reg [7:0] m_data_reg;
reg m_valid_reg;
reg m_last_reg;
reg hdr_ready;
reg parse_ready;
reg [15:0] parsed_length;
reg [9:0] udp_payload_len;
reg ip_checksum_ok;
reg udp_checksum_ok;
reg [17:0] temp_sum;

wire [15:0] word16_input;
reg [9:0] word16_offset;

function automatic [15:0] fold16(input [17:0] val);
    reg [17:0] v;
    begin
        v = val;
        v = (v & 16'hFFFF) + (v >> 16);
        v = (v & 16'hFFFF) + (v >> 16);
        fold16 = v[15:0];
    end
endfunction

always @(*) begin
    word16_offset = ptr;
end

assign s_ready = !rst && state == 3'd0;

always @(posedge clk) begin
    if (rst) begin
        state <= 3'd0;
        n <= 10'd0;
        ptr <= 10'd20;
        status_valid_reg <= 1'b0;
        status_error_reg <= 4'd0;
        m_valid_reg <= 1'b0;
        m_last_reg <= 1'b0;
        m_data_reg <= 8'd0;
        m_src_ip_reg <= 32'd0;
        m_src_port_reg <= 16'd0;
        m_dst_port_reg <= 16'd0;
        m_payload_len_reg <= 16'd0;
        ip_checksum_ok <= 1'b0;
        udp_checksum_ok <= 1'b0;
        parsed_length <= 16'd0;
    end else begin
        status_valid_reg <= 1'b0;
        
        case (state)
            3'd0: begin
                m_valid_reg <= 1'b0;
                if (s_valid && s_ready) begin
                    if (n < 10'd512) begin
                        bytes[n] <= s_data;
                    end
                    n <= n + 10'd1;
                    if (s_last) begin
                        state <= 3'd1;
                    end
                end
            end
            
            3'd1: begin
                // Calculate all checksums and validations
                ip_len = {bytes[2], bytes[3]};
                udp_len = {bytes[24], bytes[25]};
                error_code = 4'd0;
                
                // Error 1: Basic header checks
                if (n < 10'd28 || n > 10'd512) begin
                    error_code = 4'd1;
                end else if (bytes[0] != 8'h45) begin // version=4, IHL=5
                    error_code = 4'd1;
                end else if (bytes[9] != 8'd17) begin // protocol=UDP
                    error_code = 4'd1;
                end else if ((bytes[6] & 8'h20) != 8'h00) begin // MF flag
                    error_code = 4'd1;
                end else if (bytes[7] != 8'h00 || (bytes[6] & 8'h1F) != 8'h00) begin // fragment offset != 0
                    error_code = 4'd1;
                end else begin
                    // Error 2: Length checks
                    if (ip_len != n[15:0]) begin
                        error_code = 4'd2;
                    end else if (udp_len != ip_len - 16'd20) begin
                        error_code = 4'd2;
                    end else begin
                        udp_payload_len = udp_len - 16'd8;
                        if (udp_payload_len < 10'd1 || udp_payload_len > 10'd256) begin
                            error_code = 4'd2;
                        end else begin
                            // Error 3: IP header checksum
                            ip_sum = 18'd0;
                            for (j = 0; j < 10; j = j + 1) begin
                                ip_sum = ip_sum + {10'd0, bytes[j*2], bytes[j*2+1]};
                            end
                            if (fold16(ip_sum) != 16'hFFFF) begin
                                error_code = 4'd3;
                            end else begin
                                // Error 4: UDP checksum
                                if ({bytes[26], bytes[27]} == 16'd0) begin
                                    // Zero checksum accepted
                                    udp_checksum_ok = 1'b1;
                                end else begin
                                    // Pseudo-header: src IP (4 bytes) + dst IP (4 bytes) + zero + protocol + UDP length
                                    udp_sum = 18'd0;
                                    // Source IP
                                    udp_sum = udp_sum + {10'd0, bytes[12], bytes[13]};
                                    udp_sum = udp_sum + {10'd0, bytes[14], bytes[15]};
                                    // Dest IP
                                    udp_sum = udp_sum + {10'd0, bytes[16], bytes[17]};
                                    udp_sum = udp_sum + {10'd0, bytes[18], bytes[19]};
                                    // Zero + protocol
                                    udp_sum = udp_sum + {10'd0, 8'd0, 8'd17};
                                    // UDP length
                                    udp_sum = udp_sum + {10'd0, bytes[24], bytes[25]};
                                    // UDP header and payload
                                    for (j = 10'd20; j < n; j = j + 2) begin
                                        if (j + 1 < n) begin
                                            udp_sum = udp_sum + {10'd0, bytes[j], bytes[j+1]};
                                        end else begin
                                            // Odd byte, pad with zero
                                            udp_sum = udp_sum + {10'd0, bytes[j], 8'd0};
                                        end
                                    end
                                    if (fold16(udp_sum) != 16'hFFFF) begin
                                        error_code = 4'd4;
                                    end
                                end
                                
                                // Error 5: Destination checks
                                if (error_code == 4'd0) begin
                                    if ({bytes[16], bytes[17], bytes[18], bytes[19]} != 32'h0A000002) begin
                                        error_code = 4'd5;
                                    end else if ({bytes[22], bytes[23]} != 16'd9000) begin
                                        error_code = 4'd5;
                                    end
                                end
                            end
                        end
                    end
                end
                
                status_valid_reg <= 1'b1;
                status_error_reg <= error_code;
                
                if (error_code == 4'd0) begin
                    // Valid packet - setup output
                    m_src_ip_reg <= {bytes[12], bytes[13], bytes[14], bytes[15]};
                    m_src_port_reg <= {bytes[20], bytes[21]};
                    m_dst_port_reg <= {bytes[22], bytes[23]};
                    m_payload_len_reg <= udp_len - 16'd8;
                    parsed_length <= udp_len;
                    ptr <= 10'd28; // Start of UDP payload (after 20 byte IP + 8 byte UDP header)
                    state <= 3'd2;
                end else begin
                    // Invalid packet - reset and rearm
                    state <= 3'd0;
                    n <= 10'd0;
                end
            end
            
            3'd2: begin
                // Output payload bytes
                if (m_ready || !m_valid_reg) begin
                    if (ptr < n) begin
                        m_data_reg <= bytes[ptr];
                        m_valid_reg <= 1'b1;
                        if (ptr == n - 10'd1) begin
                            m_last_reg <= 1'b1;
                            state <= 3'd3;
                        end else begin
                            m_last_reg <= 1'b0;
                            ptr <= ptr + 10'd1;
                        end
                    end
                end
            end
            
            3'd3: begin
                // Wait for last byte to be accepted
                if (m_ready && m_valid_reg && m_last_reg) begin
                    m_valid_reg <= 1'b0;
                    m_last_reg <= 1'b0;
                    state <= 3'd0;
                    n <= 10'd0;
                    ptr <= 10'd20;
                end
            end
            
            default: begin
                state <= 3'd0;
            end
        endcase
    end
end

assign m_data = m_data_reg;
assign m_valid = m_valid_reg;
assign m_last = m_last_reg;
assign m_src_ip = m_src_ip_reg;
assign m_src_port = m_src_port_reg;
assign m_dst_port = m_dst_port_reg;
assign m_payload_len = m_payload_len_reg;
assign status_valid = status_valid_reg;
assign status_error = status_error_reg;

endmodule
