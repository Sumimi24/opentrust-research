module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

// State encoding
localparam IDLE = 3'd0;
localparam RECEIVE = 3'd1;
localparam PARSE = 3'd2;
localparam OUTPUT = 3'd3;
localparam OUTPUT_LAST = 3'd4;
localparam STATUS = 3'd5;
localparam DRAIN_OVERSIZE = 3'd6;

reg [2:0] state;
reg [9:0] n; // bytes received
reg [9:0] ptr; // output pointer
reg [9:0] payload_len; // actual payload length
reg [15:0] ip_total_len;
reg [15:0] udp_total_len;
reg [15:0] udp_payload_len16;

// Buffer for frame (max 512 bytes)
reg [7:0] bytes[0:511];

// Output registers
reg [7:0] m_data_reg;
reg m_valid_reg;
reg m_last_reg;
reg [31:0] m_src_ip_reg;
reg [15:0] m_src_port_reg;
reg [15:0] m_dst_port_reg;
reg [15:0] m_payload_len_reg;
reg status_valid_reg;
reg [3:0] status_error_reg;

// Error detection
reg [3:0] error_code;

// Checksum calculation
reg [17:0] ip_checksum_acc;
reg [17:0] udp_checksum_acc;
reg ip_checksum_ok;
reg udp_checksum_ok;

// Control
reg frame_valid;
reg [9:0] j;
reg [9:0] k;

// Combinational checksum folding
function automatic [15:0] fold16(input [17:0] val);
    reg [17:0] tmp;
    begin
        tmp = val;
        tmp = (tmp & 18'h0FFFF) + (tmp >> 16);
        tmp = (tmp & 18'h0FFFF) + (tmp >> 16);
        fold16 = tmp[15:0];
    end
endfunction

// State machine
always @(posedge clk) begin
    if (rst) begin
        state <= IDLE;
        n <= 10'd0;
        ptr <= 10'd0;
        m_valid_reg <= 1'b0;
        m_last_reg <= 1'b0;
        status_valid_reg <= 1'b0;
        status_error_reg <= 4'd0;
        m_data_reg <= 8'd0;
        m_src_ip_reg <= 32'd0;
        m_src_port_reg <= 16'd0;
        m_dst_port_reg <= 16'd0;
        m_payload_len_reg <= 16'd0;
    end else begin
        status_valid_reg <= 1'b0;
        
        case (state)
            IDLE: begin
                n <= 10'd0;
                m_valid_reg <= 1'b0;
                m_last_reg <= 1'b0;
                if (s_valid) begin
                    state <= RECEIVE;
                    bytes[0] <= s_data;
                    n <= 10'd1;
                    if (s_last) begin
                        state <= PARSE;
                    end
                end
            end
            
            RECEIVE: begin
                if (s_valid) begin
                    if (n < 10'd512) begin
                        bytes[n] <= s_data;
                    end
                    n <= n + 10'd1;
                    if (s_last) begin
                        state <= PARSE;
                    end else if (n == 10'd511) begin
                        // Reached max, wait for last to drain oversize
                        state <= DRAIN_OVERSIZE;
                    end
                end
            end
            
            DRAIN_OVERSIZE: begin
                // Wait for s_last while discarding data
                if (s_valid && s_last) begin
                    n <= n + 10'd1; // Mark as oversize
                    state <= PARSE;
                end
            end
            
            PARSE: begin
                // Default error code
                error_code = 4'd0;
                frame_valid = 1'b0;
                
                // Error 1 checks
                if (n < 10'd28) begin
                    error_code = 4'd1;
                end else if (n > 10'd512) begin
                    error_code = 4'd1;
                end else if (bytes[0] != 8'h45) begin // version=4, IHL=5
                    error_code = 4'd1;
                end else if (bytes[9] != 8'd17) begin // protocol=UDP
                    error_code = 4'd1;
                end else if ((bytes[6] & 8'h20) != 8'h00) begin // MF flag
                    error_code = 4'd1;
                end else if (({bytes[6], bytes[7]} & 16'h1FFF) != 16'h0000) begin // fragment offset != 0
                    error_code = 4'd1;
                end else begin
                    // Extract lengths
                    ip_total_len = {bytes[2], bytes[3]};
                    udp_total_len = {bytes[24], bytes[25]};
                    
                    // Error 2 checks
                    if (ip_total_len != n[15:0]) begin
                        error_code = 4'd2;
                    end else if (udp_total_len != ip_total_len - 16'd20) begin
                        error_code = 4'd2;
                    end else begin
                        udp_payload_len16 = udp_total_len - 16'd8;
                        if (udp_payload_len16 < 16'd1 || udp_payload_len16 > 16'd256) begin
                            error_code = 4'd2;
                        end else begin
                            // Error 3: IP header checksum
                            ip_checksum_acc = 18'd0;
                            for (j = 0; j < 10; j = j + 1) begin
                                ip_checksum_acc = ip_checksum_acc + {2'b00, bytes[j*2], bytes[j*2+1]};
                            end
                            ip_checksum_ok = (fold16(ip_checksum_acc) == 16'hFFFF);
                            
                            if (!ip_checksum_ok) begin
                                error_code = 4'd3;
                            end else begin
                                // Error 4: UDP checksum
                                udp_checksum_ok = 1'b0;
                                if ({bytes[26], bytes[27]} == 16'd0) begin
                                    udp_checksum_ok = 1'b1; // zero checksum accepted
                                end else begin
                                    // Pseudo-header
                                    udp_checksum_acc = 18'd0;
                                    // Source IP
                                    udp_checksum_acc = udp_checksum_acc + {2'b00, bytes[12], bytes[13]};
                                    udp_checksum_acc = udp_checksum_acc + {2'b00, bytes[14], bytes[15]};
                                    // Dest IP
                                    udp_checksum_acc = udp_checksum_acc + {2'b00, bytes[16], bytes[17]};
                                    udp_checksum_acc = udp_checksum_acc + {2'b00, bytes[18], bytes[19]};
                                    // Zero + protocol
                                    udp_checksum_acc = udp_checksum_acc + {2'b00, 8'd0, 8'd17};
                                    // UDP length
                                    udp_checksum_acc = udp_checksum_acc + {2'b00, bytes[24], bytes[25]};
                                    // UDP header and payload
                                    for (k = 10'd20; k < n; k = k + 2) begin
                                        if (k + 1 < n) begin
                                            udp_checksum_acc = udp_checksum_acc + {2'b00, bytes[k], bytes[k+1]};
                                        end else begin
                                            // Odd byte, pad with zero
                                            udp_checksum_acc = udp_checksum_acc + {2'b00, bytes[k], 8'd0};
                                        end
                                    end
                                    udp_checksum_ok = (fold16(udp_checksum_acc) == 16'hFFFF);
                                end
                                
                                if (!udp_checksum_ok) begin
                                    error_code = 4'd4;
                                end else begin
                                    // Error 5: Destination checks
                                    if ({bytes[16], bytes[17], bytes[18], bytes[19]} != 32'h0A000002) begin
                                        error_code = 4'd5;
                                    end else if ({bytes[22], bytes[23]} != 16'd9000) begin
                                        error_code = 4'd5;
                                    end else begin
                                        // All checks passed
                                        frame_valid = 1'b1;
                                    end
                                end
                            end
                        end
                    end
                end
                
                // Set status
                status_valid_reg <= 1'b1;
                status_error_reg <= error_code;
                
                if (frame_valid) begin
                    // Setup valid frame output
                    m_src_ip_reg <= {bytes[12], bytes[13], bytes[14], bytes[15]};
                    m_src_port_reg <= {bytes[20], bytes[21]};
                    m_dst_port_reg <= {bytes[22], bytes[23]};
                    m_payload_len_reg <= udp_payload_len16;
                    payload_len <= udp_payload_len16[9:0];
                    ptr <= 10'd28; // Start of UDP payload
                    state <= OUTPUT;
                end else begin
                    // Invalid frame - rearm immediately
                    state <= IDLE;
                end
            end
            
            OUTPUT: begin
                if (!m_valid_reg || m_ready) begin
                    m_data_reg <= bytes[ptr];
                    m_valid_reg <= 1'b1;
                    if (ptr == 10'd27 + payload_len) begin
                        m_last_reg <= 1'b1;
                        state <= OUTPUT_LAST;
                    end else begin
                        ptr <= ptr + 10'd1;
                    end
                end
            end
            
            OUTPUT_LAST: begin
                if (m_ready) begin
                    m_valid_reg <= 1'b0;
                    m_last_reg <= 1'b0;
                    state <= IDLE;
                end
            end
            
            default: state <= IDLE;
        endcase
    end
end

// Output assignments
assign s_ready = (state == IDLE) || (state == RECEIVE) || (state == DRAIN_OVERSIZE);
assign m_data = m_data_reg;
assign m_valid = m_valid_reg;
assign m_last = m_last_reg;
assign m_src_ip = m_src_ip_reg;
assign m_src_port = m_src_port_reg;
assign m_dst_port = m_dst_port_reg;
assign m_payload_len = m_payload_len_reg;
assign status_valid = status_valid_reg;
assign status_error = status_error_reg;

endmodule
