`timescale 1ns/1ps
`default_nettype none

module dma_write(
    input wire clk,
    input wire rst,
    input wire [15:0] desc_addr,
    input wire [15:0] desc_len,
    input wire [7:0] desc_tag,
    input wire desc_valid,
    output wire desc_ready,
    input wire [31:0] s_data,
    input wire [3:0] s_keep,
    input wire s_valid,
    output wire s_ready,
    input wire s_last,
    output wire [15:0] status_len,
    output wire [7:0] status_tag,
    output wire [3:0] status_error,
    output wire status_valid,
    output wire [3:0] m_axi_awid,
    output wire [15:0] m_axi_awaddr,
    output wire [7:0] m_axi_awlen,
    output wire [2:0] m_axi_awsize,
    output wire [1:0] m_axi_awburst,
    output wire m_axi_awlock,
    output wire [3:0] m_axi_awcache,
    output wire [2:0] m_axi_awprot,
    output wire m_axi_awvalid,
    input wire m_axi_awready,
    output wire [31:0] m_axi_wdata,
    output wire [3:0] m_axi_wstrb,
    output wire m_axi_wlast,
    output wire m_axi_wvalid,
    input wire m_axi_wready,
    input wire [3:0] m_axi_bid,
    input wire [1:0] m_axi_bresp,
    input wire m_axi_bvalid,
    output wire m_axi_bready
);

    // Constants
    localparam AXI_AWBURST_INCR = 2'b01;
    localparam AXI_AWSIZE_FULL = 3'b010;
    localparam AXI_AWLOCK_NORMAL = 1'b0;
    localparam AXI_AWCACHE_MEM = 4'b0011;
    localparam AXI_AWPROT_DEFAULT = 3'b000;
    localparam AXI_AWID_DEFAULT = 4'd0;
    
    localparam MAX_BURST_BEATS = 16;
    localparam PAGE_SIZE = 4096;
    
    localparam ERROR_NONE = 4'd0;
    localparam ERROR_SLVERR = 4'd6;
    localparam ERROR_DECERR = 4'd7;
    
    // State machine
    localparam IDLE = 3'd0;
    localparam ISSUE_AW = 3'd1;
    localparam WRITE_DATA = 3'd2;
    localparam WAIT_B = 3'd3;
    localparam DONE = 3'd4;
    
    reg [2:0] state;
    reg [15:0] addr_reg;
    reg [15:0] len_reg;
    reg [7:0] tag_reg;
    reg [15:0] bytes_left;
    reg [15:0] aw_addr;
    reg [7:0] aw_len;
    reg [7:0] aw_len_reg;
    reg [7:0] beat_cnt;
    reg [7:0] b_outstanding;
    reg [7:0] b_received;
    reg seen_slverr, seen_decerr;
    
    // Stream buffer
    reg [31:0] data_buf;
    reg [3:0] keep_buf;
    reg last_buf;
    reg buf_valid;
    
    // Output registers
    reg aw_valid_reg;
    reg w_valid_reg;
    reg w_last_reg;
    reg [31:0] w_data_reg;
    reg [3:0] w_strb_reg;
    reg b_ready_reg;
    reg status_valid_reg;
    reg [15:0] status_len_reg;
    reg [7:0] status_tag_reg;
    reg [3:0] status_error_reg;
    
    // Combinational signals
    wire [15:0] page_boundary;
    wire [15:0] bytes_to_page;
    wire [15:0] max_beats;
    wire [15:0] beats_this_burst;
    wire [15:0] bytes_this_burst;
    wire [15:0] first_beat_offset;
    
    // Page boundary calculation
    assign page_boundary = (aw_addr[15:12] + 1) << 12;
    assign bytes_to_page = page_boundary - aw_addr;
    
    // Max beats calculation
    assign max_beats = (bytes_left < bytes_to_page) ? 
                       ((bytes_left + 15) >> 4) : 
                       ((bytes_to_page + 15) >> 4);
    assign beats_this_burst = (max_beats > MAX_BURST_BEATS) ? 
                               MAX_BURST_BEATS : max_beats;
    assign bytes_this_burst = (beats_this_burst << 4) > bytes_left ? 
                               bytes_left : (beats_this_burst << 4);
    assign first_beat_offset = aw_addr[3:0];
    
    // Output assignments
    assign desc_ready = (state == IDLE) && !rst;
    assign s_ready = (state == WRITE_DATA) && !buf_valid && !rst;
    
    assign m_axi_awid = AXI_AWID_DEFAULT;
    assign m_axi_awaddr = aw_addr;
    assign m_axi_awlen = aw_len;
    assign m_axi_awsize = AXI_AWSIZE_FULL;
    assign m_axi_awburst = AXI_AWBURST_INCR;
    assign m_axi_awlock = AXI_AWLOCK_NORMAL;
    assign m_axi_awcache = AXI_AWCACHE_MEM;
    assign m_axi_awprot = AXI_AWPROT_DEFAULT;
    assign m_axi_awvalid = aw_valid_reg;
    
    assign m_axi_wdata = w_data_reg;
    assign m_axi_wstrb = w_strb_reg;
    assign m_axi_wlast = w_last_reg;
    assign m_axi_wvalid = w_valid_reg;
    
    assign m_axi_bready = b_ready_reg;
    
    assign status_len = status_len_reg;
    assign status_tag = status_tag_reg;
    assign status_error = status_error_reg;
    assign status_valid = status_valid_reg;
    
    // Sequential logic
    always @(posedge clk) begin
        if (rst) begin
            state <= IDLE;
            addr_reg <= 16'd0;
            len_reg <= 16'd0;
            tag_reg <= 8'd0;
            bytes_left <= 16'd0;
            aw_addr <= 16'd0;
            aw_len <= 8'd0;
            aw_len_reg <= 8'd0;
            beat_cnt <= 8'd0;
            b_outstanding <= 8'd0;
            b_received <= 8'd0;
            seen_slverr <= 1'b0;
            seen_decerr <= 1'b0;
            
            data_buf <= 32'd0;
            keep_buf <= 4'd0;
            last_buf <= 1'b0;
            buf_valid <= 1'b0;
            
            aw_valid_reg <= 1'b0;
            w_valid_reg <= 1'b0;
            w_last_reg <= 1'b0;
            w_data_reg <= 32'd0;
            w_strb_reg <= 4'd0;
            b_ready_reg <= 1'b1;
            status_valid_reg <= 1'b0;
            status_len_reg <= 16'd0;
            status_tag_reg <= 8'd0;
            status_error_reg <= ERROR_NONE;
        end else begin
            status_valid_reg <= 1'b0;
            
            case (state)
                IDLE: begin
                    if (desc_valid && desc_ready) begin
                        addr_reg <= desc_addr;
                        len_reg <= desc_len;
                        tag_reg <= desc_tag;
                        aw_addr <= desc_addr;
                        bytes_left <= desc_len;
                        seen_slverr <= 1'b0;
                        seen_decerr <= 1'b0;
                        b_outstanding <= 8'd0;
                        b_received <= 8'd0;
                        beat_cnt <= 8'd0;
                        state <= ISSUE_AW;
                    end
                end
                
                ISSUE_AW: begin
                    if (!aw_valid_reg) begin
                        aw_valid_reg <= 1'b1;
                        aw_len <= beats_this_burst[7:0] - 8'd1;
                        aw_len_reg <= beats_this_burst[7:0] - 8'd1;
                    end else if (m_axi_awready) begin
                        aw_valid_reg <= 1'b0;
                        b_outstanding <= b_outstanding + 8'd1;
                        state <= WRITE_DATA;
                    end
                end
                
                WRITE_DATA: begin
                    // Buffer stream data
                    if (s_valid && s_ready && !buf_valid && !w_valid_reg) begin
                        data_buf <= s_data;
                        keep_buf <= s_keep;
                        last_buf <= s_last;
                        buf_valid <= 1'b1;
                    end
                    
                    // Issue W beat
                    if (buf_valid && !w_valid_reg) begin
                        w_valid_reg <= 1'b1;
                        w_data_reg <= data_buf;
                        
                        // Calculate strobe with first-beat masking
                        if (beat_cnt == 8'd0) begin
                            case (first_beat_offset[3:0])
                                4'd0: w_strb_reg <= keep_buf;
                                4'd1: w_strb_reg <= {keep_buf[3:1], 1'b0};
                                4'd2: w_strb_reg <= {keep_buf[3:2], 2'b00};
                                4'd3: w_strb_reg <= {keep_buf[3], 3'b000};
                                default: w_strb_reg <= 4'b0000;
                            endcase
                        end else begin
                            w_strb_reg <= keep_buf;
                        end
                        
                        w_last_reg <= (beat_cnt == aw_len_reg);
                        buf_valid <= 1'b0;
                    end
                    
                    // W handshake
                    if (w_valid_reg && m_axi_wready) begin
                        w_valid_reg <= 1'b0;
                        w_last_reg <= 1'b0;
                        beat_cnt <= beat_cnt + 8'd1;
                        aw_addr <= aw_addr + 16'd4;
                        bytes_left <= bytes_left - 16'd4;
                        
                        if (w_last_reg) begin
                            beat_cnt <= 8'd0;
                            if (bytes_left <= 16'd4) begin
                                state <= WAIT_B;
                            end else begin
                                state <= ISSUE_AW;
                            end
                        end
                    end
                end
                
                WAIT_B: begin
                    if (m_axi_bvalid && m_axi_bready) begin
                        b_received <= b_received + 8'd1;
                        if (m_axi_bresp == 2'b10) seen_slverr <= 1'b1;
                        if (m_axi_bresp == 2'b11) seen_decerr <= 1'b1;
                        
                        if (b_received + 8'd1 == b_outstanding) begin
                            state <= DONE;
                        end
                    end
                end
                
                DONE: begin
                    status_valid_reg <= 1'b1;
                    status_len_reg <= len_reg;
                    status_tag_reg <= tag_reg;
                    if (seen_decerr) status_error_reg <= ERROR_DECERR;
                    else if (seen_slverr) status_error_reg <= ERROR_SLVERR;
                    else status_error_reg <= ERROR_NONE;
                    state <= IDLE;
                end
            endcase
        end
    end

endmodule
`default_nettype wire
