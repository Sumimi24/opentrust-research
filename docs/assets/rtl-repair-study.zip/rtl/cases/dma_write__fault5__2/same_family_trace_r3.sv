`timescale 1ns/1ps
`default_nettype none

module dma_write(
    input wire clk,
    input wire rst,
    input wire [15:0] desc_addr,
    input wire [15:0] desc_len,
    input wire [7:0] desc_tag,
    input wire desc_valid,
    output reg desc_ready,
    input wire [31:0] s_data,
    input wire [3:0] s_keep,
    input wire s_valid,
    output reg s_ready,
    input wire s_last,
    output reg [15:0] status_len,
    output reg [7:0] status_tag,
    output reg [3:0] status_error,
    output reg status_valid,
    output wire [3:0] m_axi_awid,
    output reg [15:0] m_axi_awaddr,
    output reg [7:0] m_axi_awlen,
    output wire [2:0] m_axi_awsize,
    output wire [1:0] m_axi_awburst,
    output wire m_axi_awlock,
    output wire [3:0] m_axi_awcache,
    output wire [2:0] m_axi_awprot,
    output reg m_axi_awvalid,
    input wire m_axi_awready,
    output reg [31:0] m_axi_wdata,
    output reg [3:0] m_axi_wstrb,
    output reg m_axi_wlast,
    output reg m_axi_wvalid,
    input wire m_axi_wready,
    input wire [3:0] m_axi_bid,
    input wire [1:0] m_axi_bresp,
    input wire m_axi_bvalid,
    output reg m_axi_bready
);

    localparam MAX_BURST_BEATS = 16;
    localparam PAGE_SIZE = 4096;
    localparam BYTES_PER_BEAT = 4;

    typedef enum reg [2:0] {
        IDLE,
        ACCEPT,
        STREAM,
        DONE
    } state_t;

    reg [2:0] state, state_next;

    reg [15:0] desc_addr_r;
    reg [15:0] desc_len_r;
    reg [7:0] desc_tag_r;
    reg [15:0] bytes_left;
    reg error_slverr;
    reg error_decerr;

    reg [15:0] burst_start_addr;
    reg [15:0] burst_bytes;
    reg [7:0] burst_beats;
    reg [7:0] burst_beat_cnt;
    reg [15:0] burst_waddr;
    reg [7:0] pending_aw, pending_b;
    reg aw_issued, w_active;
    reg [31:0] held_wdata;
    reg [3:0] held_wstrb;
    reg held_wlast;
    reg held_wvalid;

    wire desc_accepted;
    assign desc_accepted = (state == IDLE) && desc_valid;

    always @(posedge clk) begin
        if (rst) begin
            state <= IDLE;
            desc_ready <= 1'b0;
            s_ready <= 1'b0;
            status_valid <= 1'b0;
            status_len <= 16'd0;
            status_tag <= 8'd0;
            status_error <= 4'd0;
            m_axi_awvalid <= 1'b0;
            m_axi_awaddr <= 16'd0;
            m_axi_awlen <= 8'd0;
            m_axi_wvalid <= 1'b0;
            m_axi_wdata <= 32'd0;
            m_axi_wstrb <= 4'd0;
            m_axi_wlast <= 1'b0;
            m_axi_bready <= 1'b1;
            desc_addr_r <= 16'd0;
            desc_len_r <= 16'd0;
            desc_tag_r <= 8'd0;
            bytes_left <= 16'd0;
            error_slverr <= 1'b0;
            error_decerr <= 1'b0;
            burst_start_addr <= 16'd0;
            burst_bytes <= 16'd0;
            burst_beats <= 8'd0;
            burst_beat_cnt <= 8'd0;
            burst_waddr <= 16'd0;
            pending_aw <= 8'd0;
            pending_b <= 8'd0;
            aw_issued <= 1'b0;
            w_active <= 1'b0;
            held_wvalid <= 1'b0;
            held_wdata <= 32'd0;
            held_wstrb <= 4'd0;
            held_wlast <= 1'b0;
        end else begin
            case (state)
                IDLE: begin
                    s_ready <= 1'b0;
                    status_valid <= 1'b0;
                    m_axi_awvalid <= 1'b0;
                    m_axi_wvalid <= 1'b0;
                    m_axi_bready <= 1'b1;
                    aw_issued <= 1'b0;
                    w_active <= 1'b0;
                    held_wvalid <= 1'b0;
                    
                    desc_ready <= 1'b1;
                    if (desc_accepted) begin
                        desc_ready <= 1'b0;
                        desc_addr_r <= desc_addr;
                        desc_len_r <= desc_len;
                        desc_tag_r <= desc_tag;
                        bytes_left <= desc_len;
                        error_slverr <= 1'b0;
                        error_decerr <= 1'b0;
                        pending_aw <= 8'd0;
                        pending_b <= 8'd0;
                        burst_start_addr <= desc_addr;
                        burst_waddr <= desc_addr;
                        burst_beat_cnt <= 8'd0;
                        compute_burst(desc_addr, desc_len);
                        state <= ACCEPT;
                    end else begin
                        state <= IDLE;
                    end
                end

                ACCEPT: begin
                    s_ready <= 1'b0;
                    desc_ready <= 1'b0;
                    status_valid <= 1'b0;
                    m_axi_bready <= 1'b1;
                    
                    if (m_axi_awvalid && m_axi_awready) begin
                        m_axi_awvalid <= 1'b0;
                        aw_issued <= 1'b1;
                    end
                    
                    if (!aw_issued && !m_axi_awvalid) begin
                        m_axi_awvalid <= 1'b1;
                        m_axi_awaddr <= burst_waddr;
                        m_axi_awlen <= burst_beats - 8'd1;
                        pending_aw <= pending_aw + 8'd1;
                    end
                    
                    if (aw_issued || (m_axi_awvalid && m_axi_awready)) begin
                        state <= STREAM;
                        s_ready <= 1'b1;
                        w_active <= 1'b1;
                    end
                end

                STREAM: begin
                    status_valid <= 1'b0;
                    m_axi_bready <= 1'b1;
                    
                    if (!m_axi_wvalid || (m_axi_wvalid && m_axi_wready)) begin
                        if (s_valid && s_ready) begin
                            held_wvalid <= 1'b1;
                            held_wdata <= s_data;
                            held_wstrb <= (burst_beat_cnt == 0) ? 
                                        mask_first_strb(burst_start_addr, s_keep) : s_keep;
                            held_wlast <= (burst_beat_cnt == (burst_beats - 1)) || s_last;
                            
                            if (held_wvalid && m_axi_wready) begin
                            end else begin
                                s_ready <= 1'b0;
                            end
                            
                            if (burst_beat_cnt == (burst_beats - 1)) begin
                                burst_beat_cnt <= 8'd0;
                                bytes_left <= bytes_left - burst_bytes;
                            end else begin
                                burst_beat_cnt <= burst_beat_cnt + 8'd1;
                            end
                            
                            if (s_last || burst_beat_cnt == (burst_beats - 1)) begin
                                if (bytes_left == burst_bytes) begin
                                    state <= DONE;
                                    aw_issued <= 1'b0;
                                    w_active <= 1'b0;
                                end else begin
                                    burst_start_addr <= burst_start_addr + burst_bytes;
                                    burst_waddr <= burst_start_addr + burst_bytes;
                                    compute_burst(burst_start_addr + burst_bytes, bytes_left - burst_bytes);
                                    state <= ACCEPT;
                                    aw_issued <= 1'b0;
                                    w_active <= 1'b0;
                                end
                            end
                        end
                        
                        if (!m_axi_wvalid && held_wvalid) begin
                            m_axi_wvalid <= 1'b1;
                            m_axi_wdata <= held_wdata;
                            m_axi_wstrb <= held_wstrb;
                            m_axi_wlast <= held_wlast;
                            held_wvalid <= 1'b0;
                        end else if (m_axi_wvalid && m_axi_wready) begin
                            m_axi_wvalid <= 1'b0;
                            m_axi_wlast <= 1'b0;
                        end
                    end
                    
                    if (m_axi_bvalid && m_axi_bready) begin
                        pending_b <= pending_b + 8'd1;
                        if (m_axi_bresp == 2'b10) error_slverr <= 1'b1;
                        if (m_axi_bresp == 2'b11) error_decerr <= 1'b1;
                    end
                end

                DONE: begin
                    s_ready <= 1'b0;
                    desc_ready <= 1'b0;
                    m_axi_awvalid <= 1'b0;
                    m_axi_bready <= 1'b1;
                    held_wvalid <= 1'b0;
                    
                    if (m_axi_wvalid && m_axi_wready) begin
                        m_axi_wvalid <= 1'b0;
                        m_axi_wlast <= 1'b0;
                    end
                    
                    if (m_axi_bvalid && m_axi_bready) begin
                        pending_b <= pending_b + 8'd1;
                        if (m_axi_bresp == 2'b10) error_slverr <= 1'b1;
                        if (m_axi_bresp == 2'b11) error_decerr <= 1'b1;
                    end

                    if (pending_b == pending_aw) begin
                        status_valid <= 1'b1;
                        status_len <= desc_len_r;
                        status_tag <= desc_tag_r;
                        if (error_decerr) status_error <= 4'd7;
                        else if (error_slverr) status_error <= 4'd6;
                        else status_error <= 4'd0;
                        state <= IDLE;
                    end
                end
            endcase
        end
    end

    assign m_axi_awid = 4'd0;
    assign m_axi_awsize = 3'b010;
    assign m_axi_awburst = 2'b01;
    assign m_axi_awlock = 1'b0;
    assign m_axi_awcache = 4'b0011;
    assign m_axi_awprot = 3'b000;

    task compute_burst(input [15:0] start_addr, input [15:0] remaining);
        reg [15:0] page_end;
        begin
            page_end = ((start_addr[15:12] + 1) << 12);
            burst_bytes = (page_end - start_addr < remaining) ? (page_end - start_addr) : remaining;
            burst_beats = (burst_bytes + BYTES_PER_BEAT - 1) >> 2;
            if (burst_beats > MAX_BURST_BEATS) begin
                burst_beats = MAX_BURST_BEATS;
                burst_bytes = MAX_BURST_BEATS * BYTES_PER_BEAT;
            end
        end
    endtask

    function [3:0] mask_first_strb(input [15:0] addr, input [3:0] orig_strb);
        case (addr[1:0])
            2'b00: mask_first_strb = orig_strb;
            2'b01: mask_first_strb = {1'b0, orig_strb[3:1]};
            2'b10: mask_first_strb = {2'b00, orig_strb[3:2]};
            2'b11: mask_first_strb = {3'b000, orig_strb[3]};
        endcase
    endfunction

endmodule
`default_nettype wire
