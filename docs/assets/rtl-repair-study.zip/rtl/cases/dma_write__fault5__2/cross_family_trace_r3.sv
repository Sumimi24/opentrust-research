`timescale 1ns/1ps
`default_nettype none

module dma_write(
input wire clk,
input wire rst,
input wire [15:0] desc_addr,
input wire [15:0] desc_len,
input wire [7:0] desc_tag,
input wire desc_valid,
output wire desc_ready,
input wire [31:0] s_data,
input wire [3:0] s_keep,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [15:0] status_len,
output wire [7:0] status_tag,
output wire [3:0] status_error,
output wire status_valid,
output wire [3:0] m_axi_awid,
output wire [15:0] m_axi_awaddr,
output wire [7:0] m_axi_awlen,
output wire [2:0] m_axi_awsize,
output wire [1:0] m_axi_awburst,
output wire m_axi_awlock,
output wire [3:0] m_axi_awcache,
output wire [2:0] m_axi_awprot,
output wire m_axi_awvalid,
input wire m_axi_awready,
output wire [31:0] m_axi_wdata,
output wire [3:0] m_axi_wstrb,
output wire m_axi_wlast,
output wire m_axi_wvalid,
input wire m_axi_wready,
input wire [3:0] m_axi_bid,
input wire [1:0] m_axi_bresp,
input wire m_axi_bvalid,
output wire m_axi_bready
);

localparam [3:0] ERR_NONE   = 4'd0;
localparam [3:0] ERR_SLVERR = 4'd6;
localparam [3:0] ERR_DECERR = 4'd7;

reg active_reg;

reg [15:0] desc_addr_reg;
reg [15:0] desc_len_reg;
reg [7:0]  desc_tag_reg;

reg [15:0] cur_addr_reg;
reg [15:0] bytes_remaining_reg;

reg [15:0] burst_addr_reg;
reg [7:0]  burst_beats_reg;
reg [15:0] burst_bytes_reg;

reg aw_valid_reg;
reg [15:0] aw_addr_reg;
reg [7:0]  aw_len_reg;

reg w_valid_reg;
reg [31:0] w_data_reg;
reg [3:0]  w_strb_reg;
reg w_last_reg;

reg [7:0] beats_sent_reg;
reg [15:0] bytes_sent_total_reg;
reg [15:0] bytes_sent_in_burst_reg;

reg [31:0] in_data_reg;
reg [3:0]  in_keep_reg;
reg in_last_reg;
reg in_valid_reg;

reg [7:0] b_pending_reg;
reg seen_slverr_reg;
reg seen_decerr_reg;

reg status_valid_reg;
reg [15:0] status_len_reg;
reg [7:0]  status_tag_reg;
reg [3:0]  status_error_reg;

wire [15:0] aligned_addr_w;
wire [11:0] page_off_w;
wire [15:0] bytes_to_4k_w;
wire [15:0] beats_4k_limit_w;
wire [15:0] beats_len_limit_w;
wire [15:0] beats_next_w;
wire [15:0] burst_bytes_next_w;

assign aligned_addr_w = {cur_addr_reg[15:2], 2'b00};
assign page_off_w = {aligned_addr_w[11:0]};
assign bytes_to_4k_w = 16'd4096 - {4'd0, page_off_w};
assign beats_4k_limit_w = bytes_to_4k_w >> 2;
assign beats_len_limit_w = (cur_addr_reg[1:0] + bytes_remaining_reg + 16'd3) >> 2;
assign beats_next_w = (beats_len_limit_w < beats_4k_limit_w) ? beats_len_limit_w : beats_4k_limit_w;
assign burst_bytes_next_w = (beats_next_w << 2);

wire aw_fire = m_axi_awvalid && m_axi_awready;
wire w_fire = m_axi_wvalid && m_axi_wready;
wire b_fire = m_axi_bvalid && m_axi_bready;

wire idle_for_new_burst = active_reg && !aw_valid_reg && (burst_beats_reg == 0) && !w_valid_reg && !in_valid_reg && (bytes_remaining_reg != 0);

assign desc_ready = !rst && !active_reg;

assign s_ready = !rst && active_reg && (burst_beats_reg != 0) && !in_valid_reg && !w_valid_reg;

assign status_len = status_len_reg;
assign status_tag = status_tag_reg;
assign status_error = status_error_reg;
assign status_valid = status_valid_reg;

assign m_axi_awid = 4'd0;
assign m_axi_awaddr = aw_addr_reg;
assign m_axi_awlen = aw_len_reg;
assign m_axi_awsize = 3'd2;
assign m_axi_awburst = 2'b01;
assign m_axi_awlock = 1'b0;
assign m_axi_awcache = 4'b0011;
assign m_axi_awprot = 3'b000;
assign m_axi_awvalid = aw_valid_reg;

assign m_axi_wdata = w_data_reg;
assign m_axi_wstrb = w_strb_reg;
assign m_axi_wlast = w_last_reg;
assign m_axi_wvalid = w_valid_reg;

assign m_axi_bready = 1'b1;

always @(posedge clk) begin
    if (rst) begin
        active_reg <= 1'b0;

        desc_addr_reg <= 16'd0;
        desc_len_reg <= 16'd0;
        desc_tag_reg <= 8'd0;

        cur_addr_reg <= 16'd0;
        bytes_remaining_reg <= 16'd0;

        burst_addr_reg <= 16'd0;
        burst_beats_reg <= 8'd0;
        burst_bytes_reg <= 16'd0;

        aw_valid_reg <= 1'b0;
        aw_addr_reg <= 16'd0;
        aw_len_reg <= 8'd0;

        w_valid_reg <= 1'b0;
        w_data_reg <= 32'd0;
        w_strb_reg <= 4'd0;
        w_last_reg <= 1'b0;

        beats_sent_reg <= 8'd0;
        bytes_sent_total_reg <= 16'd0;
        bytes_sent_in_burst_reg <= 16'd0;

        in_data_reg <= 32'd0;
        in_keep_reg <= 4'd0;
        in_last_reg <= 1'b0;
        in_valid_reg <= 1'b0;

        b_pending_reg <= 8'd0;
        seen_slverr_reg <= 1'b0;
        seen_decerr_reg <= 1'b0;

        status_valid_reg <= 1'b0;
        status_len_reg <= 16'd0;
        status_tag_reg <= 8'd0;
        status_error_reg <= ERR_NONE;
    end else begin
        status_valid_reg <= 1'b0;

        if (b_fire) begin
            if (b_pending_reg != 0) begin
                b_pending_reg <= b_pending_reg - 8'd1;
            end
            if (m_axi_bresp == 2'b10) begin
                seen_slverr_reg <= 1'b1;
            end
            if (m_axi_bresp == 2'b11) begin
                seen_decerr_reg <= 1'b1;
            end
        end

        if (desc_valid && desc_ready) begin
            active_reg <= 1'b1;

            desc_addr_reg <= desc_addr;
            desc_len_reg <= desc_len;
            desc_tag_reg <= desc_tag;

            cur_addr_reg <= desc_addr;
            bytes_remaining_reg <= desc_len;

            burst_addr_reg <= 16'd0;
            burst_beats_reg <= 8'd0;
            burst_bytes_reg <= 16'd0;

            aw_valid_reg <= 1'b0;
            aw_addr_reg <= 16'd0;
            aw_len_reg <= 8'd0;

            w_valid_reg <= 1'b0;
            w_data_reg <= 32'd0;
            w_strb_reg <= 4'd0;
            w_last_reg <= 1'b0;

            beats_sent_reg <= 8'd0;
            bytes_sent_total_reg <= 16'd0;
            bytes_sent_in_burst_reg <= 16'd0;

            in_data_reg <= 32'd0;
            in_keep_reg <= 4'd0;
            in_last_reg <= 1'b0;
            in_valid_reg <= 1'b0;

            b_pending_reg <= 8'd0;
            seen_slverr_reg <= 1'b0;
            seen_decerr_reg <= 1'b0;
        end else begin
            if (idle_for_new_burst) begin
                burst_addr_reg <= aligned_addr_w;
                burst_beats_reg <= (beats_next_w > 16'd16) ? 8'd16 : beats_next_w[7:0];
                burst_bytes_reg <= ((beats_next_w > 16'd16) ? 16'd64 : burst_bytes_next_w);
                aw_valid_reg <= 1'b1;
                aw_addr_reg <= aligned_addr_w;
                aw_len_reg <= (((beats_next_w > 16'd16) ? 16'd16 : beats_next_w) - 16'd1)[7:0];
                beats_sent_reg <= 8'd0;
                bytes_sent_in_burst_reg <= 16'd0;
            end

            if (aw_fire) begin
                aw_valid_reg <= 1'b0;
                b_pending_reg <= b_pending_reg + 8'd1;
            end

            if (s_valid && s_ready) begin
                in_data_reg <= s_data;
                in_keep_reg <= s_keep;
                in_last_reg <= s_last;
                in_valid_reg <= 1'b1;
            end

            if (!w_valid_reg && in_valid_reg) begin
                w_valid_reg <= 1'b1;
                w_data_reg <= in_data_reg;
                w_strb_reg <= in_keep_reg;
                w_last_reg <= (beats_sent_reg + 8'd1 == burst_beats_reg);
            end

            if (w_fire) begin
                w_valid_reg <= 1'b0;
                in_valid_reg <= 1'b0;

                beats_sent_reg <= beats_sent_reg + 8'd1;
                bytes_sent_in_burst_reg <= bytes_sent_in_burst_reg + 16'd4;

                cur_addr_reg <= cur_addr_reg + 16'd4;
                bytes_sent_total_reg <= bytes_sent_total_reg + 16'd4;

                if (bytes_remaining_reg > 16'd4) begin
                    bytes_remaining_reg <= bytes_remaining_reg - 16'd4;
                end else begin
                    bytes_remaining_reg <= 16'd0;
                end

                if (beats_sent_reg + 8'd1 == burst_beats_reg) begin
                    burst_beats_reg <= 8'd0;
                    burst_bytes_reg <= 16'd0;
                    beats_sent_reg <= 8'd0;
                    bytes_sent_in_burst_reg <= 16'd0;
                end
            end

            if (active_reg && (bytes_remaining_reg == 0) && !aw_valid_reg && (burst_beats_reg == 0) && !w_valid_reg && !in_valid_reg && (b_pending_reg == 0) && !status_valid_reg) begin
                active_reg <= 1'b0;
                status_valid_reg <= 1'b1;
                status_len_reg <= desc_len_reg;
                status_tag_reg <= desc_tag_reg;
                if (seen_decerr_reg) begin
                    status_error_reg <= ERR_DECERR;
                end else if (seen_slverr_reg) begin
                    status_error_reg <= ERR_SLVERR;
                end else begin
                    status_error_reg <= ERR_NONE;
                end
            end
        end
    end
end

endmodule
`default_nettype wire
