`timescale 1ns/1ps
`default_nettype none

module dma_write(
    input wire clk,
    input wire rst,
    input wire [15:0] desc_addr,
    input wire [15:0] desc_len,
    input wire [7:0] desc_tag,
    input wire desc_valid,
    output wire desc_ready,
    input wire [31:0] s_data,
    input wire [3:0] s_keep,
    input wire s_valid,
    output wire s_ready,
    input wire s_last,
    output wire [15:0] status_len,
    output wire [7:0] status_tag,
    output wire [3:0] status_error,
    output wire status_valid,
    output wire [3:0] m_axi_awid,
    output wire [15:0] m_axi_awaddr,
    output wire [7:0] m_axi_awlen,
    output wire [2:0] m_axi_awsize,
    output wire [1:0] m_axi_awburst,
    output wire m_axi_awlock,
    output wire [3:0] m_axi_awcache,
    output wire [2:0] m_axi_awprot,
    output wire m_axi_awvalid,
    input wire m_axi_awready,
    output wire [31:0] m_axi_wdata,
    output wire [3:0] m_axi_wstrb,
    output wire m_axi_wlast,
    output wire m_axi_wvalid,
    input wire m_axi_wready,
    input wire [3:0] m_axi_bid,
    input wire [1:0] m_axi_bresp,
    input wire m_axi_bvalid,
    output wire m_axi_bready
);

    // Constants
    localparam AXI_DATA_WIDTH = 32;
    localparam AXI_ADDR_WIDTH = 16;
    localparam AXI_STRB_WIDTH = 4;
    localparam AXI_ID_WIDTH = 4;
    localparam AXI_BURST_WIDTH = 8;
    localparam AXIS_DATA_WIDTH = 32;
    localparam AXIS_KEEP_WIDTH = 4;
    localparam LEN_WIDTH = 16;
    localparam TAG_WIDTH = 8;
    localparam ERROR_NONE = 4'd0;
    localparam ERROR_SLVERR = 4'd6;
    localparam ERROR_DECERR = 4'd7;
    
    // Fixed AXI parameters
    localparam AXI_AWBURST_INCR = 2'b01;
    localparam AXI_AWSIZE_FULL = 3'b010;
    localparam AXI_AWLOCK_NORMAL = 1'b0;
    localparam AXI_AWCACHE_MEM = 4'b0011;
    localparam AXI_AWPROT_DEFAULT = 3'b000;
    localparam AXI_AWID_DEFAULT = 4'd0;
    
    // Descriptor boundary
    localparam MAX_BURST_BEATS = 16;
    localparam PAGE_BOUNDARY = 4096;
    
    // Pipeline control
    reg active;
    reg [15:0] addr_reg;
    reg [15:0] len_reg;
    reg [7:0] tag_reg;
    reg [15:0] bytes_left;
    reg seen_slverr, seen_decerr;
    reg status_done;
    
    // Stream interface
    reg s_ready_int;
    reg [31:0] s_data_reg;
    reg [3:0] s_keep_reg;
    reg s_last_reg;
    reg s_valid_reg;
    reg stream_beat_valid;
    
    // AXI AW channel
    reg aw_valid;
    wire aw_hs;
    reg [15:0] aw_addr;
    reg [7:0] aw_len;
    
    // AXI W channel
    reg w_valid;
    wire w_hs;
    reg [31:0] w_data;
    reg [3:0] w_strb;
    reg w_last;
    reg [7:0] w_beat_counter;
    reg [7:0] w_burst_len;
    reg [15:0] w_bytes_in_burst;
    reg [15:0] w_burst_addr;
    
    // AXI B channel
    reg b_ready_int;
    reg [7:0] b_count;
    reg [7:0] b_total;
    
    // Status output
    reg status_valid_int;
    reg [15:0] status_len_reg;
    reg [7:0] status_tag_reg;
    reg [3:0] status_error_reg;
    
    // Internal wires
    wire desc_accepted;
    wire stream_beat_hs;
    wire [15:0] burst_boundary;
    wire [7:0] max_beats_in_burst;
    
    // Assignments
    assign desc_ready = !active && !rst;
    assign desc_accepted = desc_valid && desc_ready;
    
    assign s_ready = s_ready_int;
    assign stream_beat_hs = s_valid && s_ready_int;
    
    assign aw_hs = aw_valid && m_axi_awready;
    assign w_hs = w_valid && m_axi_wready;
    
    assign m_axi_awid = AXI_AWID_DEFAULT;
    assign m_axi_awaddr = aw_addr;
    assign m_axi_awlen = aw_len;
    assign m_axi_awsize = AXI_AWSIZE_FULL;
    assign m_axi_awburst = AXI_AWBURST_INCR;
    assign m_axi_awlock = AXI_AWLOCK_NORMAL;
    assign m_axi_awcache = AXI_AWCACHE_MEM;
    assign m_axi_awprot = AXI_AWPROT_DEFAULT;
    assign m_axi_awvalid = aw_valid;
    
    assign m_axi_wdata = w_data;
    assign m_axi_wstrb = w_strb;
    assign m_axi_wlast = w_last;
    assign m_axi_wvalid = w_valid;
    
    assign m_axi_bready = b_ready_int;
    
    assign status_len = status_len_reg;
    assign status_tag = status_tag_reg;
    assign status_error = status_error_reg;
    assign status_valid = status_valid_int;
    
    // Burst size calculation
    assign burst_boundary = (w_burst_addr[11:0] == 12'd0) ? PAGE_BOUNDARY : 
                           ((w_burst_addr[15:12] + 16'd1) << 12) - w_burst_addr;
    assign max_beats_in_burst = (bytes_left < burst_boundary) ? 
                               ((bytes_left + 8'd3) >> 4) : 
                               ((burst_boundary + 8'd3) >> 4);
    
    // Buffer stream data (register slice)
    always @(posedge clk) begin
        if (rst) begin
            s_data_reg <= 32'd0;
            s_keep_reg <= 4'd0;
            s_last_reg <= 1'b0;
            s_valid_reg <= 1'b0;
            stream_beat_valid <= 1'b0;
        end else begin
            if (stream_beat_hs && !w_valid) begin
                s_data_reg <= s_data;
                s_keep_reg <= s_keep;
                s_last_reg <= s_last;
                s_valid_reg <= 1'b1;
            end else if (w_hs) begin
                s_valid_reg <= 1'b0;
            end
            
            if (stream_beat_hs && w_valid) begin
                s_data_reg <= s_data;
                s_keep_reg <= s_keep;
                s_last_reg <= s_last;
                s_valid_reg <= 1'b1;
            end
        end
    end
    
    // Transfer valid to W channel
    always @(posedge clk) begin
        if (rst) begin
            stream_beat_valid <= 1'b0;
        end else begin
            if (stream_beat_hs && !w_valid) begin
                stream_beat_valid <= 1'b1;
            end else if (w_hs) begin
                stream_beat_valid <= 1'b0;
            end
            if (stream_beat_hs && w_valid) begin
                stream_beat_valid <= 1'b1;
            end
        end
    end
    
    // AXI write channel logic
    always @(posedge clk) begin
        if (rst) begin
            w_valid <= 1'b0;
            w_data <= 32'd0;
            w_strb <= 4'd0;
            w_last <= 1'b0;
            w_beat_counter <= 8'd0;
            w_burst_len <= 8'd0;
            w_bytes_in_burst <= 16'd0;
            w_burst_addr <= 16'd0;
            s_ready_int <= 1'b0;
            aw_valid <= 1'b0;
            aw_addr <= 16'd0;
            aw_len <= 8'd0;
        end else begin
            // Default
            s_ready_int <= 1'b0;
            
            // Accept new descriptor
            if (desc_accepted) begin
                aw_valid <= 1'b0;
                w_valid <= 1'b0;
                w_beat_counter <= 8'd0;
            end
            
            // Issue new AW burst
            if (active && !aw_valid && bytes_left > 0 && w_beat_counter == 8'd0 && w_bytes_in_burst == 16'd0) begin
                aw_valid <= 1'b1;
                aw_addr <= w_burst_addr;
                aw_len <= (max_beats_in_burst > 8'd16) ? 8'd15 : (max_beats_in_burst - 8'd1);
            end
            
            if (aw_hs) begin
                aw_valid <= 1'b0;
                w_burst_len <= aw_len + 8'd1;
                w_bytes_in_burst <= (aw_len + 8'd1) << 4;
            end
            
            // Stream to W data
            if (active && w_bytes_in_burst > 0 && (stream_beat_valid || s_valid) && !w_valid) begin
                s_ready_int <= 1'b1;
                if (s_valid && s_ready_int) begin
                    w_valid <= 1'b1;
                    w_data <= s_data;
                    w_strb <= s_keep;
                    w_beat_counter <= w_beat_counter + 8'd1;
                    
                    if (w_beat_counter == 8'd0) begin
                        // First beat: mask unaligned bytes
                        case (w_burst_addr[3:0])
                            4'd0: w_strb <= s_keep;
                            4'd1: w_strb <= {s_keep[3:1] & s_keep[3:1], 1'b0};
                            4'd2: w_strb <= {s_keep[3:2] & s_keep[3:2], 2'b00};
                            4'd3: w_strb <= {s_keep[3] & s_keep[3], 3'b000};
                            default: w_strb <= s_keep;
                        endcase
                    end
                    
                    // Check for last beat
                    if (w_beat_counter == w_burst_len || (s_last && w_beat_counter == w_burst_len - 8'd1)) begin
                        w_last <= 1'b1;
                        w_valid <= 1'b1;
                    end else begin
                        w_last <= 1'b0;
                    end
                end
            end
            
            // W handshake complete
            if (w_hs) begin
                w_valid <= 1'b0;
                w_last <= 1'b0;
                
                if (w_beat_counter == w_burst_len + 1) begin
                    // Burst complete
                    w_beat_counter <= 8'd0;
                    w_bytes_in_burst <= 16'd0;
                    w_burst_addr <= w_burst_addr + (w_burst_len[7:0] + 8'd1) * 4;
                end
            end
        end
    end
    
    // Descriptor and state control
    always @(posedge clk) begin
        if (rst) begin
            active <= 1'b0;
            addr_reg <= 16'd0;
            len_reg <= 16'd0;
            tag_reg <= 8'd0;
            bytes_left <= 16'd0;
            seen_slverr <= 1'b0;
            seen_decerr <= 1'b0;
            status_done <= 1'b0;
            w_burst_addr <= 16'd0;
            b_count <= 8'd0;
            b_total <= 8'd0;
        end else begin
            if (desc_accepted) begin
                active <= 1'b1;
                addr_reg <= desc_addr;
                len_reg <= desc_len;
                tag_reg <= desc_tag;
                bytes_left <= desc_len;
                w_burst_addr <= desc_addr;
                seen_slverr <= 1'b0;
                seen_decerr <= 1'b0;
                status_done <= 1'b0;
                b_count <= 8'd0;
                b_total <= 8'd0;
            end
            
            if (aw_hs) begin
                b_total <= b_total + 8'd1;
            end
            
            // Track bytes left
            if (w_hs && w_last) begin
                bytes_left <= 16'd0;
            end
            
            // B response tracking
            if (m_axi_bvalid && m_axi_bready) begin
                b_count <= b_count + 8'd1;
                if (m_axi_bresp == 2'b10) seen_slverr <= 1'b1;
                if (m_axi_bresp == 2'b11) seen_decerr <= 1'b1;
            end
            
            if (active && bytes_left == 16'd0 && b_count == b_total && b_total > 0) begin
                status_done <= 1'b1;
            end
            
            if (status_done && status_valid_int) begin
                active <= 1'b0;
                status_done <= 1'b0;
            end
        end
    end
    
    // B ready control
    always @(posedge clk) begin
        if (rst) begin
            b_ready_int <= 1'b1;
        end else begin
            b_ready_int <= 1'b1;
        end
    end
    
    // Status generation
    always @(posedge clk) begin
        if (rst) begin
            status_valid_int <= 1'b0;
            status_len_reg <= 16'd0;
            status_tag_reg <= 8'd0;
            status_error_reg <= ERROR_NONE;
        end else begin
            if (status_valid_int) begin
                status_valid_int <= 1'b0;
            end
            
            if (active && bytes_left == 16'd0 && b_count == b_total && b_total > 0 && !status_done) begin
                status_valid_int <= 1'b1;
                status_len_reg <= len_reg;
                status_tag_reg <= tag_reg;
                if (seen_decerr) status_error_reg <= ERROR_DECERR;
                else if (seen_slverr) status_error_reg <= ERROR_SLVERR;
                else status_error_reg <= ERROR_NONE;
            end
        end
    end
    
    // Write channel bytes tracking
    always @(posedge clk) begin
        if (rst) begin
            w_bytes_in_burst <= 16'd0;
        end else if (w_hs && w_last) begin
            w_bytes_in_burst <= 16'd0;
        end else if (aw_hs) begin
            // Will be set by combinational logic
        end
    end

endmodule
`default_nettype wire
