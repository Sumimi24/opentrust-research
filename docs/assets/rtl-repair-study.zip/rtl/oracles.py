"""Independent byte-level models; no RTL reference imports."""
import struct

def checksum(data):
    if len(data)%2:data+=b'\0'
    s=sum(struct.unpack('!'+str(len(data)//2)+'H',data))
    while s>>16:s=(s&65535)+(s>>16)
    return (~s)&65535

def checksum_incremental(data):
    s=0
    for i,b in enumerate(data):
        s+=b<<(8 if i%2==0 else 0)
        s=(s&65535)+(s>>16)
    return (~s)&65535

def packet(payload,src=0x0a000001,dst=0x0a000002,port=9000,zero=False):
    udp=struct.pack('!HHHH',1234,port,len(payload)+8,0)+payload
    pseudo=struct.pack('!IIBBH',src,dst,0,17,len(udp))
    c=checksum(pseudo+udp)
    udp=udp[:6]+struct.pack('!H',0 if zero else (c or 65535))+udp[8:]
    ip=struct.pack('!BBHHHBBHII',0x45,0,len(udp)+20,0x1234,0x4000,64,17,0,src,dst)
    ip=ip[:10]+struct.pack('!H',checksum(ip))+ip[12:]
    return ip+udp

def classify(p):
    n=len(p)
    if n<28 or n>512 or p[0]!=0x45 or p[9]!=17 or ((p[6]&63)|p[7]):return 1
    iplen=int.from_bytes(p[2:4],'big');udplen=int.from_bytes(p[24:26],'big')
    if iplen!=n or udplen!=iplen-20 or not 9<=udplen<=264:return 2
    if checksum_incremental(p[:20])!=0:return 3
    pseudo=p[12:20]+bytes([0,17])+p[24:26]
    if p[26:28]!=b'\0\0' and checksum_incremental(pseudo+p[20:])!=0:return 4
    if int.from_bytes(p[16:20],'big')!=0x0a000002 or int.from_bytes(p[22:24],'big')!=9000:return 5
    return 0

def memory_word(address,seed,epoch):
    return ((address*1103515245+seed*7919+epoch*0x13579b)&0xfffffffc)|3

def dma_expected(memory,address,payload):
    result=bytearray(memory);result[address:address+len(payload)]=payload
    alternate=bytearray(memory)
    for offset,value in enumerate(payload):alternate[address+offset]=value
    assert result==alternate
    return result
