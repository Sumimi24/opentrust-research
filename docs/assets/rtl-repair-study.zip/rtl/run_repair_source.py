"""Fresh, bounded three-call repair with same/cross-family paired continuations."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib,json,shlex,shutil,sys,threading,collections
BASE=Path(__file__).resolve().parent
sys.path.insert(0,r'C:/Users/10929/Documents/ChatGPT/VLA/opentrust_verified_engineering')
from subsystem_remote import connect,environment,ROOT as CORE,REMOTE as REMOTE_CORE
ROOT=CORE/'prospective_repair_v04_20261012';REMOTE=REMOTE_CORE+'/'+ROOT.name
sys.path.insert(0,str(CORE/'corrected_v03/dependencies'))
import api
MODELS=['gpt-5.4','qwen3.8-max','deepseek-v4-pro','kimi-k2.5']
SYSTEM='Repair the supplied open-source integration wrapper against the contract. Return only the complete synthesizable SystemVerilog module, exact name and ports. The pinned upstream core named in the code IS available unchanged at compile time. Do not reimplement or modify it. No testbench, file access, force/release/bind, includes, simulation system tasks, or preprocessor except timescale/default_nettype. $clog2/$bits/$signed/$unsigned/$countones are allowed. Keep the change focused; preserve correct behavior. Do not output markdown or explanation.'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def freeze():
    if (ROOT/'protocol.json').exists():return read(ROOT/'protocol.json')
    q=read(ROOT/'qualification_summary.json')
    assert len(q)==21 and all(x['pass_test'] if x['reference'] else x['functional_rejection'] for x in q)
    design=read(ROOT/'design.json');source=ROOT/'run_repair_source.py';shutil.copyfile(Path(__file__),source)
    files=[ROOT/n for n in ('cpu_grade.py','subsystem_tests.py','interfaces.json','oracles.py','faults.json','design.json','api_config.json','run_repair_source.py')]+list((ROOT/'tasks').glob('*/*'))
    p=dict(design,status='prospective_frozen_before_first_model_call',created_at=api.client.now(),sha256={f.relative_to(ROOT).as_posix():sha(f) for f in files},initial_cases=72,paired_route_rows=216,
        maximum_actual_calls=360,feedback='same development-only assertion/diagnostic and 12-event counterexample for both continuation routes',
        cross_schedule='next family in fixed GPT,Qwen,DeepSeek,Kimi cycle at call 2; following family at call 3',
        fixed_strong_control='GPT-initial same-family route is the fixed GPT three-call control on all 18 faults',
        no_transport_retry=True,reference_wrapper_not_given=True)
    save(ROOT/'protocol.json',p);return p

def main():
    p=freeze();assert sha(Path(__file__))==p['sha256']['run_repair_source.py']
    for name,digest in p['sha256'].items():assert sha(ROOT/name)==digest,name
    api.ROOT=ROOT;key=api.client.credential();c=connect();lock=threading.Lock();cache={};score_slots=threading.Semaphore(2)
    def invoke(model,messages,folder,tag):
        target=folder/(tag+'.json')
        if target.exists():return read(target)
        raw=folder/'api_attempts.jsonl';folder.mkdir(parents=True,exist_ok=True)
        assert not raw.exists() or tag not in {json.loads(x)['tag'] for x in raw.read_text(encoding='utf-8').splitlines()},'Unclosed request needs reconciliation'
        record=api.call(key,model,messages,16384,raw,tag);save(target,record);return record
    def code(record):
        text=record['text'].strip() if record['ok'] else ''
        if text.startswith('```') and text.endswith('```'):text=text.split('\n',1)[1].rsplit('```',1)[0].strip()
        return text+'\n'
    def score(task,source,stage):
        digest=sha(source);label=task+'_'+digest[:16]+'_'+stage
        with lock:local_lock=cache.setdefault(label,threading.Lock())
        with local_lock,score_slots:
            folder=ROOT/'scores'/label;target=folder/'score.json'
            if target.exists():return read(target)
            folder.mkdir(parents=True,exist_ok=True)
            remote_source=REMOTE+'/candidates/'+task+'_'+digest+'.sv'
            s=c.open_sftp()
            try:
                try:s.mkdir(REMOTE+'/candidates')
                except OSError:pass
                s.put(str(source),remote_source)
            finally:s.close()
            seeds=p['development_seeds'] if stage=='development' else p['independent_seeds']
            cmd=environment()+'nice -n 15 /usr/bin/prlimit --cpu=120 --as=4294967296 --fsize=134217728 -- python3 '+ROOT.name+'/cpu_grade.py '+task+' '+remote_source+' '+REMOTE+'/scores/'+label+' '+','.join(map(str,seeds))+' project'
            _,o,e=c.exec_command(cmd,timeout=600);log=o.read().decode()+e.read().decode();rc=o.channel.recv_exit_status();(folder/'simulation.log').write_text(log,encoding='utf-8')
            s=c.open_sftp();s.get(REMOTE+'/scores/'+label+'/score.json',str(target));s.close()
            result=read(target);assert result['source_sha256']==digest;result.update(stage=stage,returncode=rc);save(target,result)
            print(json.dumps(dict(task=task,stage=stage,passed=result['pass_test'],source=digest[:12])),flush=True);return result
    try:
        faults=read(ROOT/'faults.json');jobs=[dict(fault,producer=m,case=fault['id']+'__'+str(k)) for fault in faults for k,m in enumerate(MODELS)]
        def produce(job):
            contract=(ROOT/'tasks'/job['task']/'contract.txt').read_text(encoding='utf-8');broken=(ROOT/job['source']).read_text(encoding='utf-8');folder=ROOT/'cases'/job['case']
            record=invoke(job['producer'],[dict(role='system',content=SYSTEM),dict(role='user',content=contract+'\nBroken integration wrapper:\n'+broken)],folder,'initial')
            source=folder/'initial.sv';source.write_text(code(record),encoding='utf-8');return dict(job,source=source.relative_to(ROOT).as_posix(),status=record['status'])
        with ThreadPoolExecutor(max_workers=4) as pool:initial=list(pool.map(produce,jobs))
        save(ROOT/'initial.json',initial)
        with ThreadPoolExecutor(max_workers=2) as pool:initial_scores=list(pool.map(lambda j:score(j['task'],ROOT/j['source'],'development'),initial))
        branches=[]
        for job,s in zip(initial,initial_scores):
            for method in ('direct_patch','same_family_trace','cross_family_trace'):
                branches.append(dict(case=job['case'],fault=job['id'],task=job['task'],producer=job['producer'],method=method,source=job['source'],score=s,calls=1,history=[]))
        for round_number in (2,3):
            active=[b for b in branches if b['method']!='direct_patch' and not b['score']['pass_test']]
            def repair(b):
                current=b['score'];bad=[x for x in current['seed_results'] if not x['passed']]
                feedback=dict(status=current['status'],failures=bad)
                if any(x.get('error')=='compile_or_runtime_error' for x in bad):
                    log=(ROOT/'scores'/(b['task']+'_'+current['source_sha256'][:16]+'_development')/'simulation.log').read_text(encoding='utf-8')
                    feedback['compiler_diagnostics']='\n'.join(x for x in log.splitlines() if any(w in x.lower() for w in ('error:','syntax error','unsupported:')))[:6000]
                index=MODELS.index(b['producer']);model=b['producer'] if b['method']=='same_family_trace' else MODELS[(index+round_number-1)%len(MODELS)]
                contract=(ROOT/'tasks'/b['task']/'contract.txt').read_text(encoding='utf-8');candidate=(ROOT/b['source']).read_text(encoding='utf-8');tag=b['method']+'_r'+str(round_number)
                record=invoke(model,[dict(role='system',content=SYSTEM),dict(role='user',content=contract),dict(role='assistant',content=candidate),dict(role='user',content='Development feedback only:\n'+json.dumps(feedback)+'\nReturn a complete repair. Total route model call '+str(round_number)+' of maximum 3.')],ROOT/'cases'/b['case'],tag)
                source=ROOT/'cases'/b['case']/(tag+'.sv');source.write_text(code(record),encoding='utf-8');b.update(source=source.relative_to(ROOT).as_posix(),calls=round_number);b['history'].append(dict(round=round_number,model=model,api_status=record['status'],feedback=feedback))
                return b
            with ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(repair,active))
            with ThreadPoolExecutor(max_workers=2) as pool:values=list(pool.map(lambda b:score(b['task'],ROOT/b['source'],'development'),active))
            for b,s in zip(active,values):b['score']=s
            save(ROOT/('branches_round'+str(round_number)+'.json'),branches)
        selected=[dict(case=b['case'],fault=b['fault'],task=b['task'],producer=b['producer'],method=b['method'],source=b['source'],source_sha256=sha(ROOT/b['source']),development_pass=b['score']['pass_test'],calls=b['calls']) for b in branches]
        save(ROOT/'selection.json',dict(independent_feedback_used=False,rows=selected));save(ROOT/'selection_manifest.json',dict(sha256=sha(ROOT/'selection.json'),frozen_at=api.client.now()))
        with ThreadPoolExecutor(max_workers=2) as pool:final=list(pool.map(lambda b:score(b['task'],ROOT/b['source'],'independent'),selected))
        results=[dict(b,independent_pass=s['pass_test']) for b,s in zip(selected,final)];save(ROOT/'final_results.json',results)
        attempts=[json.loads(line) for path in (ROOT/'cases').glob('*/api_attempts.jsonl') for line in path.read_text(encoding='utf-8').splitlines()]
        assert len(attempts)==72+sum(b['calls']-1 for b in results if b['method']!='direct_patch')
        for name,digest in p['sha256'].items():assert sha(ROOT/name)==digest,name
        summary=dict(complete=True,initial_cases=72,distinct_injected_faults=18,base_contracts=3,route_rows=len(results),actual_calls=len(attempts),api_statuses=dict(collections.Counter(r['status'] for r in attempts)),methods={m:dict(n=72,independent_pass=sum(r['independent_pass'] for r in results if r['method']==m),correct_adoption=sum(r['development_pass'] and r['independent_pass'] for r in results if r['method']==m),false_adoption=sum(r['development_pass'] and not r['independent_pass'] for r in results if r['method']==m),logical_calls=sum(r['calls'] for r in results if r['method']==m)) for m in ('direct_patch','same_family_trace','cross_family_trace')},CPU_only=True,GPU_used=False)
        save(ROOT/'summary.json',summary);print(json.dumps(summary),flush=True)
    finally:c.close()

if __name__=='__main__':main()
