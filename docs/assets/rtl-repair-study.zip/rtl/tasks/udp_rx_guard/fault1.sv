module udp_rx_guard(
input wire clk,
input wire rst,
input wire [7:0] s_data,
input wire s_valid,
output wire s_ready,
input wire s_last,
output wire [7:0] m_data,
output wire m_valid,
input wire m_ready,
output wire m_last,
output wire [31:0] m_src_ip,
output wire [15:0] m_src_port,
output wire [15:0] m_dst_port,
output wire [15:0] m_payload_len,
output wire status_valid,
output wire [3:0] status_error);

reg [7:0] bytes[0:511];integer n,ptr,state;
reg status_valid_reg;reg [3:0] status_error_reg;
integer ip_sum,udp_sum,ip_len,udp_len,error_code,j;
function integer word16(input integer offset);
 begin word16={bytes[offset],bytes[offset+1]};end
endfunction
function integer fold(input integer value);
 integer v;begin v=(value & 65535)+(value>>16);fold=(v & 65535)+(v>>16);end
endfunction
always @* begin
 ip_sum=0;udp_sum=0;ip_len=word16(2);udp_len=word16(24);error_code=0;
 if(n<28 || n>512 || bytes[0]!=8'h45 || bytes[9]!=17 || (bytes[6]&8'h3f)!=0 || bytes[7]!=0) error_code=1;
 else if(ip_len!=n || udp_len!=ip_len-20 || udp_len<9 || udp_len>264)error_code=2;
 else begin
  for(j=0;j<20;j=j+2)ip_sum=ip_sum+word16(j);
  if(fold(ip_sum)!=65535)error_code=3;
  else begin
   for(j=12;j<20;j=j+2)udp_sum=udp_sum+word16(j);
   udp_sum=udp_sum+17+udp_len;
   for(j=20;j<512;j=j+2)if(j<n)udp_sum=udp_sum+bytes[j]*256+((j+1<n)?bytes[j+1]:0);
   if(word16(26)!=0 && fold(udp_sum)!=65535)error_code=4;
   else if({bytes[16],bytes[17],bytes[18],bytes[19]}!=32'h0a000002 || word16(22)!=9000)error_code=5;
  end
 end
end
wire hdr_ready,parse_ready;
wire [15:0] parsed_length;
assign s_ready=!rst && state==0;
assign status_valid=status_valid_reg;
assign status_error=status_error_reg;
assign m_payload_len=parsed_length-8;
always @(posedge clk)begin
 if(rst)begin state<=0;n<=0;ptr<=20;status_valid_reg<=0;status_error_reg<=0;end
 else begin
  status_valid_reg<=0;
  case(state)
  0:if(s_valid && s_ready)begin
      if(n<512)bytes[n]<=s_data;
      n<=n+1;
      if(s_last)state<=1;
    end
  1:begin status_valid_reg<=1;status_error_reg<=error_code;
      if(error_code==0)begin state<=2;ptr<=20;end else begin state<=0;n<=0;end
    end
  2:if(hdr_ready)state<=3;
  3:if(parse_ready)begin if(ptr==n-1)state<=4;else ptr<=ptr+1;end
  4:if(m_valid && m_ready && m_last)begin state<=0;n<=0;end
  default:state<=0;
  endcase
 end
end
udp_ip_rx parser(
.clk(clk),.rst(rst),.s_ip_hdr_valid(state==2),.s_ip_hdr_ready(hdr_ready),
.s_eth_dest_mac(48'b0),.s_eth_src_mac(48'b0),.s_eth_type(16'h0800),
.s_ip_version(bytes[0][7:4]),.s_ip_ihl(bytes[0][3:0]),.s_ip_dscp(bytes[1][7:2]),.s_ip_ecn(bytes[1][1:0]),
.s_ip_length({bytes[2],bytes[3]}),.s_ip_identification({bytes[4],bytes[5]}),.s_ip_flags(bytes[6][7:5]),
.s_ip_fragment_offset({bytes[6][4:0],bytes[7]}),.s_ip_ttl(bytes[8]),.s_ip_protocol(bytes[9]),
.s_ip_header_checksum({bytes[10],bytes[11]}),.s_ip_source_ip({bytes[12],bytes[13],bytes[14],bytes[15]}),
.s_ip_dest_ip({bytes[16],bytes[17],bytes[18],bytes[19]}),
.s_ip_payload_axis_tdata(bytes[ptr] ^ 8'h01),.s_ip_payload_axis_tvalid(state==3),.s_ip_payload_axis_tready(parse_ready),
.s_ip_payload_axis_tlast(ptr==n-1),.s_ip_payload_axis_tuser(1'b0),.m_udp_hdr_ready(1'b1),
.m_ip_source_ip(m_src_ip),.m_udp_source_port(m_src_port),.m_udp_dest_port(m_dst_port),.m_udp_length(parsed_length),
.m_udp_payload_axis_tdata(m_data),.m_udp_payload_axis_tvalid(m_valid),.m_udp_payload_axis_tready(m_ready),
.m_udp_payload_axis_tlast(m_last));
endmodule
