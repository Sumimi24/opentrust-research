import json,os,random,traceback
from pathlib import Path
import cocotb
from cocotb.triggers import Timer
from oracles import packet,classify,checksum,checksum_incremental,memory_word,dma_expected

class Bench:
    def __init__(self,d,task,seed):
        self.d=d;self.task=task;self.r=random.Random(seed);self.cycle=0;self.events=[]
        self.clock='clk_i' if task=='icache_ctrl' else 'clk'
        interfaces=json.loads((Path(__file__).parent/'interfaces.json').read_text())
        self.outputs=[n for n,w,direction in interfaces[task] if direction=='output']
        for n,w,direction in interfaces[task]:
            if direction=='input':getattr(d,n).value=0
    async def tick(self,**inputs):
        getattr(self.d,self.clock).value=0
        for name,value in inputs.items():getattr(self.d,name).value=value
        await Timer(5,units='ns')
        s={}
        for name in self.outputs:
            value=getattr(self.d,name).value;s[name]=int(value) if value.is_resolvable else -1
        getattr(self.d,self.clock).value=1
        await Timer(5,units='ns');self.cycle+=1
        self.events.append(dict(cycle=self.cycle,inputs=inputs,outputs=s))
        self.events=self.events[-12:]
        return s
    async def reset(self):
        name='rst_ni' if self.task=='icache_ctrl' else 'rst'
        for _ in range(4):await self.tick(**{name:0 if name=='rst_ni' else 1})
        await self.tick(**{name:1 if name=='rst_ni' else 0})

def stable(previous,s,valid,ready,fields,can_cancel=False):
    if previous is not None and not can_cancel:
        assert s[valid]==1 and all(s[f]==previous[f] for f in fields),f'hold_violation {valid}: {previous} -> {s}'
    return {f:s[f] for f in fields} if s[valid]==1 and not ready else None

async def dma(b,seed):
    r=b.r;data_rng=random.Random(seed^0x6d21);mem=bytearray([0xa5])*65536
    cases=[(0x100,1,0),(0x103,13,0),(4093,131,0),(0x1802,257,2),(0x2001,512,3),(0x4001,512,'mixed')]
    cases+=[(0x3000+data_rng.randrange(4),data_rng.randrange(1,513),0)]
    cases=[(address,length,response,bytes(data_rng.randrange(256) for _ in range(length)),data_rng.randrange(256)) for address,length,response in cases]
    for address,length,response,payload,tag in cases:
        expected=dma_expected(mem,address,payload)
        desc_pending=True;index=0;source=None;awq=[];wq=[];bq=[];completed=0
        awhold=whold=None;seen_status=0;last_status=False;writes=0
        for cycle in range(8192):
            if not desc_pending and source is None and index<length and (cycle%8==0 or r.random()<.65):
                chunk=payload[index:index+4];source=(int.from_bytes(chunk,'little'),(1<<len(chunk))-1,index+len(chunk)==length,len(chunk))
            ar=int(cycle%8==0 or r.random()<.65);wr=int(cycle%8==0 or r.random()<.65)
            bv=bool(bq and bq[0]<=cycle)
            s=await b.tick(desc_addr=address,desc_len=length,desc_tag=tag,desc_valid=int(desc_pending),s_data=source[0] if source else 0,s_keep=source[1] if source else 0,s_last=int(source[2]) if source else 0,s_valid=int(source is not None),m_axi_awready=ar,m_axi_wready=wr,m_axi_bid=0,m_axi_bresp=([3,2,0][completed%3] if response=='mixed' else response),m_axi_bvalid=int(bv))
            if desc_pending and s['desc_ready']==1:desc_pending=False
            if source and s['s_ready']==1:index+=source[3];source=None
            awfields=['m_axi_awid','m_axi_awaddr','m_axi_awlen','m_axi_awsize','m_axi_awburst','m_axi_awlock','m_axi_awcache','m_axi_awprot']
            awhold=stable(awhold,s,'m_axi_awvalid',ar,awfields)
            whold=stable(whold,s,'m_axi_wvalid',wr,['m_axi_wdata','m_axi_wstrb','m_axi_wlast'])
            if s['m_axi_awvalid']==1 and ar:
                addr=s['m_axi_awaddr'];beats=s['m_axi_awlen']+1
                assert 1<=beats<=16,'burst_length'
                assert (addr&4095)+beats*4-(addr&3)<=4096,'4k_boundary'
                assert [s[x] for x in awfields if x not in ('m_axi_awaddr','m_axi_awlen')]==[0,2,1,0,3,0],'AXI_attributes'
                awq.append([addr,beats,0])
            if s['m_axi_wvalid']==1 and wr:wq.append((s['m_axi_wdata'],s['m_axi_wstrb'],s['m_axi_wlast']))
            while awq and wq:
                a=awq[0];data,strb,last=wq.pop(0);addr=a[0]&~3;a[2]+=1
                assert last==int(a[2]==a[1]),'WLAST_position'
                for lane in range(4):
                    if strb>>lane&1:
                        p=addr+4*(a[2]-1)+lane
                        assert address<=p<address+length,'write_outside_descriptor'
                        mem[p]=(data>>(lane*8))&255;writes+=1
                if a[2]==a[1]:awq.pop(0);bq.append(cycle+r.randrange(1,13))
            if bv and s['m_axi_bready']==1:bq.pop(0);completed+=1
            assert not(last_status and s['status_valid']==1),'status_not_one_cycle'
            last_status=s['status_valid']==1
            if last_status:
                seen_status+=1
                assert not awq and not wq and not bq and index==length and not desc_pending,'premature_status'
                assert completed>=1 and writes==length,'missing_or_repeated_byte_writes'
                assert (s['status_len'],s['status_tag'],s['status_error'])==(length,tag,{0:0,2:6,3:7,'mixed':7}[response]),'status_fields'
                if mem!=expected:
                    bad=next(i for i in range(len(mem)) if mem[i]!=expected[i])
                    raise AssertionError(f'memory_bytes address={bad} expected={expected[bad]} actual={mem[bad]}')
                for _ in range(12):
                    t=await b.tick(desc_valid=0,s_valid=0,m_axi_bvalid=0,m_axi_awready=1,m_axi_wready=1)
                    assert t['status_valid']==0 and t['m_axi_awvalid']==0 and t['m_axi_wvalid']==0,'extra_activity_after_completion'
                break
        else:raise AssertionError('DMA_completion_timeout')
        assert seen_status==1
    # An in-flight descriptor and partial stream are cancelled at reset.
    for _ in range(8):await b.tick(desc_valid=1,desc_addr=0x5001,desc_len=40,desc_tag=2,s_valid=0,m_axi_awready=0,m_axi_wready=0,m_axi_bvalid=0)
    await b.reset()
    for _ in range(16):
        s=await b.tick(desc_valid=0,s_valid=0,m_axi_awready=1,m_axi_wready=1,m_axi_bvalid=0)
        assert not s['status_valid'] and not s['m_axi_awvalid'] and not s['m_axi_wvalid'],'reset_ghost'

def udp_cases(r):
    good=[packet(bytes(r.randrange(256) for _ in range(n)),zero=n==2) for n in (1,2,7,31,255,256)]
    bad=[]
    def change(p,offset,value):q=bytearray(p);q[offset]=value;return bytes(q)
    p=good[2]
    bad += [p[:12],p[:27],p+b'\0',change(p,0,0x46),change(p,6,0x20),change(p,9,6),change(p,2,1),change(p,24,1),change(p,10,p[10]^1),change(p,28,p[28]^1)]
    bad += [packet(b'abc',dst=0x0a000003),packet(b'abc',port=9001),packet(b'')]
    bad += [packet(bytes(257)),packet(bytes(490))]
    # Combined faults must obey classification priority, not arbitrary first detection.
    bad += [change(change(p,10,p[10]^1),28,p[28]^1),change(packet(b'abc',port=9001),28,9)]
    return good+bad

async def udp(b,seed):
    for p in udp_cases(b.r):
        wanted=classify(p);position=0;pending=None;out=[];statuses=[];hold=None;prev_status=False;last_seen=False;last_cycle=None;status_cycle=None;input_wait=0
        for cycle in range(32768):
            if pending is None and position<len(p) and (cycle%8==0 or b.r.random()<.65):pending=p[position]
            ready=int(cycle%8==0 or b.r.random()<.6)
            s=await b.tick(s_valid=int(pending is not None),s_data=pending or 0,s_last=int(position==len(p)-1),m_ready=ready)
            accepted_last=False
            input_wait=input_wait+1 if pending is not None and s['s_ready']!=1 else 0
            assert input_wait<=32,'input_accept_deadline'
            if pending is not None and s['s_ready']==1:
                position+=1;pending=None;accepted_last=position==len(p)
            # Pre-edge outputs cannot depend on the not-yet-accepted final byte.
            assert last_seen or (s['m_valid']==0 and s['status_valid']==0),'store_forward_leak'
            last_seen|=accepted_last
            if accepted_last:last_cycle=cycle
            if last_cycle is not None and not statuses:assert cycle-last_cycle<=1024,'status_deadline'
            if status_cycle is not None:assert cycle-status_cycle<=4096,'payload_deadline'
            hold=stable(hold,s,'m_valid',ready,['m_data','m_last','m_src_ip','m_src_port','m_dst_port','m_payload_len'])
            assert not(prev_status and s['status_valid']==1),'status_not_one_cycle'
            prev_status=s['status_valid']==1
            if prev_status:status_cycle=cycle;statuses.append(s['status_error']);assert statuses==[wanted],f'classification expected={wanted} actual={statuses}'
            if s['m_valid']==1:
                assert wanted==0,'rejected_frame_payload'
                assert (s['m_src_ip'],s['m_src_port'],s['m_dst_port'],s['m_payload_len'])==(int.from_bytes(p[12:16],'big'),1234,9000,len(p)-28),'metadata'
                if ready:
                    assert 0<=s['m_data']<=255,'payload_data_unknown'
                    out.append(s['m_data']);assert s['m_last']==int(len(out)==len(p)-28),'payload_last'
            done=statuses and (wanted!=0 or len(out)==len(p)-28)
            if done:
                assert wanted!=0 or bytes(out)==p[28:],'payload_bytes'
                for _ in range(16):
                    t=await b.tick(s_valid=0,m_ready=1)
                    assert t['m_valid']==0 and t['status_valid']==0,'extra_frame_output'
                break
        else:raise AssertionError('UDP_frame_timeout')
    # Partial packet reset, then another valid packet.
    p=packet(b'reset')
    for i in range(13):
        for _ in range(1024):
            s=await b.tick(s_data=p[i],s_valid=1,s_last=0,m_ready=0)
            if s['s_ready']==1:break
        else:raise AssertionError('reset_partial_input_timeout')
    await b.reset()
    for _ in range(24):
        s=await b.tick(s_valid=0,m_ready=1)
        assert s['m_valid']==0 and s['status_valid']==0,'reset_ghost'
    assert all(checksum(p)==checksum_incremental(p) for p in udp_cases(b.r))

async def cache(b,seed):
    pending=[];epoch=0;pc=0;consumed=0;hold=None;requests=[];error_at=None;post_error=False
    async def step(req=1,ready=None,branch=None,inval=0):
        nonlocal pc,consumed,hold,post_error
        cycle=b.cycle;ready=int(cycle%7==0 or b.r.random()<.65) if ready is None else ready
        grant=int(cycle%5==0 or b.r.random()<.7)
        response=pending[0] if pending and pending[0][0]<=cycle else None
        s=await b.tick(req_i=req,ready_i=ready,branch_i=int(branch is not None),addr_i=branch or 0,icache_inval_i=inval,instr_gnt_i=grant,instr_rvalid_i=int(response is not None),instr_rdata_i=response[2] if response else 0,instr_err_i=response[3] if response else 0)
        if branch is not None:pc=branch;hold=None;post_error=False
        else:
            hold=None if post_error else stable(hold,s,'valid_o',ready,['rdata_o','addr_o','err_o'])
            if s['valid_o']==1 and ready:
                assert s['addr_o']==pc,f'PC expected={pc:x} got={s["addr_o"]:x}'
                assert s['err_o']==int(pc==error_at),'instruction_error_flag'
                if pc!=error_at:assert s['rdata_o']==memory_word(pc,seed,epoch),f'instruction_data pc={pc:x}'
                post_error=bool(s['err_o']);pc+=4;consumed+=1
                if post_error:hold=None
        # For pre-edge outstanding requests, busy must remain asserted even on final response.
        if pending:assert s['busy_o']==1,'busy_missing_outstanding'
        if response:pending.pop(0)
        if s['instr_req_o']==1 and grant:
            address=s['instr_addr_o'];assert address>=0 and address%4==0,'memory_request_alignment'
            requests.append(address)
            pending.append((cycle+b.r.randrange(1,9),address,memory_word(address,seed,epoch),int(address==error_at)))
            assert len(pending)<=32,'too_many_outstanding'
        return s
    async def drain():
        nonlocal hold
        for _ in range(2048):
            s=await step(req=0,ready=0)
            if not pending and s['busy_o']==0:return
        raise AssertionError('cache_drain_timeout')
    async def fetch(address,count):
        nonlocal consumed,hold
        consumed=0;await step(branch=address,ready=0)
        idle_cycles=0
        while idle_cycles<2048:
            previous=consumed;await step()
            idle_cycles=0 if consumed>previous else idle_cycles+1
            if consumed>=count:return
        raise AssertionError('cache_fetch_timeout')
    await drain()
    await fetch(0x1000,8);await drain();start=len(requests)
    await fetch(0x1000,8)
    assert sum(0x1000<=x<0x1020 for x in requests[start:])<=1,'hot_region_miss'
    await drain();await fetch(0x1800,9);await drain()
    # Branch while several old responses are still outstanding, with output paused.
    await step(branch=0x2000,ready=0)
    for _ in range(4):await step(ready=0)
    await fetch(0x2400,12);await drain()
    epoch=1;await step(req=0,ready=0,inval=1);await drain()
    await fetch(0x1000,8);await drain()
    error_at=0x4020;await fetch(error_at,1);await drain()
    error_at=None;await fetch(0x5000,7);await drain()
    await step(branch=0x5800,ready=0)
    for _ in range(2048):
        s=await step(ready=0)
        if s['valid_o']==1:break
    else:raise AssertionError('cache_reset_setup_timeout')
    b.d.clk_i.value=0;await Timer(1,units='ns')
    b.d.rst_ni.value=0;await Timer(5,units='ns')
    assert int(b.d.valid_o.value)==0,'async_reset_output_not_cleared'
    pending.clear();hold=None;b.d.req_i.value=0;b.d.ready_i.value=0
    await b.reset();await drain();await fetch(0x6000,4);await drain()

@cocotb.test()
async def subsystem_contract(dut):
    task=os.environ['TEST_TASK'];seed=int(os.environ['TEST_SEED']);b=Bench(dut,task,seed)
    result=dict(task=task,seed=seed,passed=False,judge_version='corrected_v03')
    try:
        await b.reset()
        await {'dma_write':dma,'udp_rx_guard':udp,'icache_ctrl':cache}[task](b,seed)
        result['passed']=True
    except Exception as exc:
        result.update(error_type=type(exc).__name__,error=str(exc),counterexample=b.events)
        raise
    finally:
        result['cycles']=b.cycle
        Path(os.environ['TEST_RESULT']).write_text(json.dumps(result,indent=2))
