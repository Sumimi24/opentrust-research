"""Bounded requests with explicit attempts; never treat truncated text as usable."""
import json
from pathlib import Path
import sys
import threading
import time
import requests

ROOT = Path(__file__).resolve().parent
import client
LOCK = threading.Lock()


def classify(record):
    if record.get('response_parse_error'):
        return 'invalid_response'
    if record.get('error_type'):
        return 'transport_error'
    if record.get('http_status') != 200:
        return 'http_error'
    if record.get('finish_reason') == 'length':
        return 'truncated'
    if not record.get('text', '').strip():
        return 'empty_output'
    if record.get('finish_reason') != 'stop':
        return 'incomplete_finish'
    return 'complete'


def call(key, model, messages, limit, out, tag, role='producer'):
    config = json.loads((ROOT / 'api_config.json').read_text(encoding='utf-8'))
    payload = dict(model=model, messages=messages, max_completion_tokens=limit)
    payload.update(config['model_parameters'].get(model, {}))
    if role == 'review':
        payload.update(config['review_parameters'].get(model, {}))
    attempts = []
    for attempt in range(1, config['maximum_transport_attempts'] + 1):
        start = time.monotonic()
        record = dict(tag=tag, attempt=attempt, started_at=client.now(), request=payload,
                      timeout_seconds=config['timeout_seconds'])
        try:
            response = requests.post(client.BASE + '/chat/completions', json=payload,
                headers={'Authorization': 'Bearer ' + key},
                timeout=tuple(config['timeout_seconds']), allow_redirects=False)
            record['http_status'] = response.status_code
            if response.status_code == 200:
                body = response.json()
                choice = (body.get('choices') or [{}])[0]
                # Preserve the response metadata and final output, not private reasoning text.
                message = choice.get('message') or {}
                record.update(text=message.get('content') or '', finish_reason=choice.get('finish_reason'),
                    usage=body.get('usage'), reported_model=body.get('model'), response_id=body.get('id'),
                    reasoning_characters=len(message.get('reasoning_content') or ''))
            else:
                # Status is sufficient; don't retain potentially credential-echoing error pages.
                record['error_body_discarded'] = True
        except requests.exceptions.JSONDecodeError:
            record['response_parse_error'] = True
        except requests.RequestException as exc:
            record['error_type'] = type(exc).__name__
            # Names only: enough to distinguish proxy/connect/read failures without URLs/secrets.
            record['exception_chain_types'] = [type(x).__name__ for x in exc.args]
        except ValueError:
            record['response_parse_error'] = True
        record.update(finished_at=client.now(), elapsed_seconds=round(time.monotonic()-start, 3))
        record['status'] = classify(record)
        record['ok'] = record['status'] == 'complete'
        with LOCK:
            with out.open('a', encoding='utf-8') as stream:
                stream.write(json.dumps(record, ensure_ascii=False)+'\n')
        attempts.append(record)
        print(json.dumps(dict(tag=tag, model=model, attempt=attempt, status=record['status'],
                              seconds=record['elapsed_seconds'])), flush=True)
        # One recorded transport retry only; never retry truncation, HTTP errors or bad output.
        if record['status'] != 'transport_error' or attempt == config['maximum_transport_attempts']:
            break
    return dict(attempts[-1], attempts=len(attempts), first_attempt_status=attempts[0]['status'])
