"""IAIE research calls; credentials stay in Windows DPAPI, never in records."""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import threading
import time

import requests

HERE = Path(__file__).resolve().parent
BASE = 'https://www.iaiemas.com:20443/ias-openai-model/v1'
LOCK = threading.Lock()


def now():
    return datetime.now(timezone.utc).isoformat()


def credential():
    path = Path(os.environ['LOCALAPPDATA']) / 'OpenTrust/iaie_research_20261007.dpapi'
    command = "$ErrorActionPreference='Stop'; $s=Get-Content -Raw -LiteralPath '" + str(path) + "' | ConvertTo-SecureString; [System.Net.NetworkCredential]::new('', $s).Password"
    result = subprocess.run([shutil.which('pwsh'), '-NoProfile', '-NonInteractive', '-Command', command],
                            capture_output=True, text=True, check=True)
    key = result.stdout.strip()
    if not key.startswith('sk-') or len(key) < 32:
        raise ValueError('Credential decryption failed; no request sent')
    return key


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def call(key, model, messages, limit, out, tag):
    payload = {'model': model, 'messages': messages, 'max_completion_tokens': limit}
    start = time.monotonic()
    record = {'tag': tag, 'started_at': now(), 'request': payload}
    try:
        response = requests.post(BASE + '/chat/completions', json=payload,
                                 headers={'Authorization': 'Bearer ' + key},
                                 timeout=(20, 180), allow_redirects=False)
        record['http_status'] = response.status_code
        # Do not preserve an error page that might echo authentication headers.
        if response.status_code == 200:
            record['response'] = response.json()
            choice = record['response'].get('choices', [{}])[0]
            record['text'] = choice.get('message', {}).get('content') or ''
            record['finish_reason'] = choice.get('finish_reason')
            record['ok'] = bool(record['text'])
        else:
            record['ok'] = False
            record['error'] = re.sub(r'sk-[A-Za-z0-9_-]+', '[REDACTED]', response.text.replace(key, '[REDACTED]'))[:500]
    except requests.RequestException as exc:
        record['ok'] = False
        record['error'] = type(exc).__name__
    record['elapsed_seconds'] = round(time.monotonic() - start, 3)
    record['finished_at'] = now()
    with LOCK:
        with out.open('a', encoding='utf-8') as stream:
            stream.write(json.dumps(record, ensure_ascii=False) + '\n')
    return record


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['models', 'probe'])
    parser.add_argument('--model')
    args = parser.parse_args()
    key = credential()
    if args.action == 'models':
        response = requests.get(BASE + '/models', headers={'Authorization': 'Bearer ' + key},
                                timeout=(20, 60), allow_redirects=False)
        print('model_list_http_status', response.status_code)
        if response.status_code != 200:
            print(re.sub(r'sk-[A-Za-z0-9_-]+', '[REDACTED]', response.text.replace(key, '[REDACTED]'))[:300])
            return
        listing = response.json()
        save(HERE / 'model_catalog.json', {'fetched_at': now(), 'base_url': BASE, 'catalog': listing})
        ids = [m['id'] for m in listing.get('data', [])]
        print(json.dumps({'total': len(ids), 'relevant': [m for m in ids if any(s in m.lower() for s in ['gpt-5', 'gemini', 'qwen'])]}, ensure_ascii=False))
    else:
        record = call(key, args.model, [{'role': 'user', 'content': 'Compute 17 + 26. Reply with the integer only.'}],
                      256, HERE / 'probes.jsonl', 'connectivity')
        print(json.dumps({k: record.get(k) for k in ['ok', 'http_status', 'text', 'finish_reason', 'elapsed_seconds', 'error']}, ensure_ascii=False))
        if record.get('response'):
            print(json.dumps({k: record['response'].get(k) for k in ['model', 'usage', 'system_fingerprint']}))


if __name__ == '__main__':
    main()
