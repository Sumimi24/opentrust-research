"""Independent saved-data and truth audit; no model calls and no credentials needed."""
from pathlib import Path
import hashlib,importlib.util,json,re,sys
import protocol_tasks_corrected as fixed
BASE=Path(__file__).resolve().parent;ROOT=BASE/'protocol_formal'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    summary=read(ROOT/'completion.json');assert summary['complete']
    protocol=read(ROOT/'protocol.json')
    for path,digest in protocol['sha256'].items():assert sha(Path(path))==digest,path
    module_spec=importlib.util.spec_from_file_location('original_protocol_tasks',ROOT/'frozen_sources/protocol_tasks.py');original=importlib.util.module_from_spec(module_spec);module_spec.loader.exec_module(original)
    cases=read(ROOT/'cases.json');lookup={c['id']:c for c in cases}
    for c in cases:
        assert original.oracle(c['spec'],c['events'])==original.reference(c['spec'],c['events'])==c['truth']
        assert fixed.oracle(c['spec'],c['events'])==fixed.reference(c['spec'],c['events'])==c['truth']
    # Contract allows integer timestamps; verify negative starts and deadline equality too.
    boundary=[(dict(family='lease',capacity=2,max_ttl=2),[dict(t=-10,op='ACQUIRE',id='a',n=2,ttl=1),dict(t=-9,op='TICK')],True),
      (dict(family='lease',capacity=2,max_ttl=2),[dict(t=0,op='ACQUIRE',id='a',n=2,ttl=1),dict(t=1,op='USE',id='a')],False),
      (dict(family='request',capacity=2,max_bytes=2,chunk_bytes=2,timeout=1),[dict(t=-10,op='SUBMIT',id='a',n=1),dict(t=-10,op='ACCEPT',id='a'),dict(t=-9,op='DATA',id='a',seq=0,n=1),dict(t=-9,op='COMPLETE',id='a')],True),
      (dict(family='request',capacity=2,max_bytes=2,chunk_bytes=2,timeout=1),[dict(t=-10,op='SUBMIT',id='a',n=1),dict(t=-10,op='ACCEPT',id='a'),dict(t=-8,op='CANCEL',id='a')],False)]
    for spec,events,valid in boundary:assert fixed.oracle(spec,events)==fixed.reference(spec,events) and fixed.oracle(spec,events)['valid']==valid
    raw=[json.loads(x) for x in (ROOT/'api_attempts.jsonl').read_text(encoding='utf-8').splitlines()]
    assert len(raw)==4560==len({r['tag'] for r in raw})
    for r in raw:
        target=ROOT/'responses'/(r['tag']+'.json');response=read(target)
        assert all(response.get(k)==v for k,v in r.items())
        assert set(response)-set(r)=={'attempts','first_attempt_status'}
        assert response['attempts']==1 and response['first_attempt_status']==r['status']
        case_id=r['tag'].split('__',1)[0];c=lookup[case_id]
        problem=original.public_problem(c);messages=r['request']['messages'];review='__review__' in r['tag']
        assert messages[0]['content']==protocol['review_system' if review else 'analysis_system']
        if review:
            producer=r['tag'].split('__')[2]
            proposal=read(ROOT/'responses'/(case_id+'__produce__'+producer+'.json')).get('text','')
            assert messages[1]['content']==problem+'\nProposed analysis (untrusted):\n'+proposal
        else:assert messages[1]['content']==problem
        assert r['attempt']==1 and 'headers' not in r and 'Authorization' not in r
    assert len(read(ROOT/'production.json'))==960 and len(read(ROOT/'reviews.json'))==2880 and len(read(ROOT/'blind.json'))==720
    for row in read(ROOT/'production.json'):
        assert row['correct']==(row['answer']==lookup[row['case']]['truth'])
    for p in ROOT.rglob('*'):
        if p.is_file() and p.suffix in ('.json','.jsonl','.py','.csv'):
            assert not re.search(r'\bsk-[A-Za-z0-9_-]{40,}',p.read_text(encoding='utf-8',errors='replace')),p
    audit=dict(passed=True,original_truth_agreement_cases=len(cases),independent_recheck_cases=len(cases),
        negative_time_and_expiry_boundary_checks=len(boundary),api_response_bindings=len(raw),unique_call_tags=True,
        labels_not_present_in_requests=True,all_failures_retained=True,credential_scan=True,CPU_only=True,GPU_used=False,
        evaluator_revision='Initial-time and negative-deadline generalization corrected after collection; all 240 actual labels unchanged. Original frozen evaluator and execution schema fix preserved.',
        evaluator_source_sha256=sha(BASE/'protocol_tasks_corrected.py'))
    (ROOT/'delivery_audit.json').write_text(json.dumps(audit,indent=2)+'\n',encoding='utf-8');print(json.dumps(audit))

if __name__=='__main__':main()
